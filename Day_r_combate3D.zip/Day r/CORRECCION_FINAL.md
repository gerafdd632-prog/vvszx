﻿# Corrección técnica final — Pirate Survival

> Revisión estática + dos pasadas de revisión de compilación leyendo el código. **Unity no se ha ejecutado**.
> El código completo de cada archivo está en el zip (`Assets/_Project/Scripts/...`).

## AUDITORÍA PREVIA

| # | Problema | Confirmado / riesgo | Archivo | Sev. | Solución |
|---|---|---|---|---|---|
| 1 | El océano entero (PolygonCollider2D de ±40) era una `WaterSource` `IInteractable`: competía con palmeras, rocas y pickups de la costa | Confirmado | GameBootstrap.cs | Alta | OceanBorder solo lleva PolygonCollider2D + SeaZone; 4 puntos de orilla pequeños (trigger r=0,6) con WaterSource salada |
| 2 | Las confirmaciones no bloqueaban movimiento, E, inventario, zoom ni F5/F9; el Rigidbody seguía con velocidad | Confirmado | MenuManager.cs, GameInput.cs | Alta | `GameInput.ModalBlocked` (separado de `GameplayBlocked`, no toca GameState ni timeScale); `StopImmediately()` al abrir; ESC = Cancelar; una sola confirmación |
| 3 | Morir en combate pasaba a `Playing` con la pantalla de muerte encima | Confirmado | BattleManager.cs | Alta | `GameScreen.Dead`; `PlayerStats.Die` → Dead; BattleManager ya no decide el estado |
| 4 | Una lista de pickups vacía/ausente borraba los objetos iniciales al cargar un v1 | Confirmado | SaveManager.cs | Alta | `hasWorldPickupSnapshot`; sin foto se conservan los iniciales |
| 5 | El punto de aparición no se validaba | Confirmado | SaveManager.cs | Media | `SafePositionTracker.TryFindNearestSafePosition` (anillos acotados) + error claro |
| 6 | `WorldLimit = 33` fijo en SafePositionTracker | Confirmado | SafePositionTracker.cs | Media | `WorldBoundsProvider` estático configurable; sin configurar no bloquea (warning una vez) |
| 7 | `EquipTool` desequipaba antes de validar y aceptaba cualquier objeto/índice | Confirmado | InventoryManager.cs | Media | `bool EquipTool(...)` valida todo antes de tocar el equipo |
| 8 | Morir por quemadura contaba como "Combat" | Confirmado | StatusEffectSystem.cs | Baja | `DeathCause.Burning` solo para el daño periódico; impactos de fuego siguen siendo Combat |
| 9 | La munición se consumía sin comprobar el resultado (podía disparar gratis) | Confirmado | BattleManager.cs | Media | `TryConsumeAmmo` antes de gastar AP; si falla no hay ataque ni coste. Enemigos nunca usan el inventario |
| 10 | Heridas durante el desmayo sin regla | Confirmado | PlayerWounds.cs | Baja | x0,5 sangrado y veneno, aviso único al desmayarse, no se usan objetos desmayado |
| 11 | PlayerInteraction podía mostrar prompt/objetivo fuera de Playing o con modal | Confirmado | PlayerInteraction2D.cs | Media | Bloquea si `!IsPlaying` o `ModalBlocked`: limpia objetivo, prompt y holdTimer (la flecha se oculta) |
| 12 | PlayerStats simulaba supervivencia según el `deltaTime`, sin regla explícita de estado | Riesgo | PlayerStats.cs | Media | Solo simula en Playing; en combate solo el desgaste de BattleManager (sin doble consumo). Emisión de eventos intacta |
| 13 | Pickups cargados en el mar/dentro de una roca | Confirmado | SaveManager.cs | Media | Validación al aplicar: búsqueda cercana o junto al jugador, warning; no se pierde ninguno |
| 14 | Texto "dañado" en varios archivos | Riesgo (ver nota) | todos | Baja | Los .cs eran UTF-8 válido sin caracteres dañados. El problema era la lectura sin BOM: ahora todos llevan BOM UTF-8 |
| 15 | Abortar combate dejaba el estado a criterio de Close | Confirmado | BattleManager.cs | Media | `Close()` no cambia el estado; muerte → Dead (PlayerStats), carga → Playing (SaveManager/Menú), menú → MainMenu |

**Nota UTF-8:** busqué `Ã`, `Â`, `├`, `√`, `Ć`, `â€`; ningún archivo los contenía y todos se decodifican como UTF-8. Esos símbolos aparecen cuando un editor abre UTF-8 sin BOM como ANSI/Mac Roman. Añadí BOM a todos los `.cs` y `.md` (Unity y C# lo aceptan) sin tocar nombres, namespaces ni IDs.

**Política para guardados con salud 0:** el validador la sube a 1 con warning `[SaveData] health = 0 fuera de [1, 1000] → 1`. No es una resurrección silenciosa: queda registrada, y los guardados nunca se crean estando muerto (SaveGame lo rechaza).

## ARCHIVOS NUEVOS
- `Environment/WorldBoundsProvider.cs` — límites del mundo (`Configure`, `Contains`, `Clamp`, `IsConfigured`). Sin dependencias. Lo configuran GameBootstrap (y en el futuro World/).

## ARCHIVOS MODIFICADOS
- `Core/GameState.cs` — `GameScreen.Dead`.
- `Core/GameInput.cs` — `ModalBlocked`; los controles de exploración y F5/F9 se bloquean también con modal.
- `Player/SafePositionTracker.cs` — usa WorldBoundsProvider; `TryFindNearestSafePosition`.
- `Player/DeathCause.cs` — `Burning` + texto.
- `Player/PlayerStats.cs` — simulación solo en Playing; `Die` → `GameScreen.Dead`.
- `Player/PlayerWounds.cs` — multiplicadores de desmayo, aviso único, solo en Playing.
- `Player/PlayerController2D.cs` — velocidad 0 con modal.
- `Environment/Water/PlayerSwimming.cs` — `ResetState()`, solo en Playing.
- `Interaction/PlayerInteraction2D.cs` — bloqueo por estado y modal.
- `Inventory/InventoryManager.cs` — `bool EquipTool`; `UseItem` ignorado si muerto, desmayado o con modal.
- `Combat/BattleManager.cs` — muerte sin cambiar estado, `TryConsumeAmmo`, cambio de arma validado.
- `Combat/StatusEffectSystem.cs` — quemadura → `DeathCause.Burning`.
- `SaveSystem/SaveData.cs` — `hasWorldPickupSnapshot`.
- `SaveSystem/SaveDataValidator.cs` — v1 y lista nula → sin foto.
- `SaveSystem/SaveManager.cs` — foto de pickups, pickups validados, spawn validado, `RespawnPlayer` → Playing, carga desde Dead → Playing, guardado bloqueado en Dead/modal.
- `UI/MenuManager.cs` — modal real (una sola, ESC cancela, limpieza en OnDestroy y al morir), `IsConfirmOpen`, caso Dead.
- `UI/HUDManager.cs` — `IsDeathScreenVisible`.
- `Bootstrap/GameBootstrap.cs` — límites del mundo, océano sin WaterSource, puntos de orilla.
- `Editor/TechnicalAudit.cs` — nuevas comprobaciones (océano, WaterSource enorme, SeaZone interactuable, límites, spawn, Dead, modal, pickups importantes).
- Todos los `.cs`/`.md` — BOM UTF-8.

## REVISIÓN DE COMPILACIÓN (estática)
- **Namespaces/usings**: WorldBoundsProvider en `PirateSurvival.Environment` (usado por SafePositionTracker, GameBootstrap, TechnicalAudit, todos con el using).
- **EquipTool**: devuelve bool en todos los caminos; llamadas en `InventoryManager.UseItem`, `BattleManager.PlayerSwapWeapon` y `SaveManager.RestoreEquippedTool` revisadas.
- **GameScreen.Dead**: lo usan PlayerStats, SaveManager, MenuManager (switch con `break` en cada caso) y TechnicalAudit.
- **DeathCause.Burning**: StatusEffectSystem y DeathCauseText.
- **Eventos**: cada `+=` tiene su `-=` (comprobado por script; nuevo: `PlayerWounds` ↔ `OnPlayerFaint`).
- **Campos eliminados**: ninguna referencia a `SafePositionTracker.WorldLimit` ni `WaterSource.causesDrowning`.
- **Editor**: `UnityEditor` solo en `Editor/` (o bajo `#if UNITY_EDITOR`).
- ⚠️ Sin compilar en Unity.

## PLAN DE PRUEBAS
Errores que no deben aparecer: `NullReferenceException`, `MissingReferenceException`, errores rojos de compilación, `[GameBootstrap] Campo ... no encontrado`.

1. **Palmera junto a la costa** — Acércate a la palmera de (4.5, −1.5) por el lado del mar. *Esperado*: flecha y prompt de la palmera, nunca "beber agua de mar".
2. **Beber agua salada** — Ve al borde este (x≈8.5, y=0) y pulsa E. *Esperado*: prompt de agua de mar, −15 sed y −6 vida; en el centro de la isla no aparece ese prompt.
3. **Confirmación de Fruta + WASD + E** — Abre la confirmación y mantén WASD y E. *Esperado*: no te mueves, no hay prompts, no se repite la petición; Comer solo una vez.
4. **Cancelar** — Pulsa Cancelar o ESC. *Esperado*: vuelves a Playing con el inventario como estaba; la Fruta sigue en la casilla.
5. **Morir explorando** — Sube `hungerDecayRate` a 50 y `starvationDamage` a 20 en PlayerStats. *Esperado*: GameState Dead, mundo detenido (reloj parado), pantalla de muerte funcional; ESC no abre la pausa.
6. **Morir en combate** — Pierde contra los piratas. *Esperado*: el combate se cierra y el estado pasa de Battle a Dead sin pasar por Playing (pon un breakpoint en `GameState.Set`).
7. **Reaparecer** — *Esperado*: punto de aparición válido, estado Playing, velocidad 0, sin estado de natación.
8. **Cargar desde la pantalla de muerte** — Con guardado: carga y pasa a Playing. Sin guardado: el botón está desactivado. Con un guardado corrupto: sigues en Dead.
9. **Save v1 sin foto** — Edita un JSON: `"saveVersion": 1`, borra `worldPickups`. *Esperado*: warning de migración; siguen la Fruta, el pico, los cocos, la botella y la venda iniciales, sin duplicados.
10. **Save v2 con foto vacía** — Recoge todos los objetos, guarda y carga. *Esperado*: no reaparece ninguno.
11. **Arma válida** — Clic en el hacha. *Esperado*: se equipa.
12. **EquipTool con índice incorrecto** — Desde un script de prueba: `InventoryManager.Instance.EquipTool(hacha, 99)`. *Esperado*: devuelve false, warning y se mantiene el arma anterior.
13. **Una sola bala** — No hay armas de fuego para el jugador. Para probarlo, en Play Mode pon `ammoItemId = "piedra"`, `combatMinRange = 2` y `combatMaxRange = 5` al Pico desde el Inspector, con 1 piedra. *Esperado*: dispara una vez y gasta la piedra.
14. **Sin munición** — Mismo montaje sin piedras. *Esperado*: el botón Atacar no marca objetivos; si el inventario cambia entre la validación y el disparo, "¡Sin munición!", sin gastar AP.
15. **Muerte por quemadura** — Junto a un barril de pólvora con poca vida, déjate quemar. *Esperado*: "Las llamas han acabado contigo." si muere por la quemadura del turno.
16. **Desmayo con sangrado** — Sangrando tras un combate, provoca el desmayo (prueba 5 con sed). *Esperado*: aviso único "Sigues herido mientras estás inconsciente." y la vida baja a la mitad de ritmo.
17. **Posición inválida** — En el JSON pon `playerPosition` en (20, 0). *Esperado*: apareces en la última posición segura o en el punto de aparición.
18. **Spawn dentro de un collider** — Mueve `PlayerSpawnPoint` encima de una roca (5, 3.5) en Play Mode y reaparece. *Esperado*: error claro y aparición en un punto cercano válido.
19. **Inventario durante la confirmación** — Pulsa TAB/I con el diálogo abierto. *Esperado*: no se abre ni se cierra.
20. **Volver al menú varias veces** — Repítelo 5 veces y ejecuta Pirate Survival/Auditoría técnica. *Esperado*: sin duplicados de gestores, modal o estados; 0 errores.

## CHECKLIST

| Punto | Estado |
|---|---|
| Océano sin WaterSource; puntos de orilla | ✅ estática · ⚠️ ver prompts en Unity |
| Modal bloquea y restaura | ✅ estática · ⚠️ probar |
| GameScreen.Dead y transiciones | ✅ estática · ⚠️ probar |
| Foto de pickups v1/v2 | ✅ estática · ⚠️ probar con JSON reales |
| Spawn validado + búsqueda radial | ✅ estática · ⚠️ depende de colliders |
| WorldBoundsProvider | ✅ estática |
| EquipTool validado | ✅ estática |
| DeathCause.Burning | ✅ estática |
| Munición atómica | ✅ estática · ⚠️ sin arma de fuego del jugador para probarlo de forma natural |
| Heridas en desmayo | ✅ estática |
| PlayerInteraction por estado/modal | ✅ estática |
| PlayerStats solo en Playing | ✅ estática |
| Pickups cargados validados | ✅ estática |
| UTF-8 | ✅ verificado por script (BOM añadido) |
| Abort/Close coherente | ✅ estática |
| Auditoría técnica ampliada | ✅ estática |
| Compila en Unity | ⚠️ no ejecutado |

**Riesgos conocidos**
- `hasWorldPickupSnapshot` se inicializa a `true` para que los v2 anteriores a este campo se lean como "con foto". Si `JsonUtility` no respetara el inicializador, esos v2 antiguos conservarían los pickups iniciales (posibles objetos ya recogidos). Los v1 siempre se marcan sin foto por versión.
- Sin foto se conservan los pickups que haya en el mundo en ese momento: al cargar desde la pausa de una partida en curso, son los de esa partida, no los iniciales.
