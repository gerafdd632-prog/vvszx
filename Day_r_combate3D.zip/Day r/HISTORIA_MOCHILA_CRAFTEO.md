# Modo historia, diálogos, mochila, fabricación y espadas

Revisión estática solamente: no se ha compilado ni probado en Unity.

## Modo historia: Capítulo 1 · El náufrago del East Blue
Historia original ambientada en el mundo de One Piece. El objetivo actual sale arriba a la derecha, con una brújula que apunta hacia él y la distancia. En la mochila, la pestaña DIARIO muestra todo el capítulo.

1. Bebe agua dulce en la charca.
2. Habla con la Abuela Marea. Te da 2 vendas.
3. Ve a Aldea Coral y habla con la Alcaldesa Coral.
4. Habla con Tetsu el herrero. Te enseña a usar la forja.
5. Recoge fibra de los arbustos y fabrica una Cuerda.
6. Consigue 4 Mineral de Hierro en la Cueva del Eco. Hace falta el pico.
7. Forja un Sable, una Katana o una Nodachi en la forja.
8. Echa a los piratas de la playa este.
9. Vuelve con la alcaldesa. Te da agua y vendas, y desbloquea al jefe.
10. Derrota al Capitán Cuervo en el muelle. Recompensa: la espada legendaria Shiokaze y una recompensa de 5.000.000 berries sobre tu cabeza.
11. Habla con Bruno el pescador. Se une a tu tripulación y pelea contigo.
12. Fin del capítulo: rumbo al Grand Line.

Hasta el paso 9, el Capitán Cuervo te ignora y no hay combate. Los objetivos cumplidos se guardan en la partida (`storyFlags`).

## Diálogos
- Caja de pergamino con retrato, nombre en un tablón, texto letra a letra y hasta 4 respuestas.
- Controles:
  - [E], Espacio, Intro o clic: completar el texto o continuar.
  - [1]–[4] o clic: elegir respuesta.
  - [Esc]: salir.
- Hay 9 personajes, y lo que dicen cambia según el punto de la historia:
  - Abuela Marea
  - Alcaldesa Coral
  - Tetsu el herrero
  - Maese Tablón el carpintero
  - Lola la tabernera
  - Ramón el mercader
  - Tico
  - Bruno el pescador
  - Cabo Rocco, de la Marina
- Los diálogos pueden dar objetos, enseñar recetas, reclutar tripulantes y avanzar la historia.

## Mochila al estilo Day R
Se abre con [Tab] o [I] y tiene 4 pestañas:
- **MOCHILA**
  - Lo que llevas en la mano, con su estado y el botón Guardar.
  - Barras de vida, hambre, sed y energía.
  - Rejilla de 20 huecos con cantidad, barra de desgaste y marca "E" en lo equipado.
  - Barra de carga en kg.
  - Ficha del objeto: icono grande, tipo, descripción, estadísticas de combate, efectos y estado.
  - Botones: Comer/Beber/Usar, Equipar/Desequipar, Tirar 1 y Tirar todo.
  - Doble clic en un objeto: usarlo o equiparlo.
- **FABRICAR**
  - Categorías: Materiales, Herramientas, Espadas y Medicina.
  - Lista de recetas, con aviso de "¡Listo!" o del lugar necesario.
  - Lugar de cada receta: a mano, mesa de trabajo o forja.
  - Materiales que tienes y que te faltan, en verde y rojo.
  - Barra de tiempo y botón FABRICAR.
- **DIARIO**: capítulo, objetivos y tripulación.
- **SE BUSCA**: tu cartel de recompensa con retrato, VIVO O MUERTO y la cifra en berries. Al lado: Fruta del Diablo, Haki, experiencia y bandas derrotadas.

Toda la interfaz es de pergamino, marcos de madera con remaches dorados y botones de tablón.

## Fabricación
| Receta | Lugar | Materiales |
|---|---|---|
| Cuerda | a mano | 3 fibra |
| Tela de vela | mesa | 4 fibra |
| Lingote de hierro | forja | 2 mineral + 1 madera |
| Hacha | mesa | 2 madera + 2 piedra + 1 cuerda |
| Pico | mesa | 2 madera + 3 piedra + 1 cuerda |
| Espada de madera | a mano | 3 madera + 1 cuerda |
| Sable pirata | forja | 2 lingotes + 1 madera |
| Katana de acero | forja | 3 lingotes + 1 cuerda + 1 tela |
| Nodachi | forja | 5 lingotes + 2 cuerda + 2 madera |
| Daga de Kairoseki | forja | 2 kairoseki + 1 lingote + 1 cuerda |
| Vendas x2 | a mano | 1 tela |

Mesas de trabajo: en la carpintería de la aldea y en el campamento de la playa. Forja: en la herrería. Con [E] sobre una mesa o la forja se abre directamente la pestaña Fabricar. Las recetas de forja aparecen cuando Tetsu te enseña.

Nuevos materiales:
- **Fibra:** de los arbustos, con las manos.
- **Mineral de hierro:** de las vetas de la cueva, con pico. Cada veta tiene un 20 % de probabilidad de soltar además Kairoseki.

## Física (atascos)
- Los pies del jugador son más pequeños y sin fricción: resbala por paredes y esquinas.
- Si el jugador queda dentro de un objeto sólido, se le saca automáticamente.
- Si empujas más de 1,2 s contra algo sin avanzar, se le recoloca en el sitio libre más cercano.
- De las casas solo bloquea la pared: se puede pasar por detrás del tejado.

## Aldea Coral ampliada
- Taberna La Sirena Borracha, herrería con forja, carpintería con mesa de trabajo y puesto de la Marina con bandera y cañón.
- Casas, plaza con pozo y farolas, mercado, colmena y vallas.
