# Actualización v0.3 · Isla Coral

Base: `Day_r1_2.zip` (la versión que me pasaste). No compilado ni probado en Unity: revisión estática.

## Menús
- Menú principal nuevo: escena animada (cielo de atardecer, sol, nubes, isla lejana, mar en dos capas, barco meciéndose, gaviotas, viñeta).
- Botones de madera con animación al pasar el ratón y al pulsar (`ButtonFx`), paneles de madera oscura (`PirateTheme.DarkPanel`).
- Consejos aleatorios en el menú principal, partidas, opciones, confirmaciones y creador de personaje con el mismo estilo.
- Nombres aleatorios y aspecto por defecto originales.

## Bugs corregidos
- Combate: atajos con `Input` antiguo y sin bloqueo de pausa → `GameInput.IsBattleKeyPressed`.
- Combate: enemigos colocados sobre coberturas o encima de otros → `Grid.NearestWalkable`.
- Combate: sonidos duplicados, detección de crítico, paneles que bloqueaban clics, botín mal alineado, `stamina` → `Stamina`.
- Menús: título de partidas nulo (panel oculto) y etiquetas de botón en paneles ocultos → `GetComponentInChildren<Text>(true)`.
- Menús: la escena del título tapaba el juego al abrir una confirmación tras reanudar.
- Creador: subtítulo solapado con el título.
- Diálogos: Lola tenía 5 respuestas (máximo 4); retrato del jugador cacheado viejo; el tablón del nombre se animaba como botón.
- HUD: texto de temperatura nulo; emojis que la fuente no dibuja eliminados.
- Historia: pasos de la cueva cumplidos con el combate equivocado.
- Isla: menas de la cueva dentro de los combates; bucle pico/piedra (piedras sueltas en la playa y pico de madera fabricable).
- Fauna: los animales cinemáticos atravesaban muros; ahora se paran contra lo sólido.

## Isla
- Doble de grande (±44 unidades) con 5 zonas: Playa del Naufragio, Pueblo Portuario, Bosque Espeso, Colina del Faro y Guarida de Contrabandistas.
- Pueblo reordenado (ayuntamiento, taberna, herrería, carpintería, puesto marine, lonja, dique seco, almacén) sin solapes con caminos.
- Fauna con barra de vida y combate en el mapa (clic izquierdo o F): cangrejos en la playa, jabalíes en el bosque, ratas, arañas y murciélagos en la cueva.
- Herramienta: `Tools/island_designer/design.py` regenera el suelo, los sprites y `IslandPlacements.cs`.

## Pendiente
- Bloque 2: árboles de diálogo dinámicos, rumores, misiones secundarias, quitar lo moderno (p. ej. "Gafas de Sol (Modernas)").
- Bloque 3: frutas del diablo procedurales y crafteo naval, cocina y supervivencia.
- Bloque 4: campaña de 3 actos de la isla 1 y diseño de la isla 2.
