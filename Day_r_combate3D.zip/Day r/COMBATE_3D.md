# Combate 3D: versión mejorada

Base: `Day_r_Mejorado_2.zip`. Solo se ha tocado el combate 3D y lo que lo conecta con el mapa. No está compilado ni probado en Unity, solo revisado leyendo el código.

## Bugs que tenía y están arreglados

1. **El mapa 2D se veía detrás de la arena.** La arena estaba en el mismo sitio que la isla. Ahora se construye lejos, y durante el combate se apagan la cámara 2D y el HUD del mapa. Al terminar vuelven a encenderse.
2. **Bloqueo sin energía.** Si elegías un golpe sin energía, el menú desaparecía y no podías hacer nada. Ahora los golpes sin energía salen apagados y explican por qué.
3. **Botones que se duplicaban.** Los botones de los submenús se amontonaban unos encima de otros.
4. **Animaciones congeladas.** El combate congela `Time.timeScale`, pero la respiración, las palmeras y el mar usaban `Time.time`. Ahora todo funciona con un reloj propio.
5. **El mundo 2D se movía durante el combate.** El "hit-stop" cambiaba `Time.timeScale`. Ahora usa su propio reloj.
6. **Pausa.** Con ESC el combate seguía avanzando, y al reanudar el juego volvía a la exploración con la arena encima. Ahora se congela y vuelve al combate.
7. **Fuga de objetos.** Se creaba un material y un objeto nuevos por cada chispa. Ahora hay un sistema de partículas que reutiliza los objetos.
8. **Números de daño invisibles.** Usaban un `TextMesh` sin fuente. Ahora salen en la interfaz.
9. **Emojis y textos que la fuente no dibuja**, y el nombre y las técnicas de un personaje del anime. El jugador ahora usa su propio nombre y las técnicas tienen nombres originales.
10. **Combates repetidos al instante.** Al perder contra un animal o huir de él, el combate volvía a empezar en el mismo momento. Ahora hay 2,5 s de respiro y el jugador se aparta.
11. **Recompensas perdidas.** No se daba experiencia, el botín no se mostraba y los rivales eran inventados. Ahora se usan los rivales reales de cada encuentro, uno tras otro, y se dan la experiencia y el botín.
12. **Cargar partida en mitad del combate** dejaba la arena funcionando. Ahora se desmonta.
13. Las luces 3D no funcionan con el renderizador 2D de URP. La luz ahora viene calculada en los colores de los modelos (shaders propios en `Resources/Shaders`).

## Escenarios

- **Playa:** isla de arena con ring de cuerdas, mar con olas y espuma, palmeras que se mecen, antorchas con brasas, bandera pirata, barco fondeado, islas lejanas, sol y nubes.
- **Selva:** claro de tierra con árboles, helechos, rocas con musgo, tronco caído y setas.
- **Cueva:** bóveda de roca, estalagmitas y estalactitas, cristales que brillan, vía de mina con vagoneta, charca y antorchas.
- **Barco:** cubierta con mástiles y velas al viento, cañones, timón, barandillas y mar al atardecer.

Qué escenario sale:

| Combate | Escenario |
|---|---|
| Piratas de la playa, cangrejos | Playa |
| Jabalíes | Selva |
| Combates de cueva, arañas, murciélagos, ratas | Cueva |
| Capitán | Barco |

## Golpes

**LUCHAR:**

| Golpe | Qué hace |
|---|---|
| Golpe rápido | 2 golpes seguidos |
| Patada giratoria | Salto con giro |
| Cabezazo | Aturde, pero también te hace daño a ti |
| Embestida | Rompe la guardia del rival |
| Guardia | Recibes un 60 % menos de daño, recuperas energía y puedes contraatacar |

Con un arma equipada se añade un golpe según el arma:

- **Tajo** con espada: puede hacer sangrar.
- **Mazazo** con arma contundente: puede aturdir.
- **Disparo** con arma de fuego o tirachinas: gasta munición.

**FRUTA:** solo si has comido una fruta.

- **Puño catapulta:** el brazo se estira.
- **Lluvia de puños:** 8 golpes.
- **Martillo elástico:** el brazo sube al cielo y cae.
- **Haki de armadura:** +35 % de daño durante 3 turnos.

**MOCHILA:** comida, bebida y medicinas reales del inventario. Las curas quitan el veneno y el sangrado.

**HUIR:** cuantas menos vidas le quedan al rival, más fácil es. Contra el jefe no se puede.

## Rivales

Cada uno ataca a su manera:

| Rival | Ataque |
|---|---|
| Espadachín | Tajo |
| Tirador | Disparo |
| Jabalí | Embestida |
| Murciélago | Picado |
| Araña | Salto, o escupe veneno |
| Cangrejo | Pinza en zigzag |
| Fuego | Bola de fuego |

Además pueden:

- **Cargar un golpe brutal**, avisando un turno antes.
- **Cubrirse.**
- **Curarse una vez con ron** (solo el jefe).

Estados: sangrado, veneno, quemadura y aturdido.

## Controles

| Tecla | Acción |
|---|---|
| 1 a 6 | Elegir |
| Retroceso o clic derecho | Volver |
| Intro o Espacio | Pasar el texto o continuar |
| ESC | Pausa (el combate se congela) |
