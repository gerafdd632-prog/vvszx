"""Island designer: bakes ground PNG + pack-based sprites, writes Unity .meta files,
generates IslandPlacements.cs and a preview image.
Usage: python3 -I design.py <scratch> <unity_project_dir>
"""
import math, os, random, sys, uuid
import numpy as np
from PIL import Image, ImageDraw

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pixart as A

SCR = sys.argv[1]
PROJ = sys.argv[2]
OUT = os.path.join(PROJ, 'Resources', 'Sprites')
GEN_CS = os.path.join(PROJ, 'Scripts', 'Bootstrap', 'IslandPlacements.cs')
os.makedirs(OUT, exist_ok=True)

TOWN = os.path.join(SCR, 'town', 'Tiles')
DUNG = os.path.join(SCR, 'dungeon', 'Tiles')


def T(i):
    return Image.open(os.path.join(TOWN, f'tile_{i:04d}.png')).convert('RGBA')


def D(i):
    return Image.open(os.path.join(DUNG, f'tile_{i:04d}.png')).convert('RGBA')


def grid(rows, src=T):
    h = len(rows); w = max(len(r) for r in rows)
    im = Image.new('RGBA', (w * 16, h * 16), (0, 0, 0, 0))
    for y, r in enumerate(rows):
        for x, i in enumerate(r):
            if i is not None:
                im.alpha_composite(src(i), (x * 16, y * 16))
    return im


# ------------------------------------------------------------------ layout (MUST match IslandLayout.cs)
SPAWN = (0.0, -29.0)
POND = (-9.0, -21.0); POND_RX, POND_RY = 2.8, 1.9
VILLAGE = (14.0, 4.0); PLAZA_R = 3.4
CAVE = (-18.0, 12.0); CAVE_IN, CAVE_OUT = 5.8, 8.5; GAP_ANG, GAP_HALF = -45.0, 24.0
HILL = (-1.0, 20.0); HILL_IN, HILL_OUT = 5.0, 6.6; RAMP_ANG, RAMP_HALF = -60.0, 18.0
PIER_MIN_X, PIER_MAX_X, PIER_START_Y, PIER_END_Y = 16.6, 18.0, 23.5, 33.0
DEEP_MARGIN = 1.0; SHALLOW_W = 2.4
PATHS = [
    [(0, -27.5), (2, -20), (6, -10), (11.5, 0.8), VILLAGE],
    [(2, -20), (-5.6, -20.6)],
    [(6, -10), (-4, -6), (-9, -1), (-12, 4), (-13.2, 6.6), (-15, 8.9)],
    [VILLAGE, (16.3, 8.5), (18.4, 13.5), (17.6, 20), (17.3, 24)],
    [VILLAGE, (16.5, -4), (17.6, -12.5)],
    [VILLAGE, (8, 9), (3.5, 12.4), (1.9, 15), (0.5, 17.6)],
]
WORLD_MIN, WORLD_MAX = -46.0, 46.0
PPU = 16
SIZE = int((WORLD_MAX - WORLD_MIN) * PPU)  # 1472


def shore(a):
    return 30.5 + 2.9 * np.sin(3 * a + 0.8) + 1.9 * np.sin(5 * a + 2.1) + 1.0 * np.sin(8 * a + 0.3)


def vnoise_np(x, y, seed=0):
    xi = np.floor(x).astype(np.int64); yi = np.floor(y).astype(np.int64)
    xf = x - xi; yf = y - yi
    u = xf * xf * (3 - 2 * xf); v = yf * yf * (3 - 2 * yf)

    def h(ix, iy):
        hh = (ix * 374761393 + iy * 668265263 + seed * 2147483647) & 0xFFFFFFFF
        hh = ((hh ^ (hh >> 13)) * 1274126177) & 0xFFFFFFFF
        hh ^= hh >> 16
        return (hh & 0xFFFFFF) / 16777216.0
    a = h(xi, yi); b = h(xi + 1, yi); c = h(xi, yi + 1); d = h(xi + 1, yi + 1)
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v


def seg_dist(px, py, a, b):
    ax, ay = a; bx, by = b
    abx, aby = bx - ax, by - ay
    t = np.clip(((px - ax) * abx + (py - ay) * aby) / max(1e-4, abx * abx + aby * aby), 0, 1)
    return np.hypot(px - (ax + abx * t), py - (ay + aby * t))


def path_dist(px, py):
    best = np.full(np.shape(px), 1e9)
    for p in PATHS:
        for j in range(len(p) - 1):
            best = np.minimum(best, seg_dist(px, py, p[j], p[j + 1]))
    return best


DEEP, SHALLOW, WET, SAND, GRASS, PATH, PLAZA, ROCK, CAVEF, PONDT, PLATEAU = range(11)


def sample(px, py):
    px = np.asarray(px, dtype=np.float64); py = np.asarray(py, dtype=np.float64)
    d = np.hypot(px, py)
    r = shore(np.arctan2(py, px)) + (vnoise_np(px * 0.35 + 40, py * 0.35 + 40, 1) - 0.5) * 0.6
    off = d - r
    t = np.full(px.shape, GRASS, dtype=np.int8)
    pcx = (px - POND[0]) / POND_RX; pcy = (py - POND[1]) / POND_RY
    pk = pcx * pcx + pcy * pcy
    dc = np.hypot(px - CAVE[0], py - CAVE[1])
    rockn = (vnoise_np(px * 0.6 + 7, py * 0.6 + 3, 2) - 0.5) * 0.9
    ang = np.degrees(np.arctan2(py - CAVE[1], px - CAVE[0]))
    dang = np.abs((ang - GAP_ANG + 180) % 360 - 180)
    gap = dang < GAP_HALF
    sand_edge = -3.0 + (vnoise_np(px * 0.25, py * 0.25, 3) - 0.5) * 1.6
    pn = (vnoise_np(px * 0.8 + 11, py * 0.8, 4) - 0.5) * 0.35
    pd = path_dist(px, py)
    dv = np.hypot(px - VILLAGE[0], py - VILLAGE[1])
    # priority from lowest to highest (later overrides)
    t[pd < 0.8 + pn] = PATH
    t[dv < PLAZA_R] = PLAZA
    t[off > sand_edge] = SAND
    t[off > -0.7] = WET
    land = off <= 0
    t[land & (dc < CAVE_OUT + rockn) & ~gap] = ROCK
    t[land & (dc < CAVE_OUT + rockn) & gap] = CAVEF
    t[land & (dc < CAVE_IN)] = CAVEF
    dh = np.hypot(px - HILL[0], py - HILL[1])
    hang = np.degrees(np.arctan2(py - HILL[1], px - HILL[0]))
    ramp = np.abs((hang - RAMP_ANG + 180) % 360 - 180) < RAMP_HALF
    t[land & (dh < HILL_OUT + rockn * 0.5) & ~ramp] = ROCK
    t[land & (dh < HILL_OUT + rockn * 0.5) & ramp] = PATH
    t[land & (dh < HILL_IN)] = PLATEAU
    t[land & (dh < HILL_IN) & (pd < 0.7)] = PATH
    t[land & (pk < 1.35)] = WET
    t[land & (pk < 1)] = PONDT
    t[off > 0] = SHALLOW
    t[off > SHALLOW_W] = DEEP
    return t, off, dc


def shore_r(x, y):
    return float(shore(math.atan2(y, x)))


def is_land(x, y, margin=0.4):
    return math.hypot(x, y) < shore_r(x, y) - margin


# ------------------------------------------------------------------ ground bake
def bake_ground():
    xs = WORLD_MIN + (np.arange(SIZE) + 0.5) / PPU
    ys = WORLD_MIN + (np.arange(SIZE) + 0.5) / PPU
    X, Y = np.meshgrid(xs, ys)  # Y row 0 = bottom
    terr, off, dc = sample(X, Y)

    def arr(img):
        return np.asarray(img, dtype=np.float32)[::-1] / 255.0  # flip so row0 = bottom

    tex = {
        'grass': [arr(T(0)), arr(T(1)), arr(T(2))],
        'path': [arr(T(25)), arr(T(40)), arr(T(41))],
        'plaza': [arr(T(43))],
        'sand': [arr(D(48)), arr(D(49))],
        'cave': [arr(D(0))],
    }
    out = np.zeros((SIZE, SIZE, 4), dtype=np.float32)
    lx = (np.arange(SIZE) % 16)[None, :].repeat(SIZE, 0)
    ly = (np.arange(SIZE) % 16)[:, None].repeat(SIZE, 1)
    tx = (np.arange(SIZE) // 16)[None, :].repeat(SIZE, 0)
    ty = (np.arange(SIZE) // 16)[:, None].repeat(SIZE, 1)
    hv = ((tx * 73856093) ^ (ty * 19349663)) % 1000 / 1000.0

    def splat(mask, tiles, weights):
        idx = np.zeros(mask.shape, dtype=np.int64)
        acc = 0.0
        for k, w in enumerate(weights):
            idx[hv >= acc] = k
            acc += w
        for k, tile in enumerate(tiles):
            m = mask & (idx == k)
            out[m] = tile[ly[m], lx[m]]

    splat(terr == GRASS, tex['grass'], [0.0, 0.72, 0.97])
    splat(terr == PLATEAU, tex['grass'], [0.0, 0.72, 0.97])
    pl = terr == PLATEAU
    out[pl, :3] = np.clip(out[pl, :3] * np.array([1.06, 1.1, 0.95]), 0, 1)
    splat(terr == PATH, tex['path'], [0.0, 0.8, 0.9])
    splat(terr == PLAZA, tex['plaza'], [0.0])
    splat((terr == SAND) | (terr == WET), tex['sand'], [0.0, 0.75])
    splat(terr == CAVEF, tex['cave'], [0.0])
    cf = terr == CAVEF
    cn = vnoise_np(X * 1.5, Y * 1.5, 21) * 0.5 + vnoise_np(X * 7, Y * 7, 22) * 0.5
    out[cf, :3] *= (0.8 + 0.35 * cn[cf])[:, None]
    pebble = cf & (vnoise_np(X * 9, Y * 9, 23) > 0.86)
    out[pebble, :3] = out[pebble, :3] * 0.6 + np.array([0.45, 0.42, 0.45]) * 0.4
    wet = terr == WET
    out[wet, :3] *= 0.86
    # rock band: grey-blue stone with ridges and shading
    rk = terr == ROCK
    n = vnoise_np(X * 2.2, Y * 2.2, 9) * 0.6 + vnoise_np(X * 6, Y * 6, 10) * 0.4
    base = np.array([0.5, 0.53, 0.6])
    dhill = np.hypot(X - HILL[0], Y - HILL[1])
    near_hill = dhill < dc
    ring_d = np.where(near_hill, dhill, dc)
    ring_in = np.where(near_hill, HILL_IN, CAVE_IN); ring_out = np.where(near_hill, HILL_OUT, CAVE_OUT)
    ring_cy = np.where(near_hill, HILL[1], CAVE[1])
    mid = (ring_in + ring_out) / 2
    radial = (ring_d - mid) / ((ring_out - ring_in) / 2)
    ny = (Y - ring_cy) / np.maximum(ring_d, 1e-3)
    shade = 1.0 + 0.18 * ny * np.sign(radial) - 0.18 * np.abs(radial) + (n - 0.5) * 0.35
    crack = (np.abs(vnoise_np(X * 3, Y * 3, 12) - 0.5) < 0.03)
    col = base[None, None, :] * shade[..., None]
    col[crack] *= 0.65
    out[rk, :3] = np.clip(col[rk], 0, 1); out[rk, 3] = 1
    # pond water
    pdm = terr == PONDT
    pcx = (X - POND[0]) / POND_RX; pcy = (Y - POND[1]) / POND_RY
    pk = np.sqrt(pcx * pcx + pcy * pcy)
    pw = np.stack([0.18 + 0.15 * pk, 0.5 + 0.15 * pk, 0.78 + 0.08 * pk], -1)
    sparkle = (vnoise_np(X * 5, Y * 9, 13) > 0.82)
    pw[sparkle] = [0.75, 0.9, 1.0]
    out[pdm, :3] = pw[pdm]; out[pdm, 3] = 1
    # shallow water over sand
    sh = terr == SHALLOW
    tdepth = np.clip(off / SHALLOW_W, 0, 1)
    sandc = np.zeros_like(out)
    splat_mask = sh.copy()
    tmp = out.copy()
    out_backup = out
    # sand texture under the water
    for k, tile in enumerate(tex['sand'][:1]):
        sandc[splat_mask] = tile[ly[splat_mask], lx[splat_mask]]
    water = np.array([0.22, 0.62, 0.78])
    deep = np.array([0.11, 0.38, 0.62])
    wcol = water[None, None, :] * (1 - tdepth[..., None]) + deep[None, None, :] * tdepth[..., None]
    mixk = np.clip(0.45 + tdepth * 0.55, 0, 1)[..., None]
    shc = sandc[..., :3] * (1 - mixk) + wcol * mixk
    alpha = np.clip(1.0 - (tdepth - 0.55) / 0.45, 0, 1)
    out[sh, :3] = shc[sh]
    out[sh, 3] = alpha[sh]
    # foam line at the shore + ring
    wave = np.sin(np.arctan2(Y, X) * 40 + vnoise_np(X, Y, 14) * 6)
    foam = sh & (off < 0.22 + 0.06 * wave)
    out[foam] = [0.95, 0.98, 1.0, 1.0]
    foam2 = sh & (np.abs(off - (0.9 + 0.12 * wave)) < 0.05)
    out[foam2, :3] = out[foam2, :3] * 0.4 + 0.6
    # dark outline where path/plaza/cave/sand meets grass (Kenney-like edges)
    def edge(a_mask, b_mask, color, k=1):
        nb = np.zeros_like(b_mask)
        nb[1:, :] |= b_mask[:-1, :]; nb[:-1, :] |= b_mask[1:, :]
        nb[:, 1:] |= b_mask[:, :-1]; nb[:, :-1] |= b_mask[:, 1:]
        m = a_mask & nb
        out[m, :3] = out[m, :3] * (1 - k) + np.array(color) * k
    grass = terr == GRASS
    edge(terr == PATH, grass, [0.55, 0.36, 0.2], 0.55)
    edge(terr == PLAZA, grass, [0.4, 0.42, 0.45], 0.4)
    edge(grass, (terr == SAND), [0.25, 0.45, 0.22], 0.45)
    edge(rk, (terr == CAVEF) | grass | (terr == SAND) | pl | (terr == PATH), [0.16, 0.14, 0.18], 0.9)
    edge(terr == PONDT, terr == WET, [0.1, 0.25, 0.45], 0.6)
    img = Image.fromarray(np.clip(out[::-1] * 255 + 0.5, 0, 255).astype(np.uint8), 'RGBA')
    return img, terr


# ------------------------------------------------------------------ sprites (pack + procedural)
SPRITES = {}  # key -> (image, pivot)


def put(key, img, pivot=(0.5, 0.1)):
    SPRITES[key] = (img, pivot)


def recolor(img, mapping, tol=40):
    a = np.asarray(img).copy()
    for src, dst in mapping:
        s = np.array(src); d_ = np.array(dst)
        m = (np.abs(a[..., :3].astype(int) - s).sum(-1) < tol) & (a[..., 3] > 0)
        a[m, :3] = d_
    return Image.fromarray(a, 'RGBA')


def palette(img):
    a = np.asarray(img)
    cols = {}
    for p in a.reshape(-1, 4):
        if p[3] > 0:
            cols[tuple(p[:3])] = cols.get(tuple(p[:3]), 0) + 1
    return sorted(cols.items(), key=lambda kv: -kv[1])


def hue_map(img, fn):
    import colorsys
    a = np.asarray(img.convert('RGBA')).copy()
    for y in range(a.shape[0]):
        for x in range(a.shape[1]):
            r, g, b, al = a[y, x]
            if al == 0:
                continue
            h, sat, v = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
            res = fn(h, sat, v)
            if res is None:
                continue
            nr, ng, nb = colorsys.hsv_to_rgb(*res)
            a[y, x, :3] = (round(nr * 255), round(ng * 255), round(nb * 255))
    return Image.fromarray(a, 'RGBA')


def powder_barrel():
    b = hue_map(D(82), lambda h, sat, v: (0.0, max(sat, 0.55), v) if 0.03 < h < 0.15 else None)
    d = ImageDraw.Draw(b)
    d.rectangle([6, 6, 9, 8], fill=(240, 235, 220, 255))
    d.point([(7, 7)], fill=(30, 20, 20, 255))
    return b


def mast():
    c = A.Canvas(16, 22)
    c.shadow(8, 2, 6, 2, 0.3)
    c.rect(6, 1, 4, 21, A.WOOD_D); c.rect(7, 1, 1, 21, A.WOOD_L)
    c.rect(2, 15, 12, 2, A.WOOD)
    c.line(3, 15, 7, 3, (0.8, 0.75, 0.6)); c.line(13, 15, 9, 3, (0.8, 0.75, 0.6))
    c.outline()
    return c.image()


def fiber_icon():
    c = A.Canvas(16, 16)
    for i, x in enumerate((5, 7, 9, 11)):
        c.line(x, 2, x + (1 if i % 2 else -1), 13, A.LEAF if i % 2 else A.LEAF_D)
    c.rect(4, 6, 9, 2, (0.8, 0.7, 0.4))
    c.outline()
    return c.image()


def ore_icon():
    c = A.Canvas(16, 16)
    c.shaded(8, 7, 6, 5, (0.5, 0.45, 0.45), 0.3, 0.4)
    for x, y in ((6, 8), (9, 5), (10, 9)):
        c.rect(x, y, 2, 1, (0.75, 0.42, 0.25))
    c.outline()
    return c.image()


def ingot_icon():
    c = A.Canvas(16, 16)
    c.rect(2, 4, 12, 5, (0.62, 0.64, 0.7)); c.rect(4, 9, 8, 2, (0.8, 0.82, 0.88)); c.rect(2, 4, 12, 1, (0.4, 0.42, 0.48))
    c.outline()
    return c.image()


def rope_icon():
    c = A.Canvas(16, 16)
    col = (0.8, 0.66, 0.4)
    c.circle(8, 7, 5.5, col); c.circle(8, 7, 3.5, A.darken(col, 0.3)); c.circle(8, 7, 2, (0, 0, 0, 0))
    c.px[5:9, 6:10, 3] = 0
    c.line(12, 4, 14, 1, col)
    c.outline()
    return c.image()


def cloth_icon():
    c = A.Canvas(16, 16)
    col = (0.93, 0.9, 0.82)
    c.rect(2, 3, 12, 9, col); c.rect(2, 3, 12, 2, A.darken(col, 0.15)); c.rect(9, 3, 1, 9, A.darken(col, 0.12))
    c.outline()
    return c.image()


def kairo_icon():
    c = A.Canvas(16, 16)
    col = (0.45, 0.58, 0.68)
    for y in range(2, 14):
        half = 5 - abs(y - 8) // 2
        c.rect(8 - half, y, half * 2, 1, col)
    c.rect(6, 6, 2, 4, A.lighten(col, 0.4))
    c.outline()
    return c.image()


def lighthouse():
    c = A.Canvas(44, 104)
    c.shadow(22, 4, 18, 4, 0.3)
    stone = (0.55, 0.55, 0.6)
    c.rect(6, 2, 32, 12, stone)
    for x in range(6, 38, 5):
        c.rect(x, 2, 1, 12, A.darken(stone, 0.3))
    for y in range(14, 78):
        half = round(12 - (y - 14) * 0.08)
        band = ((y - 14) // 10) % 2 == 0
        col = (0.95, 0.94, 0.9) if band else (0.78, 0.18, 0.15)
        c.rect(22 - half, y, half * 2, 1, col)
        c.set(22 - half, y, A.darken(col, 0.25)); c.set(22 + half - 1, y, A.lighten(col, 0.2))
    c.rect(11, 77, 22, 3, (0.25, 0.25, 0.28))                    # balcon
    for x in range(12, 33, 3):
        c.rect(x, 80, 1, 5, (0.25, 0.25, 0.28))
    c.rect(13, 80, 18, 12, (0.2, 0.2, 0.24))                     # sala de la lampara
    c.rect(15, 82, 14, 8, (1.0, 0.86, 0.4))
    c.rect(21, 82, 2, 8, (1.0, 0.97, 0.8))
    for y in range(92, 101):
        half = max(1, (101 - y))
        c.rect(22 - half, y, half * 2, 1, (0.7, 0.16, 0.12))
    c.rect(19, 14, 6, 9, (0.3, 0.2, 0.12))                        # puerta
    c.rect(20, 40, 4, 5, (0.25, 0.4, 0.6)); c.rect(20, 60, 4, 5, (0.25, 0.4, 0.6))
    c.outline()
    return c.image()


def stones():
    c = A.Canvas(18, 10)
    for x, y, r in ((5, 4, 3), (11, 3.5, 2.6), (14, 6, 2), (8, 7, 2)):
        c.shaded(x, y, r, r * 0.8, (0.6, 0.6, 0.62), 0.3, 0.35)
    c.outline()
    return c.image()


def tavern():
    im = grid([[52, 53, 53, 53, 54], [64, 65, 65, 65, 66], [72, 84, 86, 84, 75]])
    d = ImageDraw.Draw(im)
    # cartel colgante con una jarra encima de la puerta
    d.line([(36, 29), (36, 31)], fill=(60, 40, 30, 255)); d.line([(43, 29), (43, 31)], fill=(60, 40, 30, 255))
    d.rectangle([33, 26, 46, 30], fill=(120, 80, 45, 255), outline=(50, 30, 20, 255))
    d.rectangle([38, 27, 41, 29], fill=(240, 200, 80, 255))
    d.point([(42, 28)], fill=(240, 200, 80, 255))
    return im


def forge():
    c = A.Canvas(36, 30)
    c.shadow(18, 3, 16, 3, 0.3)
    stone = (0.5, 0.5, 0.55)
    c.rect(2, 2, 20, 22, stone)
    for y in range(4, 24, 4):
        c.rect(2, y, 20, 1, A.darken(stone, 0.3))
    c.rect(6, 6, 12, 9, (0.15, 0.08, 0.06))
    c.ellipse(12, 9, 5, 3.5, (0.95, 0.4, 0.1)); c.ellipse(12, 8.5, 3, 2, (1, 0.8, 0.3))
    c.rect(8, 24, 8, 5, A.darken(stone, 0.2))                       # chimenea
    c.rect(24, 2, 3, 7, A.WOOD_D)                                    # pie del yunque
    c.rect(21, 9, 12, 3, (0.3, 0.3, 0.34)); c.rect(31, 10, 4, 2, (0.3, 0.3, 0.34))
    c.rect(22, 11, 10, 1, (0.55, 0.55, 0.6))
    c.outline()
    return c.image()


def workbench():
    c = A.Canvas(30, 20)
    c.shadow(15, 2, 13, 2, 0.3)
    c.rect(2, 2, 3, 9, A.WOOD_D); c.rect(25, 2, 3, 9, A.WOOD_D)
    c.rect(1, 10, 28, 4, A.WOOD); c.rect(1, 13, 28, 1, A.WOOD_L)
    c.rect(4, 14, 8, 2, (0.65, 0.65, 0.7)); c.rect(11, 14, 2, 3, A.WOOD_D)  # sierra
    c.rect(17, 14, 2, 4, A.WOOD_D); c.rect(16, 17, 4, 2, (0.45, 0.45, 0.5))  # martillo
    c.rect(22, 14, 5, 2, A.WOOD_L)                                            # tablón
    c.outline()
    return c.image()


def marine_flag():
    c = A.Canvas(22, 40)
    c.rect(3, 0, 2, 40, (0.55, 0.55, 0.6))
    c.rect(5, 26, 15, 11, (0.96, 0.96, 0.98))
    c.rect(5, 29, 15, 2, (0.2, 0.35, 0.75)); c.rect(5, 33, 15, 2, (0.2, 0.35, 0.75))
    c.rect(2, 38, 4, 2, (0.95, 0.75, 0.25))
    c.outline()
    return c.image()


def cannon():
    c = A.Canvas(26, 16)
    c.shadow(13, 2, 11, 2, 0.3)
    c.ellipse(19, 8, 6, 4, (0.22, 0.22, 0.25)); c.rect(3, 6, 16, 5, (0.22, 0.22, 0.25))
    c.rect(3, 9, 16, 1, (0.4, 0.4, 0.45))
    c.circle(9, 4, 3.5, A.WOOD); c.circle(9, 4, 1.2, A.WOOD_D)
    c.outline()
    return c.image()


def build_sprites():
    houses = [
        [[52, 53, 53, 54], [64, 65, 65, 66], [72, 84, 86, 75]],
        [[48, 49, 50], [60, 61, 62], [76, 88, 89]],
        [[48, 49, 49, 50], [60, 61, 61, 62], [88, 77, 90, 91]],
        [[52, 53, 54], [64, 65, 66], [73, 85, 75]],
    ]
    for i, h in enumerate(houses):
        put(f'w_house_{i}', grid(h), (0.5, 0.02))
    put('w_hut_0', grid([[67], [87]]), (0.5, 0.02))
    put('w_house_5', tavern(), (0.5, 0.02))
    put('w_house_6', grid([[48, 49, 50], [60, 61, 62], [77, 88, 78]]), (0.5, 0.02))
    put('w_forge', forge(), (0.5, 0.08))
    put('w_stones', stones(), (0.5, 0.2))
    put('c_boar', D(124), (0.5, 0.25))
    put('c_rat', D(123), (0.5, 0.25))
    put('w_workbench', workbench(), (0.5, 0.1))
    put('w_marineflag', marine_flag(), (0.5, 0.02))
    put('w_cannon', cannon(), (0.5, 0.15))
    put('c_herrero', hue_map(D(86), lambda h, sat, v: (0.08, min(1, sat * 1.1), v * 0.75) if 0.55 < h < 0.7 else None), (0.5, 0.25))
    put('c_carpintero', hue_map(D(85), lambda h, sat, v: (0.3, max(sat, 0.4), v) if 0.55 < h < 0.7 else None), (0.5, 0.25))
    put('c_tabernera', hue_map(D(99), lambda h, sat, v: (0.98, max(sat, 0.55), v) if 0.75 < h < 0.95 else None), (0.5, 0.25))
    put('w_hut_1', grid([[63], [85]]), (0.5, 0.02))
    for key, idx in (('w_pine', 4), ('w_tree_round', 5), ('w_tree', 16), ('w_pine_dark', 28),
                     ('w_autumn_0', 3), ('w_autumn_1', 15), ('w_autumn_2', 27)):
        put(key, T(idx), (0.5, 0.06))
    put('w_mushroom', T(29), (0.5, 0.1))
    put('w_sprout', T(17), (0.5, 0.1))
    put('w_fence_l', T(80), (0.5, 0.25)); put('w_fence', T(81), (0.5, 0.25)); put('w_fence_r', T(82), (0.5, 0.25))
    put('w_sign', T(83), (0.5, 0.06))
    put('w_well', T(104), (0.5, 0.06))
    put('w_beehive', T(94), (0.5, 0.06))
    put('w_sack', T(107), (0.5, 0.08))
    put('w_bucket', T(131), (0.5, 0.08))
    put('w_barrel', D(82), (0.5, 0.06))
    put('w_chest', D(89), (0.5, 0.06))
    put('w_bush', T(5), (0.5, 0.06))
    # procedural ones
    put('w_palm', A.palm(), (0.5, 3 / 58))
    put('w_rock', A.rock(False), (0.5, 3 / 22)); put('w_rock_ore', A.rock(True), (0.5, 3 / 22))
    put('w_boulder_0', A.boulder(0), (0.5, 3 / 26)); put('w_boulder_1', A.boulder(1), (0.5, 3 / 26))
    put('w_stalagmite', A.stalagmite(), (0.5, 1 / 18))
    put('w_crate', A.crate(), (0.5, 1 / 16))
    put('w_tent', A.tent(), (0.5, 2 / 30))
    put('w_campfire', A.campfire(), (0.5, 0.2))
    put('w_flame_0', A.flame(0), (0.5, 0.05)); put('w_flame_1', A.flame(1), (0.5, 0.05))
    put('w_wreck', A.wreck(), (0.5, 5 / 38))
    put('w_rowboat', A.rowboat(), (0.5, 0.2))
    put('w_shell_0', A.shell(0), (0.5, 0.3)); put('w_shell_1', A.shell(1), (0.5, 0.3))
    put('w_driftwood', A.driftwood(), (0.5, 0.3))
    put('w_torch', A.torch(), (0.5, 0.02))
    put('w_stall', A.stall(), (0.5, 2 / 42))
    put('w_lantern', A.lantern(), (0.5, 0.02))
    put('w_pier', A.pier_plank(), (0.5, 0.5)); put('w_pier_post', A.pier_post(), (0.5, 0.1))
    put('w_ship', A.ship(), (0.5, 10 / 104))
    # characters (16x16 pack)
    hero = D(98)
    pal = palette(hero)
    print('hero palette', pal[:8])
    put('c_player', hero, (0.5, 0.25))
    put('c_marine_elite', hue_map(D(97), lambda h, sat, v: (0.62, max(sat, 0.45), v * 0.7) if sat < 0.25 and v > 0.3 else None), (0.5, 0.25))
    put('c_captain', hue_map(D(84), lambda h, sat, v: (0.98, 0.65, v * 0.55) if 0.65 < h < 0.9 and sat > 0.2 else None), (0.5, 0.25))
    put('c_fire', hue_map(D(110), lambda h, sat, v: (0.07, sat, min(1.0, v * 1.1)) if (h < 0.05 or h > 0.95) and sat > 0.3 else None), (0.5, 0.25))
    for key, idx in (('c_villager_0', 85), ('c_villager_1', 88), ('c_villager_2', 99), ('c_villager_3', 100),
                     ('c_villager_4', 111), ('c_bandit', 112), ('c_gunner', 86), ('c_swordsman', 87),
                     ('c_marine_shield', 96), ('c_marine', 97), ('c_crab', 110), ('c_bat', 120), ('c_spider', 122)):
        put(key, D(idx), (0.5, 0.25))
    # items
    put('item_madera', T(106), (0.5, 0.5)); put('item_pico', T(115), (0.3, 0.25))
    put('item_hacha', D(119), (0.3, 0.25)); put('item_sable', D(104), (0.3, 0.25))
    put('item_botella', D(116), (0.5, 0.5)); put('item_coco', A.coconut_icon(), (0.5, 0.5))
    put('item_piedra', A.stone_icon(), (0.5, 0.5)); put('item_venda', A.bandage_icon(), (0.5, 0.5))
    put('item_fruta', A.fruit_icon(), (0.5, 0.5))
    put('item_fibra', fiber_icon(), (0.5, 0.5))
    put('item_mineral_hierro', ore_icon(), (0.5, 0.5))
    put('item_lingote_hierro', ingot_icon(), (0.5, 0.5))
    put('item_cuerda', rope_icon(), (0.5, 0.5))
    put('item_tela', cloth_icon(), (0.5, 0.5))
    put('item_kairoseki', kairo_icon(), (0.5, 0.5))
    put('item_espada_madera', D(107), (0.3, 0.25))
    put('item_katana', D(106), (0.3, 0.25))
    put('item_nodachi', D(105), (0.3, 0.25))
    put('item_daga_kairoseki', hue_map(D(103), lambda h, sat, v: (0.58, 0.35, v) if sat < 0.2 and v > 0.4 else None), (0.3, 0.25))
    put('item_shiokaze', hue_map(D(106), lambda h, sat, v: (0.5, 0.45, min(1, v * 1.05)) if sat < 0.2 and v > 0.4 else ((0.12, 0.8, v) if 0.02 < h < 0.15 else None)), (0.3, 0.25))
    # battle tiles
    put('bt_sand_0', D(48), (0.5, 0.5)); put('bt_sand_1', D(49), (0.5, 0.5))
    put('bt_grass_0', T(0), (0.5, 0.5)); put('bt_grass_1', T(1), (0.5, 0.5))
    plank = A.pier_plank()
    put('bt_deck_0', plank, (0.5, 0.5))
    put('bt_deck_1', hue_map(plank, lambda h, sat, v: (h, sat, v * 0.88)), (0.5, 0.5))
    put('bt_debris', T(92), (0.5, 0.1))
    put('bt_powder', powder_barrel(), (0.5, 0.06))
    put('bt_mast', mast(), (0.5, 0.04))
    water16 = Image.new('RGBA', (16, 16), (28, 97, 158, 255))
    wd = ImageDraw.Draw(water16)
    wd.line([(2, 4), (5, 4)], fill=(70, 150, 210, 255)); wd.line([(9, 11), (13, 11)], fill=(70, 150, 210, 255))
    wd.point([(3, 3), (10, 10)], fill=(150, 200, 235, 255))
    put('bt_water', water16, (0.5, 0.5))
    sh = D(48).copy()
    sh.alpha_composite(Image.new('RGBA', (16, 16), (40, 165, 205, 175)))
    ImageDraw.Draw(sh).line([(1, 12), (6, 12)], fill=(235, 250, 255, 255))
    put('bt_shallow', sh, (0.5, 0.5))
    put('bt_floor_0', D(0), (0.5, 0.5)); put('bt_floor_1', D(1), (0.5, 0.5))


# ------------------------------------------------------------------ placements
SCENERY = []   # (kind, variant, x, y)
NAMED = {}     # name -> (x, y)
occupied = []  # (x, y, r)


def free(x, y, r):
    for ox, oy, orr in occupied:
        if math.hypot(x - ox, y - oy) < r + orr:
            return False
    return True


def add(kind, x, y, variant=0, r=0.4, force=False):
    if not force and not free(x, y, r):
        return False
    SCENERY.append((kind, variant, round(x, 2), round(y, 2)))
    occupied.append((x, y, r))
    return True


def named(name, x, y, r=0.5):
    NAMED[name] = (x, y)
    occupied.append((x, y, r))


def terr_at(x, y):
    t, off, _ = sample(np.array([x]), np.array([y]))
    return int(t[0])


def path_d(x, y):
    return float(path_dist(np.array([x]), np.array([y]))[0])


def place():
    rnd = random.Random(1234)
    VX, VY = VILLAGE[0] - 8.0, VILLAGE[1] - 1.0   # desplazamiento del pueblo respecto al plano antiguo
    def V(x, y):
        return x + VX, y + VY

    # ---- reservas
    named('spawn', *SPAWN, r=1.4)
    named('enc_piratas', 18.0, -15.0, r=2.0)
    named('enc_capitan', 17.3, 22.2, r=1.6)

    # ---- Playa del Naufragio (sur)
    add('campfire', 2.2, -28.2, r=0.8, force=True)
    add('tent', -2.9, -27.6, r=1.4, force=True)
    add('crate', -4.7, -28.2, r=0.5, force=True)
    add('crate', -4.5, -27.4, r=0.4, force=True)
    add('workbench', -1.6, -30.6, r=0.7, force=True)
    add('wreck', 6.6, -31.4, r=2.2, force=True)
    add('anchor', 10.6, -30.6, r=0.6, force=True)
    add('rowboat', -5.4, -30.6, r=1.0, force=True)
    for x, y in ((3.6, -26.0), (-3.6, -25.4), (5.6, -24.2), (-6.6, -26.8), (1.0, -24.6), (8.4, -27.0), (-8.6, -28.4)):
        add('stones', x, y, r=0.5, force=True)
    named('item_pico', 8.6, -29.6); named('item_coco', 1.0, -30.4)
    add('sign', 1.6, -25.2, 3, r=0.4, force=True)

    # ---- charca (borde del Bosque Espeso)
    occupied.append((POND[0], POND[1], 3.0))
    named('npc_abuela', -5.6, -23.2)

    # ---- Pueblo Portuario (Aldea Coral): plaza con fuente en (14,4); cada edificio en su manzana, sin pisar caminos
    add('fountain', VILLAGE[0], VILLAGE[1], r=1.2, force=True)
    add('townhall', 11.0, 9.6, r=2.6, force=True)            # ayuntamiento (noroeste)
    add('tavern', 21.6, 8.4, r=2.4, force=True)              # taberna La Sirena Borracha (noreste)
    add('house', 21.2, 2.0, 2, r=2.2, force=True)            # herreria (este)
    add('house', 20.0, -5.6, 0, r=2.2, force=True)           # carpinteria (sureste)
    add('house', 12.6, -4.4, 3, r=1.7, force=True)           # casa (suroeste)
    add('house', 5.2, 6.2, 6, r=1.7, force=True)             # puesto de la Marina (oeste)
    add('house', 8.6, -7.6, 4, r=0.9, force=True)            # cabana
    add('house', 21.6, 15.0, 1, r=1.7, force=True)           # almacen del puerto
    add('house', 25.2, -1.4, 0, r=2.2, force=True)           # lonja
    add('drydock', 27.0, 5.0, r=1.8, force=True)
    add('forge', 19.0, 0.6, r=0.9, force=True)
    add('workbench', 18.0, -7.0, r=0.7, force=True)
    add('well', 16.6, 0.8, r=0.6, force=True)
    add('stall', 8.4, 2.0, r=1.5, force=True)
    add('marineflag', 3.0, 6.0, r=0.4, force=True)
    add('defense_cannon', 7.2, 5.0, r=0.7, force=True)
    add('defense_cannon', 15.6, 21.0, r=0.7, force=True)
    add('defense_cannon', 19.4, 21.0, r=0.7, force=True)
    for lx, ly in ((10.8, 6.6), (17.2, 6.6), (10.8, 1.4), (17.4, 2.4)):
        add('lantern', lx, ly, r=0.3, force=True)
    for v, x, y in ((0, 9.6, 8.8), (0, 12.6, 8.8), (1, 20.0, 7.6), (2, 4.0, 5.6), (1, 21.8, -6.8)):
        add('banner', x, y, v, r=0.3, force=True)
    for i in range(6):
        add('fence', 5.6 + i, 14.6, 0 if i == 0 else (2 if i == 5 else 1), r=0.45, force=True)
    add('beehive', 4.8, 13.8, r=0.4, force=True)
    for kind, x, y in (('barrel', 19.4, 7.6), ('barrel', 24.0, 7.8), ('crate', 22.8, 0.6), ('barrel', 23.4, 1.2),
                       ('crate', 21.8, -6.6), ('sack', 6.6, 1.0), ('crate', 6.2, 0.0), ('bucket', 15.8, 0.2), ('crate', 14.6, -6.2)):
        add(kind, x, y, r=0.4, force=True)
    for x, y in ((14.6, 15.6), (19.6, 16.4)):
        add('fishrack', x, y, r=1.0, force=True)
    add('sign', 10.0, -0.9, 0, r=0.4, force=True)
    named('npc_alcaldesa', 12.4, 8.6); named('npc_nino', 13.0, 2.0); named('npc_mercader', 8.4, 0.9)
    named('npc_herrero', 20.4, 0.4); named('npc_carpintero', 19.2, -7.4); named('npc_tabernera', 21.6, 7.2)
    named('npc_marine', 6.2, 5.0)
    named('npc_pescador', 15.0, 12.6)
    named('forge_spot', 19.0, 0.6, r=0.1)
    named('item_venda', 9.2, -3.2)
    # muelle y barco de Cuervo
    add('ship', 24.4, 28.6, r=0.1, force=True)
    add('anchor', 14.2, 22.4, r=0.6, force=True)
    for kind, x, y in (('barrel', 15.5, 22.6), ('barrel', 19.3, 22.9), ('crate', 14.7, 23.3), ('crate', 19.9, 21.7), ('sack', 15.2, 21.8)):
        add(kind, x, y, r=0.4, force=True)

    # ---- campamento pirata (playa sureste)
    add('tent', 21.4, -13.0, r=1.3, force=True)
    for kind, x, y in (('barrel', 15.6, -17.2), ('crate', 20.8, -16.6), ('barrel', 21.8, -15.6)):
        add(kind, x, y, r=0.4, force=True)

    # ---- Guarida de Contrabandistas (vieja mina): vetas junto a la entrada, peligros al fondo
    cx, cy = CAVE
    occupied.append((cx, cy, 1.0))
    for dx, dy in ((2.0, -1.0), (0.8, -2.8), (2.9, 0.8)):
        add('ore', cx + dx, cy + dy, r=0.8, force=True)
    add('rock', cx + 3.6, cy - 2.2, r=0.8, force=True)
    named('enc_cueva_aranas', cx - 2.4, cy + 3.0, r=1.2)
    named('enc_cueva_murcielagos', cx - 3.9, cy - 0.2, r=1.2)
    named('enc_cueva_bandidos', cx + 0.6, cy + 3.9, r=1.2)
    add('chest', cx - 0.9, cy + 4.8, r=0.5, force=True)
    named('item_botella', cx + 0.1, cy + 4.6, r=0.3)
    named('item_fruta', cx - 1.9, cy + 4.5, r=0.3)
    for kind, dx, dy in (('crate', -4.6, 1.6), ('crate', -4.2, 2.6), ('barrel', -3.4, -3.0), ('barrel', -1.2, -4.6), ('sack', -2.2, -4.2)):
        add(kind, cx + dx, cy + dy, r=0.4, force=True)
    for a in (60, 150, 240):
        ra = math.radians(a)
        add('torch', cx + math.cos(ra) * 5.2, cy + math.sin(ra) * 5.2, r=0.3, force=True)
    for v, a, rr in ((0, 100, 4.6), (1, 130, 3.4), (0, 170, 4.8), (1, 200, 3.0), (0, 30, 4.4)):
        ra = math.radians(a)
        add('crystal', cx + math.cos(ra) * rr, cy + math.sin(ra) * rr, v, r=0.4, force=True)
    for a in (20, 115, 190, 265):
        ra = math.radians(a)
        add('stalagmite', cx + math.cos(ra) * 4.8, cy + math.sin(ra) * 4.8, r=0.3)
    add('spider', cx - 1.0, cy + 1.2, r=0.3, force=True)
    add('bat', cx - 2.6, cy - 2.0, r=0.2, force=True); add('bat', cx + 0.4, cy + 1.6, r=0.2, force=True)
    add('rat', cx - 1.4, cy - 3.4, r=0.3, force=True); add('rat', cx - 3.2, cy + 1.0, r=0.3, force=True)
    named('cave_entrance', cx + 6.0 * 0.707, cy - 6.0 * 0.707, r=0.1)
    add('sign', -11.4, 5.0, 1, r=0.4, force=True)

    def ring_boulders(center, rin, rout, gap_ang, gap_half, count):
        for i in range(count):
            a = rnd.uniform(0, 360)
            if abs((a - gap_ang + 180) % 360 - 180) < gap_half + 12:
                continue
            rr = rnd.uniform(rin + 0.8, rout - 0.3)
            add('boulder', center[0] + math.cos(math.radians(a)) * rr, center[1] + math.sin(math.radians(a)) * rr, rnd.randint(0, 1), r=0.9)
    ring_boulders(CAVE, CAVE_IN, CAVE_OUT, GAP_ANG, GAP_HALF, 26)

    # ---- Colina del Faro
    hx, hy = HILL
    add('lighthouse', hx - 0.4, hy + 0.8, r=1.8, force=True)
    named('npc_farero', hx + 1.4, hy - 1.2)
    named('lighthouse', hx - 0.4, hy + 0.8, r=0.1)
    add('sign', 4.6, 11.4, 2, r=0.4, force=True)
    for dx, dy in ((-2.8, -1.8), (2.6, 1.8), (-2.2, 2.6)):
        add('bush', hx + dx, hy + dy, r=0.5, force=True)
    ring_boulders(HILL, HILL_IN, HILL_OUT, RAMP_ANG, RAMP_HALF, 14)

    # ---- rocas para picar fuera de la mina
    for x, y in ((-3.0, 8.6), (6.5, 16.0), (-12.0, -14.0), (25.0, 12.0), (-16.0, -18.0), (10.0, -18.0)):
        add('rock', x, y, r=0.8, force=True)

    # ---- palmeras en toda la costa
    a = 0.0
    while a < 360:
        ang = a + rnd.uniform(-3, 3)
        inset = rnd.uniform(1.4, 3.2)
        ra = math.radians(ang)
        R = shore_r(math.cos(ra), math.sin(ra))
        x, y = math.cos(ra) * (R - inset), math.sin(ra) * (R - inset)
        if path_d(x, y) > 1.9 and terr_at(x, y) in (SAND, WET, GRASS) and math.hypot(x - SPAWN[0], y - SPAWN[1]) > 3.5:
            add('palm', x, y, r=1.1)
        a += rnd.uniform(6, 10)

    def scatter(kinds, n, box, spacing, path_clear=1.4, allowed=(GRASS,), apart=0.0):
        # spacing = hueco libre contra todo lo colocado; apart = distancia mínima entre los de esta misma tanda
        tries = 0; placed = 0; mine = []
        while placed < n and tries < n * 60:
            tries += 1
            x = rnd.uniform(box[0], box[2]); y = rnd.uniform(box[1], box[3])
            if terr_at(x, y) not in allowed or path_d(x, y) < path_clear:
                continue
            if math.hypot(x - VILLAGE[0], y - VILLAGE[1]) < PLAZA_R + 1.0:
                continue
            if math.hypot(x - CAVE[0], y - CAVE[1]) < CAVE_OUT + 0.8 or math.hypot(x - HILL[0], y - HILL[1]) < HILL_OUT + 0.6:
                continue
            if any(math.hypot(x - mx, y - my) < apart for mx, my in mine):
                continue
            k, v = rnd.choice(kinds)
            if add(k, x, y, v, r=spacing):
                placed += 1; mine.append((x, y))
    trees = [('tree', 0), ('pine', 0), ('pine', 1), ('treeround', 0)]
    # Bosque Espeso: denso al oeste y suroeste
    scatter(trees + [('pine', 1), ('pine', 1), ('autumn', 0), ('autumn', 1)], 150, (-31, -26, -9, 7), 0.6, 1.2)
    scatter(trees, 26, (4, 10, 16, 22), 0.8)
    scatter(trees + [('autumn', 2)], 24, (4, -24, 18, -12), 0.8)
    scatter(trees, 18, (19, -8, 30, 12), 0.8)
    scatter(trees, 16, (-14, 8, -6, 26), 0.8)
    scatter([('bush', 0)], 60, (-31, -30, 31, 28), 0.5, 1.0)
    scatter([('mushroom', 0), ('sprout', 0)], 40, (-31, -26, -9, 7), 0.3, 0.8)
    scatter([('sprout', 0)], 50, (-31, -30, 31, 28), 0.35, 0.9)
    scatter([('shell', 0), ('shell', 1), ('driftwood', 0), ('starfish', 0)], 60, (-36, -36, 36, 36), 0.5, 0.6, allowed=(SAND, WET))
    scatter([('flowers', i) for i in range(4)], 70, (-31, -30, 31, 28), 0.4, 0.9)
    scatter([('stones', 0)], 14, (-36, -36, 36, 36), 0.6, 0.8, allowed=(SAND, GRASS), apart=4.0)
    # Fauna: hueco pequeño contra la decoración (el bosque es denso) pero separados entre sí
    scatter([('crab', 0)], 12, (-36, -36, 36, 36), 0.7, 1.0, allowed=(WET, SAND), apart=5.0)
    scatter([('boar', 0)], 7, (-31, -26, -4, 10), 0.35, 1.2, apart=5.0)


# ------------------------------------------------------------------ outputs
def write_meta(path, pivot, readable=False):
    meta = path + '.meta'
    guid = None
    if os.path.exists(meta):
        for line in open(meta):
            if line.startswith('guid:'):
                guid = line.split(':')[1].strip()
    guid = guid or uuid.uuid4().hex
    px, py = pivot
    open(meta, 'w', newline='\n').write(f"""fileFormatVersion: 2
guid: {guid}
TextureImporter:
  internalIDToNameTable: []
  externalObjects: {{}}
  serializedVersion: 13
  mipmaps:
    mipMapMode: 0
    enableMipMap: 0
    sRGBTexture: 1
    linearTexture: 0
    fadeOut: 0
    borderMipMap: 0
    mipMapsPreserveCoverage: 0
    alphaTestReferenceValue: 0.5
    mipMapFadeDistanceStart: 1
    mipMapFadeDistanceEnd: 3
  bumpmap:
    convertToNormalMap: 0
    externalNormalMap: 0
    heightScale: 0.25
    normalMapFilter: 0
    flipGreenChannel: 0
  isReadable: {1 if readable else 0}
  streamingMipmaps: 0
  streamingMipmapsPriority: 0
  vTOnly: 0
  ignoreMipmapLimit: 0
  grayScaleToAlpha: 0
  generateCubemap: 6
  cubemapConvolution: 0
  seamlessCubemap: 0
  textureFormat: 1
  maxTextureSize: 2048
  textureSettings:
    serializedVersion: 2
    filterMode: 0
    aniso: 1
    mipBias: 0
    wrapU: 1
    wrapV: 1
    wrapW: 1
  nPOTScale: 0
  lightmap: 0
  compressionQuality: 50
  spriteMode: 1
  spriteExtrude: 1
  spriteMeshType: 0
  alignment: 9
  spritePivot: {{x: {px:.4f}, y: {py:.4f}}}
  spritePixelsToUnits: 16
  spriteBorder: {{x: 0, y: 0, z: 0, w: 0}}
  spriteGenerateFallbackPhysicsShape: 0
  alphaUsage: 1
  alphaIsTransparency: 1
  spriteTessellationDetail: -1
  textureType: 8
  textureShape: 1
  singleChannelComponent: 0
  flipbookRows: 1
  flipbookColumns: 1
  maxTextureSizeSet: 0
  compressionQualitySet: 0
  textureFormatSet: 0
  ignorePngGamma: 0
  applyGammaDecoding: 0
  swizzle: 50462976
  cookieLightType: 0
  platformSettings:
  - serializedVersion: 4
    buildTarget: DefaultTexturePlatform
    maxTextureSize: 2048
    resizeAlgorithm: 0
    textureFormat: -1
    textureCompression: 0
    compressionQuality: 50
    crunchedCompression: 0
    allowsAlphaSplitting: 0
    overridden: 0
    ignorePlatformSupport: 0
    androidETC2FallbackOverride: 0
    forceMaximumCompressionQuality_BC6H_BC7: 0
  spriteSheet:
    serializedVersion: 2
    sprites: []
    outline: []
    customData:
    physicsShape: []
    bones: []
    spriteID:
    internalID: 0
    vertices: []
    indices:
    edges: []
    weights: []
    secondaryTextures: []
    spriteCustomMetadata:
      entries: []
    nameFileIdTable: {{}}
  mipmapLimitGroupName:
  pSDRemoveMatte: 0
  userData:
  assetBundleName:
  assetBundleVariant:
""")


def write_cs():
    kinds = sorted(set(k for k, _, _, _ in SCENERY))
    lines = []
    lines.append('// <auto-generated> Generado por la herramienta de diseño de la isla. Editar con cuidado: las posiciones están comprobadas contra el plano (IslandLayout). </auto-generated>')
    lines.append('using UnityEngine;')
    lines.append('')
    lines.append('namespace PirateSurvival.Bootstrap')
    lines.append('{')
    lines.append('    /// <summary>Colocación de todos los objetos de la isla inicial (tipo, variante, posición de los pies).</summary>')
    lines.append('    internal static class IslandPlacements')
    lines.append('    {')
    lines.append('        public struct Item')
    lines.append('        {')
    lines.append('            public string kind; public int variant; public Vector2 pos;')
    lines.append('            public Item(string k, int v, float x, float y) { kind = k; variant = v; pos = new Vector2(x, y); }')
    lines.append('        }')
    lines.append('')
    lines.append('        public static readonly Item[] Scenery =')
    lines.append('        {')
    for k, v, x, y in SCENERY:
        lines.append(f'            new Item("{k}", {v}, {x:.2f}f, {y:.2f}f),')
    lines.append('        };')
    lines.append('')
    for name, (x, y) in NAMED.items():
        cname = ''.join(p.capitalize() for p in name.split('_'))
        lines.append(f'        public static readonly Vector2 {cname} = new Vector2({x:.2f}f, {y:.2f}f);')
    lines.append('    }')
    lines.append('}')
    open(GEN_CS, 'w', encoding='utf-8-sig', newline='\n').write('\n'.join(lines) + '\n')


def write_pivots():
    path = os.path.join(PROJ, 'Scripts', 'Core', 'SpritePivots.cs')
    L = ['// <auto-generated> Generado junto con las imágenes de Resources/Sprites (mismos pivotes que sus .meta). </auto-generated>',
         'using System.Collections.Generic;', 'using UnityEngine;', '', 'namespace PirateSurvival.Core', '{',
         '    /// <summary>Pivote de cada imagen de Resources/Sprites, por si Unity la importa sin su .meta.</summary>',
         '    public static class SpritePivots', '    {',
         '        private static readonly Dictionary<string, Vector2> Pivots = new Dictionary<string, Vector2>',
         '        {']
    for key, (im, pv) in sorted(SPRITES.items()):
        L.append(f'            {{ "{key}", new Vector2({pv[0]:.4f}f, {pv[1]:.4f}f) }},')
    L += ['        };', '',
          '        public static Vector2 Get(string key) => Pivots.TryGetValue(key, out Vector2 p) ? p : new Vector2(0.5f, 0.1f);',
          '    }', '}']
    open(path, 'w', encoding='utf-8-sig', newline='\n').write('\n'.join(L) + '\n')


def preview(ground):
    scale = 2
    W = ground.width * scale
    water = Image.new('RGBA', (W, W), (28, 97, 158, 255))
    img = water.copy()
    img.alpha_composite(ground.resize((W, W), Image.NEAREST))

    def to_px(x, y):
        return (x - WORLD_MIN) * PPU * scale, (WORLD_MAX - y) * PPU * scale

    keymap = {
        'palm': 'w_palm', 'rock': 'w_rock', 'ore': 'w_rock_ore', 'boulder': 'w_boulder_{v}', 'stalagmite': 'w_stalagmite',
        'crate': 'w_crate', 'tent': 'w_tent', 'campfire': 'w_campfire', 'wreck': 'w_wreck', 'rowboat': 'w_rowboat',
        'shell': 'w_shell_{v}', 'driftwood': 'w_driftwood', 'torch': 'w_torch', 'stall': 'w_stall', 'lantern': 'w_lantern',
        'ship': 'w_ship', 'house': 'HOUSE', 'well': 'w_well', 'fence': 'FENCE', 'beehive': 'w_beehive', 'barrel': 'w_barrel',
        'sack': 'w_sack', 'bucket': 'w_bucket', 'sign': 'w_sign', 'chest': 'w_chest', 'tree': 'w_tree', 'pine': 'PINE',
        'treeround': 'w_tree_round', 'autumn': 'w_autumn_{v}', 'bush': 'w_bush', 'mushroom': 'w_mushroom', 'sprout': 'w_sprout',
        'stones': 'w_stones', 'boar': 'c_boar', 'rat': 'c_rat',
        'forge': 'w_forge', 'workbench': 'w_workbench', 'marineflag': 'w_marineflag', 'cannon': 'w_cannon',
        'flowers': None, 'grass': None, 'crab': 'c_crab', 'bat': 'c_bat', 'spider': 'c_spider',
    }
    items = []
    for k, v, x, y in SCENERY:
        key = keymap.get(k, 'PLACEHOLDER')
        if key is None:
            continue
        if key == 'PLACEHOLDER':
            sizes = {'townhall': (5, 4), 'tavern': (4.5, 4), 'fountain': (2.4, 1.8), 'drydock': (3.6, 2.4), 'lighthouse': (2.2, 6),
                     'defense_cannon': (1.6, 1.0), 'starfish': (0.5, 0.4), 'anchor': (1.2, 1.4), 'flowers': (0.6, 0.5), 'banner': (0.5, 2.0),
                     'fishrack': (1.8, 1.4), 'crystal': (0.8, 1.0)}
            w, h = sizes.get(k, (1, 1))
            items.append((y, ('RECT', w, h, k), x))
            continue
        if key == 'HOUSE':
            key = 'w_hut_0' if v == 4 else f'w_house_{v}'
        elif key == 'FENCE':
            key = ['w_fence_l', 'w_fence', 'w_fence_r'][v]
        elif key == 'PINE':
            key = 'w_pine' if v == 0 else 'w_pine_dark'
        key = key.format(v=v)
        items.append((y, key, x))
    chars = [('c_player', *SPAWN), ('c_villager_3', *NAMED['npc_abuela']), ('c_villager_2', *NAMED['npc_alcaldesa']),
             ('c_villager_0', *NAMED['npc_nino']), ('c_villager_1', *NAMED['npc_mercader']), ('c_villager_4', *NAMED['npc_pescador']),
             ('c_herrero', *NAMED['npc_herrero']), ('c_carpintero', *NAMED['npc_carpintero']),
             ('c_tabernera', *NAMED['npc_tabernera']), ('c_marine', *NAMED['npc_marine']),
             ('c_villager_4', *NAMED['npc_farero']),
             ('c_bandit', 17.6, -14.8), ('c_gunner', 18.6, -15.2), ('c_swordsman', 17.6, 22.4)]
    for k, x, y in chars:
        items.append((y, k, x))
    # pier
    for yy in np.arange(PIER_START_Y, PIER_END_Y, 1.0):
        for xx in (PIER_MIN_X + 0.5, PIER_MAX_X - 0.5):
            im, pv = SPRITES['w_pier']
            im2 = im.resize((im.width * scale, im.height * scale), Image.NEAREST)
            px, py = to_px(xx, yy + 0.5)
            img.alpha_composite(im2, (int(px - im2.width * 0.5), int(py - im2.height * 0.5)))
    colors = {'townhall': (160, 60, 50), 'tavern': (150, 95, 50), 'fountain': (90, 150, 210), 'drydock': (120, 80, 45), 'lighthouse': (230, 230, 230),
              'defense_cannon': (40, 40, 45), 'starfish': (240, 120, 80), 'anchor': (70, 70, 80), 'flowers': (240, 200, 80), 'banner': (200, 40, 40),
              'fishrack': (150, 110, 70), 'crystal': (120, 220, 240)}
    dr = ImageDraw.Draw(img)
    for y, key, x in sorted(items, key=lambda t: -t[0]):
        if isinstance(key, tuple):
            _, w, h, k = key
            px, py = to_px(x, y)
            dr.rectangle([px - w * PPU * scale / 2, py - h * PPU * scale, px + w * PPU * scale / 2, py], fill=colors.get(k, (255, 0, 255)) + (255,), outline=(20, 15, 10, 255))
            continue
        im, pv = SPRITES[key]
        im2 = im.resize((im.width * scale, im.height * scale), Image.NEAREST)
        px, py = to_px(x, y)
        img.alpha_composite(im2, (int(px - im2.width * pv[0]), int(py - im2.height * (1 - pv[1]))))
    img.save(os.path.join(SCR, 'preview_full.png'))
    # crops
    def crop(cx, cy, half, name):
        x0, y0 = to_px(cx - half, cy + half); x1, y1 = to_px(cx + half, cy - half)
        img.crop((int(x0), int(y0), int(x1), int(y1))).save(os.path.join(SCR, name))
    crop(0, -27, 8, 'prev_spawn.png')
    crop(14, 4, 10, 'prev_village.png')
    crop(-18, 12, 10, 'prev_cave.png')
    crop(19, 23, 9, 'prev_dock.png')
    crop(-1, 20, 8, 'prev_hill.png')
    crop(-20, -10, 12, 'prev_forest.png')
    img.resize((W // 6, W // 6), Image.LANCZOS).save(os.path.join(SCR, 'preview_small.png'))


def main():
    build_sprites()
    ground, terr = bake_ground()
    put('ground_island', ground, (0.5, 0.5))
    place()
    for key, (im, pv) in SPRITES.items():
        p = os.path.join(OUT, key + '.png')
        im.save(p)
        write_meta(p, pv)
    write_cs()
    write_pivots()
    preview(ground)
    print('sprites', len(SPRITES), 'scenery', len(SCENERY))


main()
