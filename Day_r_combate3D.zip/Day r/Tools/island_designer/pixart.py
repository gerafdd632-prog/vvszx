"""Pixel canvas + procedural art (Python port of PixelCanvas.cs / WorldArt.cs) for baking PNGs."""
import math
import numpy as np
from PIL import Image

INK = (0.1, 0.08, 0.07)


def lerp(a, b, t):
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(len(a)))


def lighten(c, t):
    return lerp(c, (1, 1, 1), t)


def darken(c, t):
    return lerp(c, (0, 0, 0), t)


def _hash(x, y, seed):
    h = (x * 374761393 + y * 668265263 + seed * 2147483647) & 0xFFFFFFFF
    h = ((h ^ (h >> 13)) * 1274126177) & 0xFFFFFFFF
    h ^= h >> 16
    return (h & 0xFFFFFF) / 16777216.0


def vnoise(x, y, seed=0):
    xi, yi = math.floor(x), math.floor(y)
    xf, yf = x - xi, y - yi
    u, v = xf * xf * (3 - 2 * xf), yf * yf * (3 - 2 * yf)
    a = _hash(xi, yi, seed); b = _hash(xi + 1, yi, seed)
    c = _hash(xi, yi + 1, seed); d = _hash(xi + 1, yi + 1, seed)
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v


class Canvas:
    def __init__(self, w, h):
        self.w, self.h = w, h
        self.px = np.zeros((h, w, 4), dtype=np.float32)  # [y][x], y=0 bottom

    def inb(self, x, y):
        return 0 <= x < self.w and 0 <= y < self.h

    def opaque(self, x, y):
        return self.inb(x, y) and self.px[y, x, 3] > 0

    def set(self, x, y, c):
        x, y = int(x), int(y)
        if not self.inb(x, y):
            return
        a = c[3] if len(c) > 3 else 1.0
        if a >= 0.999:
            self.px[y, x] = (c[0], c[1], c[2], 1.0)
            return
        if a <= 0:
            return
        u = self.px[y, x]
        na = a + u[3] * (1 - a)
        rgb = [(c[i] * a + u[i] * u[3] * (1 - a)) / na for i in range(3)]
        self.px[y, x] = (*rgb, na)

    def rect(self, x0, y0, w, h, c):
        for y in range(y0, y0 + h):
            for x in range(x0, x0 + w):
                self.set(x, y, c)

    def ellipse(self, cx, cy, rx, ry, c):
        for y in range(math.floor(cy - ry), math.ceil(cy + ry) + 1):
            for x in range(math.floor(cx - rx), math.ceil(cx + rx) + 1):
                dx = (x + 0.5 - cx) / rx; dy = (y + 0.5 - cy) / ry
                if dx * dx + dy * dy <= 1:
                    self.set(x, y, c)

    def circle(self, cx, cy, r, c):
        self.ellipse(cx, cy, r, r, c)

    def shaded(self, cx, cy, rx, ry, base, la=0.28, sa=0.35):
        light = lighten(base, la); shadow = darken(base, sa)
        for y in range(math.floor(cy - ry), math.ceil(cy + ry) + 1):
            for x in range(math.floor(cx - rx), math.ceil(cx + rx) + 1):
                dx = (x + 0.5 - cx) / rx; dy = (y + 0.5 - cy) / ry
                d = dx * dx + dy * dy
                if d > 1:
                    continue
                ld = -dx * 0.6 + dy * 0.8
                col = base
                if ld > 0.45 and d < 0.75:
                    col = light
                elif ld < -0.35 or (d > 0.82 and ld < 0.1):
                    col = shadow
                self.set(x, y, col)

    def line(self, x0, y0, x1, y1, c, t=1):
        x0, y0, x1, y1 = int(x0), int(y0), int(x1), int(y1)
        dx = abs(x1 - x0); sx = 1 if x0 < x1 else -1
        dy = -abs(y1 - y0); sy = 1 if y0 < y1 else -1
        err = dx + dy
        while True:
            if t <= 1:
                self.set(x0, y0, c)
            else:
                self.rect(x0 - t // 2, y0 - t // 2, t, t, c)
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * err
            if e2 >= dy:
                err += dy; x0 += sx
            if e2 <= dx:
                err += dx; y0 += sy

    def noise(self, amount, scale, seed):
        for y in range(self.h):
            for x in range(self.w):
                if self.px[y, x, 3] <= 0:
                    continue
                n = vnoise(x * scale + seed * 13.1, y * scale + seed * 7.7, seed) - 0.5
                n += (_hash(x, y, seed) - 0.5) * 0.6
                k = n * amount
                c = tuple(self.px[y, x, :3])
                c = lighten(c, k) if k > 0 else darken(c, -k)
                self.px[y, x, :3] = c

    def outline(self, col=INK, tint=True):
        a = self.px[:, :, 3] > 0
        src = self.px.copy()
        for y in range(self.h):
            for x in range(self.w):
                if a[y, x]:
                    continue
                n = None
                for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    if self.inb(x + dx, y + dy) and a[y + dy, x + dx]:
                        n = src[y + dy, x + dx]
                        break
                if n is None:
                    continue
                c = lerp(tuple(n[:3]), col, 0.75) if tint else col
                self.px[y, x] = (*c, 1.0)

    def shadow(self, cx, cy, rx, ry, alpha=0.3):
        self.ellipse(cx, cy, rx, ry, (0, 0, 0, alpha))

    def shadow_behind(self, cx, cy, rx, ry, alpha=0.28):
        for y in range(math.floor(cy - ry), math.ceil(cy + ry) + 1):
            for x in range(math.floor(cx - rx), math.ceil(cx + rx) + 1):
                dx = (x + 0.5 - cx) / rx; dy = (y + 0.5 - cy) / ry
                if dx * dx + dy * dy <= 1 and self.inb(x, y) and self.px[y, x, 3] == 0:
                    self.set(x, y, (0, 0, 0, alpha))

    def blit(self, img, x, y):
        """Paste an RGBA PIL image with its bottom-left at (x,y)."""
        arr = np.asarray(img.convert('RGBA'), dtype=np.float32)[::-1] / 255.0
        for yy in range(arr.shape[0]):
            for xx in range(arr.shape[1]):
                p = arr[yy, xx]
                if p[3] > 0:
                    self.set(x + xx, y + yy, tuple(p))

    def image(self):
        arr = np.clip(self.px[::-1] * 255 + 0.5, 0, 255).astype(np.uint8)
        return Image.fromarray(arr, 'RGBA')


# ---------------------------------------------------------------- palette
WOOD = (0.6, 0.4, 0.22); WOOD_D = (0.4, 0.25, 0.13); WOOD_L = (0.75, 0.55, 0.32)
LEAF = (0.27, 0.62, 0.25); LEAF_D = (0.15, 0.42, 0.18); LEAF_L = (0.5, 0.8, 0.35)
STONE = (0.55, 0.57, 0.62)


def palm():
    c = Canvas(40, 58)
    c.shadow(20, 3, 9, 2.5, 0.28)
    trunk = (0.62, 0.46, 0.28); td = (0.45, 0.31, 0.17)
    for y in range(2, 40):
        x = 18 + round(math.sin(y * 0.09) * 3)
        c.rect(x, y, 4, 1, trunk if (y // 3) % 2 == 0 else lerp(trunk, td, 0.5))
        c.set(x, y, td)
    top = 18 + round(math.sin(39 * 0.09) * 3) + 2
    for a in (15, 50, 90, 130, 165, 205, 335):
        r = math.radians(a)
        for i in range(17):
            t = i / 16
            px = top + math.cos(r) * i * 1.1
            py = 41 + math.sin(r) * i * 0.8 - t * t * 7
            w = 3.2 + (1 - 3.2) * t
            c.ellipse(px, py, w, w * 0.8, LEAF if t < 0.5 else LEAF_D)
            c.set(round(px), round(py + w * 0.5), LEAF_L)
    c.circle(top - 1, 39, 1.8, (0.45, 0.3, 0.12))
    c.circle(top + 2, 38.5, 1.8, (0.38, 0.25, 0.1))
    c.outline()
    return c.image()


def rock(ore):
    c = Canvas(26, 22)
    c.shadow(13, 3, 11, 3, 0.3)
    c.shaded(13, 9, 11, 8, STONE, 0.3, 0.4)
    c.shaded(9, 12, 6, 5, lighten(STONE, 0.1), 0.25, 0.3)
    c.noise(0.2, 0.4, 11 if ore else 5)
    c.line(12, 6, 16, 11, darken(STONE, 0.45))
    if ore:
        gold = (1, 0.82, 0.25)
        for x, y in ((7, 9), (15, 13), (18, 7), (11, 4)):
            c.rect(x, y, 2, 2, gold); c.set(x, y + 1, (1, 1, 1))
    c.outline()
    return c.image()


def boulder(v):
    c = Canvas(32, 26)
    b = lerp((0.5, 0.52, 0.58), (0.44, 0.46, 0.54), v * 0.5)
    c.shadow(16, 3, 14, 3, 0.35)
    c.shaded(16, 11, 14, 10, b, 0.25, 0.45)
    c.shaded(10 if v == 0 else 22, 15, 7, 6, lighten(b, 0.08), 0.3, 0.35)
    c.noise(0.22, 0.3, 20 + v)
    c.outline()
    return c.image()


def stalagmite():
    c = Canvas(12, 18)
    s = (0.45, 0.42, 0.48)
    for y in range(1, 16):
        half = max(1, (16 - y) // 3)
        c.rect(6 - half, y, half * 2, 1, s)
        c.set(6 - half, y, lighten(s, 0.25))
    c.outline()
    return c.image()


def crate():
    c = Canvas(16, 16)
    c.rect(1, 0, 14, 2, (0, 0, 0, 0.3))
    c.rect(1, 1, 14, 13, WOOD)
    c.rect(1, 1, 14, 2, WOOD_D); c.rect(1, 12, 14, 2, WOOD_L)
    c.line(2, 3, 13, 11, WOOD_D, 2)
    c.rect(1, 1, 2, 13, WOOD_D); c.rect(13, 1, 2, 13, WOOD_D)
    c.outline()
    return c.image()


def tent():
    c = Canvas(40, 30)
    c.rect(2, 0, 36, 3, (0, 0, 0, 0.3))
    cv = (0.88, 0.82, 0.66); cd = (0.68, 0.6, 0.45)
    for y in range(2, 26):
        half = round((26 - y) * 0.75)
        c.rect(20 - half, y, half, 1, cd)
        c.rect(20, y, half, 1, cv)
    for y in range(2, 14):
        half = (14 - y) // 2
        c.rect(20 - half, y, half * 2, 1, (0.25, 0.18, 0.12))
    c.rect(19, 25, 2, 4, WOOD_D)
    c.outline()
    return c.image()


def campfire():
    c = Canvas(20, 12)
    for i in range(8):
        a = i * math.pi / 4
        c.shaded(10 + math.cos(a) * 7.5, 5 + math.sin(a) * 3.5, 2.2, 1.8, STONE)
    c.line(4, 4, 15, 7, WOOD_D, 2); c.line(4, 7, 15, 4, WOOD, 2)
    c.ellipse(10, 5.5, 3, 1.5, (0.25, 0.12, 0.08))
    c.outline()
    return c.image()


def flame(frame):
    c = Canvas(12, 16)
    sway = -0.8 if frame == 0 else 0.8
    c.ellipse(6, 5, 4.5, 4.5, (0.95, 0.35, 0.1))
    c.ellipse(6 + sway, 9, 3, 4.5, (0.95, 0.35, 0.1))
    c.ellipse(6 + sway * 0.5, 5, 3, 3.5, (1, 0.7, 0.15))
    c.ellipse(6, 4, 1.6, 2, (1, 0.95, 0.6))
    c.set(round(6 - sway * 2), 13, (1, 0.6, 0.2))
    return c.image()


def wreck():
    c = Canvas(66, 38)
    c.ellipse(33, 6, 30, 5, (0, 0, 0, 0.25))
    for x in range(4, 62):
        t = (x - 4) / 58
        h = round(math.sin(t * math.pi) * 16) + 4
        c.rect(x, 5, 1, h, WOOD if (x // 3) % 2 == 0 else lerp(WOOD, WOOD_D, 0.5))
        c.set(x, 5 + h - 1, WOOD_L)
    for y in range(7, 22, 4):
        c.rect(6, y, 54, 1, WOOD_D)
    c.rect(22, 8, 6, 6, (0.15, 0.1, 0.08))
    c.line(40, 20, 50, 35, WOOD_D, 3)
    c.rect(46, 28, 10, 2, WOOD_D)
    c.line(48, 28, 60, 24, (0.85, 0.82, 0.75), 2)
    c.noise(0.12, 0.5, 31)
    c.outline()
    return c.image()


def rowboat():
    c = Canvas(34, 16)
    c.ellipse(17, 5, 16, 4, WOOD)
    c.ellipse(17, 7, 14, 3, WOOD_D)
    c.ellipse(17, 7.5, 12, 2.2, (0.35, 0.22, 0.12))
    c.rect(10, 6, 2, 4, WOOD_L); c.rect(22, 6, 2, 4, WOOD_L)
    c.line(6, 12, 20, 4, WOOD_L)
    c.outline()
    return c.image()


def shell(v):
    c = Canvas(8, 7)
    col = (1, 0.85, 0.8) if v == 0 else (0.95, 0.75, 0.55)
    c.ellipse(4, 3, 3.2, 2.6, col)
    c.line(4, 1, 2, 5, darken(col, 0.25)); c.line(4, 1, 6, 5, darken(col, 0.25))
    return c.image()


def driftwood():
    c = Canvas(20, 7)
    d = (0.72, 0.65, 0.55)
    c.line(1, 2, 18, 4, d, 3)
    c.line(13, 4, 17, 6, d)
    c.line(2, 2, 17, 3, darken(d, 0.3))
    c.outline()
    return c.image()


def torch():
    c = Canvas(8, 16)
    c.rect(3, 0, 2, 11, WOOD_D)
    c.rect(2, 10, 4, 2, (0.3, 0.3, 0.32))
    c.outline()
    return c.image()


def stall():
    c = Canvas(46, 42)
    c.rect(3, 0, 40, 3, (0, 0, 0, 0.3))
    c.rect(4, 2, 38, 12, WOOD); c.rect(4, 12, 38, 2, WOOD_L); c.rect(4, 2, 38, 2, WOOD_D)
    for i in range(6):
        c.circle(9 + i * 3, 15, 1.6, (0.95, 0.5, 0.15) if i % 2 == 0 else (0.9, 0.2, 0.2))
    c.ellipse(32, 15, 4, 1.4, (0.6, 0.75, 0.85)); c.ellipse(37, 15.5, 3.5, 1.2, (0.55, 0.7, 0.8))
    c.rect(5, 13, 2, 20, WOOD_D); c.rect(39, 13, 2, 20, WOOD_D)
    for x in range(1, 45):
        s = (0.9, 0.25, 0.25) if (x // 4) % 2 == 0 else (0.97, 0.95, 0.9)
        c.rect(x, 30, 1, 10, s)
        if x % 4 == 2:
            c.set(x, 29, s)
    c.rect(1, 30, 44, 1, darken((0.9, 0.25, 0.25), 0.4))
    c.outline()
    return c.image()


def lantern():
    c = Canvas(10, 30)
    m = (0.25, 0.25, 0.28)
    c.rect(4, 0, 2, 24, m); c.rect(2, 22, 6, 6, m)
    c.rect(3, 23, 4, 4, (1, 0.85, 0.4)); c.rect(2, 28, 6, 1, m)
    c.outline()
    return c.image()


def pier_plank():
    c = Canvas(16, 16)
    for y in range(0, 16, 4):
        c.rect(0, y, 16, 3, WOOD if (y // 4) % 2 == 0 else WOOD_L)
        c.rect(0, y + 3, 16, 1, WOOD_D)
    for x, y in ((3, 1), (12, 5), (6, 9), (10, 13)):
        c.set(x, y, WOOD_D)
    return c.image()


def pier_post():
    c = Canvas(6, 12)
    c.rect(1, 0, 4, 12, WOOD_D); c.rect(1, 10, 4, 2, WOOD_L)
    c.outline()
    return c.image()


def ship():
    c = Canvas(120, 104)
    hull = (0.25, 0.16, 0.12); hl = (0.42, 0.28, 0.18); trim = (0.75, 0.6, 0.3)
    c.ellipse(60, 10, 56, 7, (0, 0.05, 0.12, 0.35))
    for x in range(6, 114):
        t = (x - 6) / 108
        bottom = 8 + round(pow(abs(t - 0.5) * 2, 2) * 10)
        top = 36 + round(pow(abs(t - 0.45) * 2, 3) * 10)
        c.rect(x, bottom, 1, top - bottom, hull if (x // 4) % 2 == 0 else lerp(hull, hl, 0.4))
        c.set(x, top - 1, trim)
    c.rect(10, 22, 100, 2, trim)
    for x in range(25, 100, 14):
        c.rect(x, 26, 5, 4, (0.08, 0.06, 0.05))
    sail = (0.12, 0.12, 0.14); sl = (0.22, 0.22, 0.25); bone = (0.95, 0.95, 0.9)
    for mx in (40, 76):
        c.rect(mx, 36, 3, 64, WOOD_D)
        for y in range(52, 90):
            bulge = math.sin((y - 52) / 38 * math.pi) * 4
            half = 17 + round(bulge)
            c.rect(mx + 1 - half, y, half * 2, 1, sail if y % 6 < 3 else sl)
        c.rect(mx - 19, 89, 40, 2, WOOD_D)
        c.rect(mx - 17, 51, 36, 2, WOOD_D)
    c.circle(77, 74, 6, bone)
    c.rect(74, 66, 7, 4, bone)
    c.rect(74, 73, 2, 3, sail); c.rect(79, 73, 2, 3, sail)
    c.line(68, 62, 86, 70, bone, 2); c.line(68, 70, 86, 62, bone, 2)
    c.rect(77, 100, 1, 4, WOOD_D)
    c.rect(78, 98, 10, 5, (0.1, 0.1, 0.1)); c.rect(82, 100, 2, 2, (1, 1, 1))
    c.line(112, 34, 119, 46, WOOD_D, 2)
    c.outline()
    return c.image()


def coconut_icon():
    c = Canvas(16, 16)
    c.shaded(8, 7, 6, 6, (0.45, 0.3, 0.14), 0.25, 0.35)
    c.rect(6, 9, 1, 1, (0.2, 0.12, 0.05)); c.rect(9, 9, 1, 1, (0.2, 0.12, 0.05)); c.rect(7, 7, 1, 1, (0.2, 0.12, 0.05))
    c.outline()
    return c.image()


def stone_icon():
    c = Canvas(16, 16)
    c.shaded(8, 7, 6, 5, STONE, 0.3, 0.4)
    c.noise(0.15, 0.5, 4)
    c.outline()
    return c.image()


def bandage_icon():
    c = Canvas(16, 16)
    w = (0.94, 0.92, 0.88)
    c.shaded(8, 7, 6, 5, w, 0.1, 0.25)
    c.ellipse(8, 7, 2, 1.6, darken(w, 0.3))
    c.rect(4, 11, 3, 2, (0.85, 0.2, 0.2)); c.rect(5, 10, 1, 4, (0.85, 0.2, 0.2))
    c.outline()
    return c.image()


def fruit_icon():
    c = Canvas(16, 16)
    p = (0.55, 0.25, 0.65)
    c.shaded(8, 7, 6, 6, p, 0.3, 0.35)
    for i in range(3):
        c.ellipse(8, 7, 4 - i * 1.3, 4 - i * 1.3, lighten(p, 0.15 + i * 0.12))
        c.ellipse(8, 7, 3.4 - i * 1.3, 3.4 - i * 1.3, p)
    c.rect(8, 13, 1, 2, (0.3, 0.55, 0.2)); c.rect(9, 14, 2, 1, (0.4, 0.7, 0.3))
    c.outline()
    return c.image()
