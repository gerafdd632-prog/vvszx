# 🏴‍☠️ ACTUALIZACIÓN V0.4 - MEJORAS COMPLETAS DEL JUEGO

## 1. 🗺️ Gran Mejora del Mapa y Exploración
- **Madera a la deriva interactiva:** Se añadieron restos de madera en las playas (`driftwood`) que ahora se pueden recolectar con las manos desnudas (sin hacha), evitando quedarse atascado al inicio.
- **Hierbas medicinales silvestres:** Nuevas plantas recolectables a mano alrededor de la charca de agua dulce y en el bosque profundo (`herb`).
- **Nuevas vetas de minerales:** Vetas de Carbón (`ore_coal`) y Azufre Volcánico (`ore_sulfur`) en la Guarida de Contrabandistas (mina del oeste), permitiendo fabricar pólvora y munición.
- **Cofres del Tesoro interactivos:** Sistema de cofres con recompensas de Berries y botín temático según la zona:
  1. *Cofre del Naufragio (Playa de inicio):* Vendas, clavos, botellas vacías y madera.
  2. *Alijo de Contrabandistas (Bosque oeste):* Ron pirata, pólvora y balas de plomo.
  3. *Gran Tesoro de la Cueva (Guarida oeste):* Pistola de chispa, balas de plomo, botiquín y perlas marinas.
  4. *Cofre del Campamento Pirata (Playa sureste):* Ron, pólvora y balas.
  5. *Cofre del Muelle (Barco de Cuervo):* Pólvora y munición.
  6. *Alijo del Faro (Colina norte):* Lingotes de acero, cuero, infusión y antídotos.
  - Los cofres persisten en el guardado (`PlayerProgress`) para que no se puedan abrir repetidamente.

---

## 2. 🐛 Corrección de Bugs
- **Sonido nulo en recursos:** Resuelto el problema donde golpear árboles o rocas sin audio producía excepciones o silencio. Ahora utiliza el sintetizador procedural de audio.
- **Desincronización visual de recursos:** Corregido el desplazamiento progresivo del sprite al golpear repetidamente un recurso rápido.
- **Durabilidad de herramientas:** Golpear recursos ahora desgasta la durabilidad de la herramienta equipada (`InventoryManager.WearItem`) y reproduce la animación de golpe.
- **Duplicación de AudioListeners:** Eliminado el warning de Unity al inicializar limpiando cámaras y AudioListeners residuales antes de generar la cámara 2D.

---

## 3. 🔊 Mejoras Audiovisuales y Jugabilidad
- **Sintetizador Procedural de Audio (`AudioManager.cs`):** 10 sintetizadores de audio en tiempo real generados por código:
  - Tala de madera, extracción de piedra/minerales, recolección de arbustos.
  - Pasos dinámicos en arena y tierra con cadencia según si caminas o corres.
  - Comer, beber, apertura triunfal de cofres, disparo y crafteo.
  - Descanso junto al fuego.
- **Vibración de Cámara (Screen Shake):** Sacudida de cámara al recibir daño en combate.
- **Acceso rápido por teclado (Hotbar 1 al 9):** Teclas del 1 al 9 para equipar herramientas o consumir alimentos de la barra rápida al instante.
- **Sistema de Descanso y Alojamiento:** Presionar [E] en una tienda de campaña permite dormir 6 horas, restaurando energía y salud y avanzando el ciclo día/noche.
- **Hogueras Interactivas:** Presionar [E] en una hoguera seca la ropa, calienta el cuerpo, restaura estamina y abre el menú de cocina.

---

## 4. ⚔️ Catálogo de Nuevos Objetos y Crafteos
- **Nuevos Materiales:** Carbón, Azufre, Pólvora, Cuero, Lingote de Acero, Botella Vacía, Clavos de Hierro, Hierbas Medicinales, Perla Marina.
- **Cocina:** Carne de Jabalí Asada, Pescado a la Brasa, Guiso Marinero, Infusión Revitalizante, Ron Pirata.
- **Medicina:** Ungüento Calmante, Antídoto Herbal, Botiquín de Emergencia.
- **Herramientas:** Pala de Explorador, Antorcha Portátil, Caña de Pescar Rústica.
- **Armas Melee:** Daga de Abordaje (1 AP, crítico), Espada Oficial de la Marina, Maza con Remaches, Lanza de Caza (alcance 2 casillas).
- **Armas de Fuego y Munición:** Tirachinas + Balines de Piedra, Pistola de Chispa + Balas de Plomo con Pólvora, Trabuco de Abordaje.
- **Armaduras:** Sombrero de Paja, Chaleco de Cuero, Capa de la Justicia.
- **35+ Recetas de Fabricación:** Distribuidas en 8 categorías claras dentro del menú de crafteo.

---

## 5. 🎨 Menús y UI Mejorados
- **Menú Principal:** Iconos temáticos piratas en cada botón (`⚔ Continuar`, `⚓ Nueva Partida`, `📜 Cargar Partida`, etc.) y subtítulo *"LAS CRÓNICAS DEL EAST BLUE"*.
- **Menú de Crafteo:** Pestañas visuales para todas las categorías (Herramientas, Armas, Armaduras, Munición, Materiales, Medicina, Cocina, Supervivencia) con sonido al fabricar.
