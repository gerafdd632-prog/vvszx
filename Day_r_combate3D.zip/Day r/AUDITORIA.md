﻿# Auditoría técnica y estabilización — Pirate Survival

> Revisión hecha leyendo el código. **Unity no se ha ejecutado**: nada de esto está probado en el motor.
> Leyenda: **A** = error confirmado por código · **B** = riesgo que requiere prueba en Unity · **C** = mejora recomendada, no bug.
> El código completo de cada archivo modificado está en el zip (ruta `Assets/_Project/Scripts/...`).

## 1. AUDITORÍA

| # | Problema | Sev. | Archivo | Tipo | Solución |
|---|---|---|---|---|---|
| 1 | WaterSource mezclaba beber, mar, estamina y ahogamiento; el daño era `TakeDamage` cada frame | Alta | Interaction/WaterSource.cs | A | WaterSource solo bebe. Nuevo `SeaZone` + `PlayerSwimming` (estados OnLand/Swimming/ExhaustedSwimming/Drowning/DevilFruitWeakness) |
| 2 | Al tocar el mar se perdía vida al instante, sin nadar | Alta | WaterSource.cs | A | Nadar gasta estamina; ahogamiento solo tras 0 de estamina + 3 s, en ticks de 1 s |
| 3 | Usuario de Fruta recibía x3 de daño por frame, sin estados ni lentitud | Alta | WaterSource.cs | A | Debilidad: velocidad x0.2, estamina x7, sin sprint ni poderes, daño progresivo por ticks |
| 4 | `OnPlayerDamaged` se disparaba cada frame con hambre/sed/frío/heridas/mar → destello rojo continuo | Media | PlayerStats.cs, PlayerAnimation2D.cs | A | `TakeDamage(amount, cause, continuous)`: la vida baja exacta, el evento se agrupa cada 1,5 s |
| 5 | No había última posición segura; cargar podía dejarte en el mar o dentro de una roca | Alta | SaveManager.cs | A | `SafePositionTracker` + validación al cargar (guardada → última segura → spawn) |
| 6 | `CurrentSaveVersion = 1`, sin migración ni validación: un JSON con listas nulas lanzaba NRE a mitad de carga y dejaba el mundo a medias | Alta | SaveManager.cs | A | Versión 2, `SaveDataValidator.ValidateAndNormalize` ANTES de aplicar nada |
| 7 | Inventario cargado sin validar: cantidad > máximo, índices fuera de rango, dos entradas en la misma casilla se sobrescribían en silencio | Media | SaveManager.cs | A | Validador: recorta, recoloca en hueco libre o descarta con warning |
| 8 | El arma equipada se restauraba buscando el id en la base de datos, no en la casilla real | Media | SaveManager.cs | A | Solo se equipa si la casilla existe, contiene ese itemId y es Tool/Weapon |
| 9 | No existía causa de muerte; la pantalla siempre decía lo mismo | Media | PlayerStats.cs, HUDManager.cs | A | `DeathCause` + `DeathCauseText`, se reinicia al reaparecer/cargar |
| 10 | El desmayo solo podía ocurrir cargando una partida (no había mecánica) | Media | PlayerStats.cs | A | Estado crítico prolongado (40 s) → desmayo 6 s → 120 s de protección. Agotamiento ≠ desmayo |
| 11 | Lluvia empapaba en 20 s y tormenta en 8 s; el secado actuaba a la vez que la lluvia; ritmos repartidos entre WeatherSystem y PlayerStats | Baja | WeatherSystem.cs, PlayerStats.cs | A | Ritmos centralizados en PlayerStats: lluvia ≈2,8 min, tormenta ≈50 s, mar instantáneo, secado solo sin mojarse |
| 12 | Derrotar cualquier pirata sumaba su recompensa a la del jugador | Media | BattleManager.cs, PlayerProgress.cs | A | `bounty` = del enemigo; nuevo `playerBountyOnDefeat` (solo Marines); `AddPlayerBounty()` |
| 13 | Todo jefe recibía Haki reforzado al bajar al 50% | Media | BossAI.cs | A | `canUseArmamentHaki` / `canUseObservationHaki` en BattleUnit; enfurecerse = +1 AP y +3 ataque |
| 14 | Al entrar en Battle/Pause/Menú el Rigidbody conservaba su velocidad y el jugador seguía deslizándose al volver | Media | PlayerController2D.cs | A | Reacciona a `GameState.OnChanged` → `StopImmediately()`; `ApplyMovement` anula velocidad si el juego está bloqueado |
| 15 | La Fruta del Diablo del suelo desaparecía a los 10 min; al cargar, todos los objetos del suelo reiniciaban su temporizador | Media | WorldItemPickup.cs, SaveManager.cs | A | `ItemData.neverDespawn` (+ toda DevilFruit) y `remainingDespawnSeconds` guardado |
| 16 | Comer la Fruta era un solo clic, irreversible | Media | InventoryManager.cs | A | `GameEvents.RequestConfirmation` → diálogo [Comer]/[Cancelar]; sin UI no se come |
| 17 | Cada reconstrucción del mundo creaba de nuevo todos los ItemData, texturas y sprites (palmera x5, roca x3, piratas por combate…) y sus plantillas | Baja | GameBootstrap.cs, BattleSprites.cs, InteractableTargetIndicator.cs | A | `RuntimeSpriteCache`, base de datos de objetos y plantillas creadas una vez (raíz `RuntimeTemplates` persistente) |
| 18 | `HarvestableResource.Awake` registraba el nombre del GameObject antes de que Bootstrap inyectase el ID real (registro de duplicados con claves incorrectas) | Baja | HarvestableResource.cs, GameBootstrap.cs | A | `SetResourceId()` re-registra; Bootstrap lo usa en vez de reflexión |
| 19 | Huir colocaba al jugador 1,5 u más allá sin comprobar si era mar o roca | Media | BattleManager.cs | B | Se valida; si no es seguro usa la última posición segura |
| 20 | Compañeros de tripulación se colocaban antes que los enemigos (podían ocupar su casilla) | Baja | BattleManager.cs | B (no hay tripulación aún) | Enemigos primero, luego tripulación |
| 21 | Guardar/autoguardar desmayado o nadando | Media | SaveManager.cs | A | Rechazado con aviso (y autoguardado lo salta) |
| 22 | Se podía empezar un combate desmayado; el inventario no se cerraba al desmayarse | Baja | BattleEncounter.cs, InventoryUI.cs | A | Bloqueado / se cierra |
| 23 | `GetSlotInfo` con `playerStats`/`worldData` nulos lanzaba excepción y la ranura parecía vacía | Baja | SaveManager.cs | A | Lecturas con null-check |
| 24 | Las habilidades de Fruta seguían disponibles dentro del mar | Baja | AbilityController.cs | A | Bloqueadas si `PlayerSwimming.FruitPowersBlocked` |
| 25 | Refugios: `SetSheltered` existe pero nada lo llama | — | PlayerStats.cs | C | La API bloquea lluvia correctamente; falta el objeto refugio (fase de mapa) |
| 26 | `GameEvents.OnPlayerDeath` no lleva la causa; HUD la lee con `FindFirstObjectByType` una vez al morir | — | HUDManager.cs | C | Aceptable (evento raro). Cambiar la firma rompería suscriptores |
| 27 | Disparar a un barril/caja no gasta munición del jugador (no hay armas de fuego del jugador) | — | BattleManager.cs | C | Ruta de munición existe en `Attack`; añadir en `AttackObject` cuando haya pistola |

**BattleManager — puntos pedidos, revisados y sin cambio necesario (A = comprobado por código):**
AP nunca negativos (todas las acciones pasan por `CanAttack/CanUseAbility/CanFlee` o comprobación de AP) · cooldowns se descuentan al inicio del turno propio · muerte durante corrutina: `HandlePlayerDeath → StopAllCoroutines → Close()` deja `Busy=false`, UI oculta, `InBattle=false`, `GameState=Playing` y el encuentro solo desarmado hasta que te alejas · victoria durante explosiones: `AfterPlayerAction/RoundLoop` llaman a `CheckVictory` · contraataque solo si defiende, cuerpo a cuerpo y no es ya un contraataque · arma rota → puños · Battle→Pause→Battle: `Wait()` se congela en pausa y `Resume()` vuelve a Battle · cargar en combate: `AbortBattle()` antes de aplicar · `AbortBattle` no deja suscripciones activas que actúen (`HandlePlayerDeath` sale si `!IsActive`).

## 2. CAMBIOS POR ARCHIVO

**Nuevos**
- `Environment/Water/SeaZone.cs` — marca agua profunda (trigger). `SeaZone.IsDeepWaterAt(Vector2)`.
- `Environment/Water/SeaState.cs` — enum de estados acuáticos.
- `Environment/Water/PlayerSwimming.cs` — natación, agotamiento, ahogamiento por ticks, debilidad de Fruta, avisos. Depende de PlayerStats y DevilFruitManager.
- `Player/DeathCause.cs` — enum + textos de la pantalla de muerte.
- `Player/SafePositionTracker.cs` — muestreo cada 1 s y `IsValidLandPosition()` (finito, límites ±33, fuera de SeaZone, sin colliders sólidos salvo los propios).
- `Core/RuntimeSpriteCache.cs` — caché de sprites generados; `Clear()` explícito (no se llama en la reconstrucción normal).
- `SaveSystem/SaveDataValidator.cs` — migración v1→v2 y normalización con warnings `[SaveData]`.
- `Editor/TechnicalAudit.cs` — menú **Pirate Survival/Auditoría técnica**.

**Modificados** (qué estaba mal → qué cambia → dependencias)
- `Player/PlayerStats.cs` — sin causa de muerte, daño con spam visual, desmayo inexistente, humedad dispersa → `TakeDamage(float, DeathCause, bool)` (se conserva `TakeDamage(float)`), `LastDeathCause`, desmayo crítico, `AddRainWetness`/`Soak`/`SetSwimming`, sin regeneración ni sprint nadando. Usado por WaterSource, PlayerWounds, PlayerSwimming, BattleUnit, InventoryManager, HUD.
- `Player/PlayerController2D.cs` — deslizamiento tras cambiar de estado → `StopImmediately()` + `GameState.OnChanged`; velocidad x multiplicador de natación; sin sprint en el agua.
- `Interaction/WaterSource.cs` — ahora solo beber (dulce/salada). Eliminado `causesDrowning` y `OnTriggerStay2D`.
- `Environment/WeatherSystem.cs` — elimina `rainWetnessRate/stormWetnessRate`; llama a `PlayerStats.AddRainWetness`.
- `Player/PlayerWounds.cs` — daño continuo con causa Bleeding/Poison.
- `SaveSystem/SaveData.cs` — v2: `lastSafeLandPosition`, `hasLastSafeLandPosition`, `PickupSaveData.remainingDespawnSeconds`.
- `SaveSystem/SaveManager.cs` — versión 2, validación previa, aplicación separada (`ApplySaveData`), arma equipada estricta, posición validada, temporizador de objetos, guardado bloqueado en estados inseguros, `DefaultSpawnPoint` público (lo usa la auditoría).
- `Inventory/InventoryManager.cs` — Fruta con confirmación (`ConfirmEatDevilFruit` revalida la casilla).
- `Inventory/ItemData.cs` — `neverDespawn`.
- `Interaction/WorldItemPickup.cs` — `IsPersistent`, `RemainingDespawnSeconds`, `SetRemainingDespawnSeconds`.
- `Interaction/HarvestableResource.cs` — `SetResourceId`.
- `Core/GameEvents.cs` — `OnConfirmationRequested` / `RequestConfirmation`.
- `UI/MenuManager.cs` — diálogo de confirmación con textos configurables, usable desde el juego sin abrir menús.
- `UI/HUDManager.cs` + `Bootstrap/GameUIBuilder.cs` — texto de causa de muerte; icono de temperatura cacheado.
- `Inventory/UI/InventoryUI.cs` — se cierra al desmayarse.
- `Combat/BattleUnit.cs` — `playerBountyOnDefeat`, `canUseArmamentHaki`, `canUseObservationHaki`, `ApplyDamage(int, DeathCause = Combat)`.
- `Combat/BattleManager.cs` — causas de muerte en combate, recompensa del jugador separada, huida segura, orden enemigos/tripulación.
- `Combat/StatusEffectSystem.cs` — `StatusDamage` con causa.
- `Combat/AI/BossAI.cs`, `Combat/EnemyLibrary.cs` — Haki configurable; Marines suben la recompensa del jugador.
- `Combat/AbilityController.cs` — sin poderes de Fruta en el mar.
- `Combat/BattleEncounter.cs` — no se activa desmayado.
- `Combat/BattleSprites.cs`, `UI/InteractableTargetIndicator.cs` — sprites cacheados.
- `Player/PlayerProgress.cs` — `AddBounty` → `AddPlayerBounty` (única llamada: BattleManager).
- `Bootstrap/GameBootstrap.cs` — base de datos y plantillas una sola vez, sprites cacheados, `NewClearTexture` (quita 8 bucles duplicados), mar = SeaZone + WaterSource salada, añade PlayerSwimming y SafePositionTracker al jugador. Isla, encuentros y creación automática intactos.

## 3. COMPILATION REVIEW

Revisión manual (dos pasadas, una independiente) contra el código:
- **Namespaces/using**: DeathCause/SafePositionTracker → `PirateSurvival.Player`; SeaZone/PlayerSwimming/SeaState → `PirateSurvival.Environment`; RuntimeSpriteCache → `PirateSurvival.Core`; SaveDataValidator → `PirateSurvival.SaveSystem`. Todos los archivos que los usan tienen el `using`.
- **Firmas**: `TakeDamage(float)` y `TakeDamage(float, DeathCause, bool=false)` sin ambigüedad; `ApplyDamage(int, DeathCause=Combat)`; `LoadSlot(int, ItemData, int, int=0)`; `Confirm(string, Action, string="Sí", string="No")`.
- **Enums**: `DeathCause`, `SeaState`, `GameScreen.Battle` usados con sus valores existentes.
- **Eventos**: cada `+=` de GameEvents/GameState tiene su `-=` en OnDisable (comprobado por script en todos los archivos).
- **Visibilidad**: `GameBootstrap.CreateTemperatureSprite` es `internal`; `InjectField` `internal`; nada de UnityEditor fuera de `Editor/` salvo `#if UNITY_EDITOR`.
- **Constructores**: `Vector3Data(Vector2)` y `Vector3Data(Vector3)` resuelven sin ambigüedad.
- ⚠️ No compilado de verdad: puede quedar algún error que solo detecte el compilador de Unity.

## 4. UNITY TEST PLAN

Errores que NO deben aparecer en ninguno: `NullReferenceException`, `MissingReferenceException`, `InvalidOperationException`, `[GameBootstrap] Campo '...' no encontrado`, errores rojos de compilación.

1. **Nueva partida** — Escena vacía → Play → "Nueva Partida". *Esperado*: isla, HUD, coco x2 y hacha en el inventario, reloj avanzando. Sin warnings `[SaveData]`.
2. **Guardar** — Pausa (ESC) → Guardar → Ranura 1. *Esperado*: "Partida guardada en la ranura 1". JSON en `persistentDataPath` con `"saveVersion": 2` y `lastSafeLandPosition`.
3. **Cargar** — Muévete, tala un árbol, carga la ranura 1. *Esperado*: posición, árbol e inventario restaurados; arma equipada solo si estaba equipada.
4. **Mar sin fruta** — Camina hacia el mar. *Esperado*: aviso "Estás nadando", velocidad reducida, sin sprint, la energía baja (~5/s), la vida NO baja. Con 0 de energía: aviso, 3 s después −5 PV por segundo, un destello por tick. Sal del agua: se corta al instante.
5. **Mar con fruta** — Come la Fruta, entra al mar. *Esperado*: aviso de Fruta, casi inmóvil, energía cae muy rápido; tras 1,5 s daño 4, 6, 8… por segundo. Salir cancela.
6. **Lluvia** — Espera a lluvia (o pon `currentWeather` a Rain en el Inspector). *Esperado*: humedad sube ~1% cada 1,7 s (≈2,8 min a 100%); con tormenta ≈50 s; al parar, seca despacio.
7. **Desmayo** — En el Inspector de PlayerStats sube `thirstDecayRate` a 5 (la sed llega a 0 en ~20 s). *Esperado*: unos 40 s después "Te desmayas", 6 s sin moverte ni abrir inventario; no vuelve a pasar en 120 s. Correr hasta 0 de energía NO desmaya.
8. **Muerte hambre** — En PlayerStats sube `hungerDecayRate` a 50 y `starvationDamage` a 20. *Esperado*: pantalla "Has muerto de hambre."; el destello no parpadea cada frame.
9. **Muerte ahogamiento** — Nada hasta morir. *Esperado*: "Te has ahogado." (con fruta: "El mar ha reclamado…").
10. **Fruta** — Recoge la Fruta (oeste) y haz clic. *Esperado*: diálogo [Comer]/[Cancelar]; Cancelar no la consume; Comer la consume. Guarda y carga: las habilidades siguen en combate y la debilidad en el mar también.
11. **Primer combate** — Piratas playa sureste. *Esperado*: el jugador se para en seco; gana/pierde; tras ganar no sube la recompensa del jugador.
12. **Jefe** — Capitán Cuervo (costa norte). *Esperado*: al 50% "se enfurece" SIN mensaje de Haki.
13. **Inventario** — Arrastra, suelta (Shift+clic), equipa/desequipa, guarda y carga. *Esperado*: sin duplicados ni casillas perdidas.
14. **Arma rota** — En el Inspector baja la durabilidad del sable a 1 (InventoryManager → slots) y ataca. *Esperado*: "¡Tu Sable… se ha roto!", pasas a puños.
15. **Pausar en combate** — ESC durante el turno enemigo. *Esperado*: el enemigo se detiene; Reanudar vuelve al combate; "Guardar" muestra "No puedes guardar durante un combate."
16. **Volver al menú** — Pausa → Menú Principal → Sí. *Esperado*: menú principal, mundo nuevo detrás, sin errores.
17. **New Game tras volver al menú** — "Nueva Partida". *Esperado*: mundo limpio, Fruta y venda de nuevo en el suelo.
18. **Save v1 antiguo** — Edita un JSON: `"saveVersion": 1`, borra `lastSafeLandPosition`, pon `"inventorySlots": null`. Carga. *Esperado*: warnings `[SaveData]` ("Migrado guardado v1", "inventorySlots ausente"), la partida carga.
19. **Posición inválida** — Edita `playerPosition` a (20, 0) (mar) o `NaN`. *Esperado*: warning y apareces en la última posición segura o en (0,0), nunca en el agua.
20. **Reconstruir varias veces** — Menú principal → Nueva Partida ×5. *Esperado*: sin errores; en el Profiler, el número de Texture2D no crece en cada vuelta.

## 5. FINAL CHECKLIST

| Criterio | Estado |
|---|---|
| WaterSource ya no controla el ahogamiento | ✅ código |
| SeaZone separado | ✅ código |
| Jugador normal nada antes de ahogarse | ✅ código · ⚠️ balance en Unity |
| Usuario de Fruta se debilita en el mar | ✅ código · ⚠️ sensación en Unity |
| Daño continuo sin destello cada frame | ✅ código |
| LastSafeLandPosition | ✅ código |
| Posiciones cargadas validadas | ✅ código · ⚠️ depende de colliders (Physics2D.SyncTransforms) |
| Save v2 con fallback v1 | ✅ código · ⚠️ probar con un JSON v1 real |
| Listas nulas no rompen la carga | ✅ código (JsonUtility puede dejar nulos; se normalizan) |
| Slots inválidos no rompen la carga | ✅ código |
| Arma equipada validada | ✅ código |
| DeathCause + HUD | ✅ código |
| Desmayo real y razonable | ✅ código · ⚠️ ajustar 40 s / 120 s jugando |
| Humedad reequilibrada | ✅ código · ⚠️ balance |
| Combate sigue funcionando | ⚠️ no ejecutado |
| Bounty del enemigo no sube la del jugador | ✅ código |
| Jefes sin Haki automático | ✅ código |
| Sprites repetidos cacheados | ✅ código · ⚠️ confirmar en Profiler |
| Sin suscripciones a eventos destruidos | ✅ código (paridad +=/-= verificada) |
| Jugador se detiene en Battle/Pause/Menu | ✅ código |
| Objetos únicos sin despawn | ✅ código |
| Fruta con confirmación | ✅ código |
| Nueva partida / guardar / cargar / menú / RebuildWorld | ⚠️ necesitan Unity |

**Riesgos que conozco y no puedo descartar sin Unity**
- Si `Physics2D.autoSyncTransforms` está desactivado y algún collider no se ha registrado aún, la validación de posición podría aceptar una posición dentro de un collider (mitigado con `Physics2D.SyncTransforms()`).
- `PolygonCollider2D` con agujero: `OverlapPoint` debe respetar el hueco (isla). Si no, verías "Estás nadando" en tierra → avísame.
- Mientras el diálogo de la Fruta está abierto el juego sigue corriendo (no se pausa).
