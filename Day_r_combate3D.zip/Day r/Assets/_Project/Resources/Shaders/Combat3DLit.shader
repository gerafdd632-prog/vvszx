// Shader opaco del combate 3D. La luz viene "horneada" en los colores de vértice (Combat3DMesh),
// así funciona igual con el Renderer 2D de URP, que ignora las luces 3D.
// Extras: textura, recorte alfa (sprites de personajes), destello de golpe y niebla por distancia.
// No usa _Time: el juego congela Time.timeScale durante el combate, la animación va por script.
Shader "PirateSurvival/Combat3DLit"
{
    Properties
    {
        _MainTex ("Textura", 2D) = "white" {}
        _Color ("Tinte", Color) = (1,1,1,1)
        _Cutoff ("Recorte alfa", Range(0,1)) = 0
        _FlashColor ("Color destello", Color) = (1,1,1,1)
        _Flash ("Destello", Range(0,1)) = 0
        _FogAmount ("Niebla (multiplicador)", Range(0,1)) = 1
        [Enum(UnityEngine.Rendering.CullMode)] _Cull ("Cull", Float) = 2
    }
    SubShader
    {
        Tags { "RenderType"="Opaque" "Queue"="Geometry" "IgnoreProjector"="True" }
        Pass
        {
            Cull [_Cull]
            ZWrite On
            ZTest LEqual

            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "UnityCG.cginc"

            sampler2D _MainTex;
            float4 _MainTex_ST;
            fixed4 _Color;
            fixed _Cutoff;
            fixed4 _FlashColor;
            fixed _Flash;
            fixed _FogAmount;

            // Globales que fija Combat3DArena (Shader.SetGlobal*)
            float4 _C3DFogColor;
            float4 _C3DFogParams; // x = inicio, y = fin, z = máximo

            struct appdata
            {
                float4 vertex : POSITION;
                float2 uv : TEXCOORD0;
                fixed4 color : COLOR;
            };

            struct v2f
            {
                float4 pos : SV_POSITION;
                float2 uv : TEXCOORD0;
                fixed4 color : COLOR;
                float fog : TEXCOORD1;
            };

            v2f vert (appdata v)
            {
                v2f o;
                o.pos = UnityObjectToClipPos(v.vertex);
                o.uv = TRANSFORM_TEX(v.uv, _MainTex);
                o.color = v.color * _Color;
                float dist = length(UnityObjectToViewPos(v.vertex));
                float span = max(0.001, _C3DFogParams.y - _C3DFogParams.x);
                o.fog = saturate((dist - _C3DFogParams.x) / span) * _C3DFogParams.z * _FogAmount;
                return o;
            }

            fixed4 frag (v2f i) : SV_Target
            {
                fixed4 c = tex2D(_MainTex, i.uv) * i.color;
                clip(c.a - _Cutoff);
                c.rgb = lerp(c.rgb, _FlashColor.rgb, _Flash);
                c.rgb = lerp(c.rgb, _C3DFogColor.rgb, i.fog);
                c.a = 1;
                return c;
            }
            ENDCG
        }
    }
    Fallback Off
}
