﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace PirateSurvival.SaveSystem
{
    /// <summary>
    /// Estructuras serializables para guardado en JSON (A2.16: constructores sin parámetros incluidos).
    /// </summary>
    [Serializable]
    public class Vector3Data
    {
        public float x;
        public float y;
        public float z;

        public Vector3Data()
        {
            x = 0f;
            y = 0f;
            z = 0f;
        }

        public Vector3Data(Vector3 vec)
        {
            x = vec.x;
            y = vec.y;
            z = vec.z;
        }

        public Vector3Data(Vector2 vec)
        {
            x = vec.x;
            y = vec.y;
            z = 0f;
        }

        public Vector3 ToVector3() => new Vector3(x, y, z);
        public Vector2 ToVector2() => new Vector2(x, y);
    }

    [Serializable]
    public class PlayerStatsData
    {
        public float health;
        public float hunger;
        public float thirst;
        public float stamina;
        public float temperature;
        public float wetness;
        public bool isFainted;

        public PlayerStatsData()
        {
            health = 100f;
            hunger = 100f;
            thirst = 100f;
            stamina = 100f;
            temperature = 36.6f;
            wetness = 0f;
            isFainted = false;
        }
    }

    [Serializable]
    public class SlotSaveData
    {
        public int slotIndex;
        public string itemId;
        public int quantity;
        public int durability; // 0 = sin desgaste guardado (nuevo)

        public SlotSaveData()
        {
            slotIndex = 0;
            itemId = string.Empty;
            quantity = 0;
        }
    }

    [Serializable]
    public class PickupSaveData
    {
        public string itemId;
        public int quantity;
        public Vector3Data position;
        public float remainingDespawnSeconds; // v2: <= 0 = temporizador completo (o sin despawn si es un objeto importante)

        public PickupSaveData()
        {
            itemId = string.Empty;
            quantity = 1;
            position = new Vector3Data();
            remainingDespawnSeconds = 0f;
        }
    }

    [Serializable]
    public class HarvestedResourceSaveData
    {
        public string resourceId;
        public bool isHarvested;
        public float remainingRespawnTime;

        public HarvestedResourceSaveData()
        {
            resourceId = string.Empty;
            isHarvested = false;
            remainingRespawnTime = 0f;
        }
    }

    [Serializable]
    public class WorldSaveData
    {
        public float timeOfDay;
        public string weather;
        public float weatherTimer;

        public WorldSaveData()
        {
            timeOfDay = 8f;
            weather = "Clear";
            weatherTimer = 0f;
        }
    }

    [Serializable]
    public class GameSaveData
    {
        public int saveVersion = 1;
        public string saveDate;
        public Vector3Data playerPosition;
        public PlayerStatsData playerStats;
        public string equippedToolId;
        public int equippedSlotIndex = -1;
        public List<SlotSaveData> inventorySlots = new List<SlotSaveData>();
        public List<PickupSaveData> worldPickups = new List<PickupSaveData>();
        public List<HarvestedResourceSaveData> harvestedResources = new List<HarvestedResourceSaveData>();
        public WorldSaveData worldData;
        public int experience;
        public int bounty;
        public List<string> defeatedEncounters = new List<string>();
        public string devilFruitId = "";
        public bool hakiObservation;
        public bool hakiArmament;
        public bool hakiConqueror;
        public float bleedSeconds;
        public float poisonSeconds;
        public List<PirateSurvival.Player.CrewMemberData> crew = new List<PirateSurvival.Player.CrewMemberData>();
        // v2
        public Vector3Data lastSafeLandPosition;
        public bool hasLastSafeLandPosition;
        /// <summary>
        /// true = worldPickups es una foto completa del suelo (una lista vacía significa "todo recogido").
        /// false = el guardado no traía esa información (v1 o lista corrupta): se conservan los objetos iniciales del mundo.
        /// Inicializado a true para que los v2 anteriores a este campo (que sí guardaban la foto) se carguen como tal.
        /// </summary>
        public bool hasWorldPickupSnapshot = true;
        /// <summary>Modo historia: flags conseguidos (diálogos, objetivos, fabricaciones). Vacío en guardados antiguos.</summary>
        public List<string> storyFlags = new List<string>();
        public string playerName = "Náufrago";
        public string playerLookJson = "";

        public GameSaveData()
        {
            saveVersion = 1;
            saveDate = string.Empty;
            playerPosition = new Vector3Data();
            playerStats = new PlayerStatsData();
            equippedToolId = string.Empty;
            equippedSlotIndex = -1;
            inventorySlots = new List<SlotSaveData>();
            worldPickups = new List<PickupSaveData>();
            harvestedResources = new List<HarvestedResourceSaveData>();
            worldData = new WorldSaveData();
            experience = 0;
            defeatedEncounters = new List<string>();
            devilFruitId = string.Empty;
            crew = new List<PirateSurvival.Player.CrewMemberData>();
            lastSafeLandPosition = new Vector3Data();
            hasLastSafeLandPosition = false;
            hasWorldPickupSnapshot = true;
            storyFlags = new List<string>();
            playerName = "Náufrago";
            playerLookJson = "";
        }
    }
}
