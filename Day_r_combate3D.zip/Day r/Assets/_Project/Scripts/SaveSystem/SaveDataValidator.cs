﻿using System;
using System.Collections.Generic;
using UnityEngine;
using PirateSurvival.Inventory;
using PirateSurvival.Player;

namespace PirateSurvival.SaveSystem
{
    /// <summary>
    /// Valida, migra (v1 → v2) y normaliza un GameSaveData recién leído ANTES de aplicarlo al mundo.
    /// Repara lo recuperable con un warning claro y descarta entradas imposibles, sin perder la partida
    /// por una lista secundaria ausente. Devuelve false solo si no hay nada que cargar (data == null).
    /// </summary>
    public static class SaveDataValidator
    {
        private const string Tag = "[SaveData]";

        public static bool ValidateAndNormalize(GameSaveData data, int inventorySlotCount, Func<string, ItemData> findItem)
        {
            if (data == null)
            {
                Debug.LogError($"{Tag} Datos nulos: no se puede cargar.");
                return false;
            }

            Migrate(data);

            if (data.saveDate == null) data.saveDate = string.Empty;
            if (data.equippedToolId == null) data.equippedToolId = string.Empty;
            if (data.equippedSlotIndex < -1 || data.equippedSlotIndex >= inventorySlotCount)
            {
                Warn($"equippedSlotIndex {data.equippedSlotIndex} fuera de rango: sin arma equipada.");
                data.equippedSlotIndex = -1;
                data.equippedToolId = string.Empty;
            }
            if (data.devilFruitId == null) data.devilFruitId = string.Empty;
            if (data.experience < 0) { Warn("Experiencia negativa → 0."); data.experience = 0; }
            if (data.bounty < 0) { Warn("Recompensa negativa → 0."); data.bounty = 0; }
            data.bleedSeconds = NonNegative(data.bleedSeconds, "bleedSeconds");
            data.poisonSeconds = NonNegative(data.poisonSeconds, "poisonSeconds");

            ValidateStats(data);
            ValidatePositions(data);
            ValidateWorld(data);
            ValidateInventory(data, inventorySlotCount, findItem);
            ValidatePickups(data, findItem);
            ValidateResources(data);
            ValidateProgress(data);
            ValidateCrew(data);
            return true;
        }

        private static void Migrate(GameSaveData data)
        {
            if (data.saveVersion < 1)
            {
                Warn($"Versión de guardado desconocida ({data.saveVersion}); se trata como v1.");
                data.saveVersion = 1;
            }
            if (data.saveVersion > SaveManager.CurrentSaveVersion)
            {
                Warn($"Guardado de una versión más nueva ({data.saveVersion}) que el juego ({SaveManager.CurrentSaveVersion}). Se intenta cargar igualmente.");
                return;
            }
            if (data.saveVersion == 1)
            {
                // v1 no tenía última posición segura, ni temporizador, ni una foto fiable de los objetos del suelo
                data.hasLastSafeLandPosition = false;
                data.hasWorldPickupSnapshot = false;
                data.lastSafeLandPosition = new Vector3Data();
                if (data.worldPickups != null)
                    foreach (PickupSaveData p in data.worldPickups)
                        if (p != null) p.remainingDespawnSeconds = 0f;
                Debug.Log($"{Tag} Migrado guardado v1 → v{SaveManager.CurrentSaveVersion}.");
                data.saveVersion = SaveManager.CurrentSaveVersion;
            }
        }

        private static void ValidateStats(GameSaveData data)
        {
            if (data.playerStats == null)
            {
                Warn("playerStats ausente: se usan valores por defecto.");
                data.playerStats = new PlayerStatsData();
            }
            PlayerStatsData s = data.playerStats;
            s.health = Range(s.health, 1f, 1000f, 50f, "health");
            s.hunger = Range(s.hunger, 0f, 1000f, 50f, "hunger");
            s.thirst = Range(s.thirst, 0f, 1000f, 50f, "thirst");
            s.stamina = Range(s.stamina, 0f, 1000f, 50f, "stamina");
            s.temperature = Range(s.temperature, 20f, 44f, 36.6f, "temperature");
            s.wetness = Range(s.wetness, 0f, 1f, 0f, "wetness");
        }

        private static void ValidatePositions(GameSaveData data)
        {
            if (data.playerPosition == null || !Finite(data.playerPosition))
            {
                Warn("playerPosition ausente o inválida: se usará la última posición segura o el punto de aparición.");
                data.playerPosition = new Vector3Data(new Vector3(float.NaN, float.NaN, 0f));
            }
            if (data.lastSafeLandPosition == null || !Finite(data.lastSafeLandPosition))
            {
                data.lastSafeLandPosition = new Vector3Data();
                data.hasLastSafeLandPosition = false;
            }
        }

        private static void ValidateWorld(GameSaveData data)
        {
            if (data.worldData == null)
            {
                Warn("worldData ausente: hora 08:00 y cielo despejado.");
                data.worldData = new WorldSaveData();
            }
            WorldSaveData w = data.worldData;
            w.timeOfDay = Range(w.timeOfDay, 0f, 24f, 8f, "timeOfDay");
            if (string.IsNullOrEmpty(w.weather)) w.weather = "Clear";
            w.weatherTimer = NonNegative(w.weatherTimer, "weatherTimer");
        }

        private static void ValidateInventory(GameSaveData data, int slotCount, Func<string, ItemData> findItem)
        {
            if (data.inventorySlots == null)
            {
                Warn("inventorySlots ausente: inventario vacío.");
                data.inventorySlots = new List<SlotSaveData>();
                return;
            }

            var clean = new List<SlotSaveData>();
            var used = new HashSet<int>();
            var displaced = new List<SlotSaveData>();
            foreach (SlotSaveData e in data.inventorySlots)
            {
                if (e == null || string.IsNullOrEmpty(e.itemId)) { Warn("Casilla sin itemId: ignorada."); continue; }
                ItemData item = findItem(e.itemId);
                if (item == null) { Warn($"Objeto '{e.itemId}' no existe en la base de datos: ignorado."); continue; }
                if (e.quantity <= 0) { Warn($"'{e.itemId}' con cantidad {e.quantity}: ignorado."); continue; }
                int maxStack = Mathf.Max(1, item.maxStackSize);
                if (e.quantity > maxStack) { Warn($"'{e.itemId}' x{e.quantity} supera el máximo ({maxStack}): recortado."); e.quantity = maxStack; }
                if (e.durability < 0) { Warn($"'{e.itemId}' con durabilidad negativa: se restaura al máximo."); e.durability = 0; }
                if (item.maxDurability > 0 && e.durability > item.maxDurability) { Warn($"'{e.itemId}' durabilidad {e.durability} > {item.maxDurability}: recortada."); e.durability = item.maxDurability; }
                if (item.maxDurability <= 0) e.durability = 0;

                if (e.slotIndex < 0 || e.slotIndex >= slotCount || used.Contains(e.slotIndex))
                {
                    Warn($"'{e.itemId}' en la casilla {e.slotIndex} (fuera de rango u ocupada): se recoloca.");
                    displaced.Add(e);
                    continue;
                }
                used.Add(e.slotIndex);
                clean.Add(e);
            }

            // Recolocar en huecos libres en vez de sobrescribir otra casilla
            foreach (SlotSaveData e in displaced)
            {
                int free = -1;
                for (int i = 0; i < slotCount; i++) if (!used.Contains(i)) { free = i; break; }
                if (free < 0) { Warn($"Sin casillas libres para '{e.itemId}': descartado."); continue; }
                e.slotIndex = free;
                used.Add(free);
                clean.Add(e);
            }
            data.inventorySlots = clean;
        }

        private static void ValidatePickups(GameSaveData data, Func<string, ItemData> findItem)
        {
            if (data.worldPickups == null)
            {
                // No confundir con "lo recogí todo" (lista vacía con foto): sin datos se conservan los objetos iniciales
                Warn("worldPickups ausente: se mantienen los objetos del suelo del mundo nuevo.");
                data.worldPickups = new List<PickupSaveData>();
                data.hasWorldPickupSnapshot = false;
                return;
            }
            var clean = new List<PickupSaveData>();
            foreach (PickupSaveData p in data.worldPickups)
            {
                if (p == null || string.IsNullOrEmpty(p.itemId)) continue;
                ItemData item = findItem(p.itemId);
                if (item == null) { Warn($"Objeto de suelo '{p.itemId}' inexistente: ignorado."); continue; }
                if (p.quantity <= 0) continue;
                if (p.position == null || !Finite(p.position)) { Warn($"Objeto de suelo '{p.itemId}' sin posición válida: ignorado."); continue; }
                p.quantity = Mathf.Min(p.quantity, Mathf.Max(1, item.maxStackSize));
                p.remainingDespawnSeconds = NonNegative(p.remainingDespawnSeconds, "remainingDespawnSeconds");
                clean.Add(p);
            }
            data.worldPickups = clean;
        }

        private static void ValidateResources(GameSaveData data)
        {
            if (data.harvestedResources == null)
            {
                Warn("harvestedResources ausente: todos los recursos aparecen sin talar.");
                data.harvestedResources = new List<HarvestedResourceSaveData>();
                return;
            }
            data.harvestedResources.RemoveAll(r => r == null || string.IsNullOrEmpty(r.resourceId));
            foreach (HarvestedResourceSaveData r in data.harvestedResources)
                r.remainingRespawnTime = NonNegative(r.remainingRespawnTime, "remainingRespawnTime");
        }

        private static void ValidateProgress(GameSaveData data)
        {
            if (data.defeatedEncounters == null)
            {
                Warn("defeatedEncounters ausente: lista vacía.");
                data.defeatedEncounters = new List<string>();
            }
            data.defeatedEncounters.RemoveAll(string.IsNullOrEmpty);
        }

        private static void ValidateCrew(GameSaveData data)
        {
            if (data.crew == null)
            {
                data.crew = new List<CrewMemberData>();
                return;
            }
            data.crew.RemoveAll(c => c == null || string.IsNullOrEmpty(c.id));
            foreach (CrewMemberData c in data.crew)
            {
                c.maxHp = Mathf.Max(1, c.maxHp);
                c.hp = Mathf.Clamp(c.hp, 0, c.maxHp);
                c.maxAp = Mathf.Clamp(c.maxAp, 1, 12);
                c.weaponMinRange = Mathf.Max(1, c.weaponMinRange);
                c.weaponMaxRange = Mathf.Max(c.weaponMinRange, c.weaponMaxRange);
                c.weaponApCost = Mathf.Max(1, c.weaponApCost);
                c.weaponAccuracy = Range(c.weaponAccuracy, 0.05f, 1f, 0.85f, "crew.weaponAccuracy");
                if (c.name == null) c.name = "Tripulante";
                if (c.weaponName == null) c.weaponName = "Puños";
            }
        }

        // ------------------------------------------------------------------ utilidades

        private static bool Finite(Vector3Data v) => IsFinite(v.x) && IsFinite(v.y) && IsFinite(v.z);
        private static bool IsFinite(float f) => !float.IsNaN(f) && !float.IsInfinity(f);

        private static float Range(float value, float min, float max, float fallback, string name)
        {
            if (!IsFinite(value)) { Warn($"{name} no es un número válido → {fallback}."); return fallback; }
            if (value < min || value > max)
            {
                float c = Mathf.Clamp(value, min, max);
                Warn($"{name} = {value} fuera de [{min}, {max}] → {c}.");
                return c;
            }
            return value;
        }

        private static float NonNegative(float value, string name)
        {
            if (!IsFinite(value) || value < 0f)
            {
                Warn($"{name} = {value} inválido → 0.");
                return 0f;
            }
            return value;
        }

        private static void Warn(string message) => Debug.LogWarning($"{Tag} {message}");
    }
}
