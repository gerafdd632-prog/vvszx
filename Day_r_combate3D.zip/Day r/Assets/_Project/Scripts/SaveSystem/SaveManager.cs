﻿using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using PirateSurvival.Core;
using PirateSurvival.Player;
using PirateSurvival.Inventory;
using PirateSurvival.Interaction;
using PirateSurvival.Environment;
using PirateSurvival.UI;
using PirateSurvival.Combat;

namespace PirateSurvival.SaveSystem
{
    /// <summary>Resumen de una ranura para los menús.</summary>
    public struct SaveSlotInfo
    {
        public bool exists;
        public string saveDate;
        public float health;
        public float timeOfDay;
    }

    /// <summary>
    /// Gestor de guardado en 2D (Item D, A2.10, Puntos 11 y 18).
    /// Escritura atómica con File.Replace y respaldo .bak, restauración desde .bak si el archivo está corrupto,
    /// versión 2 con migración desde v1 y validación completa (SaveDataValidator) ANTES de tocar el mundo,
    /// posición cargada validada (con LastSafeLandPosition y punto de aparición como respaldo),
    /// autoguardado periódico bloqueado en estados inseguros (muerto, combate, desmayo, nadando).
    /// </summary>
    public class SaveManager : MonoBehaviour
    {
        public static SaveManager Instance { get; private set; }

        public const int CurrentSaveVersion = 2;
        public const int SlotCount = 3;

        [Header("Ranura Activa")]
        [Tooltip("Índice de la ranura de guardado (1, 2, 3...)")]
        [SerializeField] private int activeSlot = 1;

        [Header("Autoguardado (Punto 11)")]
        [Tooltip("Intervalo de autoguardado en minutos (0 para desactivar)")]
        [SerializeField] private float autosaveIntervalMinutes = 5.0f;
        private float autosaveTimer;

        [Header("Base de Datos de Objetos")]
        [Tooltip("Lista de todos los ScriptableObjects de objetos del juego")]
        [SerializeField] private List<ItemData> itemDatabase = new List<ItemData>();

        [Header("Referencias Cacheadas (Punto 18)")]
        [SerializeField] private PlayerController2D playerController;
        [SerializeField] private PlayerStats playerStats;
        [SerializeField] private InventoryManager inventoryManager;
        [SerializeField] private DayNightCycle dayNightCycle;
        [SerializeField] private WeatherSystem weatherSystem;
        [SerializeField] private HUDManager hudManager;
        [SerializeField] private Transform defaultSpawnPoint;

        [Header("Recuperación de posición")]
        [Tooltip("Radio máximo para buscar un punto seguro si el de aparición no lo es")]
        [SerializeField] private float spawnSearchRadius = 6f;
        [SerializeField] private float spawnSearchStep = 0.5f;

        public List<ItemData> ItemDatabase => itemDatabase;
        public int ActiveSlot => activeSlot;
        public Transform DefaultSpawnPoint => defaultSpawnPoint;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(this);
                return;
            }
            Instance = this;

            FindReferencesIfMissing();
            autosaveTimer = autosaveIntervalMinutes * 60f;
        }

        private void Start()
        {
            FindReferencesIfMissing();
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        private void Update()
        {
            // F5: Guardado rápido usando GameInput
            if (GameInput.IsQuickSavePressed())
            {
                SaveGame(activeSlot);
            }

            // F9: Carga rápida usando GameInput
            if (GameInput.IsQuickLoadPressed())
            {
                LoadGame(activeSlot);
            }

            // Punto 11: Autoguardado periódico (solo en un estado seguro; si no, se reintenta al siguiente intervalo)
            if (autosaveIntervalMinutes > 0f)
            {
                autosaveTimer -= Time.deltaTime;
                if (autosaveTimer <= 0f)
                {
                    autosaveTimer = autosaveIntervalMinutes * 60f;
                    if (GetUnsafeSaveReason() == null)
                    {
                        SaveGame(activeSlot);
                    }
                }
            }
        }

        public void SetActiveSlot(int slotIndex)
        {
            activeSlot = Mathf.Clamp(slotIndex, 1, SlotCount);
        }

        private string GetSlotFilePath(int slot)
        {
            return Path.Combine(Application.persistentDataPath, $"pirate_save_slot_{slot}.json");
        }

        public SaveSlotInfo GetSlotInfo(int slot)
        {
            string path = GetSlotFilePath(slot);
            foreach (string p in new[] { path, path + ".bak" })
            {
                if (!File.Exists(p)) continue;
                try
                {
                    GameSaveData d = JsonUtility.FromJson<GameSaveData>(File.ReadAllText(p));
                    if (d == null) continue;
                    return new SaveSlotInfo
                    {
                        exists = true,
                        saveDate = d.saveDate ?? string.Empty,
                        health = d.playerStats != null ? d.playerStats.health : 0f,
                        timeOfDay = d.worldData != null ? d.worldData.timeOfDay : 8f
                    };
                }
                catch (Exception) { /* archivo ilegible: probar el .bak */ }
            }
            return default;
        }

        public bool HasAnySave()
        {
            for (int i = 1; i <= SlotCount; i++)
                if (GetSlotInfo(i).exists) return true;
            return false;
        }

        public void DeleteSlot(int slot)
        {
            string path = GetSlotFilePath(slot);
            foreach (string p in new[] { path, path + ".bak", path + ".tmp" })
            {
                try { if (File.Exists(p)) File.Delete(p); }
                catch (Exception e) { Debug.LogWarning($"[SaveManager] No se pudo borrar {p}: {e.Message}"); }
            }
        }

        private void FindReferencesIfMissing()
        {
            if (playerController == null) playerController = FindFirstObjectByType<PlayerController2D>();
            if (playerStats == null) playerStats = FindFirstObjectByType<PlayerStats>();
            if (inventoryManager == null) inventoryManager = FindFirstObjectByType<InventoryManager>();
            if (dayNightCycle == null) dayNightCycle = FindFirstObjectByType<DayNightCycle>();
            if (weatherSystem == null) weatherSystem = FindFirstObjectByType<WeatherSystem>();
            if (hudManager == null) hudManager = FindFirstObjectByType<HUDManager>();
        }

        private ItemData FindItem(string itemId)
        {
            if (string.IsNullOrEmpty(itemId)) return null;
            ItemData found = itemDatabase.Find(x => x != null && x.itemId == itemId);
            if (found != null) return found;
            return PirateSurvival.Inventory.ItemDatabase.Get(itemId);
        }

        /// <summary>Motivo por el que guardar ahora sería inseguro, o null si se puede guardar.</summary>
        private string GetUnsafeSaveReason()
        {
            if (playerStats == null || playerController == null) return "Sin jugador.";
            if (playerStats.IsDead || GameState.Current == GameScreen.Dead) return "No se puede guardar estando muerto.";
            if (GameInput.ModalBlocked) return "Cierra la confirmación antes de guardar.";
            if (GameState.InBattle) return "No puedes guardar durante un combate.";
            if (playerStats.IsFainted) return "No puedes guardar mientras estás inconsciente.";
            PlayerSwimming swim = playerController.GetComponent<PlayerSwimming>();
            if (swim != null && swim.InWater) return "No puedes guardar en el agua.";
            return null;
        }

        public bool SaveGame() => SaveGame(activeSlot);

        public bool SaveGame(int slot)
        {
            FindReferencesIfMissing();

            if (playerController == null || playerStats == null || inventoryManager == null)
            {
                Debug.LogError("[SaveManager] Error: Referencias al jugador o inventario nulas.");
                return false;
            }

            string unsafeReason = GetUnsafeSaveReason();
            if (unsafeReason != null)
            {
                GameEvents.TriggerNotificationMessage(unsafeReason);
                Debug.LogWarning($"[SaveManager] Guardado cancelado: {unsafeReason}");
                return false;
            }

            GameObject hero = playerController.gameObject;
            PlayerProgress progress = hero.GetComponent<PlayerProgress>();

            string filePath = GetSlotFilePath(slot);
            string tempFilePath = filePath + ".tmp";
            string bakFilePath = filePath + ".bak";

            GameSaveData data = new GameSaveData
            {
                saveVersion = CurrentSaveVersion,
                saveDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                playerPosition = new Vector3Data(playerController.transform.position),
                playerStats = new PlayerStatsData
                {
                    health = playerStats.CurrentHealth,
                    hunger = playerStats.CurrentHunger,
                    thirst = playerStats.CurrentThirst,
                    stamina = playerStats.CurrentStamina,
                    temperature = playerStats.CurrentTemperature,
                    wetness = playerStats.Wetness,
                    isFainted = playerStats.IsFainted
                },
                equippedToolId = inventoryManager.CurrentEquippedTool != null ? inventoryManager.CurrentEquippedTool.itemId : string.Empty,
                equippedSlotIndex = inventoryManager.EquippedSlotIndex,
                worldData = new WorldSaveData
                {
                    timeOfDay = dayNightCycle != null ? dayNightCycle.TimeOfDay : 8f,
                    weather = weatherSystem != null ? weatherSystem.CurrentWeather.ToString() : "Clear",
                    weatherTimer = weatherSystem != null ? weatherSystem.WeatherTimer : 0f
                },
                experience = progress != null ? progress.Experience : 0,
                bounty = progress != null ? progress.Bounty : 0,
                defeatedEncounters = progress != null ? progress.DefeatedList : new List<string>(),
                storyFlags = progress != null ? progress.FlagList : new List<string>(),
                playerName = CharacterArt.PlayerName,
                playerLookJson = CharacterArt.CurrentPlayerLook.ToJson(),
                hasWorldPickupSnapshot = true // este guardado incluye la foto completa del suelo
            };

            // Última posición segura en tierra
            SafePositionTracker tracker = hero.GetComponent<SafePositionTracker>();
            if (tracker != null && tracker.HasSafePosition)
            {
                data.lastSafeLandPosition = new Vector3Data(tracker.LastSafeLandPosition);
                data.hasLastSafeLandPosition = true;
            }

            // Poderes, heridas y tripulación
            DevilFruitManager fruit = hero.GetComponent<DevilFruitManager>();
            if (fruit != null) data.devilFruitId = fruit.FruitId;
            HakiManager haki = hero.GetComponent<HakiManager>();
            if (haki != null)
            {
                data.hakiObservation = haki.Has(HakiType.Observation);
                data.hakiArmament = haki.Has(HakiType.Armament);
                data.hakiConqueror = haki.Has(HakiType.Conqueror);
            }
            PlayerWounds wounds = hero.GetComponent<PlayerWounds>();
            if (wounds != null)
            {
                data.bleedSeconds = wounds.BleedSeconds;
                data.poisonSeconds = wounds.PoisonSeconds;
            }
            CrewManager crew = hero.GetComponent<CrewManager>();
            if (crew != null) data.crew = new List<CrewMemberData>(crew.Members);

            // Guardar casillas de inventario
            var slots = inventoryManager.Slots;
            for (int i = 0; i < slots.Count; i++)
            {
                if (!slots[i].IsEmpty)
                {
                    data.inventorySlots.Add(new SlotSaveData
                    {
                        slotIndex = i,
                        itemId = slots[i].ItemData.itemId,
                        quantity = slots[i].Quantity,
                        durability = slots[i].Durability
                    });
                }
            }

            // Guardar pickups del suelo (con su temporizador de despawn)
            WorldItemPickup[] pickups = FindObjectsByType<WorldItemPickup>(FindObjectsSortMode.None);
            for (int i = 0; i < pickups.Length; i++)
            {
                if (pickups[i] != null && pickups[i].ItemData != null && pickups[i].Quantity > 0)
                {
                    data.worldPickups.Add(new PickupSaveData
                    {
                        itemId = pickups[i].ItemData.itemId,
                        quantity = pickups[i].Quantity,
                        position = new Vector3Data(pickups[i].transform.position),
                        remainingDespawnSeconds = pickups[i].RemainingDespawnSeconds
                    });
                }
            }

            // Guardar recursos con detección de duplicados
            HarvestableResource[] resources = FindObjectsByType<HarvestableResource>(FindObjectsSortMode.None);
            HashSet<string> seenIds = new HashSet<string>();

            for (int i = 0; i < resources.Length; i++)
            {
                if (resources[i] != null && !string.IsNullOrEmpty(resources[i].ResourceId))
                {
                    if (seenIds.Contains(resources[i].ResourceId))
                    {
                        Debug.LogWarning($"[SaveManager] resourceId duplicado: '{resources[i].ResourceId}' en '{resources[i].name}'.");
                    }
                    else
                    {
                        seenIds.Add(resources[i].ResourceId);
                    }

                    data.harvestedResources.Add(new HarvestedResourceSaveData
                    {
                        resourceId = resources[i].ResourceId,
                        isHarvested = resources[i].IsHarvested,
                        remainingRespawnTime = resources[i].RemainingRespawnTime
                    });
                }
            }

            // Punto 11: Escritura atómica con File.Replace y copia de seguridad .bak
            try
            {
                string json = JsonUtility.ToJson(data, true);
                File.WriteAllText(tempFilePath, json);

                if (File.Exists(filePath))
                {
                    try
                    {
                        File.Copy(filePath, bakFilePath, true);
                    }
                    catch (Exception exBak)
                    {
                        Debug.LogWarning($"[SaveManager] Advertencia al crear .bak: {exBak.Message}");
                    }

                    File.Replace(tempFilePath, filePath, null);
                }
                else
                {
                    File.Move(tempFilePath, filePath);
                    try
                    {
                        File.Copy(filePath, bakFilePath, true);
                    }
                    catch (Exception exBak)
                    {
                        Debug.LogWarning($"[SaveManager] Advertencia al crear .bak: {exBak.Message}");
                    }
                }

                GameEvents.TriggerNotificationMessage("Guardado");
                Debug.Log($"[SaveManager] Partida guardada atómicamente en Ranura {slot}.");
                return true;
            }
            catch (Exception e)
            {
                if (File.Exists(tempFilePath)) File.Delete(tempFilePath);
                Debug.LogError($"[SaveManager] Error al guardar partida: {e.Message}");
                return false;
            }
        }

        public bool LoadGame() => LoadGame(activeSlot);

        public bool LoadGame(int slot)
        {
            string filePath = GetSlotFilePath(slot);
            string bakFilePath = filePath + ".bak";

            if (!File.Exists(filePath) && !File.Exists(bakFilePath))
            {
                Debug.LogWarning($"[SaveManager] No existe archivo en Ranura {slot}.");
                return false;
            }

            FindReferencesIfMissing();

            if (playerController == null || playerStats == null || inventoryManager == null)
            {
                Debug.LogError("[SaveManager] Error de referencias nulas al cargar.");
                return false;
            }

            GameSaveData data = ReadSaveFile(filePath);

            // Punto 11: Si el principal está ausente o corrupto, restaurar copia .bak
            if (data == null && File.Exists(bakFilePath))
            {
                data = ReadSaveFile(bakFilePath);
                if (data != null)
                {
                    try
                    {
                        File.Copy(bakFilePath, filePath, true);
                        Debug.Log("[SaveManager] Archivo corrupto restaurado exitosamente desde .bak.");
                        GameEvents.TriggerNotificationMessage("Partida restaurada de respaldo");
                    }
                    catch (Exception exCopy)
                    {
                        Debug.LogWarning($"[SaveManager] No se pudo restaurar el principal desde .bak: {exCopy.Message}");
                    }
                }
            }

            // Validar y migrar ANTES de tocar el mundo: si algo es imposible, no se aplica nada a medias
            if (!SaveDataValidator.ValidateAndNormalize(data, inventoryManager.Slots.Count, FindItem))
            {
                Debug.LogError("[SaveManager] Archivo corrupto o ilegible.");
                return false;
            }

            try
            {
                ApplySaveData(data);
                Debug.Log($"[SaveManager] Partida de Ranura {slot} cargada con éxito (v{data.saveVersion}).");
                return true;
            }
            catch (Exception e)
            {
                Debug.LogError($"[SaveManager] Error al aplicar datos cargados: {e}");
                return false;
            }
        }

        private static GameSaveData ReadSaveFile(string path)
        {
            if (!File.Exists(path)) return null;
            try
            {
                return JsonUtility.FromJson<GameSaveData>(File.ReadAllText(path));
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[SaveManager] '{Path.GetFileName(path)}' ilegible: {ex.Message}");
                return null;
            }
        }

        private void ApplySaveData(GameSaveData data)
        {
            GameObject hero = playerController.gameObject;

            // 0. Un combate abierto no sobrevive a una carga
            if (BattleManager.Instance != null) BattleManager.Instance.AbortBattle();
            PirateSurvival.Combat3D.Combat3DManager m3d = PirateSurvival.Combat3D.Combat3DManager.Instance;
            if (m3d != null && m3d.IsInCombat3D) m3d.Abort();

            // 0. Apariencia y nombre del personaje
            if (!string.IsNullOrEmpty(data.playerName))
                CharacterArt.PlayerName = data.playerName;
            if (!string.IsNullOrEmpty(data.playerLookJson))
                CharacterArt.ApplyPlayerLook(CharacterLook.FromJson(data.playerLookJson), data.playerName);

            // 1. Progreso, poderes, heridas y tripulación
            PlayerProgress loadedProgress = hero.GetComponent<PlayerProgress>();
            if (loadedProgress != null)
            {
                loadedProgress.Load(data.experience, data.defeatedEncounters, data.bounty);
                loadedProgress.LoadFlags(data.storyFlags);
            }
            DevilFruitManager loadedFruit = hero.GetComponent<DevilFruitManager>();
            if (loadedFruit != null) loadedFruit.Load(data.devilFruitId);
            HakiManager loadedHaki = hero.GetComponent<HakiManager>();
            if (loadedHaki != null) loadedHaki.Load(data.hakiObservation, data.hakiArmament, data.hakiConqueror);
            PlayerWounds loadedWounds = hero.GetComponent<PlayerWounds>();
            if (loadedWounds != null) loadedWounds.Load(data.bleedSeconds, data.poisonSeconds);
            CrewManager loadedCrew = hero.GetComponent<CrewManager>();
            if (loadedCrew != null) loadedCrew.Load(data.crew);

            // 2. Estadísticas
            playerStats.LoadStats(
                data.playerStats.health,
                data.playerStats.hunger,
                data.playerStats.thirst,
                data.playerStats.stamina,
                data.playerStats.temperature,
                data.playerStats.wetness,
                data.playerStats.isFainted
            );

            // 3. Inventario (las entradas ya vienen validadas: índice, objeto, cantidad, durabilidad, sin duplicados)
            for (int i = 0; i < inventoryManager.Slots.Count; i++)
            {
                inventoryManager.LoadSlot(i, null, 0);
            }
            foreach (SlotSaveData savedSlot in data.inventorySlots)
            {
                inventoryManager.LoadSlot(savedSlot.slotIndex, FindItem(savedSlot.itemId), savedSlot.quantity, savedSlot.durability);
            }
            float weight = inventoryManager.CalculateTotalWeight();
            if (weight > inventoryManager.MaxCarryWeight)
                Debug.LogWarning($"[SaveData] El inventario cargado pesa {weight:F1} kg (máx. {inventoryManager.MaxCarryWeight:F1}). Se conserva, pero no podrás recoger más.");

            // 4. Arma equipada: solo si la casilla real contiene exactamente ese objeto equipable
            RestoreEquippedTool(data);
            inventoryManager.NotifyInventoryChanged();

            // 5. Recursos cosechados (antes de validar la posición: un árbol talado no tiene collider)
            HarvestableResource[] resources = FindObjectsByType<HarvestableResource>(FindObjectsSortMode.None);
            foreach (HarvestableResource res in resources)
            {
                HarvestedResourceSaveData savedRes = data.harvestedResources.Find(x => x.resourceId == res.ResourceId);
                if (savedRes != null) res.SetHarvestedState(savedRes.isHarvested, savedRes.remainingRespawnTime);
                else res.SetHarvestedState(false, 0f);
            }

            // 6. Posición validada
            Vector2 position = ResolveLoadPosition(data);
            Rigidbody2D rb = playerController.GetComponent<Rigidbody2D>();
            if (rb != null)
            {
                rb.position = position;
                rb.linearVelocity = Vector2.zero;
            }
            playerController.transform.position = new Vector3(position.x, position.y, 0f);
            playerController.StopImmediately();
            PlayerSwimming swimming = hero.GetComponent<PlayerSwimming>();
            if (swimming != null) swimming.ResetState();
            SafePositionTracker tracker = hero.GetComponent<SafePositionTracker>();
            if (tracker != null) tracker.SetSafePosition(position);

            // 7. Objetos del suelo (después de colocar al jugador: una posición inválida se recoloca cerca o junto a él)
            RestoreWorldPickups(data, position, rb);

            // 8. Hora y clima
            if (dayNightCycle != null) dayNightCycle.SetTimeOfDay(data.worldData.timeOfDay);
            if (weatherSystem != null)
            {
                if (Enum.TryParse(data.worldData.weather, out WeatherType parsedWeather))
                {
                    weatherSystem.SetWeather(parsedWeather);
                    weatherSystem.SetWeatherTimer(data.worldData.weatherTimer);
                }
                else
                {
                    Debug.LogWarning($"[SaveData] Clima '{data.worldData.weather}' desconocido: se mantiene el actual.");
                }
            }

            // Punto 18: Referencia cacheada a HUDManager
            if (hudManager != null)
            {
                hudManager.HideDeathScreen();
            }

            // Carga correcta desde la pantalla de muerte: ya hay un jugador vivo (el validador garantiza vida >= 1)
            if (GameState.Current == GameScreen.Dead) GameState.Set(GameScreen.Playing);
        }

        /// <summary>
        /// Con foto (v2): se sustituyen los objetos del suelo por los guardados (lista vacía = todo recogido).
        /// Sin foto (v1 o lista corrupta): se conservan los objetos iniciales del mundo recién construido, sin duplicar.
        /// </summary>
        private void RestoreWorldPickups(GameSaveData data, Vector2 playerPosition, Rigidbody2D playerBody)
        {
            if (!data.hasWorldPickupSnapshot)
            {
                Debug.LogWarning("[SaveData] El guardado no tiene foto de los objetos del suelo: se conservan los objetos iniciales del mundo.");
                return;
            }

            WorldItemPickup[] existingPickups = FindObjectsByType<WorldItemPickup>(FindObjectsSortMode.None);
            for (int i = 0; i < existingPickups.Length; i++)
            {
                if (existingPickups[i] != null) Destroy(existingPickups[i].gameObject);
            }

            foreach (PickupSaveData pickupData in data.worldPickups)
            {
                ItemData item = FindItem(pickupData.itemId);
                Vector2 pos = pickupData.position.ToVector2();
                // El pickup aún no existe: su collider no interviene. El jugador se ignora (los pickups son triggers).
                if (!SafePositionTracker.IsValidLandPosition(pos, playerBody))
                {
                    if (!SafePositionTracker.TryFindNearestSafePosition(pos, playerBody, 4f, 0.5f, out Vector2 near))
                        near = playerPosition + Vector2.down * 0.6f;
                    Debug.LogWarning($"[SaveData] '{pickupData.itemId}' estaba en una posición inválida {pos}: recolocado en {near}.");
                    pos = near;
                }
                GameObject spawned = WorldItemFactory.Spawn(item, pickupData.quantity, pos, Vector2.zero);
                WorldItemPickup pickup = spawned != null ? spawned.GetComponent<WorldItemPickup>() : null;
                if (pickup != null) pickup.SetRemainingDespawnSeconds(pickupData.remainingDespawnSeconds);
            }
        }

        private void RestoreEquippedTool(GameSaveData data)
        {
            inventoryManager.UnequipTool();
            if (string.IsNullOrEmpty(data.equippedToolId)) return;

            // EquipTool valida casilla, objeto, tipo y cantidad; aquí solo se informa si falla
            if (!inventoryManager.EquipTool(FindItem(data.equippedToolId), data.equippedSlotIndex))
                Debug.LogWarning($"[SaveData] No se pudo equipar '{data.equippedToolId}' en la casilla {data.equippedSlotIndex}: sin arma.");
        }

        /// <summary>Punto de aparición validado; si no es seguro se busca uno cercano (error claro: es un fallo de configuración del mundo).</summary>
        private Vector2 GetValidatedSpawn(Rigidbody2D body)
        {
            Vector2 spawn = defaultSpawnPoint != null ? (Vector2)defaultSpawnPoint.position : Vector2.zero;
            if (SafePositionTracker.TryFindNearestSafePosition(spawn, body, spawnSearchRadius, spawnSearchStep, out Vector2 safe))
            {
                if (safe != spawn) Debug.LogError($"[SaveManager] El punto de aparición {spawn} no es seguro (mar, fuera de límites o dentro de un collider). Se usa {safe}.");
                return safe;
            }
            Debug.LogError($"[SaveManager] El punto de aparición {spawn} no es seguro y no hay posición válida en {spawnSearchRadius} unidades. Revisa el mundo.");
            return spawn;
        }

        /// <summary>Posición guardada → última posición segura → punto de aparición. Nunca mar, roca, fuera de límites ni dentro de un collider.</summary>
        private Vector2 ResolveLoadPosition(GameSaveData data)
        {
            Physics2D.SyncTransforms();
            Rigidbody2D rb = playerController.GetComponent<Rigidbody2D>();

            Vector2 saved = data.playerPosition.ToVector2();
            if (SafePositionTracker.IsValidLandPosition(saved, rb)) return saved;

            if (data.hasLastSafeLandPosition)
            {
                Vector2 lastSafe = data.lastSafeLandPosition.ToVector2();
                if (SafePositionTracker.IsValidLandPosition(lastSafe, rb))
                {
                    Debug.LogWarning($"[SaveData] Posición guardada {saved} no válida: se usa la última posición segura {lastSafe}.");
                    return lastSafe;
                }
            }

            Vector2 spawn = GetValidatedSpawn(rb);
            Debug.LogWarning($"[SaveData] Posición guardada {saved} no válida y sin posición segura válida: se usa el punto de aparición {spawn}.");
            return spawn;
        }

        public void RespawnPlayer()
        {
            FindReferencesIfMissing();

            if (playerStats == null || playerController == null) return;

            Rigidbody2D rb = playerController.GetComponent<Rigidbody2D>();
            Vector2 spawnPos = GetValidatedSpawn(rb);

            if (rb != null)
            {
                rb.position = spawnPos;
                rb.linearVelocity = Vector2.zero;
            }
            playerController.transform.position = new Vector3(spawnPos.x, spawnPos.y, 0f);
            playerController.StopImmediately();

            playerStats.Respawn();
            PlayerSwimming swimming = playerController.GetComponent<PlayerSwimming>();
            if (swimming != null) swimming.ResetState();
            SafePositionTracker tracker = playerController.GetComponent<SafePositionTracker>();
            if (tracker != null) tracker.SetSafePosition(spawnPos);
            GameState.Set(GameScreen.Playing);

            // Punto 18: Referencia cacheada a HUDManager
            if (hudManager != null)
            {
                hudManager.HideDeathScreen();
            }

            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }
    }
}
