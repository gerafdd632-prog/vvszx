﻿using System;
using PirateSurvival.Crafting;
using PirateSurvival.Player;

namespace PirateSurvival.Story
{
    /// <summary>
    /// Conversaciones enriquecidas de todos los habitantes de Isla Coral con estilo, trasfondo
    /// y lore auténtico de One Piece (Grand Line, Haki, Frutas del Diablo, Marina y la Gran Era Pirata).
    /// </summary>
    public static class NpcDialogues
    {
        private const string Me = "Tú";
        private const string MePortrait = "c_player";

        public static Func<Dialogue> For(string npcId)
        {
            switch (npcId)
            {
                case "abuela": return Abuela;
                case "alcaldesa": return Alcaldesa;
                case "herrero": return Herrero;
                case "carpintero": return Carpintero;
                case "tabernera": return Tabernera;
                case "mercader": return Mercader;
                case "nino": return Nino;
                case "pescador": return Pescador;
                case "marine": return Marine;
                case "boticario": return Boticario;
                case "kenshi": return Kenshi;
                case "sogeking": return Sogeking;
                case "timon": return Timon;
                default: return null;
            }
        }

        private static StoryManager S => StoryManager.Instance;
        private static bool F(string flag) => S != null && S.Flag(flag);
        private static bool Done(string step) => S != null && S.StepDone(step);
        private static void Set(string flag) { if (S != null) S.SetFlag(flag); }
        private static void Give(string itemId, int qty) { if (S != null) S.Give(itemId, qty); }
        private static void Recruit(CrewMemberData member) { if (S != null) S.Recruit(member); }

        // ================================================================== Abuela Marea (charca)

        private static Dialogue Abuela()
        {
            Dialogue d = new Dialogue("Abuela Marea", "c_villager_3");
            if (!F("hablo_abuela"))
            {
                d.Say("a", "¡Vaya, vaya! El mar escupió algo más que algas y madera esta mañana... ¿Cómo estás, muchacho?")
                 .Choice("¿Dónde estoy exactamente?", "b")
                 .Choice("Me duele todo el cuerpo...", "c");

                d.Say("b", "Estás en Isla Coral, en pleno East Blue. Dicen que es el mar más pacífico del mundo, pero desde que atracó el Capitán Cuervo no hay paz.", "d");
                d.Say("c", "Es normal, te ha revolcado una galerna espantosa. Bebe agua dulce de la charca que tengo al lado: el agua del mar solo te secará por dentro.", "d");

                d.Say("d", "Cuervo y sus maleantes exprimen la aldea sin piedad. Si buscas qué hacer o necesitas curarte, la Alcaldesa Coral busca a alguien con valor.")
                 .Choice("Derrotaré a ese Capitán Cuervo.", "e")
                 .Choice("Solo busco comida y sobrevivir.", "f")
                 .Choice("¿Qué sabes del mar y sus peligros?", "g");

                d.Say("e", "¡Ja, ja! Tienes esa chispa en los ojos... la misma que tenían los piratas legendarios. Toma estas vendas limpias y sigue la senda hacia la aldea.", null,
                    () => { Give("venda", 2); Set("hablo_abuela"); });

                d.Say("f", "Para sobrevivir en estos mares no basta con esconderse, muchacho: hay que aprender a luchar. Toma estas vendas y ve con la alcaldesa.", null,
                    () => { Give("venda", 2); Set("hablo_abuela"); });

                d.Say("g", "El mar da la vida, pero también te la quita en un descuido. Si caes al agua cansado, te ahogas. Y si comes una fruta con espirales... el mar te odiará para siempre. Toma estas vendas y ve a la aldea.", null,
                    () => { Give("venda", 2); Set("hablo_abuela"); });

                return d;
            }

            if (Done("cuervo"))
            {
                d.Say("a", "¡Toda la aldea corea tu nombre, muchacho! Mi difunto marido navegó hacia la Reverse Mountain hace cuarenta años... Sé reconocer a un capitán destinado a la grandeza.")
                 .Choice("Háblame de lo que nos espera en Grand Line.", "gl")
                 .Choice("¿Qué misterios oculta este mundo?", "lore")
                 .Choice("Gracias por todo, abuela.", null);

                d.Say("gl", "Allí el cielo se tiñe de verde, las brújulas enloquecen y las islas guardan civilizaciones enteras. Necesitarás un Log Pose y tripulantes leales. ¡No mires atrás!");
                d.Say("lore", "Dicen que el Rey de los Piratas descubrió la verdad oculta tras el Siglo Vacío y dejó un tesoro inimaginable: el One Piece. Si zarpas, persigue tu propio sueño.");
                return d;
            }

            d.Say("a", "¿Necesitas orientación, muchacho? El océano premia a los precavidos.")
             .Choice("¿Dónde consigo recursos para forjar?", "cuev")
             .Choice("¿Cómo funcionan las Frutas del Diablo?", "frut")
             .Choice("Hasta pronto, abuela.", null);

            d.Say("cuev", "Hacia el noroeste está la vieja mina del oeste. Es oscura como la boca de un lobo, pero sus paredes esconden vetas de hierro y gemas brillantes. Necesitarás fabricar un pico.");
            d.Say("frut", "Frutas milagrosas que otorgan dones sobrenaturales. Pero ten presente la maldición canónica: si un usuario toca el agua del mar, su fuerza se desvanece por completo.");
            return d;
        }

        // ================================================================== Alcaldesa Coral (plaza)

        private static Dialogue Alcaldesa()
        {
            Dialogue d = new Dialogue("Alcaldesa Coral", "c_villager_2");
            if (!F("hablo_alcaldesa"))
            {
                d.Say("a", "¡Detente! ...Espera, no vistes el uniforme de los hombres de Cuervo. ¿Quién eres y qué buscas en Aldea Coral?")
                 .Choice("Soy un náufrago. La Abuela Marea me envía.", "b")
                 .Choice("Soy un pirata, pero tengo mi propio código.", "c");

                d.Say("b", "Disculpa mi hostilidad... Llevamos semanas viviendo con el corazón en un puño. Si la abuela confía en ti, yo también.", "d");
                d.Say("c", "¿Un pirata con honor? En este mar abundan los bribones cobardes, pero tu mirada transmite determinación. Te escucharé.", "d");

                d.Say("d", "La situación es crítica: dos esbirros de Cuervo bloquean el paso en la playa este y nos extorsionan. El propio Cuervo custodia el muelle con su buque de guerra.")
                 .Choice("¿Cómo puedo ayudar a liberar la aldea?", "e");

                d.Say("e", "Ir con las manos vacías sería un suicidio. Habla primero con Tetsu, nuestro herrero: conoce el arte de forjar acero de alta calidad.", null,
                    () => Set("hablo_alcaldesa"));
                return d;
            }

            if (Done("piratas") && !F("alcaldesa_cuervo"))
            {
                d.Say("a", "¡Increíble! Los vigías han visto correr a los piratas de la playa este. ¡Has demostrado un coraje sin igual!")
                 .Choice("Es hora de ajustar cuentas con Cuervo.", "b");

                d.Say("b", "Cuervo es despiadado y pelea sobre la cubierta de su barco con su mejor tirador y un espadachín. Toma estas provisiones de reserva del pueblo.", null,
                    () => { Give("botella_agua", 2); Give("venda", 2); Set("alcaldesa_cuervo"); });
                return d;
            }

            if (Done("cuervo"))
            {
                d.Say("a", "¡Has hecho historia en Isla Coral! El barco de Cuervo está atracado y te pertenece por derecho de victoria. Habla con Bruno en el muelle: él sabe cómo navegar el océano.")
                 .Choice("¿Vendrá la Marina a por mí?", "marina")
                 .Choice("Cuidaré de esta isla desde alta mar.", null);

                d.Say("marina", "Tu hazaña no pasará desapercibida para el Gobierno Mundial. Tu recompensa en Berries subirá, pero sé que estás listo para cualquier desafío.");
                return d;
            }

            d.Say("a", "El pozo comunal de la plaza mana agua dulce purificada. Bebe cuanto necesites antes de salir al camino.")
             .Choice("¿Cuál es el siguiente paso?", "pista")
             .Choice("¿Qué sabes sobre la historia de la isla?", "hist")
             .Choice("Nos vemos luego.", null);

            d.Say("pista", ObjectiveHint());
            d.Say("hist", "Isla Coral solía ser un puerto de abastecimiento para navegantes rumbo a Loguetown, la ciudad del principio y del fin. Si liberas el muelle, volverá a florecer.");
            return d;
        }

        // ================================================================== Tetsu el herrero (forja)

        private static Dialogue Herrero()
        {
            Dialogue d = new Dialogue("Tetsu el herrero", "c_herrero");
            if (!F(RecipeBook.ForgeFlag))
            {
                d.Say("a", "¿Qué estás mirando, novato? ¿El calor te asusta? ...Ah, vienes con el sello de la alcaldesa.")
                 .Choice("Necesito un arma digna de un pirata.", "b")
                 .Choice("Enséñame los secretos de la forja.", "b");

                d.Say("b", "El buen acero no se regala ni se compra con palabras bonitas: se gana con sudor, carbón y martillo.", "c");
                d.Say("c", "Primero trenza cuerda firme con la fibra vegetal de los arbustos. Después desciende a la vieja mina del oeste con un pico y extrae Mineral de Hierro.")
                 .Choice("¿Qué clases de espadas puedo crear?", "d")
                 .Choice("Entendido, manos a la obra.", null, () => Set(RecipeBook.ForgeFlag));

                d.Say("d", "El Sable Pirata es ligero, veloz y gasta poco AP. La Katana de Acero ofrece cortes quirúrgicos con alta probabilidad crítica. Y la Nodachi es un coloso capaz de quebrar escudos. ¡Y si hallas Kairoseki, forjarás una daga anti-frutas!", null,
                    () => Set(RecipeBook.ForgeFlag));
                return d;
            }

            d.Say("a", "El fuelle arde al rojo vivo. Acércate al yunque y abre la mochila [Tab] → Fabricar para forjar hojas legendarias.")
             .Choice("Háblame de las legendarias espadas Meito.", "meito")
             .Choice("¿Qué es el Kairoseki y cómo se forja?", "kairo")
             .Choice("Dame un consejo táctico para el combate.", "tac")
             .Choice("Sigue con tu trabajo, Tetsu.", null);

            d.Say("meito", "Existen espadas de grado supremo en el mundo: Ryo Wazamono y Saijo O Wazamono. Se dice que los mejores espadachines imbuyen su propia voluntad en el filo hasta volverlas Espadas Negras indestructibles.");
            d.Say("kairo", "Es una piedra marina mística más dura que el diamante. Emite la longitud de onda del propio océano. Si cortas a un usuario de Fruta con ella, anulas sus poderes al instante.");
            d.Say("tac", "En combate táctico gestiona tus AP con cabeza. Ataca desde los flancos, utiliza la cobertura de los restos de barco y mantén siempre energía para contraatacar.");
            return d;
        }

        // ================================================================== Maese Tablón (carpintería)

        private static Dialogue Carpintero()
        {
            Dialogue d = new Dialogue("Maese Tablón", "c_carpintero");
            d.Say("a", "¡Epa! ¡Cuidado con las virutas! Bienvenido al taller de carpintería. Mi mesa de trabajo está afilada y lista para ti.")
             .Choice("¿Cómo aprovecho tu mesa de trabajo?", "b")
             .Choice("¿Qué se necesita para construir un barco pirata?", "c")
             .Choice("¿Has oído hablar del Klabautermann?", "klab")
             .Choice("Hasta otra, Tablón.", null);

            d.Say("b", "Reúne madera, piedra y cuerda trenzada. Sitúate junto a la mesa y abre la mochila [Tab] → Fabricar. Puedes manufacturar hachas, picos, vendas y lienzos de vela.");
            d.Say("c", "¡Ja! Para un gran navío hace falta madera del legendario Árbol del Tesoro Adam, la misma con la que surcan el Grand Line los mejores capitanes. Cuida el barco de Cuervo: está hecho de buen roble.");
            d.Say("klab", "¡Vaya si lo conozco! Es el espíritu protector del barco. Si amas tu nave y la cuidas con esmero, se manifestará en forma de duendecillo con chubasquero para salvar a la tripulación en la tempestad.");
            return d;
        }

        // ================================================================== Lola la tabernera (taberna)

        private static Dialogue Tabernera()
        {
            Dialogue d = new Dialogue("Lola la tabernera", "c_tabernera");
            d.Say("a", "¡Bienvenido a La Sirena Borracha! Aquí el ron calienta el gaznate y los chismes corren como la espuma de ola.")
             .Choice("¿Qué rumores hay sobre los Cuatro Emperadores (Yonko)?", "yonko")
             .Choice("¿Qué sabes de la entrada al Grand Line?", "reverse")
             .Choice("¿Cómo se diferencian las Frutas del Diablo?", "frutas")
             .Choice("Háblame del Capitán Cuervo.", "cuervo");
            // Máximo 4 respuestas por nodo (DialogueUI): para irse, [Esc] o la opción del siguiente nodo
            d.Say("adios", "¡Vuelve cuando quieras, forastero!");

            d.Say("yonko", "Dicen que en el Nuevo Mundo reinan cuatro titanes monstruosos. Gobiernan mares enteros y desafían al Gobierno Mundial sin pestañear. ¡Nadie llega allí sin una tripulación formidable!")
             .Choice("Quiero preguntarte otra cosa.", "a")
             .Choice("Me voy, gracias.", "adios");
            d.Say("reverse", "¡La Reverse Mountain! Es una montaña donde cuatro canales ascienden hacia la cima contra la gravedad para converger en el cabo de los Gemelos. Un error en el timón y el barco se estrella contra las rocas.")
             .Choice("Quiero preguntarte otra cosa.", "a")
             .Choice("Me voy, gracias.", "adios");
            d.Say("frutas", "Hay tres clases: Paramecia (cambian tu cuerpo o generan sustancias), Zoan (te transforman en bestia) y Logia (te convierten en elementos naturales invulnerables a golpes ordinarios).")
             .Choice("Quiero preguntarte otra cosa.", "a")
             .Choice("Me voy, gracias.", "adios");
            d.Say("cuervo", Done("cuervo")
                ? "¡Le diste una paliza memorable! Cuervo presumía de su espada Shiokaze, pero no pudo con tu espíritu. ¡Esta ronda va a mi cuenta!"
                : "Cuervo empuña a Shiokaze, un sable con nombre propio. Lucha en la cubierta de su barco para que sus rivales caigan por la borda. ¡No vayas sin vendas y agua dulce!")
             .Choice("Quiero preguntarte otra cosa.", "a")
             .Choice("Me voy, gracias.", "adios");
            return d;
        }

        // ================================================================== Ramón el mercader (puesto)

        private static Dialogue Mercader()
        {
            Dialogue d = new Dialogue("Ramón el mercader", "c_villager_1");
            d.Say("a", "¡Fruta tropical de primera calidad! ¡Suministros náuticos! ...Cuando las rutas marítimas vuelvan a abrirse, claro.")
             .Choice("¿Qué consejos tienes para almacenar provisiones?", "peso")
             .Choice("¿Cómo se mueve el mercado negro en el mar?", "mercado")
             .Choice("¿Qué vale más en este océano?", "berries")
             .Choice("Que tengas buenas ventas, Ramón.", null);

            d.Say("peso", "Tu mochila tiene un límite estricto de kilogramos, igual que un fardo de mercancías. Si te sobrecargas te moverás más lento y gastarás más energía al andar. ¡Lleva solo lo necesario!");
            d.Say("mercado", "En las sombras del bajo mundo operan intermediarios que compran Frutas del Diablo por cientos de millones de Berries. El Gobierno Mundial y los nobles pagan fortunas por ellas.");
            d.Say("berries", "Los Berries compran barcos y cañones, pero en mitad de una galerna una simple botella de agua dulce y una venda limpia valen más que todo el oro del mundo.");
            return d;
        }

        // ================================================================== Tico (niño de la aldea)

        private static Dialogue Nino()
        {
            Dialogue d = new Dialogue("Tico", "c_villager_0");
            d.Say("a", Done("cuervo")
                ? "¡Uaaaau! ¡Venciste a los piratas malos! ¡Enséñame a pelear con espada! ¡Quiero ser como tú!"
                : "¡Eh, tú! ¡Tienes pinta de aventurero! ¿Eres un pirata de verdad? ¿Tienes ya tu propio barco?")
             .Choice("Algún día navegaré hasta el fin del mundo.", "b")
             .Choice("¿Qué tripulantes reclutarías tú?", "trip")
             .Choice("Ten cuidado con los piratas, Tico.", "c");

            d.Say("b", "¡Sí! ¡Tienes que ponerle un mascarón de proa con forma de león o dragón! ¡Y una bandera negra con tu propia calavera!");
            d.Say("trip", "¡Yo reclutaría a un francotirador con tirachinas genial, un cocinero que pelee solo con patadas para no mancharse las manos, y un reno que hable!");
            d.Say("c", "¡No tengo miedo! Mi abuela me contó que los verdaderos piratas persiguen la libertad y protegen a sus amigos.");
            return d;
        }

        // ================================================================== Bruno el pescador (muelle)

        private static Dialogue Pescador()
        {
            Dialogue d = new Dialogue("Bruno el pescador", "c_villager_4");
            if (Done("cuervo") && !F("bruno_unido"))
            {
                d.Say("a", "¡Por todos los mares del sur! ¡Has derribado a Cuervo en su propia cubierta! Llevo veinte años pescando en estas calas soñando con ver qué hay más allá del horizonte.")
                 .Choice("Únete a mi tripulación, Bruno. Zarpamos juntos.", "b")
                 .Choice("¿Qué puedes aportar al barco?", "c")
                 .Choice("Aún tengo cosas pendientes en tierra.", null);

                d.Say("b", "¿Lo dices en serio? ¡Ja, ja, ja! ¡Cuenta con mi arpón y mis ojos de vigía! Sé leer las corrientes, esquivar remolinos y clavar un arpón a dos casillas de distancia. ¡A la orden, capitán!", null, () =>
                {
                    Recruit(new CrewMemberData
                    {
                        id = "bruno", name = "Bruno", role = "Navegante", maxHp = 55, hp = 55, defense = 1, maxAp = 5, speed = 4,
                        weaponName = "Arpón", weaponDamage = 9, weaponMinRange = 1, weaponMaxRange = 2, weaponApCost = 2, weaponAccuracy = 0.85f,
                        playerControlled = true, inParty = true
                    });
                    Set("bruno_unido");
                });

                d.Say("c", "Conozco las mareas del East Blue de memoria. Sé cuándo se avecina una tormenta antes de que sople el viento, y en combate mi arpón mantiene a raya a los enemigos cuerpo a cuerpo.", "a");
                return d;
            }

            if (F("bruno_unido"))
            {
                d.Say("a", "¡Capitán! El velero está en perfecto estado: bodega con provisiones, velas remendadas y timón engrasado. El Grand Line nos aguarda en cuanto ordenes zarpar.")
                 .Choice("¿Qué peligros nos aguardan en el mar abierto?", "mar")
                 .Choice("Mantente alerta, Bruno.", null);

                d.Say("mar", "El Calm Belt bordea el Grand Line: una franja sin viento ni olas infestada de gigantescos Reyes Marinos. Por eso la única vía segura de entrada es escalar la Reverse Mountain.");
                return d;
            }

            d.Say("a", "El Capitán Cuervo y su guardia tienen el muelle tomado. Tienen fusiles y sables afilados... ni siquiera puedo salir con mi esquife.")
             .Choice("¿Qué táctica utiliza Cuervo en combate?", "b")
             .Choice("Pronto recuperarás tu muelle.", null);

            d.Say("b", "Pelea en la cubierta con su tripulación: un tirador a distancia que busca cobertura y un espadachín veloz. Si te descuidas te acorralarán hacia el mar. ¡Lleva vendas, agua dulce y una espada resistente!");
            return d;
        }

        // ================================================================== Cabo Rocco (puesto de la Marina)

        private static Dialogue Marine()
        {
            Dialogue d = new Dialogue("Cabo Rocco", "c_marine");
            if (Done("cuervo"))
            {
                d.Say("a", "Así que tú abatiste a Cuervo... La gente de la aldea está a salvo gracias a ti. Pero las leyes del mar son inexorables: en cuanto ondees tu bandera, la Marina te perseguirá.")
                 .Choice("¿Por qué perseguir a quien defiende a los débiles?", "b")
                 .Choice("No le temo a la Marina ni al Cuartel General.", "c");

                d.Say("b", "El Cuartel General cree en la 'Justicia Absoluta': ningún pirata está por encima de la ley. Por hoy fingiré que mis prismáticos no te han visto. La próxima vez no habrá miramientos.");
                d.Say("c", "Muchos novatos dijeron lo mismo antes de cruzar los mares. Ten cuidado con los capitanes de la Marina en Loguetown... dicen que hay uno con poderes de humo que jamás ha dejado escapar a nadie.");
                return d;
            }

            d.Say("a", "¡Alto! Estás ante el puesto avanzado de la 153ª división de la Marina del East Blue. ¡Identifícate!")
             .Choice("¿Por qué no detenéis a la banda de Cuervo?", "b")
             .Choice("Solo soy un náufrago explorando la costa.", "c");

            d.Say("b", "¡No me hables con arrogancia! Somos solo tres marines rasos con un cañón con pólvora húmeda. He solicitado buques de guerra de refuerzo hace seis meses, pero el Cuartel General tarda en responder.");
            d.Say("c", "Mantén la distancia. La Marina no tolerará saqueos ni disturbios en esta isla. Si causas problemas, tu cabeza tendrá precio antes del atardecer.");
            return d;
        }

        // ================================================================== Doctor Tonic (Boticario)
        private static Dialogue Boticario()
        {
            Dialogue d = new Dialogue("Doctor Tonic", "c_villager_1");
            d.Say("a", "¡Saludos! Soy el boticario de la aldea. El sol tropical y las criaturas venenosas no perdonan a los descuidados.")
             .Choice("¿Tienes algo para curar heridas?", "b")
             .Choice("¿Cómo me protejo del calor del sol?", "c");

            d.Say("b", "Toma este ungüento calmante. Si recoges hierbas medicinales cerca de la charca de agua dulce, podrás fabricar tus propios antídotos y botiquines en la mesa de trabajo.", null,
                () => { if (!F("regalo_boticario")) { Give("unguento", 2); Set("regalo_boticario"); } });
            d.Say("c", "Usa un sombrero de paja o descansa bajo la sombra de los árboles durante el mediodía. ¡Y mantente siempre bien hidratado!");
            return d;
        }

        // ================================================================== Kenshi (Espadachín Perdido - Zoro Easter Egg)
        private static Dialogue Kenshi()
        {
            Dialogue d = new Dialogue("Kenshi el Extraviado", "c_herrero");
            d.Say("a", "¿Eh? ¿Quién anda ahí? Iba camino de la gran taberna a tomar un trago... pero terminé subiendo a este risco. ¡Juro que el camino se desvió solo!")
             .Choice("¿Por qué llevas tres espadas en el cinto?", "b")
             .Choice("La taberna está exactamente en la otra dirección...", "c");

            d.Say("b", "Tres espadas multiplican por tres la determinación de un guerrero. Si vas a blandir una hoja en este mar, jamás retrocedas.", "d");
            d.Say("c", "¡Tonterías! Mi sentido de la orientación es impecable. El mapa del mundo debe estar mal dibujado.", "d");
            d.Say("d", "Toma este lingote de acero templado. Tal vez Tetsu en la forja pueda forjarte un filo digno.", null,
                () => { if (!F("regalo_kenshi")) { Give("lingote_acero", 2); Set("regalo_kenshi"); } });
            return d;
        }

        // ================================================================== Tirador Miedoso (Sogeking - Usopp Easter Egg)
        private static Dialogue Sogeking()
        {
            Dialogue d = new Dialogue("Tirador Misterioso", "c_villager_0");
            d.Say("a", "¡A-alto ahí! ¡Estás ante el temible capitán de una flota de 8.000 bravos guerreros! ¡Si das un paso más, mis hombres abrirán fuego!")
             .Choice("No veo a nadie detrás de ti...", "b")
             .Choice("Tranquilo, no voy a hacerte daño.", "c");

            d.Say("b", "¡E-están camuflados con técnicas ninjas del país de Wano! ... Vale, lo admito, ¡estoy solo y tengo pánico a los piratas de Cuervo!");
            d.Say("c", "¡Uf, qué alivio! Pensaba que eras uno de los matones de Cuervo. Como muestra de amistad, toma estos balines y pólvora negra.", null,
                () => { if (!F("regalo_sogeking")) { Give("balines_piedra", 15); Give("polvora", 3); Set("regalo_sogeking"); } });
            return d;
        }

        // ================================================================== Viejo Timón (Vigía del Faro)
        private static Dialogue Timon()
        {
            Dialogue d = new Dialogue("Viejo Timón", "c_villager_4");
            d.Say("a", "Desde este faro he visto zarpar a cientos de soñadores hacia el Grand Line. Casi ninguno ha regresado.")
             .Choice("¿Qué hay al final de este mar?", "b")
             .Choice("¿Conociste al legendario Gol D. Roger?", "c");

            d.Say("b", "La Reverse Mountain, la corriente ascendente que lleva al mar más peligroso del planeta. Solo los que poseen una voluntad inquebrantable sobreviven.");
            d.Say("c", "¡Ja, ja! Lo vi con mis propios ojos sonreír antes de morir en Loguetown. Toma esta botella de ron pirata, muchacho: en las noches frías te calentará el espíritu.", null,
                () => { if (!F("regalo_timon")) { Give("ron_pirata", 2); Set("regalo_timon"); } });
            return d;
        }

        // ================================================================== Auxiliar de misiones

        private static string ObjectiveHint()
        {
            QuestStep step = S != null ? S.Current : null;
            return step != null ? step.objective : "Explora la isla y habla con los habitantes de Aldea Coral.";
        }
    }
}
