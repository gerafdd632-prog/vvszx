﻿using System;
using System.Collections.Generic;
using UnityEngine;
using PirateSurvival.Core;
using PirateSurvival.Player;
using PirateSurvival.Inventory;
using PirateSurvival.Interaction;
using PirateSurvival.Combat;

namespace PirateSurvival.Story
{
    /// <summary>Un objetivo del modo historia.</summary>
    public class QuestStep
    {
        public string id;
        public string title;
        public string objective;
        /// <summary>Dónde está el objetivo (para la brújula del HUD). Null = sin flecha.</summary>
        public Vector2? target;
        public Func<StoryManager, bool> isDone;
        public Action<StoryManager> onComplete;
        /// <summary>Último paso del capítulo: no se completa nunca.</summary>
        public bool final;
    }

    /// <summary>
    /// Modo historia: lleva el capítulo y el objetivo actual, guarda los flags en PlayerProgress (se guardan con la partida)
    /// y desbloquea combates de jefe cuando toca. Los diálogos y recompensas viven en Chapter1 y NpcDialogues.
    /// </summary>
    public class StoryManager : MonoBehaviour
    {
        public static StoryManager Instance { get; private set; }

        public string ChapterTitle => Chapter1.Title;
        public QuestStep Current { get; private set; }
        public int CurrentIndex { get; private set; } = -1;
        public IReadOnlyList<QuestStep> Steps => steps;
        public PlayerProgress Progress => progress;
        public event Action OnObjectiveChanged;

        private List<QuestStep> steps;
        private PlayerProgress progress;
        private InventoryManager inventory;
        private CrewManager crew;
        private float timer;

        private void Awake()
        {
            Instance = this;
            steps = Chapter1.Build();
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        private void OnEnable() { GameEvents.OnStoryEvent += HandleStoryEvent; }
        private void OnDisable() { GameEvents.OnStoryEvent -= HandleStoryEvent; }

        private void Start()
        {
            ResolveRefs();
            Evaluate();
        }

        private void ResolveRefs()
        {
            if (progress == null) progress = FindAnyObjectByType<PlayerProgress>();
            if (inventory == null) inventory = InventoryManager.Instance;
            if (crew == null && progress != null) crew = progress.GetComponent<CrewManager>();
        }

        private void Update()
        {
            timer += Time.unscaledDeltaTime;
            if (timer < 0.4f) return;
            timer = 0f;
            Evaluate();
        }

        private void HandleStoryEvent(string id) => SetFlag(id);

        // ------------------------------------------------------------------ Estado

        public bool Flag(string flag) => progress != null && progress.HasFlag(flag);

        public void SetFlag(string flag)
        {
            ResolveRefs();
            if (progress != null && progress.SetFlag(flag)) timer = 1f; // reevaluar en el siguiente frame
        }

        public int Count(string itemId) => inventory != null ? inventory.CountItem(itemId) : 0;
        public bool Defeated(string encounterId) => progress != null && progress.HasDefeated(encounterId);
        public bool StepDone(string stepId) => Flag("q:" + stepId);

        /// <summary>Da un objeto al jugador; si no cabe, cae al suelo a sus pies.</summary>
        public void Give(string itemId, int quantity)
        {
            ResolveRefs();
            ItemData item = ItemDatabase.Get(itemId);
            if (item == null || inventory == null) return;
            if (!inventory.AddItem(item, quantity))
            {
                WorldItemFactory.Spawn(item, quantity, (Vector2)inventory.transform.position + Vector2.down * 0.7f);
            }
            GameEvents.TriggerNotificationMessage(quantity > 1 ? $"Recibes: {item.itemName} x{quantity}" : $"Recibes: {item.itemName}");
        }

        public void Recruit(CrewMemberData member)
        {
            ResolveRefs();
            if (crew == null) return;
            if (crew.Members.Exists(m => m.id == member.id)) return;
            crew.Recruit(member);
        }

        public void AddBounty(int berries)
        {
            ResolveRefs();
            if (progress != null) progress.AddPlayerBounty(berries);
        }

        // ------------------------------------------------------------------ Avance

        /// <summary>Completa en orden todos los objetivos ya cumplidos y fija el actual.</summary>
        private void Evaluate()
        {
            ResolveRefs();
            if (progress == null || steps == null) return;

            int index = steps.Count - 1;
            for (int i = 0; i < steps.Count; i++)
            {
                QuestStep s = steps[i];
                if (StepDone(s.id)) continue;
                if (!s.final && s.isDone != null && s.isDone(this))
                {
                    progress.SetFlag("q:" + s.id);
                    s.onComplete?.Invoke(this);
                    GameEvents.TriggerNotificationMessage($"¡Objetivo cumplido! {s.title}");
                    continue;
                }
                index = i;
                break;
            }

            if (index != CurrentIndex)
            {
                CurrentIndex = index;
                Current = steps[index];
                OnObjectiveChanged?.Invoke();
            }
            ApplyLocks();
        }

        /// <summary>El Capitán Cuervo no pelea con un don nadie: hasta que la alcaldesa te lo pide, solo te ignora.</summary>
        private void ApplyLocks()
        {
            foreach (BattleEncounter enc in BattleEncounter.All)
            {
                if (enc == null || enc.EncounterId != Chapter1.BossEncounter) continue;
                enc.Locked = !StepDone(Chapter1.UnlockBossStep);
                enc.LockedMessage = "Capitán Cuervo: «¿Un náufrago con pinta de pirata? Vuelve cuando seas alguien, novato.»";
            }
        }
    }
}
