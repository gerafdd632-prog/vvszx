﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using PirateSurvival.Core;
using PirateSurvival.UI;

namespace PirateSurvival.Story
{
    /// <summary>
    /// Caja de diálogo: retrato del personaje, nombre, texto que aparece letra a letra y hasta 4 respuestas.
    /// [E]/Espacio/Intro o clic: completar el texto o continuar. [1]-[4] o clic: elegir respuesta. [Esc]: salir.
    /// Mientras está abierta el jugador no se mueve ni interactúa (GameInput.DialogueBlocked).
    /// </summary>
    public class DialogueUI : MonoBehaviour
    {
        private const int MaxChoices = 4;
        private const float CharsPerSecond = 55f;

        public static DialogueUI Instance { get; private set; }
        public static bool IsOpen => Instance != null && Instance.open;
        /// <summary>Frame en que ESC cerró el diálogo (para que el menú de pausa no se abra en el mismo pulso).</summary>
        public static int CancelConsumedFrame = -1;

        private GameObject root;
        private Image portrait;
        private Text nameText, bodyText, hintText;
        private readonly Button[] choiceButtons = new Button[MaxChoices];
        private readonly Text[] choiceTexts = new Text[MaxChoices];
        private readonly List<DialogueChoice> shownChoices = new List<DialogueChoice>();

        private Dialogue dialogue;
        private DialogueNode node;
        private bool open;
        private bool typing;
        private float typed;
        private int openedFrame;

        public static DialogueUI Create(Transform parent)
        {
            GameObject go = new GameObject("DialogueUI");
            go.transform.SetParent(parent, false);
            DialogueUI ui = go.AddComponent<DialogueUI>();
            ui.Build();
            return ui;
        }

        private void Awake() { Instance = this; }

        // Una conversación no sobrevive a morir, desmayarse, entrar en combate o pausar
        private void OnEnable()
        {
            GameEvents.OnPlayerDeath += CloseNow;
            GameEvents.OnPlayerFaint += OnFaint;
            GameState.OnChanged += OnStateChanged;
        }

        private void OnDisable()
        {
            GameEvents.OnPlayerDeath -= CloseNow;
            GameEvents.OnPlayerFaint -= OnFaint;
            GameState.OnChanged -= OnStateChanged;
        }

        private void CloseNow() => Close();
        private void OnFaint(bool fainted) { if (fainted) Close(); }
        private void OnStateChanged(GameScreen screen) { if (screen != GameScreen.Playing && screen != GameScreen.Paused) Close(); }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
            if (open) GameInput.DialogueBlocked = false;
        }

        // ------------------------------------------------------------------ API

        public void Open(Dialogue d)
        {
            if (d == null || d.Get(d.start) == null) return;
            dialogue = d;
            open = true;
            openedFrame = Time.frameCount;
            GameInput.DialogueBlocked = true;
            root.SetActive(true);
            ShowNode(d.start);
        }

        public void Close()
        {
            if (!open) return;
            open = false;
            root.SetActive(false);
            dialogue = null;
            node = null;
            // Se libera un frame después: así la misma pulsación de [E] no vuelve a abrir la conversación
            StartCoroutine(ReleaseInputNextFrame());
        }

        private IEnumerator ReleaseInputNextFrame()
        {
            yield return null;
            if (!open) GameInput.DialogueBlocked = false;
        }

        // ------------------------------------------------------------------ Flujo

        private void ShowNode(string id)
        {
            // Nada seleccionado en el EventSystem: así Intro no "pulsa" además un botón (doble avance)
            if (EventSystem.current != null) EventSystem.current.SetSelectedGameObject(null);
            node = dialogue != null ? dialogue.Get(id) : null;
            if (node == null) { Close(); return; }

            node.onEnter?.Invoke();
            nameText.text = node.speaker;
            portrait.sprite = PortraitFor(node.portraitKey);
            portrait.enabled = portrait.sprite != null;
            bodyText.text = string.Empty;
            typed = 0f;
            typing = true;

            shownChoices.Clear();
            foreach (DialogueChoice c in node.choices)
            {
                if (c.visible == null || c.visible()) shownChoices.Add(c);
            }
            for (int i = 0; i < MaxChoices; i++) choiceButtons[i].gameObject.SetActive(false);
            hintText.text = string.Empty;
        }

        private void FinishTyping()
        {
            typing = false;
            bodyText.text = node.text;
            for (int i = 0; i < MaxChoices; i++)
            {
                bool show = i < shownChoices.Count;
                choiceButtons[i].gameObject.SetActive(show);
                if (show) choiceTexts[i].text = $"{i + 1}. {shownChoices[i].text}";
            }
            hintText.text = shownChoices.Count > 0 ? string.Empty : (node.next != null ? "[E] Continuar" : "[E] Terminar");
        }

        private void Advance()
        {
            if (typing) { FinishTyping(); return; }
            if (shownChoices.Count > 0) return; // hay que elegir
            if (node.next != null) ShowNode(node.next);
            else Close();
        }

        private void Choose(int index)
        {
            if (!open || typing || index < 0 || index >= shownChoices.Count) return;
            DialogueChoice c = shownChoices[index];
            AudioManager.Instance.PlayUiClick();
            c.onChosen?.Invoke();
            if (!open) return; // la acción pudo cerrar la conversación
            if (c.next != null) ShowNode(c.next);
            else Close();
        }

        private void Update()
        {
            if (!open || node == null) return;

            if (typing)
            {
                typed += Time.unscaledDeltaTime * CharsPerSecond;
                int n = Mathf.Min(node.text.Length, Mathf.FloorToInt(typed));
                bodyText.text = node.text.Substring(0, n);
                if (n >= node.text.Length) FinishTyping();
            }

            if (Time.frameCount == openedFrame) return; // la [E] que abrió la conversación no cuenta

            if (GameInput.IsCancelPressed())
            {
                CancelConsumedFrame = Time.frameCount;
                Close();
                return;
            }
            int number = GameInput.GetChoiceNumberPressed();
            if (number > 0) { Choose(number - 1); return; }
            if (GameInput.IsDialogueAdvancePressed()) Advance();
        }

        private static Sprite PortraitFor(string key)
        {
            if (string.IsNullOrEmpty(key)) return null;
            // El protagonista se lee siempre de "c_player" (cambia con el creador de personaje); el resto, cacheado
            if (key == "c_player") return GameSprites.Get(key, () => CharacterArt.Draw(CharacterArt.Castaway()));
            return RuntimeSpriteCache.Get("op_" + key, () => GameSprites.Get(key, () => CharacterArt.Draw(CharacterArt.Castaway())));
        }

        // ------------------------------------------------------------------ Construcción

        private void Build()
        {
            root = new GameObject("Canvas_Dialogue");
            root.transform.SetParent(transform, false);
            Canvas canvas = root.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 40; // encima del HUD (0), debajo del combate (50) y los menús (100)
            CanvasScaler scaler = root.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;
            root.AddComponent<GraphicRaycaster>();

            RectTransform content = PirateTheme.Panel(root.transform, "DialogueBox", out RectTransform box);
            UIFactory.Place(box, new Vector2(0.5f, 0f), new Vector2(0f, 30f), new Vector2(1560f, 330f));

            // Clic en la caja = continuar
            Image clickArea = box.Find("Paper").GetComponent<Image>();
            Button areaBtn = clickArea.gameObject.AddComponent<Button>();
            areaBtn.transition = Selectable.Transition.None;
            areaBtn.onClick.AddListener(Advance);
            areaBtn.navigation = new Navigation { mode = Navigation.Mode.None };

            // Retrato
            Image portraitFrame = PirateTheme.Inset(content, "PortraitFrame");
            UIFactory.Place(portraitFrame.rectTransform, new Vector2(0f, 0.5f), new Vector2(0f, 0f), new Vector2(230f, 230f));
            portrait = UIFactory.Box(portraitFrame.transform, "Portrait", Color.white, false);
            portrait.preserveAspect = true;
            portrait.raycastTarget = false;
            UIFactory.Stretch(portrait.rectTransform, 14, 14, 14, 14);

            // Nombre en un tablón sobre la caja
            Button plate = PirateTheme.WoodButton(box, "", new Vector2(380f, 58f), null, 26);
            plate.interactable = true;
            plate.transition = Selectable.Transition.None;
            Destroy(plate.GetComponent<PirateSurvival.UI.ButtonFx>()); // el tablón del nombre no es un botón real
            RectTransform plateRt = (RectTransform)plate.transform;
            UIFactory.Place(plateRt, new Vector2(0f, 1f), new Vector2(40f, 34f), new Vector2(380f, 58f));
            nameText = plate.GetComponentInChildren<Text>();
            nameText.color = PirateTheme.GoldText;

            // Texto
            RectTransform textArea = UIFactory.NewRect("TextArea", content);
            textArea.anchorMin = new Vector2(0f, 0f);
            textArea.anchorMax = new Vector2(1f, 1f);
            textArea.offsetMin = new Vector2(260f, 30f);
            textArea.offsetMax = new Vector2(-500f, -10f);
            bodyText = PirateTheme.InkText(textArea, "", 30, TextAnchor.UpperLeft);
            bodyText.lineSpacing = 1.1f;

            // Respuestas
            for (int i = 0; i < MaxChoices; i++)
            {
                int idx = i;
                Button b = PirateTheme.WoodButton(content, "", new Vector2(470f, 56f), () => Choose(idx), 21);
                RectTransform rt = (RectTransform)b.transform;
                UIFactory.Place(rt, new Vector2(1f, 1f), new Vector2(0f, -4f - i * 62f), new Vector2(470f, 56f));
                Text t = b.GetComponentInChildren<Text>();
                t.alignment = TextAnchor.MiddleLeft;
                UIFactory.Stretch(t.rectTransform, 16, 0, 10, 0);
                t.horizontalOverflow = HorizontalWrapMode.Wrap;
                t.resizeTextForBestFit = true;
                t.resizeTextMinSize = 14;
                t.resizeTextMaxSize = 21;
                choiceButtons[i] = b;
                choiceTexts[i] = t;
            }

            hintText = UIFactory.Label(content, "", 20, PirateTheme.InkSoft, TextAnchor.LowerRight, FontStyle.Italic, false);
            UIFactory.Stretch(hintText.rectTransform, 260, -14, 0, 0);

            root.SetActive(false);
        }
    }
}
