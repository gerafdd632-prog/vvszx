﻿using System.Collections.Generic;
using UnityEngine;
using PirateSurvival.Bootstrap;
using PirateSurvival.Core;
using PirateSurvival.Crafting;

namespace PirateSurvival.Story
{
    /// <summary>
    /// Capítulo 1: El náufrago del East Blue (historia original en el mundo de One Piece).
    /// Despiertas en la playa de Isla Coral; el Capitán Cuervo y su banda tienen atemorizada a la Aldea Coral.
    /// Aprendes a sobrevivir y a forjar acero, echas a los piratas de la playa, derrotas a Cuervo
    /// y consigues barco y primer tripulante para zarpar rumbo al Grand Line.
    /// </summary>
    public static class Chapter1
    {
        public const string Title = "Capítulo 1 · El náufrago del East Blue";
        public const string BossEncounter = "capitan_cuervo";
        public const string UnlockBossStep = "informe";

        public static List<QuestStep> Build()
        {
            return new List<QuestStep>
            {
                new QuestStep
                {
                    id = "beber", title = "Agua dulce",
                    objective = "Tienes mucha sed. Bebe en la charca de agua dulce (noroeste de la playa) con [E].",
                    target = IslandLayout.Pond,
                    isDone = s => s.Flag("bebio_agua")
                },
                new QuestStep
                {
                    id = "abuela", title = "La anciana de la charca",
                    objective = "Habla con la Abuela Marea, junto a la charca.",
                    target = IslandPlacements.NpcAbuela,
                    isDone = s => s.Flag("hablo_abuela")
                },
                new QuestStep
                {
                    id = "aldea", title = "Aldea Coral",
                    objective = "Sigue el camino hasta Aldea Coral y habla con la Alcaldesa Coral en la plaza.",
                    target = IslandPlacements.NpcAlcaldesa,
                    isDone = s => s.Flag("hablo_alcaldesa")
                },
                new QuestStep
                {
                    id = "herrero", title = "El herrero Tetsu",
                    objective = "Ve a la herrería y habla con Tetsu.",
                    target = IslandPlacements.NpcHerrero,
                    isDone = s => s.Flag(RecipeBook.ForgeFlag)
                },
                new QuestStep
                {
                    id = "cuerda", title = "Trenzar cuerda",
                    objective = "Recoge fibra de los arbustos ([E]) y fabrica una Cuerda (Mochila [Tab] → Fabricar).",
                    target = null,
                    isDone = s => s.Count("cuerda") > 0 || s.Flag("craft:cuerda")
                },
                new QuestStep
                {
                    id = "mineral", title = "Hierro de la vieja mina",
                    objective = "Equípate el pico y consigue 4 Mineral de Hierro en las vetas brillantes de la vieja mina del oeste.",
                    target = IslandPlacements.CaveEntrance,
                    isDone = s => s.Count("mineral_hierro") >= 4 || s.Flag("craft:lingote_hierro")
                },
                new QuestStep
                {
                    id = "forjar", title = "Tu primera espada",
                    objective = "En la forja de Tetsu funde lingotes y forja un Sable o una Katana.",
                    target = IslandPlacements.ForgeSpot,
                    isDone = s => s.Flag("craft:sable") || s.Flag("craft:katana") || s.Flag("craft:nodachi")
                },
                new QuestStep
                {
                    id = "cueva_peligro", title = "Peligro en la caverna",
                    objective = "Pon a prueba tu espada en la vieja mina del oeste: limpia el nido de arañas o la plaga de murciélagos.",
                    target = IslandPlacements.EncCuevaAranas,
                    isDone = s => s.Defeated("cueva_aranas") || s.Defeated("cueva_murcielagos")
                },
                new QuestStep
                {
                    id = "piratas", title = "Piratas en la playa",
                    objective = "Equípate la espada y echa a los piratas que acampan en la playa del este.",
                    target = IslandPlacements.EncPiratas,
                    isDone = s => s.Defeated("piratas_playa")
                },
                new QuestStep
                {
                    id = UnlockBossStep, title = "Buenas noticias",
                    objective = "Vuelve a la plaza y cuéntaselo a la Alcaldesa Coral.",
                    target = IslandPlacements.NpcAlcaldesa,
                    isDone = s => s.Flag("alcaldesa_cuervo")
                },
                new QuestStep
                {
                    id = "cuervo", title = "El Capitán Cuervo",
                    objective = "Derrota al Capitán Cuervo en el muelle del norte. ¡De este combate no se puede huir!",
                    target = IslandPlacements.EncCapitan,
                    isDone = s => s.Defeated(BossEncounter),
                    onComplete = s =>
                    {
                        // Una sola vez aunque el capítulo se reevalúe (p. ej. guardados antiguos sin flags de historia)
                        if (s.Progress != null && s.Progress.Bounty < 5000000) s.AddBounty(5000000);
                        GameEvents.TriggerNotificationMessage("¡La Marina pone precio a tu cabeza: 5.000.000 berries! (Mochila → Se busca)");
                    }
                },
                new QuestStep
                {
                    id = "bruno", title = "Un barco y un tripulante",
                    objective = "El barco de Cuervo es tuyo. Habla con Bruno el pescador.",
                    target = IslandPlacements.NpcPescador,
                    isDone = s => s.Flag("bruno_unido")
                },
                new QuestStep
                {
                    id = "cueva_tesoro", title = "El tesoro de los saqueadores",
                    objective = "Desciende a las profundidades de la cueva y derrota a los bandidos para reclamar su cofre del tesoro.",
                    target = IslandPlacements.EncCuevaBandidos,
                    isDone = s => s.Defeated("cueva_bandidos")
                },
                new QuestStep
                {
                    id = "fin", title = "Rumbo a Isla Volcán Negro",
                    objective = "¡Capítulo 1 completado! Ve al extremo norte del muelle y pulsa [E] en el bote de travesía para zarpar hacia la peligrosa Isla Volcán Negro.",
                    target = new Vector2(17.3f, 30.5f),
                    final = true
                },
            };
        }
    }
}
