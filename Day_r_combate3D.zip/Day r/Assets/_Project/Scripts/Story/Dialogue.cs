﻿using System;
using System.Collections.Generic;

namespace PirateSurvival.Story
{
    /// <summary>Respuesta que el jugador puede elegir.</summary>
    public class DialogueChoice
    {
        public string text;
        /// <summary>Nodo al que salta (null = termina la conversación).</summary>
        public string next;
        /// <summary>Se ejecuta al elegirla (dar objetos, marcar flags, reclutar...).</summary>
        public Action onChosen;
        /// <summary>Si devuelve false, la respuesta no aparece.</summary>
        public Func<bool> visible;
    }

    /// <summary>Una frase de un personaje, con sus respuestas o el nodo siguiente.</summary>
    public class DialogueNode
    {
        public string id;
        public string speaker;
        public string portraitKey;
        public string text;
        public string next;
        public Action onEnter;
        public readonly List<DialogueChoice> choices = new List<DialogueChoice>();
    }

    /// <summary>Conversación completa (grafo de nodos). Se crea en el momento de hablar, según cómo vaya la historia.</summary>
    public class Dialogue
    {
        public readonly Dictionary<string, DialogueNode> nodes = new Dictionary<string, DialogueNode>();
        public string start;

        private readonly string defaultSpeaker;
        private readonly string defaultPortrait;
        private DialogueNode last;

        public Dialogue(string speaker, string portraitKey)
        {
            defaultSpeaker = speaker;
            defaultPortrait = portraitKey;
        }

        /// <summary>Añade un nodo hablado por el personaje principal de la conversación.</summary>
        public Dialogue Say(string id, string text, string next = null, Action onEnter = null)
        {
            return SayAs(id, defaultSpeaker, defaultPortrait, text, next, onEnter);
        }

        /// <summary>Añade un nodo dicho por otro (p. ej. "Tú" o un narrador).</summary>
        public Dialogue SayAs(string id, string speaker, string portraitKey, string text, string next = null, Action onEnter = null)
        {
            DialogueNode n = new DialogueNode { id = id, speaker = speaker, portraitKey = portraitKey, text = text, next = next, onEnter = onEnter };
            nodes[id] = n;
            if (start == null) start = id;
            last = n;
            return this;
        }

        /// <summary>Respuesta para el último nodo añadido.</summary>
        public Dialogue Choice(string text, string next, Action onChosen = null, Func<bool> visible = null)
        {
            if (last != null) last.choices.Add(new DialogueChoice { text = text, next = next, onChosen = onChosen, visible = visible });
            return this;
        }

        public DialogueNode Get(string id) => id != null && nodes.TryGetValue(id, out DialogueNode n) ? n : null;
    }
}
