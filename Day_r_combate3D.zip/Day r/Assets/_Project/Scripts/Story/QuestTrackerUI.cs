﻿using UnityEngine;
using UnityEngine.UI;
using PirateSurvival.Core;
using PirateSurvival.Player;
using PirateSurvival.UI;

namespace PirateSurvival.Story
{
    /// <summary>
    /// Objetivo actual de la historia (arriba a la derecha del HUD) con brújula: una flecha que gira hacia el objetivo
    /// y la distancia en metros. Parpadea al cambiar de objetivo.
    /// </summary>
    public class QuestTrackerUI : MonoBehaviour
    {
        private Text chapterText, titleText, objectiveText, distanceText;
        private RectTransform arrow;
        private GameObject compass;
        private Image flash;
        private float flashTimer;
        private Transform player;
        private StoryManager story;

        public static QuestTrackerUI Create(Transform hudRoot)
        {
            RectTransform content = PirateTheme.Panel(hudRoot, "QuestTracker", out RectTransform panel);
            UIFactory.Place(panel, new Vector2(1f, 1f), new Vector2(-20f, -20f), new Vector2(560f, 210f));
            QuestTrackerUI ui = panel.gameObject.AddComponent<QuestTrackerUI>();
            ui.Build(panel, content);
            return ui;
        }

        private void Build(RectTransform panel, RectTransform content)
        {
            foreach (Graphic g in panel.GetComponentsInChildren<Graphic>()) g.raycastTarget = false;

            // Cinta de cabecera náutica / sello de cera
            Image headerRibbon = UIFactory.Box(panel, "HeaderRibbon", new Color(0.68f, 0.18f, 0.15f, 0.95f));
            UIFactory.Place(headerRibbon.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, 6f), new Vector2(260f, 24f));
            Text headerTxt = UIFactory.Label(headerRibbon.transform, "CUADERNO DE BITÁCORA", 12, UIFactory.Gold, TextAnchor.MiddleCenter, FontStyle.Bold);
            UIFactory.Stretch(headerTxt.rectTransform);

            chapterText = UIFactory.Label(content, "", 14, PirateTheme.InkSoft, TextAnchor.UpperLeft, FontStyle.Italic, false);
            UIFactory.Place(chapterText.rectTransform, new Vector2(0f, 1f), new Vector2(0f, -2f), new Vector2(380f, 20f));

            titleText = UIFactory.Label(content, "", 22, PirateTheme.Ink, TextAnchor.UpperLeft, FontStyle.Bold, false);
            UIFactory.Place(titleText.rectTransform, new Vector2(0f, 1f), new Vector2(0f, -24f), new Vector2(380f, 30f));

            objectiveText = UIFactory.Label(content, "", 17, new Color(0.25f, 0.16f, 0.10f), TextAnchor.UpperLeft, FontStyle.Normal, false);
            UIFactory.Place(objectiveText.rectTransform, new Vector2(0f, 1f), new Vector2(0f, -56f), new Vector2(380f, 88f));

            // Brújula náutica auténtica: dial de latón y aguja giratoria
            RectTransform dialRt = UIFactory.NewRect("CompassDial", content);
            UIFactory.Place(dialRt, new Vector2(1f, 1f), new Vector2(-6f, -6f), new Vector2(92f, 92f));
            Image dialImg = dialRt.gameObject.AddComponent<Image>();
            dialImg.sprite = Bootstrap.WorldArt.CompassDial();
            dialImg.raycastTarget = false;
            compass = dialRt.gameObject;

            Image needleImg = UIFactory.Box(dialRt, "CompassNeedle", Color.white, false);
            needleImg.sprite = Bootstrap.WorldArt.CompassNeedle();
            needleImg.raycastTarget = false;
            arrow = needleImg.rectTransform;
            UIFactory.Place(arrow, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(22f, 74f));
            arrow.pivot = new Vector2(0.5f, 0.5f);

            // Insignia de distancia con icono de ancla
            Image distBadge = UIFactory.Box(content, "DistanceBadge", new Color(0.18f, 0.12f, 0.08f, 0.92f));
            UIFactory.Place(distBadge.rectTransform, new Vector2(1f, 1f), new Vector2(-6f, -106f), new Vector2(92f, 26f));
            distanceText = UIFactory.Label(distBadge.transform, "", 14, UIFactory.Gold, TextAnchor.MiddleCenter, FontStyle.Bold, false);
            UIFactory.Stretch(distanceText.rectTransform);

            flash = UIFactory.Box(panel, "Flash", new Color(1f, 0.9f, 0.4f, 0f), false);
            flash.raycastTarget = false;
            UIFactory.Stretch(flash.rectTransform, 12, 12, 12, 12);
        }

        private void Update()
        {
            if (story == null)
            {
                story = StoryManager.Instance;
                if (story == null) return;
                story.OnObjectiveChanged += Refresh;
                Refresh();
            }
            if (player == null)
            {
                PlayerController2D pc = FindAnyObjectByType<PlayerController2D>();
                if (pc != null) player = pc.transform;
            }

            QuestStep step = story.Current;
            bool hasTarget = step != null && step.target.HasValue && player != null;
            compass.SetActive(hasTarget);
            distanceText.gameObject.SetActive(hasTarget);
            if (hasTarget)
            {
                Vector2 to = step.target.Value - (Vector2)player.position;
                float angle = Mathf.Atan2(to.y, to.x) * Mathf.Rad2Deg - 90f;
                arrow.localRotation = Quaternion.Euler(0f, 0f, angle);
                float dist = to.magnitude;
                distanceText.text = dist < 3f ? "¡LLEGASTE!" : $"{dist:0} m";
            }

            if (flashTimer > 0f)
            {
                flashTimer -= Time.unscaledDeltaTime;
                flash.color = new Color(1f, 0.9f, 0.4f, Mathf.Clamp01(flashTimer) * 0.45f * (Mathf.Sin(flashTimer * 12f) * 0.5f + 0.5f));
            }
        }

        private void OnDestroy()
        {
            if (story != null) story.OnObjectiveChanged -= Refresh;
        }

        private void Refresh()
        {
            QuestStep step = story != null ? story.Current : null;
            chapterText.text = story != null ? story.ChapterTitle : string.Empty;
            titleText.text = step != null ? step.title : string.Empty;
            objectiveText.text = step != null ? step.objective : string.Empty;
            flashTimer = 1.6f;
        }
    }
}
