﻿using System.Collections;
using UnityEngine;
using PirateSurvival.Core;

namespace PirateSurvival.Combat3D
{
    /// <summary>
    /// Reloj propio del combate 3D. El juego pone Time.timeScale = 0 fuera de la exploración, así que todo el combate
    /// usa tiempo real, pero SOLO avanza mientras la pantalla es "Battle": con la pausa (ESC) abierta el combate se congela.
    /// También gestiona el "hit-stop" (micro-parón en los golpes fuertes) sin tocar Time.timeScale.
    /// </summary>
    public static class Combat3DTime
    {
        private const float MaxFrame = 0.05f;      // un tirón de FPS no teletransporta animaciones
        private const float HitStopScale = 0.06f;

        private static float hitStopLeft;
        private static int lastTickFrame = -1;

        /// <summary>Segundos de combate acumulados (para ondas, balanceos y parpadeos).</summary>
        public static float Now { get; private set; }

        /// <summary>Multiplicador actual (1 normal, casi 0 durante el hit-stop).</summary>
        public static float Scale => hitStopLeft > 0f ? HitStopScale : 1f;

        /// <summary>Delta de este frame: 0 en pausa, reducido durante el hit-stop.</summary>
        public static float Delta => RawDelta * Scale;

        /// <summary>Delta sin hit-stop (cámara y UI siguen fluidas durante el parón).</summary>
        public static float RawDelta => GameState.Current == GameScreen.Battle ? Mathf.Min(Time.unscaledDeltaTime, MaxFrame) : 0f;

        /// <summary>Lo llama una vez por frame Combat3DManager.</summary>
        public static void Tick()
        {
            if (lastTickFrame == Time.frameCount) return;
            lastTickFrame = Time.frameCount;
            float raw = RawDelta;
            Now += raw * Scale;
            if (hitStopLeft > 0f) hitStopLeft -= raw;
        }

        public static void HitStop(float seconds)
        {
            hitStopLeft = Mathf.Max(hitStopLeft, seconds);
        }

        public static void Reset()
        {
            Now = 0f;
            hitStopLeft = 0f;
        }

        /// <summary>Espera en tiempo de combate (se detiene con la pausa).</summary>
        public static IEnumerator Wait(float seconds)
        {
            float t = 0f;
            while (t < seconds)
            {
                t += Delta;
                yield return null;
            }
        }

        /// <summary>Espera en tiempo de combate sin hit-stop (textos, cámara).</summary>
        public static IEnumerator WaitRaw(float seconds)
        {
            float t = 0f;
            while (t < seconds)
            {
                t += RawDelta;
                yield return null;
            }
        }
    }
}
