﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using PirateSurvival.Core;
using PirateSurvival.UI;

namespace PirateSurvival.Combat3D
{
    /// <summary>Entrada de un submenú (técnica, objeto de la mochila...).</summary>
    public class Combat3DMenuEntry
    {
        public string name;
        public string detail;
        public Color tint = Color.white;
        public bool enabled = true;
    }

    /// <summary>
    /// Interfaz del combate 3D con el estilo de madera y pergamino del juego:
    /// placas de vida del jugador y del rival (barra con estela de daño, energía, estados, rivales restantes),
    /// caja de diálogo con quien habla, menú de órdenes 2x2, submenús de técnicas con daño/coste/precisión,
    /// cartel de turno, números de daño que salen del golpe, presentación "VS", pantalla de resultado,
    /// fundidos y destellos. Atajos: 1-6 eligen, Retroceso o clic derecho vuelve, Intro/Espacio continúa.
    /// </summary>
    public class Combat3DUI : MonoBehaviour
    {
        public Action<int> OnCommand;
        public Action<int> OnMove;
        public Action OnBack;
        public Action OnContinue;

        public Camera WorldCamera { get; set; }

        private RectTransform canvasRect;
        private Plate playerPlate, enemyPlate;
        private Text speakerText, dialogueText;
        private GameObject commandRoot, moveRoot;
        private readonly Button[] commandButtons = new Button[4];
        private static readonly Color[] CommandTints = { new Color(1f, 0.62f, 0.55f), new Color(0.85f, 0.65f, 1f), new Color(0.6f, 0.82f, 1f), new Color(0.82f, 0.82f, 0.82f) };
        private readonly List<GameObject> moveButtons = new List<GameObject>();
        private int moveCount;
        private RectTransform popupLayer;
        private Text bannerText;
        private float bannerTime = -1f;
        private Image fade, flashImg;
        private float flashAlpha;
        private GameObject resultRoot;
        private Text resultTitle, resultBody;
        private RectTransform vsRoot, vsLeft, vsRight;
        private Text vsLeftText, vsRightText, vsText;
        private float vsTime = -1f;
        private string fullDialogue = "";
        private float typed;
        private readonly List<PopupItem> popups = new List<PopupItem>();

        private class Plate
        {
            public RectTransform root;
            public Image portrait;
            public Text name, badge, hpText, stText, status, extra;
            public Image hpFill, hpLag, stFill;
            public float hpTarget = 1f, stTarget = 1f;
            public RectTransform pipsRoot;
        }

        private class PopupItem
        {
            public RectTransform rt;
            public Text text;
            public Vector3 world;
            public float age, life, scale;
            public Color color;
        }

        // ================================================================ Construcción

        public void Build()
        {
            Canvas canvas = gameObject.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 50; // encima del juego y del HUD, debajo de los menús (100)
            CanvasScaler scaler = gameObject.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920f, 1080f);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;
            gameObject.AddComponent<GraphicRaycaster>();
            canvasRect = (RectTransform)transform;

            // Viñeta suave para centrar la mirada
            Image vignette = UIFactory.Box(transform, "Vignette", new Color(0f, 0f, 0f, 0f), false);
            UIFactory.Stretch(vignette.rectTransform);
            vignette.raycastTarget = false;
            vignette.sprite = VignetteSprite();
            vignette.color = new Color(1f, 1f, 1f, 0.75f);

            popupLayer = UIFactory.NewRect("Popups", transform);
            UIFactory.Stretch(popupLayer);

            playerPlate = BuildPlate(true);
            enemyPlate = BuildPlate(false);
            BuildDialogue();
            BuildCommands();
            BuildBanner();
            BuildVersus();
            BuildResult();

            flashImg = UIFactory.Box(transform, "Flash", new Color(1f, 1f, 1f, 0f), false);
            UIFactory.Stretch(flashImg.rectTransform);
            flashImg.raycastTarget = false;
            fade = UIFactory.Box(transform, "Fade", new Color(0f, 0f, 0f, 1f), false);
            UIFactory.Stretch(fade.rectTransform);
            fade.raycastTarget = false;

            HideMenus();
        }

        private Plate BuildPlate(bool isPlayer)
        {
            Plate p = new Plate();
            Vector2 anchor = isPlayer ? new Vector2(0f, 1f) : new Vector2(1f, 1f);
            RectTransform content = PirateTheme.DarkPanel(transform, isPlayer ? "PlayerPlate" : "EnemyPlate", out RectTransform root);
            UIFactory.Place(root, anchor, new Vector2(isPlayer ? 36f : -36f, -30f), new Vector2(600f, isPlayer ? 196f : 186f));
            p.root = root;

            Image frame = PirateTheme.Inset(content, "PortraitFrame");
            UIFactory.Place(frame.rectTransform, new Vector2(0f, 1f), new Vector2(-6f, 6f), new Vector2(116f, 116f));
            RectTransform pr = UIFactory.NewRect("Portrait", frame.rectTransform);
            UIFactory.Stretch(pr, 10f, 10f, 10f, 10f);
            p.portrait = pr.gameObject.AddComponent<Image>();
            p.portrait.preserveAspect = true;
            p.portrait.raycastTarget = false;

            p.name = UIFactory.Label(content, "", 26, PirateTheme.GoldText, TextAnchor.MiddleLeft, FontStyle.Bold);
            UIFactory.Place(p.name.rectTransform, new Vector2(0f, 1f), new Vector2(124f, 4f), new Vector2(300f, 34f));
            p.badge = UIFactory.Label(content, "", 16, PirateTheme.Cream, TextAnchor.MiddleRight, FontStyle.Bold);
            UIFactory.Place(p.badge.rectTransform, new Vector2(1f, 1f), new Vector2(4f, 4f), new Vector2(170f, 34f));

            // Vida
            RectTransform hpBg = Bar(content, "HpBar", new Vector2(124f, -36f), new Vector2(408f, 24f), out p.hpLag, out p.hpFill, UIFactory.Green);
            p.hpText = UIFactory.Label(hpBg, "", 16, Color.white, TextAnchor.MiddleCenter, FontStyle.Bold);
            UIFactory.Stretch(p.hpText.rectTransform);
            Text hpLbl = UIFactory.Label(content, "PV", 15, PirateTheme.Cream, TextAnchor.MiddleRight, FontStyle.Bold);
            UIFactory.Place(hpLbl.rectTransform, new Vector2(0f, 1f), new Vector2(84f, -36f), new Vector2(34f, 24f));

            if (isPlayer)
            {
                RectTransform stBg = Bar(content, "StBar", new Vector2(124f, -66f), new Vector2(408f, 16f), out Image stLag, out p.stFill, new Color(0.3f, 0.72f, 1f));
                stLag.color = new Color(0.2f, 0.35f, 0.6f, 0.6f);
                p.stText = UIFactory.Label(stBg, "", 13, Color.white, TextAnchor.MiddleCenter, FontStyle.Bold);
                UIFactory.Stretch(p.stText.rectTransform);
                Text stLbl = UIFactory.Label(content, "EN", 14, PirateTheme.Cream, TextAnchor.MiddleRight, FontStyle.Bold);
                UIFactory.Place(stLbl.rectTransform, new Vector2(0f, 1f), new Vector2(84f, -62f), new Vector2(34f, 22f));
            }

            p.status = UIFactory.Label(content, "", 15, new Color(1f, 0.75f, 0.45f), TextAnchor.UpperLeft, FontStyle.Bold);
            UIFactory.Place(p.status.rectTransform, new Vector2(0f, 1f), new Vector2(124f, isPlayer ? -88f : -66f), new Vector2(408f, 22f));
            p.extra = UIFactory.Label(content, "", 14, new Color(0.85f, 0.8f, 0.7f), TextAnchor.UpperLeft);
            UIFactory.Place(p.extra.rectTransform, new Vector2(0f, 1f), new Vector2(124f, isPlayer ? -110f : -88f), new Vector2(408f, 22f));

            if (!isPlayer)
            {
                p.pipsRoot = UIFactory.NewRect("Pips", content);
                UIFactory.Place(p.pipsRoot, new Vector2(1f, 1f), new Vector2(0f, -94f), new Vector2(200f, 18f));
            }
            return p;
        }

        private static RectTransform Bar(RectTransform parent, string name, Vector2 pos, Vector2 size, out Image lag, out Image fill, Color fillColor)
        {
            RectTransform bg = UIFactory.NewRect(name, parent);
            UIFactory.Place(bg, new Vector2(0f, 1f), pos, size);
            Image bgImg = bg.gameObject.AddComponent<Image>();
            bgImg.sprite = UIFactory.Rounded;
            bgImg.type = Image.Type.Sliced;
            bgImg.color = new Color(0.08f, 0.05f, 0.04f, 0.95f);
            bgImg.raycastTarget = false;

            RectTransform lagRt = UIFactory.NewRect("Lag", bg);
            UIFactory.Stretch(lagRt, 3f, 3f, 3f, 3f);
            lag = lagRt.gameObject.AddComponent<Image>();
            lag.sprite = UIFactory.White;
            lag.type = Image.Type.Filled;
            lag.fillMethod = Image.FillMethod.Horizontal;
            lag.color = new Color(0.95f, 0.85f, 0.4f, 0.9f);
            lag.raycastTarget = false;

            RectTransform fillRt = UIFactory.NewRect("Fill", bg);
            UIFactory.Stretch(fillRt, 3f, 3f, 3f, 3f);
            fill = fillRt.gameObject.AddComponent<Image>();
            fill.sprite = UIFactory.White;
            fill.type = Image.Type.Filled;
            fill.fillMethod = Image.FillMethod.Horizontal;
            fill.color = fillColor;
            fill.raycastTarget = false;

            // Brillo superior
            Image shine = UIFactory.Box(bg, "Shine", new Color(1f, 1f, 1f, 0.16f), false);
            shine.raycastTarget = false;
            shine.rectTransform.anchorMin = new Vector2(0f, 0.55f);
            shine.rectTransform.anchorMax = new Vector2(1f, 1f);
            shine.rectTransform.offsetMin = new Vector2(3f, 0f);
            shine.rectTransform.offsetMax = new Vector2(-3f, -3f);
            return bg;
        }

        private void BuildDialogue()
        {
            RectTransform content = PirateTheme.DarkPanel(transform, "DialoguePanel", out RectTransform root);
            UIFactory.Place(root, new Vector2(0f, 0f), new Vector2(36f, 26f), new Vector2(1090f, 250f));
            dialogueText = UIFactory.Label(content, "", 27, PirateTheme.Cream, TextAnchor.UpperLeft);
            UIFactory.Stretch(dialogueText.rectTransform, 8f, 4f, 8f, 26f);
            dialogueText.lineSpacing = 1.1f;

            // Tablón con el nombre de quien habla, montado sobre el borde
            RectTransform tag = UIFactory.NewRect("SpeakerTag", root);
            UIFactory.Place(tag, new Vector2(0f, 1f), new Vector2(40f, 22f), new Vector2(300f, 46f));
            Image plank = tag.gameObject.AddComponent<Image>();
            plank.sprite = PirateTheme.Plank();
            plank.type = Image.Type.Sliced;
            plank.raycastTarget = false;
            speakerText = UIFactory.Label(tag, "", 20, PirateTheme.Ink, TextAnchor.MiddleCenter, FontStyle.Bold, false);
            UIFactory.Stretch(speakerText.rectTransform);

            // Clic en la caja = terminar de escribir el texto
            Button skip = root.gameObject.AddComponent<Button>();
            skip.transition = Selectable.Transition.None;
            skip.onClick.AddListener(CompleteDialogue);
            Image hit = root.GetComponent<Image>();
            if (hit == null)
            {
                hit = root.gameObject.AddComponent<Image>();
                hit.color = new Color(0f, 0f, 0f, 0f);
            }
            skip.targetGraphic = hit;
        }

        private void BuildCommands()
        {
            RectTransform content = PirateTheme.DarkPanel(transform, "CommandPanel", out RectTransform root);
            UIFactory.Place(root, new Vector2(1f, 0f), new Vector2(-36f, 26f), new Vector2(740f, 250f));

            commandRoot = UIFactory.NewRect("Commands", content).gameObject;
            UIFactory.Stretch((RectTransform)commandRoot.transform);
            string[] labels = { "1  LUCHAR", "2  FRUTA", "3  MOCHILA", "4  HUIR" };
            for (int i = 0; i < 4; i++)
            {
                int idx = i;
                Button b = PirateTheme.WoodButton(commandRoot.transform, labels[i], new Vector2(318f, 80f), CommandTints[i], () => OnCommand?.Invoke(idx), 26);
                RectTransform rt = (RectTransform)b.transform;
                UIFactory.Place(rt, new Vector2(i % 2 == 0 ? 0f : 1f, 1f), new Vector2(0f, i < 2 ? 0f : -98f), new Vector2(318f, 80f));
                commandButtons[i] = b;
            }

            moveRoot = UIFactory.NewRect("Moves", content).gameObject;
            UIFactory.Stretch((RectTransform)moveRoot.transform);
        }

        private void BuildBanner()
        {
            bannerText = PirateTheme.Title(transform, "", 64);
            UIFactory.Place(bannerText.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0f, 150f), new Vector2(1400f, 110f));
            bannerText.gameObject.SetActive(false);
        }

        private void BuildVersus()
        {
            vsRoot = UIFactory.NewRect("Versus", transform);
            UIFactory.Stretch(vsRoot);
            vsLeft = Ribbon(vsRoot, new Color(0.18f, 0.42f, 0.3f, 0.92f), out vsLeftText);
            vsRight = Ribbon(vsRoot, new Color(0.55f, 0.14f, 0.12f, 0.92f), out vsRightText);
            vsText = PirateTheme.Title(vsRoot, "VS", 110);
            UIFactory.Place(vsText.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0f, 60f), new Vector2(400f, 160f));
            vsRoot.gameObject.SetActive(false);
        }

        private static RectTransform Ribbon(RectTransform parent, Color c, out Text label)
        {
            Image img = UIFactory.Box(parent, "Ribbon", c, false);
            img.raycastTarget = false;
            RectTransform rt = img.rectTransform;
            rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.sizeDelta = new Vector2(1100f, 96f);
            label = PirateTheme.Title(rt, "", 46);
            UIFactory.Stretch(label.rectTransform, 40f, 0f, 40f, 0f);
            return rt;
        }

        private void BuildResult()
        {
            RectTransform content = PirateTheme.Panel(transform, "Result", out RectTransform root);
            UIFactory.Place(root, new Vector2(0.5f, 0.5f), new Vector2(0f, 40f), new Vector2(780f, 560f));
            resultRoot = root.gameObject;
            resultTitle = PirateTheme.Title(content, "", 58);
            UIFactory.Place(resultTitle.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, -6f), new Vector2(700f, 80f));
            resultBody = PirateTheme.InkText(content, "", 24, TextAnchor.UpperCenter);
            UIFactory.Place(resultBody.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, -100f), new Vector2(680f, 300f));
            Button cont = PirateTheme.WoodButton(content, "Continuar  [Intro]", new Vector2(360f, 72f), new Color(0.75f, 1f, 0.75f), () => OnContinue?.Invoke(), 26);
            UIFactory.Place((RectTransform)cont.transform, new Vector2(0.5f, 0f), new Vector2(0f, 0f), new Vector2(360f, 72f));
            resultRoot.SetActive(false);
        }

        // ================================================================ API para el director del combate

        public void SetPlayer(string name, Sprite portrait, float hp, float maxHp, float st, float maxSt, string badge, string status, string extra)
        {
            SetPlate(playerPlate, name, portrait, hp, maxHp, badge, status, extra);
            playerPlate.stTarget = maxSt > 0f ? Mathf.Clamp01(st / maxSt) : 0f;
            if (playerPlate.stText != null) playerPlate.stText.text = $"{Mathf.FloorToInt(st)} / {Mathf.FloorToInt(maxSt)}";
        }

        public void SetEnemy(string name, Sprite portrait, float hp, float maxHp, string badge, string status, string extra, int index, int total)
        {
            SetPlate(enemyPlate, name, portrait, hp, maxHp, badge, status, extra);
            if (enemyPlate.pipsRoot == null) return;
            for (int i = enemyPlate.pipsRoot.childCount - 1; i >= 0; i--) Destroy(enemyPlate.pipsRoot.GetChild(i).gameObject);
            if (total <= 1) return;
            for (int i = 0; i < total; i++)
            {
                Image pip = UIFactory.Box(enemyPlate.pipsRoot, "Pip", i < index ? new Color(0.3f, 0.25f, 0.22f) : i == index ? new Color(1f, 0.4f, 0.3f) : new Color(0.95f, 0.85f, 0.6f));
                pip.raycastTarget = false;
                UIFactory.Place(pip.rectTransform, new Vector2(1f, 0.5f), new Vector2(-(total - 1 - i) * 26f, 0f), new Vector2(18f, 18f));
            }
        }

        private static void SetPlate(Plate p, string name, Sprite portrait, float hp, float maxHp, string badge, string status, string extra)
        {
            p.name.text = name;
            if (portrait != null) p.portrait.sprite = portrait;
            p.badge.text = badge ?? "";
            p.status.text = status ?? "";
            p.extra.text = extra ?? "";
            p.hpTarget = maxHp > 0f ? Mathf.Clamp01(hp / maxHp) : 0f;
            p.hpText.text = $"{Mathf.CeilToInt(Mathf.Max(0f, hp))} / {Mathf.RoundToInt(maxHp)}";
        }

        /// <summary>Pone las barras al valor actual sin animación (al empezar o al cambiar de rival).</summary>
        public void SnapBars(bool enemyOnly = false)
        {
            if (!enemyOnly)
            {
                playerPlate.hpFill.fillAmount = playerPlate.hpLag.fillAmount = playerPlate.hpTarget;
                if (playerPlate.stFill != null) playerPlate.stFill.fillAmount = playerPlate.stTarget;
            }
            enemyPlate.hpFill.fillAmount = enemyPlate.hpLag.fillAmount = enemyPlate.hpTarget;
        }

        public void SetDialogue(string text, string speaker)
        {
            fullDialogue = text ?? "";
            typed = 0f;
            dialogueText.text = "";
            speakerText.text = string.IsNullOrEmpty(speaker) ? "COMBATE" : speaker.ToUpperInvariant();
        }

        public bool IsTyping => dialogueText != null && typed < fullDialogue.Length;

        public void CompleteDialogue()
        {
            typed = fullDialogue.Length;
            if (dialogueText != null) dialogueText.text = fullDialogue;
        }

        public void ShowCommands(bool fruitUnlocked, int bagCount, bool canFlee)
        {
            moveRoot.SetActive(false);
            commandRoot.SetActive(true);
            UIFactory.SetButtonLabel(commandButtons[1], fruitUnlocked ? "2  FRUTA" : "2  FRUTA (sin fruta)");
            UIFactory.SetButtonLabel(commandButtons[2], bagCount > 0 ? $"3  MOCHILA ({bagCount})" : "3  MOCHILA (vacía)");
            UIFactory.SetButtonLabel(commandButtons[3], canFlee ? "4  HUIR" : "4  HUIR (imposible)");
            SetCommandLook(1, fruitUnlocked);
            SetCommandLook(2, bagCount > 0);
            SetCommandLook(3, canFlee);
        }

        private void SetCommandLook(int i, bool available)
        {
            // Se pueden pulsar igualmente (explican por qué no se puede), pero se ven apagados
            Button b = commandButtons[i];
            Text t = b.GetComponentInChildren<Text>(true);
            if (t != null) t.color = available ? PirateTheme.Cream : new Color(0.75f, 0.68f, 0.6f);
            ((Image)b.targetGraphic).color = available ? CommandTints[i] : new Color(0.55f, 0.52f, 0.5f);
        }

        public void ShowMoves(List<Combat3DMenuEntry> entries)
        {
            commandRoot.SetActive(false);
            moveRoot.SetActive(true);
            foreach (GameObject g in moveButtons) if (g != null) Destroy(g);
            moveButtons.Clear();

            moveCount = Mathf.Min(entries.Count, 5);
            for (int i = 0; i < 6; i++)
            {
                bool isBack = i == 5;
                if (!isBack && i >= moveCount) continue;
                int idx = i;
                Combat3DMenuEntry e = isBack ? null : entries[i];
                string label = isBack ? "6  VOLVER" : $"{i + 1}  {e.name}";
                Color tint = isBack ? new Color(0.82f, 0.82f, 0.82f) : e.tint;
                Button b = PirateTheme.WoodButton(moveRoot.transform, label, new Vector2(320f, 56f), tint,
                    isBack ? (UnityEngine.Events.UnityAction)(() => OnBack?.Invoke()) : () => OnMove?.Invoke(idx), 19);
                RectTransform rt = (RectTransform)b.transform;
                UIFactory.Place(rt, new Vector2(i % 2 == 0 ? 0f : 1f, 1f), new Vector2(0f, -(i / 2) * 63f), new Vector2(320f, 56f));

                Text main = b.GetComponentInChildren<Text>(true);
                if (main != null && !isBack)
                {
                    main.alignment = TextAnchor.UpperCenter;
                    main.rectTransform.offsetMax = new Vector2(main.rectTransform.offsetMax.x, -5f);
                    Text sub = UIFactory.Label(rt, e.detail ?? "", 14, e.enabled ? new Color(1f, 0.88f, 0.6f) : new Color(1f, 0.55f, 0.45f), TextAnchor.LowerCenter, FontStyle.Bold, false);
                    UIFactory.Stretch(sub.rectTransform, 8f, 5f, 8f, 0f);
                    Outline so = sub.gameObject.AddComponent<Outline>();
                    so.effectColor = new Color(0.15f, 0.08f, 0.03f, 1f);
                    so.effectDistance = new Vector2(1.5f, -1.5f);
                    if (!e.enabled)
                    {
                        main.color = new Color(0.82f, 0.76f, 0.7f);
                        ((Image)b.targetGraphic).color = new Color(0.58f, 0.54f, 0.5f);
                    }
                }
                moveButtons.Add(b.gameObject);
            }
        }

        public void HideMenus()
        {
            // Que el botón pulsado con el ratón no quede seleccionado (Intro/Espacio lo volverían a pulsar)
            if (UnityEngine.EventSystems.EventSystem.current != null) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(null);
            if (commandRoot != null) commandRoot.SetActive(false);
            if (moveRoot != null) moveRoot.SetActive(false);
        }

        public bool MenusVisible => (commandRoot != null && commandRoot.activeSelf) || (moveRoot != null && moveRoot.activeSelf);

        public void Banner(string text, Color color)
        {
            bannerText.text = text;
            bannerText.color = color;
            bannerText.gameObject.SetActive(true);
            bannerTime = 0f;
        }

        /// <summary>Número o texto que sale del punto del mundo indicado (daño, fallo, curación, estado).</summary>
        public void Popup(Vector3 world, string text, Color color, float scale = 1f)
        {
            Text t = UIFactory.Label(popupLayer, text, 44, color, TextAnchor.MiddleCenter, FontStyle.Bold, false);
            Outline o = t.gameObject.AddComponent<Outline>();
            o.effectColor = new Color(0.08f, 0.04f, 0.02f, 1f);
            o.effectDistance = new Vector2(3f, -3f);
            RectTransform rt = t.rectTransform;
            rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.sizeDelta = new Vector2(600f, 80f);
            popups.Add(new PopupItem { rt = rt, text = t, world = world + UnityEngine.Random.insideUnitSphere * 0.25f, age = 0f, life = 1.1f, scale = scale, color = color });
        }

        public void Flash(Color c, float alpha)
        {
            flashImg.color = new Color(c.r, c.g, c.b, 0f);
            flashAlpha = Mathf.Max(flashAlpha, alpha);
        }

        public IEnumerator FadeTo(float target, float duration)
        {
            float start = fade.color.a;
            float t = 0f;
            while (t < duration)
            {
                t += Time.unscaledDeltaTime;
                fade.color = new Color(0f, 0f, 0f, Mathf.Lerp(start, target, Mathf.Clamp01(t / duration)));
                yield return null;
            }
            fade.color = new Color(0f, 0f, 0f, target);
        }

        public void Versus(string left, string right)
        {
            vsLeftText.text = left;
            vsRightText.text = right;
            vsRoot.gameObject.SetActive(true);
            vsTime = 0f;
        }

        public void ShowResult(bool victory, string title, string body)
        {
            HideMenus();
            resultTitle.text = title;
            resultTitle.color = victory ? PirateTheme.GoldText : new Color(0.95f, 0.45f, 0.4f);
            resultBody.text = body;
            resultRoot.SetActive(true);
            resultRoot.transform.localScale = Vector3.one * 0.6f;
        }

        public bool ResultVisible => resultRoot != null && resultRoot.activeSelf;

        // ================================================================ Bucle

        private void Update()
        {
            float dt = Time.unscaledDeltaTime;
            AnimatePlate(playerPlate, dt);
            AnimatePlate(enemyPlate, dt);

            // Máquina de escribir (~70 letras/s)
            if (typed < fullDialogue.Length && GameState.Current == GameScreen.Battle)
            {
                typed = Mathf.Min(fullDialogue.Length, typed + dt * 70f);
                dialogueText.text = fullDialogue.Substring(0, Mathf.FloorToInt(typed));
            }

            // Cartel de turno: entra grande, se asienta, se va
            if (bannerTime >= 0f)
            {
                bannerTime += dt;
                float k = bannerTime;
                float s = k < 0.18f ? Mathf.Lerp(1.8f, 1f, k / 0.18f) : 1f;
                float a = k < 0.1f ? k / 0.1f : k > 1.1f ? Mathf.Clamp01(1f - (k - 1.1f) / 0.3f) : 1f;
                bannerText.rectTransform.localScale = Vector3.one * s;
                Color c = bannerText.color; c.a = a; bannerText.color = c;
                if (k > 1.4f) { bannerText.gameObject.SetActive(false); bannerTime = -1f; }
            }

            // Presentación VS
            if (vsTime >= 0f)
            {
                vsTime += dt;
                float k = Mathf.Clamp01(vsTime / 0.35f);
                float e = 1f - Mathf.Pow(1f - k, 3f);
                float outK = Mathf.Clamp01((vsTime - 1.7f) / 0.35f);
                vsLeft.anchoredPosition = new Vector2(Mathf.Lerp(-1500f, -260f, e) - outK * 1400f, 150f);
                vsRight.anchoredPosition = new Vector2(Mathf.Lerp(1500f, 260f, e) + outK * 1400f, -30f);
                vsText.rectTransform.localScale = Vector3.one * (vsTime < 0.35f ? Mathf.Lerp(3f, 1f, e) : 1f + Mathf.Sin(vsTime * 8f) * 0.03f);
                Color vc = vsText.color; vc.a = 1f - outK; vsText.color = vc;
                if (vsTime > 2.1f) { vsRoot.gameObject.SetActive(false); vsTime = -1f; }
            }

            // Destello de pantalla
            if (flashAlpha > 0f)
            {
                flashAlpha = Mathf.Max(0f, flashAlpha - dt * 4f);
                Color fc = flashImg.color; fc.a = flashAlpha; flashImg.color = fc;
            }

            // Resultado: aparece con rebote
            if (resultRoot != null && resultRoot.activeSelf)
            {
                Vector3 sc = resultRoot.transform.localScale;
                resultRoot.transform.localScale = Vector3.Lerp(sc, Vector3.one, 1f - Mathf.Exp(-12f * dt));
            }

            UpdatePopups(dt);
            HandleKeys();
        }

        private void AnimatePlate(Plate p, float dt)
        {
            if (p == null) return;
            p.hpFill.fillAmount = Mathf.MoveTowards(p.hpFill.fillAmount, p.hpTarget, dt * 1.6f);
            float lagSpeed = p.hpLag.fillAmount > p.hpFill.fillAmount ? 0.45f : 4f;
            p.hpLag.fillAmount = Mathf.MoveTowards(p.hpLag.fillAmount, Mathf.Max(p.hpTarget, 0f), dt * lagSpeed);
            if (p.hpLag.fillAmount < p.hpFill.fillAmount) p.hpLag.fillAmount = p.hpFill.fillAmount;
            float f = p.hpFill.fillAmount;
            p.hpFill.color = f > 0.5f ? Color.Lerp(new Color(0.95f, 0.75f, 0.2f), new Color(0.3f, 0.78f, 0.35f), (f - 0.5f) * 2f)
                                      : Color.Lerp(new Color(0.85f, 0.18f, 0.15f), new Color(0.95f, 0.75f, 0.2f), f * 2f);
            if (p.stFill != null) p.stFill.fillAmount = Mathf.MoveTowards(p.stFill.fillAmount, p.stTarget, dt * 2f);
        }

        private void UpdatePopups(float dt)
        {
            for (int i = popups.Count - 1; i >= 0; i--)
            {
                PopupItem p = popups[i];
                if (GameState.Current == GameScreen.Battle) p.age += dt;
                if (p.age >= p.life || p.rt == null)
                {
                    if (p.rt != null) Destroy(p.rt.gameObject);
                    popups.RemoveAt(i);
                    continue;
                }
                float k = p.age / p.life;
                Vector3 w = p.world + Vector3.up * (k * 1.1f);
                bool visible = false;
                if (WorldCamera != null)
                {
                    Vector3 sp = WorldCamera.WorldToScreenPoint(w);
                    if (sp.z > 0f && RectTransformUtility.ScreenPointToLocalPointInRectangle(canvasRect, sp, null, out Vector2 local))
                    {
                        p.rt.anchoredPosition = local;
                        visible = true;
                    }
                }
                p.rt.gameObject.SetActive(visible);
                float pop = k < 0.12f ? Mathf.Lerp(1.9f, 1f, k / 0.12f) : 1f;
                p.rt.localScale = Vector3.one * p.scale * pop;
                Color c = p.color; c.a = k > 0.7f ? 1f - (k - 0.7f) / 0.3f : 1f;
                p.text.color = c;
            }
        }

        private void HandleKeys()
        {
            if (GameState.Current != GameScreen.Battle) return; // con la pausa abierta las teclas son del menú

            if (resultRoot.activeSelf)
            {
                if (GameInput.IsBattleKeyPressed(BattleKey.Confirm)) OnContinue?.Invoke();
                return;
            }

            if (IsTyping && GameInput.IsBattleKeyPressed(BattleKey.Confirm))
            {
                CompleteDialogue();
                return;
            }

            int digit = GameInput.GetBattleDigitPressed();
            if (commandRoot.activeSelf)
            {
                if (digit >= 1 && digit <= 4) { Click(); OnCommand?.Invoke(digit - 1); }
            }
            else if (moveRoot.activeSelf)
            {
                if (digit >= 1 && digit <= moveCount) { Click(); OnMove?.Invoke(digit - 1); }
                else if (digit == 6 || GameInput.IsBattleBackPressed()) { Click(); OnBack?.Invoke(); }
            }
        }

        private static void Click()
        {
            if (AudioManager.Instance != null) AudioManager.Instance.PlayUiClick();
        }

        private static Sprite VignetteSprite() => RuntimeSpriteCache.Get("c3d_vignette", () =>
        {
            const int S = 64;
            Texture2D tex = new Texture2D(S, S, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Bilinear;
            tex.wrapMode = TextureWrapMode.Clamp;
            for (int y = 0; y < S; y++)
                for (int x = 0; x < S; x++)
                {
                    float dx = (x + 0.5f) / S * 2f - 1f, dy = (y + 0.5f) / S * 2f - 1f;
                    float d = Mathf.Sqrt(dx * dx * 0.7f + dy * dy);
                    float a = Mathf.SmoothStep(0f, 0.6f, Mathf.InverseLerp(0.7f, 1.4f, d));
                    tex.SetPixel(x, y, new Color(0.02f, 0.02f, 0.05f, a));
                }
            tex.Apply();
            return Sprite.Create(tex, new Rect(0, 0, S, S), new Vector2(0.5f, 0.5f), 100f);
        });
    }
}
