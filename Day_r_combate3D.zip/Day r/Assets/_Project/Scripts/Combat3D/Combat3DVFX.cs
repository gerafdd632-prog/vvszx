﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace PirateSurvival.Combat3D
{
    public enum ProjectileKind { Bullet, Pellet, Fireball, Venom }

    /// <summary>
    /// Efectos del combate 3D con un sistema de partículas propio (quads reutilizados, sin crear objetos por golpe):
    /// chispas, destellos, tajos, zarpazos, polvo, ondas en el suelo, brasas, curación, auras, veneno, sangre,
    /// fogonazos y proyectiles. Incluye el brazo elástico de la Fruta (puñetazo estirado, ráfaga y martillo).
    /// Todo avanza con Combat3DTime (se congela en la pausa y respeta el hit-stop).
    /// </summary>
    public class Combat3DVFX : MonoBehaviour
    {
        public static Combat3DVFX Instance { get; private set; }

        public Camera Cam { get; set; }

        private const int MaxParticles = 450;

        private class P
        {
            public Transform t;
            public MeshFilter f;
            public MeshRenderer r;
            public bool active;
            public Vector3 pos, vel;
            public float age, life, size0, size1, rot, rotSpeed, gravity, drag, stretch, aspect;
            public Color c0, c1;
            public bool ground, fixedPose, manual;
        }

        private readonly List<P> pool = new List<P>();
        private readonly Dictionary<Texture, Material> customMats = new Dictionary<Texture, Material>();
        private readonly List<UnityEngine.Object> owned = new List<UnityEngine.Object>();
        private MaterialPropertyBlock block;
        private Mesh armMesh, fistMesh;
        private Material skinMat, hakiMat;

        private void Awake()
        {
            Instance = this;
            block = new MaterialPropertyBlock();
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
            foreach (UnityEngine.Object o in owned) if (o != null) Destroy(o);
            owned.Clear();
        }

        // ================================================================ Núcleo de partículas

        private P Get()
        {
            for (int i = 0; i < pool.Count; i++) if (!pool[i].active) return pool[i];
            if (pool.Count >= MaxParticles)
            {
                // Reutiliza la más avanzada en su vida (nunca un proyectil en vuelo)
                P oldest = null;
                for (int i = 0; i < pool.Count; i++)
                {
                    if (pool[i].manual) continue;
                    if (oldest == null || pool[i].age / Mathf.Max(0.01f, pool[i].life) > oldest.age / Mathf.Max(0.01f, oldest.life)) oldest = pool[i];
                }
                if (oldest != null) return oldest;
            }
            GameObject go = new GameObject("fx");
            go.transform.SetParent(transform, false);
            P p = new P { t = go.transform, f = go.AddComponent<MeshFilter>(), r = go.AddComponent<MeshRenderer>() };
            p.r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            p.r.receiveShadows = false;
            p.r.sortingOrder = 20;
            pool.Add(p);
            return p;
        }

        private P Spawn(Material mat, Vector3 pos, Vector3 vel, float life, float size0, float size1, Color c0, Color c1,
            float gravity = 0f, float drag = 0f, float rot = 0f, float rotSpeed = 0f, bool ground = false, float stretch = 0f, float aspect = 1f)
        {
            P p = Get();
            p.active = true;
            p.manual = false;
            p.fixedPose = false;
            p.t.gameObject.SetActive(true);
            p.f.sharedMesh = ground ? Combat3DAssets.GroundQuad : Combat3DAssets.Quad;
            p.r.sharedMaterial = mat;
            p.pos = pos; p.vel = vel;
            p.age = 0f; p.life = Mathf.Max(0.01f, life);
            p.size0 = size0; p.size1 = size1;
            p.c0 = c0; p.c1 = c1;
            p.gravity = gravity; p.drag = drag;
            p.rot = rot; p.rotSpeed = rotSpeed;
            p.ground = ground; p.stretch = stretch; p.aspect = aspect;
            Apply(p);
            return p;
        }

        private P Spawn(string tex, bool additive, Vector3 pos, Vector3 vel, float life, float size0, float size1, Color c0, Color c1,
            float gravity = 0f, float drag = 0f, float rot = 0f, float rotSpeed = 0f, bool ground = false, float stretch = 0f, float aspect = 1f)
            => Spawn(Combat3DAssets.Fx(tex, additive), pos, vel, life, size0, size1, c0, c1, gravity, drag, rot, rotSpeed, ground, stretch, aspect);

        private void Kill(P p)
        {
            p.active = false;
            p.manual = false;
            if (p.t != null) p.t.gameObject.SetActive(false);
        }

        private void Update()
        {
            float dt = Combat3DTime.Delta;
            for (int i = 0; i < pool.Count; i++)
            {
                P p = pool[i];
                if (!p.active || p.manual) continue;
                p.age += dt;
                if (p.age >= p.life) { Kill(p); continue; }
                p.vel += Vector3.down * p.gravity * dt;
                if (p.drag > 0f) p.vel *= Mathf.Max(0f, 1f - p.drag * dt);
                p.pos += p.vel * dt;
                p.rot += p.rotSpeed * dt;
                Apply(p);
            }
        }

        private void Apply(P p)
        {
            float k = Mathf.Clamp01(p.age / p.life);
            float ease = 1f - (1f - k) * (1f - k);
            float size = Mathf.Lerp(p.size0, p.size1, ease);
            Color c = Color.Lerp(p.c0, p.c1, k);
            if (!p.fixedPose)
            {
                p.t.position = p.pos;
                if (p.ground)
                {
                    p.t.rotation = Quaternion.Euler(0f, p.rot, 0f);
                    p.t.localScale = new Vector3(size, 1f, size);
                }
                else
                {
                    Quaternion face = Cam != null
                        ? Quaternion.LookRotation(p.pos - Cam.transform.position, Cam.transform.up)
                        : Quaternion.identity;
                    float roll = p.rot;
                    float sx = size * p.aspect;
                    if (p.stretch > 0f && Cam != null && p.vel.sqrMagnitude > 0.0001f)
                    {
                        Vector3 v = Cam.transform.InverseTransformDirection(p.vel);
                        roll = Mathf.Atan2(v.y, v.x) * Mathf.Rad2Deg;
                        sx = size * (1f + p.vel.magnitude * p.stretch);
                    }
                    p.t.rotation = face * Quaternion.Euler(0f, 0f, roll);
                    p.t.localScale = new Vector3(sx, size, 1f);
                }
            }
            p.r.GetPropertyBlock(block);
            block.SetColor("_Color", c);
            block.SetColor("_BaseColor", c);
            p.r.SetPropertyBlock(block);
        }

        private static Color A(Color c, float a) { c.a = a; return c; }

        // ================================================================ Golpes

        /// <summary>Impacto: destello en estrella, onda, chispas alargadas y algo de polvo. power ~1 normal, 2 brutal.</summary>
        public void HitSpark(Vector3 pos, Color color, float power = 1f)
        {
            Spawn("spark", true, pos, Vector3.zero, 0.16f, 0.6f * power, 2.6f * power, A(Color.white, 1f), A(color, 0f), 0f, 0f, UnityEngine.Random.Range(0f, 360f));
            Spawn("softcircle", true, pos, Vector3.zero, 0.22f, 0.8f * power, 2.8f * power, A(color, 0.9f), A(color, 0f));
            Spawn("ring", true, pos, Vector3.zero, 0.26f, 0.5f * power, 3.4f * power, A(Color.white, 0.9f), A(color, 0f));
            int n = Mathf.RoundToInt(10 * power);
            for (int i = 0; i < n; i++)
            {
                Vector3 v = UnityEngine.Random.onUnitSphere * UnityEngine.Random.Range(4f, 9f) * Mathf.Sqrt(power);
                v.y = Mathf.Abs(v.y) * 0.8f + 1f;
                Spawn("streak", true, pos, v, UnityEngine.Random.Range(0.18f, 0.34f), 0.14f, 0.05f, A(Color.Lerp(Color.white, color, 0.4f), 1f), A(color, 0f), 14f, 2f, 0f, 0f, false, 0.12f, 1f);
            }
        }

        /// <summary>Tajo de espada: medialuna brillante que barre y se desvanece (ángulo en grados de pantalla).</summary>
        public void Slash(Vector3 pos, Color color, float angle, float size = 1f, bool mirrored = false)
        {
            float spin = mirrored ? -260f : 260f;
            Spawn("slash", true, pos, Vector3.zero, 0.24f, 1.4f * size, 2.6f * size, A(color, 1f), A(color, 0f), 0f, 0f, angle, spin, false, 0f, mirrored ? -1f : 1f);
            Spawn("slash", true, pos, Vector3.zero, 0.18f, 1.2f * size, 2.3f * size, A(Color.white, 0.9f), A(Color.white, 0f), 0f, 0f, angle + (mirrored ? 8f : -8f), spin, false, 0f, mirrored ? -0.8f : 0.8f);
        }

        /// <summary>Zarpazo / mordisco de animal: tres arañazos.</summary>
        public void Claw(Vector3 pos, Color color)
        {
            Spawn("claw", true, pos, Vector3.zero, 0.3f, 0.9f, 1.5f, A(color, 1f), A(color, 0f), 0f, 0f, UnityEngine.Random.Range(-30f, 30f));
            Spawn("claw", false, pos, Vector3.zero, 0.3f, 0.85f, 1.45f, A(new Color(0.6f, 0.05f, 0.05f), 0.8f), A(new Color(0.6f, 0.05f, 0.05f), 0f), 0f, 0f, UnityEngine.Random.Range(-30f, 30f));
        }

        /// <summary>Nube de polvo que se levanta del suelo.</summary>
        public void Dust(Vector3 groundPos, int count, float radius, Color color, float strength = 1f)
        {
            for (int i = 0; i < count; i++)
            {
                Vector2 c = UnityEngine.Random.insideUnitCircle;
                Vector3 p = groundPos + new Vector3(c.x * radius, 0.15f, c.y * radius);
                Vector3 v = new Vector3(c.x * 2.4f, UnityEngine.Random.Range(0.6f, 1.6f), c.y * 2.4f) * strength;
                Spawn("smoke", false, p, v, UnityEngine.Random.Range(0.5f, 0.9f), 0.35f, UnityEngine.Random.Range(0.9f, 1.5f) * strength, color, A(color, 0f), -0.4f, 2.2f, UnityEngine.Random.Range(0f, 360f), UnityEngine.Random.Range(-60f, 60f));
            }
        }

        /// <summary>Onda expansiva tumbada en el suelo.</summary>
        public void GroundRing(Vector3 groundPos, Color color, float size = 4f)
        {
            Spawn("ring", true, groundPos + Vector3.up * 0.06f, Vector3.zero, 0.38f, 0.6f, size, A(color, 0.95f), A(color, 0f), 0f, 0f, 0f, 0f, true);
            Spawn("softcircle", true, groundPos + Vector3.up * 0.05f, Vector3.zero, 0.3f, 0.5f, size * 0.7f, A(color, 0.5f), A(color, 0f), 0f, 0f, 0f, 0f, true);
        }

        public void MuzzleFlash(Vector3 pos, Vector3 dir)
        {
            Spawn("spark", true, pos, Vector3.zero, 0.09f, 0.4f, 1.3f, A(new Color(1f, 0.95f, 0.7f), 1f), A(new Color(1f, 0.6f, 0.2f), 0f), 0f, 0f, UnityEngine.Random.Range(0f, 360f));
            for (int i = 0; i < 6; i++)
            {
                Vector3 v = dir * UnityEngine.Random.Range(1f, 3f) + UnityEngine.Random.insideUnitSphere * 0.8f + Vector3.up * 0.4f;
                Spawn("smoke", false, pos, v, UnityEngine.Random.Range(0.5f, 0.9f), 0.2f, 0.9f, A(new Color(0.75f, 0.72f, 0.7f), 0.7f), A(new Color(0.75f, 0.72f, 0.7f), 0f), -0.5f, 2.5f, UnityEngine.Random.Range(0f, 360f), 40f);
            }
        }

        // ================================================================ Ambiente y estados

        public void Ember(Vector3 pos, Color color)
        {
            Vector3 v = new Vector3(UnityEngine.Random.Range(-0.3f, 0.3f), UnityEngine.Random.Range(0.8f, 1.6f), UnityEngine.Random.Range(-0.3f, 0.3f));
            Spawn("softcircle", true, pos + UnityEngine.Random.insideUnitSphere * 0.1f, v, UnityEngine.Random.Range(0.8f, 1.4f), 0.12f, 0.03f, A(color, 1f), A(color, 0f), -0.2f, 0.5f);
        }

        public void HealBurst(Vector3 feet)
        {
            Spawn("softcircle", true, feet + Vector3.up * 1.0f, Vector3.zero, 0.6f, 1.2f, 3.2f, A(new Color(0.4f, 1f, 0.5f), 0.6f), A(new Color(0.4f, 1f, 0.5f), 0f));
            GroundRing(feet, new Color(0.4f, 1f, 0.55f), 3.2f);
            for (int i = 0; i < 14; i++)
            {
                Vector2 c = UnityEngine.Random.insideUnitCircle * 0.8f;
                Vector3 p = feet + new Vector3(c.x, UnityEngine.Random.Range(0.1f, 1.2f), c.y);
                Spawn(i % 2 == 0 ? "plus" : "softcircle", true, p, Vector3.up * UnityEngine.Random.Range(1.2f, 2.2f), UnityEngine.Random.Range(0.7f, 1.1f),
                    i % 2 == 0 ? 0.32f : 0.18f, 0.08f, A(new Color(0.55f, 1f, 0.6f), 1f), A(new Color(0.55f, 1f, 0.6f), 0f), 0f, 0.6f);
            }
        }

        /// <summary>Chispas que suben alrededor del cuerpo (Haki, concentración, guardia).</summary>
        public void Aura(Vector3 feet, Color color, int count = 6)
        {
            for (int i = 0; i < count; i++)
            {
                Vector2 c = UnityEngine.Random.insideUnitCircle.normalized * UnityEngine.Random.Range(0.4f, 0.8f);
                Vector3 p = feet + new Vector3(c.x, UnityEngine.Random.Range(0f, 0.6f), c.y);
                Spawn("streak", true, p, Vector3.up * UnityEngine.Random.Range(2f, 3.6f), UnityEngine.Random.Range(0.35f, 0.6f), 0.2f, 0.08f, A(color, 1f), A(color, 0f), -1f, 0f, 0f, 0f, false, 0.25f);
            }
        }

        public void PoisonPuff(Vector3 pos)
        {
            for (int i = 0; i < 6; i++)
            {
                Vector3 p = pos + UnityEngine.Random.insideUnitSphere * 0.4f;
                Spawn("bubble", false, p, Vector3.up * UnityEngine.Random.Range(0.6f, 1.2f), UnityEngine.Random.Range(0.6f, 1f), 0.15f, 0.32f,
                    A(new Color(0.55f, 0.95f, 0.3f), 0.9f), A(new Color(0.55f, 0.95f, 0.3f), 0f), 0f, 1f);
            }
        }

        public void BleedDrops(Vector3 pos)
        {
            for (int i = 0; i < 8; i++)
            {
                Vector3 v = new Vector3(UnityEngine.Random.Range(-1.5f, 1.5f), UnityEngine.Random.Range(1f, 2.5f), UnityEngine.Random.Range(-1.5f, 1.5f));
                Spawn("softcircle", false, pos, v, UnityEngine.Random.Range(0.4f, 0.6f), 0.14f, 0.08f, A(new Color(0.75f, 0.05f, 0.05f), 1f), A(new Color(0.5f, 0.02f, 0.02f), 0f), 9f);
            }
        }

        public void BurnFlames(Vector3 feet)
        {
            for (int i = 0; i < 7; i++)
            {
                Vector2 c = UnityEngine.Random.insideUnitCircle * 0.45f;
                Vector3 p = feet + new Vector3(c.x, UnityEngine.Random.Range(0.1f, 0.9f), c.y);
                Spawn("flame", true, p, Vector3.up * UnityEngine.Random.Range(1f, 2f), UnityEngine.Random.Range(0.35f, 0.6f), 0.5f, 0.15f,
                    A(new Color(1f, 0.8f, 0.4f), 1f), A(new Color(1f, 0.3f, 0.05f), 0f), 0f, 0.5f, 0f, 0f, false, 0f, 0.55f);
            }
        }

        public void Stars(Vector3 headPos)
        {
            for (int i = 0; i < 4; i++)
            {
                float ang = i * 90f * Mathf.Deg2Rad;
                Vector3 p = headPos + new Vector3(Mathf.Cos(ang) * 0.45f, 0.1f, Mathf.Sin(ang) * 0.45f);
                Spawn("star5", true, p, new Vector3(-Mathf.Sin(ang), 0f, Mathf.Cos(ang)) * 1.6f, 0.7f, 0.32f, 0.18f, A(new Color(1f, 0.95f, 0.4f), 1f), A(new Color(1f, 0.95f, 0.4f), 0f), 0f, 0f, 0f, 220f);
            }
        }

        /// <summary>Imagen residual: copia del cuerpo del luchador que se desvanece (para embestidas y esquivas).</summary>
        public void Ghost(Transform body, Mesh mesh, Texture tex, Color tint, float life = 0.28f)
        {
            if (body == null || mesh == null || tex == null) return;
            if (!customMats.TryGetValue(tex, out Material mat) || mat == null)
            {
                mat = Combat3DAssets.NewFx(tex, true);
                owned.Add(mat);
                customMats[tex] = mat;
            }
            P p = Spawn(mat, body.position, Vector3.zero, life, 1f, 1f, A(tint, 0.6f), A(tint, 0f));
            p.f.sharedMesh = mesh;
            p.fixedPose = true;
            p.t.position = body.position;
            p.t.rotation = body.rotation;
            p.t.localScale = body.lossyScale;
        }

        // ================================================================ Proyectiles

        public IEnumerator Projectile(Vector3 from, Vector3 to, ProjectileKind kind, float speed, Action onHit)
        {
            P core;
            switch (kind)
            {
                case ProjectileKind.Fireball:
                    core = Spawn("softcircle", true, from, Vector3.zero, 99f, 1.1f, 1.1f, A(new Color(1f, 0.6f, 0.15f), 1f), A(new Color(1f, 0.6f, 0.15f), 1f));
                    break;
                case ProjectileKind.Venom:
                    core = Spawn("bubble", false, from, Vector3.zero, 99f, 0.45f, 0.45f, A(new Color(0.5f, 0.95f, 0.25f), 1f), A(new Color(0.5f, 0.95f, 0.25f), 1f));
                    break;
                case ProjectileKind.Pellet:
                    core = Spawn("softcircle", true, from, Vector3.zero, 99f, 0.32f, 0.32f, A(new Color(0.9f, 0.9f, 0.85f), 1f), A(new Color(0.9f, 0.9f, 0.85f), 1f));
                    break;
                default:
                    core = Spawn("streak", true, from, (to - from).normalized * speed, 99f, 0.22f, 0.22f, A(new Color(1f, 0.92f, 0.6f), 1f), A(new Color(1f, 0.92f, 0.6f), 1f), 0f, 0f, 0f, 0f, false, 0.12f);
                    break;
            }
            core.manual = true;
            float dist = Vector3.Distance(from, to);
            float dur = dist / Mathf.Max(0.1f, speed);
            float t = 0f;
            float trail = 0f;
            while (t < dur)
            {
                float dt = Combat3DTime.Delta;
                t += dt;
                float k = Mathf.Clamp01(t / dur);
                Vector3 pos = Vector3.Lerp(from, to, k);
                if (kind == ProjectileKind.Venom) pos += Vector3.up * Mathf.Sin(k * Mathf.PI) * dist * 0.18f; // parábola
                core.pos = pos;
                core.vel = (to - from) / dur;
                core.age = 0f;
                Apply(core);
                trail -= dt;
                if (trail <= 0f)
                {
                    trail = 0.02f;
                    if (kind == ProjectileKind.Fireball)
                    {
                        Spawn("flame", true, pos + UnityEngine.Random.insideUnitSphere * 0.15f, Vector3.up * 0.8f, 0.3f, 0.8f, 0.2f, A(new Color(1f, 0.75f, 0.3f), 0.9f), A(new Color(1f, 0.3f, 0.05f), 0f), 0f, 0f, UnityEngine.Random.Range(-30f, 30f));
                        Spawn("smoke", false, pos, Vector3.up * 0.5f, 0.6f, 0.3f, 0.9f, A(new Color(0.25f, 0.2f, 0.2f), 0.5f), A(new Color(0.25f, 0.2f, 0.2f), 0f), -0.3f, 1f);
                    }
                    else if (kind == ProjectileKind.Venom)
                    {
                        Spawn("softcircle", false, pos, Vector3.down * 0.4f, 0.3f, 0.18f, 0.05f, A(new Color(0.5f, 0.95f, 0.25f), 0.8f), A(new Color(0.5f, 0.95f, 0.25f), 0f));
                    }
                    else
                    {
                        Spawn("softcircle", true, pos, Vector3.zero, 0.15f, 0.16f, 0.04f, A(new Color(1f, 0.85f, 0.5f), 0.7f), A(new Color(1f, 0.85f, 0.5f), 0f));
                    }
                }
                yield return null;
            }
            Kill(core);
            onHit?.Invoke();
            switch (kind)
            {
                case ProjectileKind.Fireball:
                    HitSpark(to, new Color(1f, 0.5f, 0.1f), 1.6f);
                    BurnFlames(to + Vector3.down * 0.9f);
                    break;
                case ProjectileKind.Venom:
                    PoisonPuff(to);
                    break;
                default:
                    HitSpark(to, new Color(1f, 0.85f, 0.4f), 0.8f);
                    break;
            }
        }

        // ================================================================ Brazo elástico (Fruta)

        private void EnsureArm()
        {
            if (armMesh != null) return;
            BakeLight light = BakeLight.Make(new Vector3(-0.4f, 0.8f, -0.5f), Color.white * 0.55f, Color.white * 0.6f, Color.white * 0.4f);
            MeshBuilder b = new MeshBuilder();
            b.Beam(Vector3.zero, Vector3.forward, 1f, 10, Color.white);
            armMesh = b.Build("c3d_arm", light);
            owned.Add(armMesh);
            b.Clear();
            b.Sphere(Vector3.zero, new Vector3(1f, 0.85f, 1.05f), 10, 6, Color.white, true, 0.08f, 3);
            b.Box(new Vector3(0f, 0.25f, 0.55f), new Vector3(1.5f, 0.55f, 0.6f), new Color(0.92f, 0.92f, 0.92f)); // nudillos
            fistMesh = b.Build("c3d_fist", light);
            owned.Add(fistMesh);
            skinMat = Combat3DAssets.NewLit(Combat3DAssets.White, new Color(0.98f, 0.78f, 0.6f));
            hakiMat = Combat3DAssets.NewLit(Combat3DAssets.White, new Color(0.2f, 0.16f, 0.26f));
            owned.Add(skinMat);
            owned.Add(hakiMat);
        }

        private Transform NewArm(bool haki, out Transform arm, out Transform fist)
        {
            EnsureArm();
            GameObject root = new GameObject("ElasticArm");
            root.transform.SetParent(transform, false);
            GameObject a = new GameObject("Arm");
            a.transform.SetParent(root.transform, false);
            a.AddComponent<MeshFilter>().sharedMesh = armMesh;
            MeshRenderer ar = a.AddComponent<MeshRenderer>();
            ar.sharedMaterial = haki ? hakiMat : skinMat;
            ar.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            GameObject f = new GameObject("Fist");
            f.transform.SetParent(root.transform, false);
            f.AddComponent<MeshFilter>().sharedMesh = fistMesh;
            MeshRenderer fr = f.AddComponent<MeshRenderer>();
            fr.sharedMaterial = haki ? hakiMat : skinMat;
            fr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            arm = a.transform;
            fist = f.transform;
            return root.transform;
        }

        private static void PoseArm(Transform arm, Transform fist, Vector3 shoulder, Vector3 hand, float thickness, float fistSize)
        {
            Vector3 d = hand - shoulder;
            float len = Mathf.Max(0.01f, d.magnitude);
            Quaternion rot = Quaternion.LookRotation(d / len, Vector3.up);
            arm.position = shoulder;
            arm.rotation = rot;
            arm.localScale = new Vector3(thickness, thickness, len);
            fist.position = hand;
            fist.rotation = rot;
            fist.localScale = Vector3.one * fistSize;
        }

        /// <summary>Puñetazo estirado: recoge, sale disparado, impacta y vuelve como una goma.</summary>
        public IEnumerator StretchPunch(Vector3 shoulder, Vector3 target, bool haki, float windup, float shoot, float hold, float retract, float fistSize, Action onHit)
        {
            Transform root = NewArm(haki, out Transform arm, out Transform fist);
            Vector3 dir = (target - shoulder).normalized;
            Vector3 back = shoulder - dir * 0.7f + Vector3.down * 0.1f;
            float t = 0f;
            while (t < windup)
            {
                t += Combat3DTime.Delta;
                float k = Mathf.Clamp01(t / windup);
                PoseArm(arm, fist, shoulder, Vector3.Lerp(shoulder + dir * 0.2f, back, Mathf.Sin(k * Mathf.PI * 0.5f)), 0.1f, fistSize * (0.7f + 0.3f * k));
                yield return null;
            }
            t = 0f;
            float trail = 0f;
            while (t < shoot)
            {
                float dt = Combat3DTime.Delta;
                t += dt;
                float k = Mathf.Clamp01(t / shoot);
                Vector3 hand = Vector3.LerpUnclamped(back, target, k * k * (3f - 2f * k));
                PoseArm(arm, fist, shoulder, hand, Mathf.Lerp(0.1f, 0.075f, k), fistSize);
                trail -= dt;
                if (trail <= 0f)
                {
                    trail = 0.02f;
                    Spawn("streak", true, hand, dir * 6f, 0.12f, 0.25f, 0.05f, A(Color.white, 0.6f), A(Color.white, 0f), 0f, 0f, 0f, 0f, false, 0.1f);
                }
                yield return null;
            }
            PoseArm(arm, fist, shoulder, target, 0.075f, fistSize * 1.15f);
            onHit?.Invoke();
            yield return Combat3DTime.Wait(hold);
            t = 0f;
            while (t < retract)
            {
                t += Combat3DTime.Delta;
                float k = Mathf.Clamp01(t / retract);
                // Vuelve con un pequeño rebote de goma
                float e = 1f - Mathf.Pow(1f - k, 3f);
                Vector3 hand = Vector3.LerpUnclamped(target, shoulder + dir * 0.25f, e) + Vector3.up * Mathf.Sin(k * Mathf.PI) * 0.4f;
                PoseArm(arm, fist, shoulder, hand, 0.1f, fistSize);
                yield return null;
            }
            Destroy(root.gameObject);
        }

        /// <summary>Martillo: el brazo sube muy alto en arco y cae sobre el rival.</summary>
        public IEnumerator HammerArm(Vector3 shoulder, Vector3 target, bool haki, Action onHit)
        {
            Transform root = NewArm(haki, out Transform arm, out Transform fist);
            Vector3 up = shoulder + Vector3.up * 1.2f;
            Vector3 apex = Vector3.Lerp(shoulder, target, 0.55f) + Vector3.up * 6.5f;
            float t = 0f;
            const float rise = 0.5f, fall = 0.18f;
            while (t < rise)
            {
                t += Combat3DTime.Delta;
                float k = Mathf.Clamp01(t / rise);
                float e = 1f - (1f - k) * (1f - k);
                Vector3 hand = Bezier(shoulder, up, apex, e);
                PoseArm(arm, fist, shoulder, hand, 0.1f, Mathf.Lerp(0.3f, 0.65f, e));
                yield return null;
            }
            t = 0f;
            Vector3 impact = target + Vector3.up * 0.4f;
            while (t < fall)
            {
                t += Combat3DTime.Delta;
                float k = Mathf.Clamp01(t / fall);
                Vector3 hand = Vector3.Lerp(apex, impact, k * k);
                PoseArm(arm, fist, shoulder, hand, 0.085f, 0.7f);
                Spawn("streak", true, hand, Vector3.down * 8f, 0.12f, 0.35f, 0.05f, A(Color.white, 0.7f), A(Color.white, 0f), 0f, 0f, 0f, 0f, false, 0.08f);
                yield return null;
            }
            PoseArm(arm, fist, shoulder, impact, 0.085f, 0.75f);
            onHit?.Invoke();
            yield return Combat3DTime.Wait(0.18f);
            t = 0f;
            while (t < 0.22f)
            {
                t += Combat3DTime.Delta;
                float k = Mathf.Clamp01(t / 0.22f);
                PoseArm(arm, fist, shoulder, Vector3.Lerp(impact, shoulder + Vector3.up * 0.2f, 1f - Mathf.Pow(1f - k, 3f)), 0.1f, 0.4f);
                yield return null;
            }
            Destroy(root.gameObject);
        }

        private static Vector3 Bezier(Vector3 a, Vector3 b, Vector3 c, float t)
        {
            float u = 1f - t;
            return u * u * a + 2f * u * t * b + t * t * c;
        }
    }
}
