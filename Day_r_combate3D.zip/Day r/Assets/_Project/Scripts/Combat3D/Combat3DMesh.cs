﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace PirateSurvival.Combat3D
{
    /// <summary>
    /// Luz "horneada" en los colores de vértice: sol direccional + cielo/suelo ambiental.
    /// El Renderer 2D de URP no ilumina mallas 3D, así que la iluminación se calcula aquí una vez al construir.
    /// </summary>
    public struct BakeLight
    {
        public Vector3 toSun;      // dirección HACIA el sol (normalizada)
        public Color sun;
        public Color skyAmbient;
        public Color groundAmbient;

        public Color Shade(Vector3 n, Color albedo)
        {
            float d = Mathf.Max(0f, Vector3.Dot(n, toSun));
            d = d * 0.85f + Mathf.Max(0f, Vector3.Dot(n, toSun) + 0.25f) * 0.15f; // borde de luz algo más suave
            Color amb = Color.Lerp(groundAmbient, skyAmbient, n.y * 0.5f + 0.5f);
            Color c = albedo * (amb + sun * d);
            c.a = albedo.a;
            return c;
        }

        public static BakeLight Make(Vector3 toSun, Color sun, Color sky, Color ground)
        {
            return new BakeLight { toSun = toSun.normalized, sun = sun, skyAmbient = sky, groundAmbient = ground };
        }
    }

    /// <summary>
    /// Constructor de mallas low-poly por código (cajas, cilindros, conos, esferas, discos...) con transformaciones,
    /// UV y color por pieza. Muchas piezas se juntan en una sola malla (menos objetos, menos llamadas de dibujo).
    /// </summary>
    public class MeshBuilder
    {
        private readonly List<Vector3> verts = new List<Vector3>();
        private readonly List<Vector3> normals = new List<Vector3>();
        private readonly List<Color> colors = new List<Color>();
        private readonly List<Vector2> uvs = new List<Vector2>();
        private readonly List<int> tris = new List<int>();

        private Matrix4x4 m = Matrix4x4.identity;
        private Matrix4x4 nm = Matrix4x4.identity;

        public int VertexCount => verts.Count;

        /// <summary>Transformación aplicada a las piezas que se añadan a partir de ahora.</summary>
        public Matrix4x4 Transform
        {
            get => m;
            set { m = value; nm = value.inverse.transpose; }
        }

        public void SetTRS(Vector3 pos, Quaternion rot, Vector3 scale) => Transform = Matrix4x4.TRS(pos, rot, scale);
        public void ResetTransform() => Transform = Matrix4x4.identity;

        // ------------------------------------------------------------------ Primitivas internas

        private int AddVertex(Vector3 p, Vector3 n, Vector2 uv, Color c)
        {
            verts.Add(m.MultiplyPoint3x4(p));
            Vector3 wn = nm.MultiplyVector(n);
            normals.Add(wn.sqrMagnitude > 1e-8f ? wn.normalized : Vector3.up);
            uvs.Add(uv);
            colors.Add(c);
            return verts.Count - 1;
        }

        /// <summary>Triángulo en sentido horario visto desde delante (convención de Unity). Normal plana.</summary>
        public void Tri(Vector3 a, Vector3 b, Vector3 c, Vector2 ua, Vector2 ub, Vector2 uc, Color col)
        {
            Vector3 n = Vector3.Cross(b - a, c - a);
            int i0 = AddVertex(a, n, ua, col);
            int i1 = AddVertex(b, n, ub, col);
            int i2 = AddVertex(c, n, uc, col);
            tris.Add(i0); tris.Add(i1); tris.Add(i2);
        }

        /// <summary>Triángulo con normales por vértice (sombreado suave).</summary>
        public void TriSmooth(Vector3 a, Vector3 b, Vector3 c, Vector3 na, Vector3 nb, Vector3 nc, Vector2 ua, Vector2 ub, Vector2 uc, Color col)
        {
            int i0 = AddVertex(a, na, ua, col);
            int i1 = AddVertex(b, nb, ub, col);
            int i2 = AddVertex(c, nc, uc, col);
            tris.Add(i0); tris.Add(i1); tris.Add(i2);
        }

        /// <summary>Cuadrilátero: a abajo-izq, b arriba-izq, c arriba-dcha, d abajo-dcha (visto desde delante).</summary>
        public void Quad(Vector3 a, Vector3 b, Vector3 c, Vector3 d, Color col, Vector2 uvMin, Vector2 uvMax)
        {
            Tri(a, b, c, uvMin, new Vector2(uvMin.x, uvMax.y), uvMax, col);
            Tri(a, c, d, uvMin, uvMax, new Vector2(uvMax.x, uvMin.y), col);
        }

        public void Quad(Vector3 a, Vector3 b, Vector3 c, Vector3 d, Color col) => Quad(a, b, c, d, col, Vector2.zero, Vector2.one);

        /// <summary>Cara rectangular centrada en 'c' mirando a 'normal'; 'up' marca el lado de arriba.</summary>
        public void Face(Vector3 c, Vector3 normal, Vector3 up, float halfW, float halfH, Color col, Vector2 uvMin, Vector2 uvMax)
        {
            Vector3 r = Vector3.Cross(up, -normal).normalized;
            Vector3 u = up.normalized;
            Quad(c - r * halfW - u * halfH, c - r * halfW + u * halfH, c + r * halfW + u * halfH, c + r * halfW - u * halfH, col, uvMin, uvMax);
        }

        // ------------------------------------------------------------------ Piezas

        /// <summary>Caja centrada. uvScale = repeticiones de textura por unidad.</summary>
        public void Box(Vector3 center, Vector3 size, Color col, float uvScale = 1f)
        {
            Vector3 h = size * 0.5f;
            Vector2 uxz = new Vector2(size.x, size.z) * uvScale, uxy = new Vector2(size.x, size.y) * uvScale, uzy = new Vector2(size.z, size.y) * uvScale;
            Face(center + Vector3.up * h.y, Vector3.up, Vector3.forward, h.x, h.z, col, Vector2.zero, uxz);
            Face(center - Vector3.up * h.y, Vector3.down, Vector3.forward, h.x, h.z, col, Vector2.zero, uxz);
            Face(center + Vector3.right * h.x, Vector3.right, Vector3.up, h.z, h.y, col, Vector2.zero, uzy);
            Face(center - Vector3.right * h.x, Vector3.left, Vector3.up, h.z, h.y, col, Vector2.zero, uzy);
            Face(center + Vector3.forward * h.z, Vector3.forward, Vector3.up, h.x, h.y, col, Vector2.zero, uxy);
            Face(center - Vector3.forward * h.z, Vector3.back, Vector3.up, h.x, h.y, col, Vector2.zero, uxy);
        }

        /// <summary>
        /// Cilindro / cono truncado vertical desde baseCenter hacia arriba.
        /// smooth = laterales con sombreado suave; jitter deforma el radio (rocas, troncos irregulares).
        /// </summary>
        public void Cylinder(Vector3 baseCenter, float rBottom, float rTop, float height, int seg, Color col,
            bool smooth = true, bool capTop = true, bool capBottom = false, float uvU = 1f, float uvV = 1f, float jitter = 0f, int seed = 0)
        {
            seg = Mathf.Max(3, seg);
            float slope = (rBottom - rTop) / Mathf.Max(0.0001f, height);
            for (int i = 0; i < seg; i++)
            {
                float a0 = i * Mathf.PI * 2f / seg, a1 = (i + 1) * Mathf.PI * 2f / seg;
                float j0 = 1f + (jitter > 0f ? (Combat3DAssets.Hash(i % seg, 0, seed) - 0.5f) * jitter : 0f);
                float j1 = 1f + (jitter > 0f ? (Combat3DAssets.Hash((i + 1) % seg, 0, seed) - 0.5f) * jitter : 0f);
                Vector3 d0 = new Vector3(Mathf.Cos(a0), 0f, Mathf.Sin(a0)), d1 = new Vector3(Mathf.Cos(a1), 0f, Mathf.Sin(a1));
                Vector3 b0 = baseCenter + d0 * rBottom * j0, b1 = baseCenter + d1 * rBottom * j1;
                Vector3 t0 = baseCenter + d0 * rTop * j0 + Vector3.up * height, t1 = baseCenter + d1 * rTop * j1 + Vector3.up * height;
                float u0 = (float)i / seg * uvU, u1 = (float)(i + 1) / seg * uvU;
                if (smooth)
                {
                    Vector3 n0 = (d0 + Vector3.up * slope).normalized, n1 = (d1 + Vector3.up * slope).normalized;
                    TriSmooth(b0, t0, t1, n0, n0, n1, new Vector2(u0, 0f), new Vector2(u0, uvV), new Vector2(u1, uvV), col);
                    TriSmooth(b0, t1, b1, n0, n1, n1, new Vector2(u0, 0f), new Vector2(u1, uvV), new Vector2(u1, 0f), col);
                }
                else
                {
                    Quad(b0, t0, t1, b1, col, new Vector2(u0, 0f), new Vector2(u1, uvV));
                }
                if (capTop && rTop > 0.0001f)
                {
                    Vector3 c = baseCenter + Vector3.up * height;
                    Tri(c, t1, t0, new Vector2(0.5f, 0.5f), new Vector2(0.5f + d1.x * 0.5f, 0.5f + d1.z * 0.5f), new Vector2(0.5f + d0.x * 0.5f, 0.5f + d0.z * 0.5f), col);
                }
                if (capBottom && rBottom > 0.0001f)
                {
                    Tri(baseCenter, b0, b1, new Vector2(0.5f, 0.5f), new Vector2(0.5f + d0.x * 0.5f, 0.5f + d0.z * 0.5f), new Vector2(0.5f + d1.x * 0.5f, 0.5f + d1.z * 0.5f), col);
                }
            }
        }

        /// <summary>Cilindro entre dos puntos cualesquiera (cuerdas, vergas, radios del timón, patas).</summary>
        public void Beam(Vector3 a, Vector3 b, float radius, int seg, Color col) => Frustum(a, b, radius, radius, seg, col, 1f, 1f, true);

        /// <summary>Tronco de cono entre dos puntos (segmentos de tronco de palmera curvado).</summary>
        public void Frustum(Vector3 a, Vector3 b, float r0, float r1, int seg, Color col, float uvU, float uvV, bool caps = false)
        {
            Vector3 dir = b - a;
            float len = dir.magnitude;
            if (len < 0.0001f) return;
            Matrix4x4 saved = m;
            Transform = saved * Matrix4x4.TRS(a, Quaternion.FromToRotation(Vector3.up, dir / len), Vector3.one);
            Cylinder(Vector3.zero, r0, r1, len, seg, col, true, caps, caps, uvU, uvV);
            Transform = saved;
        }

        /// <summary>Triángulo con un color por vértice (degradados de transparencia como la espuma).</summary>
        public void TriColored(Vector3 a, Vector3 b, Vector3 c, Color ca, Color cb, Color cc)
        {
            Vector3 n = Vector3.Cross(b - a, c - a);
            int i0 = AddVertex(a, n, new Vector2(a.x, a.z), ca);
            int i1 = AddVertex(b, n, new Vector2(b.x, b.z), cb);
            int i2 = AddVertex(c, n, new Vector2(c.x, c.z), cc);
            tris.Add(i0); tris.Add(i1); tris.Add(i2);
        }

        public void Cone(Vector3 baseCenter, float radius, float height, int seg, Color col, bool smooth = false, float jitter = 0f, int seed = 0)
            => Cylinder(baseCenter, radius, 0f, height, seg, col, smooth, false, false, 1f, 1f, jitter, seed);

        /// <summary>Esfera/elipsoide low-poly. flat = facetas visibles (rocas); jitter = deformación (rocas, copas de árbol).</summary>
        public void Sphere(Vector3 center, Vector3 radii, int seg, int rings, Color col, bool flat = false, float jitter = 0f, int seed = 0, float minLat = -90f)
        {
            seg = Mathf.Max(3, seg); rings = Mathf.Max(2, rings);
            Vector3 P(int i, int j, out Vector3 dir)
            {
                float lat = Mathf.Lerp(minLat, 90f, (float)j / rings) * Mathf.Deg2Rad;
                float lon = (float)(i % seg) / seg * Mathf.PI * 2f;
                dir = new Vector3(Mathf.Cos(lat) * Mathf.Cos(lon), Mathf.Sin(lat), Mathf.Cos(lat) * Mathf.Sin(lon));
                float k = 1f;
                if (jitter > 0f && j > 0 && j < rings)
                    k += (Combat3DAssets.Noise(dir.x * 2.3f + dir.y * 1.7f + 10f, dir.z * 2.3f - dir.y * 1.3f + 10f, seed) - 0.5f) * jitter * 2f;
                return center + Vector3.Scale(dir, radii) * k;
            }
            for (int j = 0; j < rings; j++)
            {
                for (int i = 0; i < seg; i++)
                {
                    Vector3 b0 = P(i, j, out Vector3 nb0), b1 = P(i + 1, j, out Vector3 nb1);
                    Vector3 t0 = P(i, j + 1, out Vector3 nt0), t1 = P(i + 1, j + 1, out Vector3 nt1);
                    Vector2 ub0 = new Vector2((float)i / seg, (float)j / rings), ub1 = new Vector2((float)(i + 1) / seg, (float)j / rings);
                    Vector2 ut0 = new Vector2((float)i / seg, (float)(j + 1) / rings), ut1 = new Vector2((float)(i + 1) / seg, (float)(j + 1) / rings);
                    if (flat)
                    {
                        Tri(b0, t0, t1, ub0, ut0, ut1, col);
                        Tri(b0, t1, b1, ub0, ut1, ub1, col);
                    }
                    else
                    {
                        TriSmooth(b0, t0, t1, Vector3.Scale(nb0, Inv(radii)).normalized, Vector3.Scale(nt0, Inv(radii)).normalized, Vector3.Scale(nt1, Inv(radii)).normalized, ub0, ut0, ut1, col);
                        TriSmooth(b0, t1, b1, Vector3.Scale(nb0, Inv(radii)).normalized, Vector3.Scale(nt1, Inv(radii)).normalized, Vector3.Scale(nb1, Inv(radii)).normalized, ub0, ut1, ub1, col);
                    }
                }
            }
        }

        private static Vector3 Inv(Vector3 r) => new Vector3(1f / Mathf.Max(0.0001f, r.x), 1f / Mathf.Max(0.0001f, r.y), 1f / Mathf.Max(0.0001f, r.z));

        /// <summary>
        /// Disco horizontal en anillos con altura y color por punto (suelo de la arena, charcos, cubiertas redondas).
        /// height(r01, ángulo) y color(pos) permiten bordes irregulares, cúpulas y arena mojada en la orilla.
        /// UV planas (x,z) * uvScale.
        /// </summary>
        public void Disc(Vector3 center, float radius, int seg, int rings, float uvScale,
            Func<float, float, float> radiusJitter, Func<float, float> height, Func<Vector3, float, Color> color)
        {
            seg = Mathf.Max(6, seg); rings = Mathf.Max(1, rings);
            Vector3 Pt(int ring, int i)
            {
                float a = (float)(i % seg) / seg * Mathf.PI * 2f;
                float r01 = (float)ring / rings;
                float rr = radius * r01 * (radiusJitter != null ? radiusJitter(r01, a) : 1f);
                float y = height != null ? height(r01) : 0f;
                return center + new Vector3(Mathf.Cos(a) * rr, y, Mathf.Sin(a) * rr);
            }
            Color C(Vector3 p, int ring) => color != null ? color(p, (float)ring / rings) : Color.white;
            Vector2 UV(Vector3 p) => new Vector2((p.x - center.x) * uvScale, (p.z - center.z) * uvScale);

            for (int ring = 0; ring < rings; ring++)
            {
                for (int i = 0; i < seg; i++)
                {
                    Vector3 a0 = Pt(ring, i), a1 = Pt(ring, i + 1), b0 = Pt(ring + 1, i), b1 = Pt(ring + 1, i + 1);
                    Vector3 na = SlopeNormal(a0, center, ring, rings, radius, height), nb = SlopeNormal(b0, center, ring + 1, rings, radius, height);
                    Vector3 na1 = SlopeNormal(a1, center, ring, rings, radius, height), nb1 = SlopeNormal(b1, center, ring + 1, rings, radius, height);
                    // Visto desde arriba: el ángulo crece en sentido antihorario, así que se invierte el orden
                    TriSmoothColored(a0, b1, b0, na, nb1, nb, UV(a0), UV(b1), UV(b0), C(a0, ring), C(b1, ring + 1), C(b0, ring + 1));
                    if (ring > 0) // el anillo central es un abanico: a0 y a1 son el mismo punto
                        TriSmoothColored(a0, a1, b1, na, na1, nb1, UV(a0), UV(a1), UV(b1), C(a0, ring), C(a1, ring), C(b1, ring + 1));
                }
            }
        }

        private static Vector3 SlopeNormal(Vector3 p, Vector3 center, int ring, int rings, float radius, Func<float, float> height)
        {
            if (height == null || ring == 0) return Vector3.up;
            float r01 = (float)ring / rings, e = 0.5f / rings;
            float dh = (height(Mathf.Min(1f, r01 + e)) - height(Mathf.Max(0f, r01 - e))) / (radius * 2f * e);
            Vector3 radial = p - center; radial.y = 0f;
            radial = radial.sqrMagnitude > 1e-6f ? radial.normalized : Vector3.forward;
            return (Vector3.up - radial * dh).normalized;
        }

        private void TriSmoothColored(Vector3 a, Vector3 b, Vector3 c, Vector3 na, Vector3 nb, Vector3 nc, Vector2 ua, Vector2 ub, Vector2 uc, Color ca, Color cb, Color cc)
        {
            int i0 = AddVertex(a, na, ua, ca);
            int i1 = AddVertex(b, nb, ub, cb);
            int i2 = AddVertex(c, nc, uc, cc);
            tris.Add(i0); tris.Add(i1); tris.Add(i2);
        }

        /// <summary>Pared cilíndrica vista DESDE DENTRO (paredes de cueva, cúpula del cielo).</summary>
        public void InwardCylinder(Vector3 baseCenter, float radius, float height, int seg, int rows, Color col, float uvU, float uvV,
            Func<float, float, float> radiusJitter = null)
        {
            for (int r = 0; r < rows; r++)
            {
                float v0 = (float)r / rows, v1 = (float)(r + 1) / rows;
                for (int i = 0; i < seg; i++)
                {
                    float a0 = (float)i / seg * Mathf.PI * 2f, a1 = (float)(i + 1) / seg * Mathf.PI * 2f;
                    float j00 = radiusJitter != null ? radiusJitter(v0, a0) : 1f, j10 = radiusJitter != null ? radiusJitter(v0, a1) : 1f;
                    float j01 = radiusJitter != null ? radiusJitter(v1, a0) : 1f, j11 = radiusJitter != null ? radiusJitter(v1, a1) : 1f;
                    Vector3 p00 = baseCenter + new Vector3(Mathf.Cos(a0) * radius * j00, v0 * height, Mathf.Sin(a0) * radius * j00);
                    Vector3 p10 = baseCenter + new Vector3(Mathf.Cos(a1) * radius * j10, v0 * height, Mathf.Sin(a1) * radius * j10);
                    Vector3 p01 = baseCenter + new Vector3(Mathf.Cos(a0) * radius * j01, v1 * height, Mathf.Sin(a0) * radius * j01);
                    Vector3 p11 = baseCenter + new Vector3(Mathf.Cos(a1) * radius * j11, v1 * height, Mathf.Sin(a1) * radius * j11);
                    // Desde dentro el orden es el inverso que desde fuera
                    Quad(p10, p11, p01, p00, col, new Vector2((float)(i + 1) / seg * uvU, v0 * uvV), new Vector2((float)i / seg * uvU, v1 * uvV));
                }
            }
        }

        /// <summary>Plano vertical de doble cara (hojas, velas, banderas) con su propia textura.</summary>
        public void DoubleQuad(Vector3 a, Vector3 b, Vector3 c, Vector3 d, Color col, Vector2 uvMin, Vector2 uvMax)
        {
            Quad(a, b, c, d, col, uvMin, uvMax);
            Quad(d, c, b, a, col, new Vector2(uvMax.x, uvMin.y), new Vector2(uvMin.x, uvMax.y));
        }

        // ------------------------------------------------------------------ Resultado

        /// <summary>Crea la malla. Con 'bake' la luz se multiplica en los colores de vértice.</summary>
        public Mesh Build(string name, BakeLight light, bool bake = true)
        {
            Mesh mesh = new Mesh { name = name };
            if (verts.Count > 65000) mesh.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
            mesh.SetVertices(verts);
            mesh.SetNormals(normals);
            mesh.SetUVs(0, uvs);
            if (bake)
            {
                List<Color> lit = new List<Color>(colors.Count);
                for (int i = 0; i < colors.Count; i++) lit.Add(light.Shade(normals[i], colors[i]));
                mesh.SetColors(lit);
            }
            else
            {
                mesh.SetColors(colors);
            }
            mesh.SetTriangles(tris, 0);
            mesh.RecalculateBounds();
            return mesh;
        }

        public void Clear()
        {
            verts.Clear(); normals.Clear(); colors.Clear(); uvs.Clear(); tris.Clear();
            ResetTransform();
        }
    }
}
