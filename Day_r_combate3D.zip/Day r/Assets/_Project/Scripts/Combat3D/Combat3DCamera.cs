﻿using UnityEngine;

namespace PirateSurvival.Combat3D
{
    public enum CameraShot
    {
        Intro,        // barrido amplio de presentación
        Command,      // vista 3/4 con los dos luchadores (menú de órdenes)
        Action,       // lateral para carreras y golpes
        PlayerFocus,  // primer plano del jugador preparando una técnica
        EnemyFocus,   // primer plano del rival preparando su ataque
        OnEnemy,      // el rival recibe el golpe
        OnPlayer,     // el jugador recibe el golpe
        EnemyEntry,   // entra el siguiente rival
        Victory,      // órbita lenta alrededor del jugador
        Defeat        // picado sobre el jugador caído
    }

    /// <summary>
    /// Cámara cinematográfica del combate 3D: planos calculados a partir de las posiciones reales de los luchadores,
    /// transiciones suaves (o cortes secos), deriva lenta para que la imagen nunca esté muerta, temblor y golpe de zoom.
    /// Se mueve con tiempo real del combate (sigue fluida durante el hit-stop y se detiene en la pausa).
    /// </summary>
    [RequireComponent(typeof(Camera))]
    public class Combat3DCamera : MonoBehaviour
    {
        public static Combat3DCamera Instance { get; private set; }
        public Camera Cam { get; private set; }

        private Combat3DCharacter player, enemy;
        private Vector3 entryPoint;
        private CameraShot shot = CameraShot.Intro;
        private float shotTime;
        private float blendSpeed = 4f;
        private Vector3 look;
        private float trauma, fovKick, clock;

        private void Awake()
        {
            Instance = this;
            Cam = GetComponent<Camera>();
            Cam.orthographic = false;
            Cam.fieldOfView = 42f;
            Cam.nearClipPlane = 0.1f;
            Cam.farClipPlane = 420f;
            Cam.depth = 10f;
            Cam.clearFlags = CameraClearFlags.SolidColor;
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        public void SetFighters(Combat3DCharacter p, Combat3DCharacter e)
        {
            player = p;
            enemy = e;
        }

        public void SetEnemy(Combat3DCharacter e) => enemy = e;
        public void SetEntryPoint(Vector3 world) => entryPoint = world;

        /// <summary>Cambia de plano. cut = salto seco (montaje); speed = rapidez de la transición suave.</summary>
        public void Shot(CameraShot s, bool cut = false, float speed = 4f)
        {
            shot = s;
            shotTime = 0f;
            blendSpeed = speed;
            if (cut) Snap();
        }

        public void Snap()
        {
            Compute(out Vector3 pos, out Vector3 target, out float fov);
            transform.position = pos;
            look = target;
            transform.rotation = Quaternion.LookRotation(target - pos, Vector3.up);
            Cam.fieldOfView = fov;
        }

        public void Shake(float amount) => trauma = Mathf.Clamp01(trauma + amount);
        public void Kick(float fovDelta) => fovKick += fovDelta;

        private void LateUpdate()
        {
            float dt = Combat3DTime.RawDelta;
            clock += dt;
            shotTime += dt;

            Compute(out Vector3 pos, out Vector3 target, out float fov);
            float k = 1f - Mathf.Exp(-blendSpeed * dt);
            Vector3 p = Vector3.Lerp(transform.position, pos, k);
            look = Vector3.Lerp(look, target, k);
            fovKick = Mathf.Lerp(fovKick, 0f, 1f - Mathf.Exp(-8f * dt));
            Cam.fieldOfView = Mathf.Lerp(Cam.fieldOfView, fov, k) + 0f;

            transform.position = p;
            transform.rotation = Quaternion.LookRotation((look - p).sqrMagnitude > 1e-4f ? look - p : Vector3.forward, Vector3.up);

            // Temblor no lineal (trauma²) con ruido suave
            if (trauma > 0f)
            {
                trauma = Mathf.Max(0f, trauma - dt * 1.8f);
                float s = trauma * trauma;
                float n = clock * 28f;
                Vector3 off = new Vector3(Mathf.PerlinNoise(n, 0.3f) - 0.5f, Mathf.PerlinNoise(0.7f, n) - 0.5f, 0f) * 0.7f * s;
                transform.position += transform.rotation * off;
                transform.rotation *= Quaternion.Euler(0f, 0f, (Mathf.PerlinNoise(n, n * 0.5f) - 0.5f) * 6f * s);
            }
            Cam.fieldOfView += fovKick;
        }

        private void Compute(out Vector3 pos, out Vector3 target, out float fov)
        {
            Vector3 P = player != null ? player.Feet : transform.position;
            Vector3 E = enemy != null ? enemy.Feet : P + Vector3.right * 5f;
            Vector3 d = E - P; d.y = 0f;
            d = d.sqrMagnitude > 0.01f ? d.normalized : Vector3.right;
            Vector3 r = Vector3.Cross(Vector3.up, d);   // hacia la cámara (delante del escenario)
            Vector3 mid = (P + E) * 0.5f;
            Vector3 up = Vector3.up;
            float drift = Mathf.Sin(clock * 0.31f) * 0.35f;
            float driftUp = Mathf.Sin(clock * 0.23f) * 0.12f;

            switch (shot)
            {
                case CameraShot.Intro:
                {
                    float k = Mathf.Clamp01(shotTime / 2.8f);
                    float e = k * k * (3f - 2f * k);
                    float yaw = Mathf.Lerp(-75f, -8f, e);
                    Vector3 dir = Quaternion.AngleAxis(yaw, up) * r;
                    pos = mid + dir * Mathf.Lerp(13f, 8.5f, e) + up * Mathf.Lerp(5.5f, 3f, e);
                    target = mid + up * 0.7f;
                    fov = 44f;
                    break;
                }
                case CameraShot.Action:
                    pos = mid + r * 6.4f - d * 0.4f + up * 1.9f + d * drift * 0.5f;
                    target = mid + up * 0.85f;
                    fov = 42f;
                    break;
                case CameraShot.PlayerFocus:
                    pos = P + r * 3.1f + d * 1.3f + up * 1.35f;
                    target = P + up * 1.0f + d * 0.4f;
                    fov = 34f;
                    break;
                case CameraShot.EnemyFocus:
                    pos = E + r * 3.4f - d * 1.3f + up * 1.45f;
                    target = E + up * (enemy != null ? enemy.Height * 0.5f : 1f) - d * 0.4f;
                    fov = 36f;
                    break;
                case CameraShot.OnEnemy:
                    pos = E - d * 3.6f + r * 2.8f + up * 1.6f;
                    target = E + up * (enemy != null ? enemy.Height * 0.5f : 1f);
                    fov = 36f;
                    break;
                case CameraShot.OnPlayer:
                    pos = P + d * 3.5f + r * 2.8f + up * 1.5f;
                    target = P + up * 0.95f;
                    fov = 36f;
                    break;
                case CameraShot.EnemyEntry:
                    pos = mid + r * 7.5f + d * 1.5f + up * 2.4f;
                    target = Vector3.Lerp(E, entryPoint, 0.35f) + up * 0.9f;
                    fov = 44f;
                    break;
                case CameraShot.Victory:
                {
                    float yaw = shotTime * 14f;
                    Vector3 dir = Quaternion.AngleAxis(-25f + yaw, up) * (r * 3.4f + d * 1.2f);
                    pos = P + dir + up * 1.25f;
                    target = P + up * 1.0f;
                    fov = 38f;
                    break;
                }
                case CameraShot.Defeat:
                    pos = P + up * 5.8f + r * 2.6f - d * 0.6f;
                    target = P + up * 0.2f;
                    fov = 40f;
                    break;
                default: // Command
                    pos = mid + r * 7.3f - d * 1.5f + up * (2.7f + driftUp) + d * drift;
                    target = mid + up * 0.55f + d * 0.25f;
                    fov = 40f;
                    break;
            }
        }
    }
}
