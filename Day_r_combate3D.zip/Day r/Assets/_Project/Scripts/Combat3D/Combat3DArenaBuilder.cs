﻿using System.Collections.Generic;
using UnityEngine;

namespace PirateSurvival.Combat3D
{
    /// <summary>
    /// Construye por código los escenarios del combate 3D, en estilo low-poly con luz horneada:
    ///  - Playa: isla de arena con mar animado, espuma, palmeras que se mecen, ring de cuerdas, antorchas,
    ///    bandera pirata, barco fondeado, islas lejanas, sol y nubes.
    ///  - Selva: claro de tierra rodeado de árboles, helechos, rocas con musgo, tronco caído y setas.
    ///  - Cueva: bóveda de roca, estalagmitas y estalactitas, cristales brillantes, vía de mina, charca y antorchas.
    ///  - Cubierta: barco pirata con mástil y velas al viento, cañones, barandillas, timón y mar abierto.
    /// Todo queda bajo un único objeto raíz (Combat3DArena) que se destruye al acabar el combate.
    /// </summary>
    public static class Combat3DArenaBuilder
    {
        public static Combat3DArena Build(ArenaTheme theme, Vector3 origin)
        {
            GameObject root = new GameObject("Combat3D_Arena_" + theme);
            root.transform.position = origin;
            root.SetActive(false); // se activa al final (OnEnable aplica la niebla con los valores ya fijados)
            Combat3DArena arena = root.AddComponent<Combat3DArena>();
            arena.Theme = theme;

            Ctx c = new Ctx(arena);
            switch (theme)
            {
                case ArenaTheme.Jungle: BuildJungle(c); break;
                case ArenaTheme.Cave: BuildCave(c); break;
                case ArenaTheme.Deck: BuildDeck(c); break;
                default: BuildBeach(c); break;
            }
            c.Flush();
            root.SetActive(true);
            return arena;
        }

        // ================================================================ PLAYA

        private static void BuildBeach(Ctx c)
        {
            Combat3DArena a = c.arena;
            c.light = BakeLight.Make(new Vector3(-0.45f, 0.8f, -0.5f), new Color(1f, 0.92f, 0.78f) * 0.62f,
                new Color(0.66f, 0.76f, 0.92f) * 0.55f, new Color(0.62f, 0.52f, 0.4f) * 0.45f);
            a.ClearColor = new Color(0.55f, 0.78f, 0.95f);
            a.FogColor = new Color(0.8f, 0.86f, 0.88f);
            a.FogStart = 22f; a.FogEnd = 130f; a.FogMax = 0.8f;
            a.GroundY = 0.12f;
            a.DustColor = new Color(0.93f, 0.84f, 0.64f, 0.75f);

            Sky(c, new Color(1f, 0.9f, 0.74f), new Color(0.58f, 0.8f, 0.96f), new Color(0.22f, 0.48f, 0.86f));
            Sun(c, new Vector3(0.45f, 0.3f, 0.84f), new Color(1f, 0.95f, 0.8f));
            Clouds(c, 9, 95f, new Color(1f, 1f, 1f, 0.92f));
            DistantIslands(c, new Color(0.3f, 0.55f, 0.32f));
            Water(c, -0.32f, 12.2f, 150f, new Color(0.28f, 0.8f, 0.82f), new Color(0.07f, 0.34f, 0.62f), 0.12f);
            Foam(c, 13.0f, -0.28f, 1.4f);

            // Isla de arena con borde irregular, cúpula suave y arena mojada en la orilla
            MeshBuilder sand = c.G("sand");
            sand.Disc(Vector3.zero, 14f, 72, 12, 0.22f,
                (r01, ang) => 1f + (Combat3DAssets.Noise(Mathf.Cos(ang) * 2.2f + 5f, Mathf.Sin(ang) * 2.2f + 5f, 3) - 0.5f) * 0.18f * r01,
                r01 => r01 < 0.45f ? 0.12f : Mathf.Lerp(0.12f, -0.55f, Mathf.SmoothStep(0f, 1f, (r01 - 0.45f) / 0.55f)),
                (p, r01) => Color.Lerp(Color.white, new Color(0.74f, 0.64f, 0.52f), Mathf.SmoothStep(0f, 1f, (r01 - 0.78f) / 0.2f)));

            // Ring de duelo dibujado en la arena + estacas con cuerda al fondo
            c.GroundDecal("ring", false, new Color(0.42f, 0.3f, 0.18f, 0.55f), new Vector3(0f, 0.13f, 0f), 10.6f);
            c.GroundDecal("ring", false, new Color(0.42f, 0.3f, 0.18f, 0.35f), new Vector3(0f, 0.131f, 0f), 3.2f);
            RopeRing(c, 6.6f, 0.12f, 12, 15f, 165f, new Color(0.5f, 0.34f, 0.2f), new Color(0.82f, 0.7f, 0.48f));

            // Palmeras alrededor (detrás y a los lados; delante queda despejado para la cámara)
            Palm(c, new Vector3(-8.2f, 0.05f, 6.4f), 1.05f, 20f, 0.3f);
            Palm(c, new Vector3(-4.2f, 0.05f, 9.6f), 0.9f, -10f, 1.4f);
            Palm(c, new Vector3(4.6f, 0.05f, 10.2f), 1.1f, 15f, 2.2f);
            Palm(c, new Vector3(9.2f, 0.05f, 6.8f), 0.95f, -25f, 3.1f);
            Palm(c, new Vector3(-11.2f, -0.1f, 0.5f), 0.85f, 35f, 4.0f);
            Palm(c, new Vector3(11.4f, -0.1f, -1.2f), 0.9f, -40f, 5.3f);
            Palm(c, new Vector3(-10.2f, -0.2f, -6.8f), 0.8f, 50f, 6.1f);

            // Rocas, barriles, cajas, ancla
            MeshBuilder rock = c.G("rock");
            Rock(rock, new Vector3(-6.4f, 0.05f, 3.4f), new Vector3(1.0f, 0.75f, 0.85f), 11);
            Rock(rock, new Vector3(-7.1f, 0.05f, 2.6f), new Vector3(0.55f, 0.4f, 0.5f), 12);
            Rock(rock, new Vector3(7.6f, 0.0f, 3.2f), new Vector3(1.2f, 0.9f, 1.0f), 13);
            Rock(rock, new Vector3(1.2f, -0.2f, 12.4f), new Vector3(1.6f, 1.0f, 1.2f), 14);
            Rock(rock, new Vector3(12.6f, -0.4f, 4.8f), new Vector3(1.4f, 1.1f, 1.2f), 15);
            Rock(rock, new Vector3(-12.8f, -0.4f, 5.6f), new Vector3(1.1f, 0.8f, 1.0f), 16);
            Barrel(c, new Vector3(6.2f, 0.1f, 5.2f), 0f);
            Barrel(c, new Vector3(6.9f, 0.1f, 4.6f), 30f);
            Barrel(c, new Vector3(-5.8f, 0.1f, 6.8f), 10f);
            Crate(c, new Vector3(5.6f, 0.1f, 6.3f), 0.95f, 18f);
            Crate(c, new Vector3(-6.7f, 0.1f, 6.1f), 0.8f, -12f);
            Crate(c, new Vector3(-6.7f, 0.9f, 6.1f), 0.6f, 25f);
            Anchor(c, new Vector3(9.6f, 0.0f, 1.4f), -25f);

            // Antorchas de las esquinas del ring
            Torch(c, new Vector3(-6.0f, 0.1f, 4.4f));
            Torch(c, new Vector3(6.0f, 0.1f, 4.4f));
            Torch(c, new Vector3(-7.2f, 0.1f, -3.2f));
            Torch(c, new Vector3(7.2f, 0.1f, -3.2f));

            // Bandera pirata y barco fondeado al fondo
            FlagPole(c, new Vector3(-2.8f, 0.1f, 8.2f), 6.2f);
            Ship(c, new Vector3(-16f, -0.45f, 34f), 18f, 1.25f);

            // Detalles en la arena: conchas, estrellas de mar, matas
            MeshBuilder props = c.G("white");
            System.Random rnd = new System.Random(7);
            for (int i = 0; i < 26; i++)
            {
                float ang = (float)rnd.NextDouble() * Mathf.PI * 2f;
                float r = 3.5f + (float)rnd.NextDouble() * 8f;
                Vector3 p = new Vector3(Mathf.Cos(ang) * r, 0f, Mathf.Sin(ang) * r);
                if (Mathf.Abs(p.z) < 1.8f && Mathf.Abs(p.x) < 5f) continue;          // no bajo los luchadores
                p.y = r < 6.3f ? 0.12f : Mathf.Lerp(0.12f, -0.4f, (r - 6.3f) / 7.7f);
                if (i % 3 == 0)
                    c.GroundDecal("star5", false, new Color(0.95f, 0.5f, 0.35f, 1f), p + Vector3.up * 0.02f, 0.38f, (float)rnd.NextDouble() * 360f);
                else
                    props.Sphere(p, new Vector3(0.12f, 0.06f, 0.1f), 6, 3, i % 2 == 0 ? new Color(1f, 0.86f, 0.82f) : new Color(0.98f, 0.95f, 0.9f), true);
            }
            Ferns(c, new[] { new Vector3(-8.6f, 0.05f, 5.4f), new Vector3(-7.4f, 0.05f, 7.2f), new Vector3(8.3f, 0.05f, 7.9f), new Vector3(10.2f, -0.05f, 5.6f), new Vector3(3.6f, 0.05f, 9.4f) }, 0.9f);
        }

        // ================================================================ SELVA

        private static void BuildJungle(Ctx c)
        {
            Combat3DArena a = c.arena;
            c.light = BakeLight.Make(new Vector3(-0.35f, 0.85f, -0.4f), new Color(1f, 0.95f, 0.8f) * 0.6f,
                new Color(0.62f, 0.78f, 0.72f) * 0.5f, new Color(0.35f, 0.42f, 0.25f) * 0.45f);
            a.ClearColor = new Color(0.56f, 0.74f, 0.7f);
            a.FogColor = new Color(0.68f, 0.8f, 0.72f);
            a.FogStart = 10f; a.FogEnd = 48f; a.FogMax = 0.85f;
            a.GroundY = 0.02f;
            a.DustColor = new Color(0.55f, 0.42f, 0.28f, 0.7f);

            Sky(c, new Color(0.85f, 0.92f, 0.8f), new Color(0.56f, 0.78f, 0.86f), new Color(0.28f, 0.52f, 0.78f));
            Clouds(c, 6, 80f, new Color(1f, 1f, 1f, 0.8f));

            MeshBuilder grass = c.G("grass");
            grass.Disc(Vector3.zero, 46f, 64, 14, 0.25f, null,
                r01 => r01 < 0.15f ? 0f : (r01 - 0.15f) * (r01 - 0.15f) * 3.5f,
                (p, r01) => Color.Lerp(Color.white, new Color(0.75f, 0.85f, 0.7f), r01));

            // Claro de tierra para el duelo, de borde irregular
            MeshBuilder dirt = c.G("dirt");
            dirt.Disc(new Vector3(0f, 0.02f, 0f), 6.4f, 48, 4, 0.3f,
                (r01, ang) => 1f + (Combat3DAssets.Noise(Mathf.Cos(ang) * 3f + 9f, Mathf.Sin(ang) * 3f + 9f, 41) - 0.5f) * 0.35f * r01,
                null, (p, r01) => Color.Lerp(Color.white, new Color(0.85f, 0.9f, 0.75f), r01 * r01));

            // Muro de árboles alrededor y alguno más cerca
            System.Random rnd = new System.Random(21);
            for (int i = 0; i < 26; i++)
            {
                float ang = i / 26f * Mathf.PI * 2f + (float)rnd.NextDouble() * 0.2f;
                float r = 12f + (float)rnd.NextDouble() * 7f;
                Vector3 p = new Vector3(Mathf.Cos(ang) * r, 0f, Mathf.Sin(ang) * r);
                if (p.z < -6f && Mathf.Abs(p.x) < 9f) p += Vector3.back * 5f;      // delante, más lejos de la cámara
                p.y = GroundHeightJungle(p);
                if (i % 4 == 0) Palm(c, p, 0.9f + (float)rnd.NextDouble() * 0.3f, (float)rnd.NextDouble() * 360f, i);
                else BroadTree(c, p, 0.9f + (float)rnd.NextDouble() * 0.6f, i);
            }
            BroadTree(c, new Vector3(-8.4f, 0f, 5.2f), 1.25f, 101);
            BroadTree(c, new Vector3(8.8f, 0f, 6.4f), 1.4f, 102);
            Palm(c, new Vector3(-10.4f, 0f, -3.4f), 1f, 40f, 7f);

            MeshBuilder rock = c.G("rock");
            Rock(rock, new Vector3(-6.8f, 0f, 2.6f), new Vector3(1.1f, 0.8f, 0.9f), 31, new Color(0.8f, 0.9f, 0.75f));
            Rock(rock, new Vector3(6.9f, 0f, 3.4f), new Vector3(1.3f, 1.0f, 1.0f), 32, new Color(0.8f, 0.9f, 0.75f));
            Rock(rock, new Vector3(2.2f, 0f, 8.6f), new Vector3(1.6f, 1.2f, 1.2f), 33, new Color(0.8f, 0.9f, 0.75f));

            // Tronco caído y setas
            MeshBuilder bark = c.G("bark");
            bark.SetTRS(new Vector3(-3.2f, 0.32f, 7.2f), Quaternion.Euler(0f, 18f, 90f), Vector3.one);
            bark.Cylinder(new Vector3(0f, -2.2f, 0f), 0.36f, 0.32f, 4.4f, 10, Color.white, true, true, true, 2f, 3f, 0.12f, 5);
            bark.ResetTransform();
            MeshBuilder props = c.G("white");
            foreach (Vector3 m in new[] { new Vector3(-2.0f, 0f, 6.6f), new Vector3(-1.6f, 0f, 6.9f), new Vector3(5.6f, 0f, 5.0f), new Vector3(-7.4f, 0f, 1.6f) })
            {
                props.Cylinder(m, 0.06f, 0.05f, 0.22f, 6, new Color(0.95f, 0.92f, 0.85f), true, false);
                props.Sphere(m + Vector3.up * 0.22f, new Vector3(0.2f, 0.12f, 0.2f), 8, 4, new Color(0.85f, 0.2f, 0.16f), true, 0f, 0, 0f);
            }
            for (int i = 0; i < 18; i++)
            {
                float ang = (float)rnd.NextDouble() * Mathf.PI * 2f;
                float r = 6.5f + (float)rnd.NextDouble() * 5f;
                Vector3 p = new Vector3(Mathf.Cos(ang) * r, 0f, Mathf.Sin(ang) * r);
                if (p.z < -4f) continue;
                props.Sphere(p, new Vector3(0.7f, 0.5f, 0.7f) * (0.7f + (float)rnd.NextDouble() * 0.6f), 7, 4,
                    Color.Lerp(new Color(0.2f, 0.45f, 0.18f), new Color(0.36f, 0.6f, 0.22f), (float)rnd.NextDouble()), true, 0.18f, i, 0f);
            }
            List<Vector3> ferns = new List<Vector3>();
            for (int i = 0; i < 22; i++)
            {
                float ang = (float)rnd.NextDouble() * Mathf.PI * 2f;
                float r = 5.8f + (float)rnd.NextDouble() * 6f;
                Vector3 p = new Vector3(Mathf.Cos(ang) * r, 0f, Mathf.Sin(ang) * r);
                if (p.z < -3.5f && Mathf.Abs(p.x) < 6f) continue;
                ferns.Add(p);
            }
            Ferns(c, ferns.ToArray(), 1.1f);
            Torch(c, new Vector3(-5.6f, 0f, 4.2f));
            Torch(c, new Vector3(5.6f, 0f, 4.2f));
        }

        private static float GroundHeightJungle(Vector3 p)
        {
            float r01 = new Vector2(p.x, p.z).magnitude / 46f;
            return r01 < 0.15f ? 0f : (r01 - 0.15f) * (r01 - 0.15f) * 3.5f;
        }

        // ================================================================ CUEVA

        private static void BuildCave(Ctx c)
        {
            Combat3DArena a = c.arena;
            c.light = BakeLight.Make(new Vector3(-0.3f, 0.75f, -0.6f), new Color(1f, 0.7f, 0.42f) * 0.6f,
                new Color(0.3f, 0.34f, 0.5f) * 0.55f, new Color(0.22f, 0.16f, 0.14f) * 0.5f);
            a.ClearColor = new Color(0.02f, 0.02f, 0.03f);
            a.FogColor = new Color(0.04f, 0.035f, 0.05f);
            a.FogStart = 9f; a.FogEnd = 30f; a.FogMax = 0.92f;
            a.GroundY = 0f;
            a.DustColor = new Color(0.55f, 0.5f, 0.5f, 0.7f);

            MeshBuilder floor = c.G("caverock");
            floor.Disc(Vector3.zero, 17f, 64, 8, 0.28f,
                (r01, ang) => 1f + (Combat3DAssets.Noise(Mathf.Cos(ang) * 2f + 3f, Mathf.Sin(ang) * 2f + 3f, 51) - 0.5f) * 0.2f * r01,
                r01 => r01 < 0.5f ? 0f : (r01 - 0.5f) * 1.2f,
                (p, r01) => Color.Lerp(new Color(1f, 0.95f, 0.9f), new Color(0.55f, 0.55f, 0.65f), r01));

            // Bóveda de roca que se cierra arriba
            MeshBuilder walls = c.G("caverock");
            walls.InwardCylinder(new Vector3(0f, -0.5f, 0f), 15.5f, 15f, 40, 8, new Color(0.9f, 0.85f, 0.85f), 6f, 3f,
                (v, ang) => (1f - v * v * 0.72f) * (0.85f + Combat3DAssets.Noise(Mathf.Cos(ang) * 3f + 20f + v * 2f, Mathf.Sin(ang) * 3f + 20f, 52) * 0.4f));

            // Estalagmitas (suelo) y estalactitas (techo)
            MeshBuilder rock = c.G("caverock");
            System.Random rnd = new System.Random(5);
            for (int i = 0; i < 22; i++)
            {
                float ang = (float)rnd.NextDouble() * Mathf.PI * 2f;
                float r = 7.5f + (float)rnd.NextDouble() * 6f;
                Vector3 p = new Vector3(Mathf.Cos(ang) * r, -0.05f, Mathf.Sin(ang) * r);
                if (p.z < -4.5f && Mathf.Abs(p.x) < 7f) continue;
                float h = 0.8f + (float)rnd.NextDouble() * 2.6f;
                rock.Cone(p, 0.3f + h * 0.18f, h, 7, new Color(0.85f, 0.8f, 0.8f), false, 0.3f, i);
            }
            for (int i = 0; i < 30; i++)
            {
                float ang = (float)rnd.NextDouble() * Mathf.PI * 2f;
                float r = 3f + (float)rnd.NextDouble() * 6.5f;
                Vector3 at = new Vector3(Mathf.Cos(ang) * r, 0f, Mathf.Sin(ang) * r);
                if (at.z < -2f) continue;                                         // nada colgando entre la cámara y el duelo
                float h = 0.8f + (float)rnd.NextDouble() * 2.2f;
                // Altura del techo en ese radio (la bóveda se estrecha: radio = 15.5 * 0.85 * (1 - v² * 0.72))
                float v = Mathf.Min(1f, Mathf.Sqrt(Mathf.Max(0f, (1f - r / (15.5f * 0.85f)) / 0.72f)));
                float top = -0.5f + 15f * v + 0.2f;
                rock.SetTRS(new Vector3(Mathf.Cos(ang) * r, top, Mathf.Sin(ang) * r), Quaternion.Euler(180f, 0f, 0f), Vector3.one);
                rock.Cone(Vector3.zero, 0.25f + h * 0.15f, h, 6, new Color(0.7f, 0.66f, 0.7f), false, 0.25f, 100 + i);
            }
            rock.ResetTransform();
            MeshBuilder bigRocks = c.G("rock");
            Rock(bigRocks, new Vector3(-7.2f, 0f, 2.8f), new Vector3(1.3f, 1.0f, 1.1f), 61, new Color(0.6f, 0.55f, 0.58f));
            Rock(bigRocks, new Vector3(7.6f, 0f, 2.2f), new Vector3(1.1f, 0.9f, 1.0f), 62, new Color(0.6f, 0.55f, 0.58f));

            // Cristales luminosos en racimos
            Crystals(c, new Vector3(-9.4f, 0f, 5.6f), new Color(0.35f, 0.95f, 1f), 71);
            Crystals(c, new Vector3(8.8f, 0f, 7.8f), new Color(0.75f, 0.45f, 1f), 72);
            Crystals(c, new Vector3(1.6f, 0f, 11.4f), new Color(0.35f, 0.95f, 1f), 73);
            Crystals(c, new Vector3(-11.6f, 0.3f, -2.8f), new Color(0.75f, 0.45f, 1f), 74);

            // Vía de mina con vagoneta, cajas y barriles del alijo
            MineRails(c, new Vector3(-12f, 0.02f, 8.4f), new Vector3(12f, 0.02f, 6.4f));
            MineCart(c, new Vector3(4.4f, 0.02f, 6.8f), -5f);
            Crate(c, new Vector3(-5.6f, 0f, 6.4f), 0.9f, 12f);
            Crate(c, new Vector3(-4.7f, 0f, 6.9f), 0.7f, -20f);
            Barrel(c, new Vector3(6.8f, 0f, 4.6f), 0f);
            Barrel(c, new Vector3(-6.4f, 0f, 5.4f), 0f);

            // Charca subterránea
            Water(c, 0.02f, 0f, 3.6f, new Color(0.12f, 0.4f, 0.45f), new Color(0.04f, 0.16f, 0.22f), 0.03f, new Vector3(-6.2f, 0f, 9.4f), 24, 6);

            // Antorchas y charcos de luz cálida en el suelo
            Torch(c, new Vector3(-5.4f, 0f, 3.6f));
            Torch(c, new Vector3(5.4f, 0f, 3.6f));
            Torch(c, new Vector3(-6.6f, 0f, -3.6f));
            Torch(c, new Vector3(6.6f, 0f, -3.6f));
            c.GroundDecal("softcircle", true, new Color(1f, 0.62f, 0.3f, 0.32f), new Vector3(0f, 0.03f, 0.4f), 15f);
            c.GroundDecal("softcircle", true, new Color(0.3f, 0.8f, 1f, 0.18f), new Vector3(-9f, 0.04f, 5.6f), 7f);
            c.GroundDecal("softcircle", true, new Color(0.7f, 0.4f, 1f, 0.18f), new Vector3(8.6f, 0.04f, 7.6f), 7f);
        }

        // ================================================================ CUBIERTA DEL BARCO

        private static void BuildDeck(Ctx c)
        {
            Combat3DArena a = c.arena;
            c.light = BakeLight.Make(new Vector3(-0.4f, 0.78f, -0.55f), new Color(1f, 0.86f, 0.7f) * 0.62f,
                new Color(0.62f, 0.68f, 0.86f) * 0.55f, new Color(0.45f, 0.36f, 0.28f) * 0.45f);
            a.ClearColor = new Color(0.98f, 0.7f, 0.5f);
            a.FogColor = new Color(0.96f, 0.76f, 0.62f);
            a.FogStart = 25f; a.FogEnd = 140f; a.FogMax = 0.8f;
            a.GroundY = 0f;
            a.DustColor = new Color(0.7f, 0.58f, 0.44f, 0.6f);

            Sky(c, new Color(1f, 0.72f, 0.45f), new Color(0.95f, 0.6f, 0.55f), new Color(0.32f, 0.3f, 0.6f));
            Sun(c, new Vector3(0.3f, 0.12f, 0.95f), new Color(1f, 0.82f, 0.5f));
            Clouds(c, 8, 95f, new Color(1f, 0.85f, 0.78f, 0.85f));
            DistantIslands(c, new Color(0.35f, 0.4f, 0.5f));
            Water(c, -1.7f, 3f, 150f, new Color(0.18f, 0.5f, 0.66f), new Color(0.12f, 0.24f, 0.45f), 0.22f);

            // Casco y cubierta (eslora en X)
            MeshBuilder planks = c.G("planks");
            planks.SetTRS(Vector3.zero, Quaternion.identity, Vector3.one);
            planks.Box(new Vector3(0f, -0.15f, 0f), new Vector3(20f, 0.3f, 9.6f), Color.white, 0.5f);         // cubierta
            planks.Box(new Vector3(0f, -1.6f, 0f), new Vector3(20f, 2.6f, 9.0f), new Color(0.72f, 0.58f, 0.48f), 0.5f); // casco
            planks.Box(new Vector3(-8.2f, 0.6f, 0f), new Vector3(3.6f, 1.2f, 9.6f), new Color(0.9f, 0.85f, 0.8f), 0.5f); // alcázar de popa
            // Proa en cuña
            Vector3 b0 = new Vector3(10f, 0f, -4.8f), b1 = new Vector3(10f, 0f, 4.8f), tip = new Vector3(14f, 0f, 0f);
            Vector3 d0 = b0 + Vector3.down * 2.9f, d1 = b1 + Vector3.down * 2.9f, dtip = tip + Vector3.down * 2.4f;
            planks.Tri(b0, b1, tip, new Vector2(0f, 0f), new Vector2(0f, 4.8f), new Vector2(2f, 2.4f), Color.white);
            planks.Quad(d0, b0, tip, dtip, new Color(0.72f, 0.58f, 0.48f), Vector2.zero, new Vector2(2.4f, 1.5f));
            planks.Quad(dtip, tip, b1, d1, new Color(0.72f, 0.58f, 0.48f), Vector2.zero, new Vector2(2.4f, 1.5f));

            // Barandillas a los lados (la delantera es más baja para no tapar la cámara)
            MeshBuilder wood = c.G("wood");
            for (float x = -9.6f; x <= 9.7f; x += 1.6f)
            {
                wood.Box(new Vector3(x, 0.45f, 4.6f), new Vector3(0.16f, 0.9f, 0.16f), Color.white);
                wood.Box(new Vector3(x, 0.32f, -4.6f), new Vector3(0.16f, 0.64f, 0.16f), Color.white);
            }
            wood.Box(new Vector3(0f, 0.95f, 4.6f), new Vector3(19.6f, 0.14f, 0.26f), new Color(0.85f, 0.75f, 0.65f));
            wood.Box(new Vector3(0f, 0.68f, -4.6f), new Vector3(19.6f, 0.12f, 0.24f), new Color(0.85f, 0.75f, 0.65f));
            wood.Beam(new Vector3(10f, 0.9f, 4.6f), new Vector3(14f, 0.9f, 0f), 0.08f, 6, Color.white);
            wood.Beam(new Vector3(10f, 0.9f, -4.6f), new Vector3(14f, 0.9f, 0f), 0.08f, 6, Color.white);
            wood.Beam(new Vector3(13.6f, 0.4f, 0f), new Vector3(18.5f, 2.6f, 0f), 0.16f, 8, Color.white);          // bauprés

            // Mástiles con vergas, velas y jarcia
            Mast(c, new Vector3(0.2f, 0f, 2.4f), 15f, 1.0f);
            Mast(c, new Vector3(-7.4f, 1.2f, 1.4f), 11f, 0.75f);

            // Timón en el alcázar
            Vector3 wheel = new Vector3(-7.6f, 1.2f, -1.2f);
            wood.Box(wheel + new Vector3(0f, 0.45f, 0f), new Vector3(0.22f, 0.9f, 0.22f), Color.white);
            for (int i = 0; i < 8; i++)
            {
                float ang = i * 45f;
                Quaternion q = Quaternion.Euler(0f, 0f, ang);
                wood.Beam(wheel + new Vector3(0.18f, 1.25f, 0f), wheel + new Vector3(0.18f, 1.25f, 0f) + q * Vector3.up * 0.75f, 0.035f, 4, new Color(0.9f, 0.8f, 0.6f));
            }
            for (int i = 0; i < 12; i++)
            {
                Vector3 p0 = wheel + new Vector3(0.18f, 1.25f, 0f) + Quaternion.Euler(0f, 0f, i * 30f) * Vector3.up * 0.58f;
                Vector3 p1 = wheel + new Vector3(0.18f, 1.25f, 0f) + Quaternion.Euler(0f, 0f, (i + 1) * 30f) * Vector3.up * 0.58f;
                wood.Beam(p0, p1, 0.05f, 4, Color.white);
            }

            // Cañones en la banda del fondo
            for (int i = 0; i < 4; i++) Cannon(c, new Vector3(-4.5f + i * 3.6f, 0f, 3.7f), 90f);
            Barrel(c, new Vector3(6.6f, 0f, -3.4f), 0f);
            Barrel(c, new Vector3(7.4f, 0f, -2.9f), 40f);
            Crate(c, new Vector3(4.5f, 0f, 3.1f), 0.9f, 8f);
            Crate(c, new Vector3(8.2f, 0f, 3.4f), 0.85f, -15f);
            MeshBuilder rope = c.G("white");
            for (int k = 0; k < 4; k++)
                rope.Cylinder(new Vector3(4.6f, 0.06f * k, -3.3f), 0.55f - k * 0.08f, 0.55f - k * 0.08f, 0.07f, 14, new Color(0.78f, 0.64f, 0.42f), true, true);
            Torch(c, new Vector3(-6.9f, 1.2f, 3.9f));
            Torch(c, new Vector3(-6.9f, 1.2f, -3.9f));
        }

        // ================================================================ PIEZAS COMUNES

        private static void Sky(Ctx c, Color horizon, Color mid, Color zenith)
        {
            MeshBuilder sky = new MeshBuilder();
            sky.InwardCylinder(new Vector3(0f, -25f, 0f), 170f, 150f, 48, 6, Color.white, 1f, 1f, (v, ang) => 1f - v * v * 0.55f);
            Mesh m = c.arena.Own(sky.Build("c3d_sky", c.light, false));
            Material mat = c.arena.Own(Combat3DAssets.NewLit(Combat3DAssets.SkyGradient(horizon.ToString() + zenith, horizon, mid, zenith), Color.white, true));
            mat.SetFloat("_FogAmount", 0f);
            c.Obj("Sky", m, mat, 0);
        }

        private static void Sun(Ctx c, Vector3 dir, Color col)
        {
            Vector3 p = dir.normalized * 130f;
            c.FxBillboard("Sun_Glow", "softcircle", true, new Color(col.r, col.g, col.b, 0.55f), p, new Vector2(70f, 70f), false);
            c.FxBillboard("Sun_Core", "softcircle", true, new Color(1f, 1f, 0.95f, 1f), p, new Vector2(16f, 16f), false);
        }

        private static void Clouds(Ctx c, int count, float radius, Color col)
        {
            System.Random rnd = new System.Random(3);
            for (int i = 0; i < count; i++)
            {
                float ang = Mathf.Lerp(-10f, 190f, (float)rnd.NextDouble()) * Mathf.Deg2Rad; // sobre todo al fondo (+Z)
                float r = radius * (0.8f + (float)rnd.NextDouble() * 0.35f);
                Vector3 p = new Vector3(Mathf.Cos(ang) * r, 16f + (float)rnd.NextDouble() * 22f, Mathf.Sin(ang) * r);
                float w = 26f + (float)rnd.NextDouble() * 22f;
                Transform t = c.FxBillboard("Cloud" + i, "cloud", false, col, p, new Vector2(w, w * 0.45f), true).transform;
                c.arena.AddDrift(t, new Vector3(0.8f + (float)rnd.NextDouble() * 0.8f, 0f, 0f), radius * 1.3f);
            }
        }

        private static void DistantIslands(Ctx c, Color green)
        {
            MeshBuilder b = c.G("white");
            Vector3[] spots = { new Vector3(-70f, -1f, 80f), new Vector3(40f, -1f, 95f), new Vector3(95f, -1f, 30f), new Vector3(-100f, -1f, 20f) };
            float[] sizes = { 14f, 20f, 10f, 12f };
            for (int i = 0; i < spots.Length; i++)
            {
                float s = sizes[i];
                b.Sphere(spots[i], new Vector3(s, s * 0.45f, s * 0.8f), 10, 5, green, true, 0.22f, 80 + i, 0f);
                b.Cylinder(spots[i] + Vector3.down * 0.4f, s * 1.08f, s * 1.0f, 0.6f, 14, new Color(0.9f, 0.82f, 0.62f), false, true);
            }
        }

        /// <summary>Mar radial animado (o charca, con 'center'). innerRadius queda oculto bajo la isla/el barco.</summary>
        private static void Water(Ctx c, float y, float innerRadius, float outerRadius, Color near, Color far, float waveAmp,
            Vector3? center = null, int segments = 64, int rings = 26)
        {
            Vector3 ctr = center ?? Vector3.zero;
            int vertsPerRing = segments + 1;
            List<Vector3> pos = new List<Vector3>();
            List<Color> cols = new List<Color>();
            List<Vector2> uv = new List<Vector2>();
            List<int> tris = new List<int>();
            for (int r = 0; r <= rings; r++)
            {
                float k = (float)r / rings;
                float rad = Mathf.Lerp(innerRadius, outerRadius, k * k);       // anillos más densos cerca de la orilla
                Color col = Color.Lerp(near, far, Mathf.SmoothStep(0f, 1f, Mathf.Clamp01((rad - innerRadius) / 30f)));
                for (int i = 0; i <= segments; i++)
                {
                    float ang = (float)i / segments * Mathf.PI * 2f;
                    Vector3 p = ctr + new Vector3(Mathf.Cos(ang) * rad, y, Mathf.Sin(ang) * rad);
                    pos.Add(p);
                    cols.Add(col);
                    uv.Add(new Vector2(p.x * 0.08f, p.z * 0.08f));
                }
            }
            for (int r = 0; r < rings; r++)
            {
                for (int i = 0; i < segments; i++)
                {
                    int a0 = r * vertsPerRing + i, a1 = a0 + 1, b0 = a0 + vertsPerRing, b1 = b0 + 1;
                    // Visto desde arriba, el ángulo crece en sentido antihorario: orden invertido = horario
                    tris.Add(a0); tris.Add(b1); tris.Add(b0);
                    tris.Add(a0); tris.Add(a1); tris.Add(b1);
                }
            }
            Mesh mesh = c.arena.Own(new Mesh { name = "c3d_water" });
            mesh.SetVertices(pos);
            mesh.SetColors(cols);
            mesh.SetUVs(0, uv);
            mesh.SetTriangles(tris, 0);
            mesh.RecalculateBounds();
            mesh.bounds = new Bounds(mesh.bounds.center, mesh.bounds.size + Vector3.up * 2f);
            mesh.MarkDynamic();

            Material mat = c.arena.Own(Combat3DAssets.NewLit(Combat3DAssets.Tex("water"), Color.white));
            c.Obj("Water", mesh, mat, 0);
            c.arena.AddWater(new Combat3DArena.WaterSurface(mesh, pos.ToArray(), cols.ToArray(), waveAmp, mat, new Vector2(0.012f, 0.008f)));
        }

        private static void Foam(Ctx c, float radius, float y, float width)
        {
            for (int k = 0; k < 2; k++)
            {
                MeshBuilder b = new MeshBuilder();
                int seg = 72;
                float rIn = radius - width * 0.5f + k * 0.5f, rOut = radius + width * 0.5f + k * 0.9f;
                for (int i = 0; i < seg; i++)
                {
                    float a0 = (float)i / seg * Mathf.PI * 2f, a1 = (float)(i + 1) / seg * Mathf.PI * 2f;
                    float j0 = 1f + (Combat3DAssets.Noise(Mathf.Cos(a0) * 2.2f + 5f, Mathf.Sin(a0) * 2.2f + 5f, 3) - 0.5f) * 0.18f;
                    float j1 = 1f + (Combat3DAssets.Noise(Mathf.Cos(a1) * 2.2f + 5f, Mathf.Sin(a1) * 2.2f + 5f, 3) - 0.5f) * 0.18f;
                    Vector3 d0 = new Vector3(Mathf.Cos(a0), 0f, Mathf.Sin(a0)), d1 = new Vector3(Mathf.Cos(a1), 0f, Mathf.Sin(a1));
                    Vector3 i0 = d0 * rIn * j0 + Vector3.up * y, i1 = d1 * rIn * j1 + Vector3.up * y;
                    Vector3 m0 = d0 * (rIn + rOut) * 0.5f * j0 + Vector3.up * y, m1 = d1 * (rIn + rOut) * 0.5f * j1 + Vector3.up * y;
                    Vector3 o0 = d0 * rOut * j0 + Vector3.up * y, o1 = d1 * rOut * j1 + Vector3.up * y;
                    Color clear = new Color(1f, 1f, 1f, 0f), solid = new Color(1f, 1f, 1f, 0.85f);
                    AddFoamQuad(b, i0, i1, m1, m0, clear, clear, solid, solid);
                    AddFoamQuad(b, m0, m1, o1, o0, solid, solid, clear, clear);
                }
                Mesh mesh = c.arena.Own(b.Build("c3d_foam", c.light, false));
                MeshRenderer r = c.Obj("Foam" + k, mesh, Combat3DAssets.Fx("white", false), 4);
                c.arena.AddFoam(r.transform, 1.1f + k * 0.4f, k * 2.1f, r, new Color(1f, 1f, 1f, 0.8f - k * 0.3f));
            }
        }

        private static void AddFoamQuad(MeshBuilder b, Vector3 a0, Vector3 a1, Vector3 b1, Vector3 b0, Color ca0, Color ca1, Color cb1, Color cb0)
        {
            // Dos triángulos con color por vértice: se usa el triángulo suave del constructor
            b.TriColored(a0, b1, b0, ca0, cb1, cb0);
            b.TriColored(a0, a1, b1, ca0, ca1, cb1);
        }

        private static void RopeRing(Ctx c, float radius, float y, int posts, float fromDeg, float toDeg, Color postCol, Color ropeCol)
        {
            MeshBuilder wood = c.G("wood");
            MeshBuilder rope = c.G("white");
            Vector3 prevTop = Vector3.zero;
            for (int i = 0; i < posts; i++)
            {
                float ang = Mathf.Lerp(fromDeg, toDeg, (float)i / (posts - 1)) * Mathf.Deg2Rad;
                Vector3 p = new Vector3(Mathf.Cos(ang) * radius, y - 0.05f, Mathf.Sin(ang) * radius);
                wood.Cylinder(p, 0.1f, 0.09f, 1.0f, 7, postCol * 1.6f, true, true, false, 1f, 2f);
                Vector3 top = p + Vector3.up * 0.82f;
                if (i > 0)
                {
                    Vector3 mid = (prevTop + top) * 0.5f + Vector3.down * 0.16f;
                    rope.Beam(prevTop, mid, 0.035f, 5, ropeCol);
                    rope.Beam(mid, top, 0.035f, 5, ropeCol);
                    Vector3 lowA = prevTop + Vector3.down * 0.4f, lowB = top + Vector3.down * 0.4f, lowM = (lowA + lowB) * 0.5f + Vector3.down * 0.1f;
                    rope.Beam(lowA, lowM, 0.03f, 5, ropeCol);
                    rope.Beam(lowM, lowB, 0.03f, 5, ropeCol);
                }
                prevTop = top;
            }
        }

        private static void Palm(Ctx c, Vector3 basePos, float scale, float leanYaw, float phase)
        {
            MeshBuilder bark = c.G("bark");
            Vector3 lean = Quaternion.Euler(0f, leanYaw, 0f) * Vector3.right;
            Vector3 p = basePos;
            int segs = 6;
            float segH = 0.95f * scale;
            for (int i = 0; i < segs; i++)
            {
                float t0 = (float)i / segs, t1 = (float)(i + 1) / segs;
                Vector3 a = basePos + lean * (t0 * t0 * 1.9f * scale) + Vector3.up * (t0 * segs * segH);
                Vector3 b = basePos + lean * (t1 * t1 * 1.9f * scale) + Vector3.up * (t1 * segs * segH);
                float r0 = Mathf.Lerp(0.26f, 0.15f, t0) * scale, r1 = Mathf.Lerp(0.26f, 0.15f, t1) * scale;
                bark.Frustum(a, b, r0, r1, 8, Color.white, 1f, 1f);
                p = b;
            }
            MeshBuilder props = c.G("white");
            for (int i = 0; i < 3; i++)
            {
                Vector3 off = Quaternion.Euler(0f, i * 120f + leanYaw, 0f) * new Vector3(0.18f * scale, -0.22f * scale, 0f);
                props.Sphere(p + off, Vector3.one * 0.17f * scale, 7, 4, new Color(0.42f, 0.28f, 0.14f), false);
            }

            // Copa en su propio objeto para que se meza
            MeshBuilder crown = new MeshBuilder();
            int fronds = 9;
            for (int f = 0; f < fronds; f++)
            {
                float yaw = f * 360f / fronds + phase * 13f;
                Vector3 dir = Quaternion.Euler(0f, yaw, 0f) * Vector3.forward;
                float len = (2.3f + Combat3DAssets.Hash(f, 3, (int)(phase * 10f)) * 0.7f) * scale;
                Frond(crown, Vector3.zero, dir, len, 0.95f * scale, f % 3 == 0 ? 0.25f : 0.45f);
            }
            Mesh mesh = c.arena.Own(crown.Build("c3d_palmcrown", c.light));
            MeshRenderer r = c.Obj("PalmCrown", mesh, Combat3DAssets.Lit("frond", true, 0.5f), 0);
            r.transform.localPosition = p;
            c.arena.AddSway(r.transform, 2.2f, 1.1f + phase * 0.07f, phase);
        }

        /// <summary>Hoja de palmera curvada (sube y cae) con un pliegue central para dar volumen.</summary>
        private static void Frond(MeshBuilder b, Vector3 origin, Vector3 dir, float length, float width, float lift)
        {
            Vector3 side = Vector3.Cross(Vector3.up, dir).normalized;
            int segs = 5;
            Vector3 Center(float t) => origin + dir * (length * t) + Vector3.up * (lift * Mathf.Sin(t * Mathf.PI * 0.9f) * length * 0.35f - t * t * length * 0.42f);
            for (int i = 0; i < segs; i++)
            {
                float t0 = (float)i / segs, t1 = (float)(i + 1) / segs;
                Vector3 c0 = Center(t0), c1 = Center(t1);
                Vector3 l0 = c0 - side * width * 0.5f + Vector3.up * width * 0.12f, l1 = c1 - side * width * 0.5f + Vector3.up * width * 0.12f;
                Vector3 r0 = c0 + side * width * 0.5f + Vector3.up * width * 0.12f, r1 = c1 + side * width * 0.5f + Vector3.up * width * 0.12f;
                b.Quad(l0, l1, c1, c0, Color.white, new Vector2(0f, t0), new Vector2(0.5f, t1));
                b.Quad(c0, c1, r1, r0, Color.white, new Vector2(0.5f, t0), new Vector2(1f, t1));
            }
        }

        private static void BroadTree(Ctx c, Vector3 basePos, float scale, int seed)
        {
            MeshBuilder bark = c.G("bark");
            float h = 3.2f * scale;
            bark.Cylinder(basePos, 0.32f * scale, 0.22f * scale, h, 8, Color.white, true, false, false, 1f, 2f, 0.15f, seed);
            MeshBuilder leaves = c.G("white");
            System.Random rnd = new System.Random(seed);
            Color dark = new Color(0.16f, 0.38f, 0.16f), light = new Color(0.32f, 0.58f, 0.22f);
            for (int i = 0; i < 4; i++)
            {
                Vector3 off = new Vector3(((float)rnd.NextDouble() - 0.5f) * 1.6f, ((float)rnd.NextDouble()) * 1.0f, ((float)rnd.NextDouble() - 0.5f) * 1.6f) * scale;
                float s = (1.3f + (float)rnd.NextDouble() * 0.6f) * scale;
                leaves.Sphere(basePos + Vector3.up * (h + 0.4f * scale) + off, new Vector3(s, s * 0.82f, s), 9, 5,
                    Color.Lerp(dark, light, (float)rnd.NextDouble()), true, 0.22f, seed * 7 + i);
            }
        }

        private static void Rock(MeshBuilder b, Vector3 p, Vector3 size, int seed, Color? tint = null)
        {
            b.Sphere(p + Vector3.up * size.y * 0.35f, size, 8, 5, tint ?? Color.white, true, 0.3f, seed);
        }

        private static void Barrel(Ctx c, Vector3 p, float yaw)
        {
            MeshBuilder wood = c.G("wood");
            wood.Cylinder(p, 0.36f, 0.42f, 0.45f, 10, Color.white, true, false, false, 2f, 1f);
            wood.Cylinder(p + Vector3.up * 0.45f, 0.42f, 0.36f, 0.45f, 10, Color.white, true, true, false, 2f, 1f);
            MeshBuilder iron = c.G("white");
            iron.Cylinder(p + Vector3.up * 0.16f, 0.4f, 0.41f, 0.06f, 10, new Color(0.25f, 0.24f, 0.26f), true, false);
            iron.Cylinder(p + Vector3.up * 0.68f, 0.41f, 0.4f, 0.06f, 10, new Color(0.25f, 0.24f, 0.26f), true, false);
        }

        private static void Crate(Ctx c, Vector3 p, float size, float yaw)
        {
            MeshBuilder planks = c.G("planks");
            planks.SetTRS(p + Vector3.up * size * 0.5f, Quaternion.Euler(0f, yaw, 0f), Vector3.one);
            planks.Box(Vector3.zero, Vector3.one * size, Color.white, 1f);
            planks.ResetTransform();
            MeshBuilder wood = c.G("wood");
            wood.SetTRS(p + Vector3.up * size * 0.5f, Quaternion.Euler(0f, yaw, 0f), Vector3.one);
            float e = size * 0.5f + 0.01f;
            foreach (float sx in new[] { -1f, 1f })
                foreach (float sz in new[] { -1f, 1f })
                    wood.Box(new Vector3(sx * (e - 0.05f), 0f, sz * (e - 0.05f)), new Vector3(0.12f, size + 0.02f, 0.12f), new Color(0.7f, 0.55f, 0.4f));
            wood.ResetTransform();
        }

        private static void Anchor(Ctx c, Vector3 p, float yaw)
        {
            MeshBuilder iron = c.G("white");
            Color col = new Color(0.3f, 0.3f, 0.34f);
            iron.SetTRS(p, Quaternion.Euler(18f, yaw, -12f), Vector3.one);
            iron.Cylinder(Vector3.zero, 0.09f, 0.09f, 1.8f, 7, col);
            iron.Box(new Vector3(0f, 1.55f, 0f), new Vector3(0.9f, 0.1f, 0.1f), col);
            iron.Cylinder(new Vector3(0f, 1.8f, 0f), 0.16f, 0.16f, 0.08f, 10, col);
            iron.Beam(new Vector3(0f, 0.05f, 0f), new Vector3(0.7f, 0.45f, 0f), 0.08f, 6, col);
            iron.Beam(new Vector3(0f, 0.05f, 0f), new Vector3(-0.7f, 0.45f, 0f), 0.08f, 6, col);
            iron.Cone(new Vector3(0.7f, 0.45f, 0f), 0.16f, 0.3f, 5, col);
            iron.Cone(new Vector3(-0.7f, 0.45f, 0f), 0.16f, 0.3f, 5, col);
            iron.ResetTransform();
        }

        private static void Torch(Ctx c, Vector3 p)
        {
            MeshBuilder wood = c.G("wood");
            wood.Cylinder(p, 0.09f, 0.07f, 1.7f, 7, Color.white, true, false, false, 1f, 3f);
            MeshBuilder iron = c.G("white");
            iron.Cylinder(p + Vector3.up * 1.62f, 0.12f, 0.24f, 0.24f, 8, new Color(0.22f, 0.21f, 0.24f), true, true);
            Vector3 flame = p + Vector3.up * 2.12f;
            MeshRenderer glow = c.FxBillboard("TorchGlow", "softcircle", true, new Color(1f, 0.55f, 0.18f, 0.5f), flame, new Vector2(2.6f, 2.6f), false);
            c.arena.AddFlicker(glow.transform, glow, new Color(1f, 0.55f, 0.18f, 0.5f), 0.25f);
            MeshRenderer fire = c.FxBillboard("TorchFlame", "flame", true, new Color(1f, 0.85f, 0.5f, 1f), flame + Vector3.up * 0.08f, new Vector2(0.55f, 0.9f), true);
            c.arena.AddFlicker(fire.transform, fire, new Color(1f, 0.85f, 0.5f, 1f), 0.35f);
            c.arena.AddEmber(flame + Vector3.up * 0.3f, new Color(1f, 0.6f, 0.2f, 1f), 3.5f);
        }

        private static void FlagPole(Ctx c, Vector3 p, float height)
        {
            MeshBuilder wood = c.G("wood");
            wood.Cylinder(p, 0.12f, 0.08f, height, 8, Color.white, true, true, false, 1f, 6f);
            wood.Sphere(p + Vector3.up * (height + 0.08f), Vector3.one * 0.14f, 6, 3, new Color(1f, 0.85f, 0.5f), false);
            Flag(c, p + Vector3.up * (height - 0.15f), 2.4f, 1.5f, 1f);
        }

        private static void Flag(Ctx c, Vector3 topLeft, float w, float h, float side)
        {
            const int cols = 10, rows = 5;
            List<Vector3> pos = new List<Vector3>();
            List<Color> colsList = new List<Color>();
            List<Vector2> uv = new List<Vector2>();
            List<float> weight = new List<float>();
            List<int> tris = new List<int>();
            for (int y = 0; y <= rows; y++)
            {
                for (int x = 0; x <= cols; x++)
                {
                    float u = (float)x / cols, v = (float)y / rows;
                    pos.Add(topLeft + new Vector3(u * w * side, -(1f - v) * h, 0f));
                    colsList.Add(Color.white);
                    uv.Add(new Vector2(u, v));
                    weight.Add(u);
                }
            }
            for (int y = 0; y < rows; y++)
            {
                for (int x = 0; x < cols; x++)
                {
                    int i0 = y * (cols + 1) + x, i1 = i0 + 1, i2 = i0 + cols + 1, i3 = i2 + 1;
                    tris.Add(i0); tris.Add(i2); tris.Add(i3);
                    tris.Add(i0); tris.Add(i3); tris.Add(i1);
                }
            }
            Mesh mesh = c.arena.Own(new Mesh { name = "c3d_flag" });
            mesh.SetVertices(pos); mesh.SetColors(colsList); mesh.SetUVs(0, uv); mesh.SetTriangles(tris, 0);
            mesh.RecalculateBounds();
            mesh.bounds = new Bounds(mesh.bounds.center, mesh.bounds.size + Vector3.one);
            mesh.MarkDynamic();
            c.Obj("Flag", mesh, Combat3DAssets.Lit("flag", true), 0);
            c.arena.AddCloth(new Combat3DArena.Cloth(mesh, pos.ToArray(), colsList.ToArray(), weight.ToArray(), Vector3.forward, 0.28f, 7f, 5f));
        }

        private static void Ship(Ctx c, Vector3 p, float yaw, float scale)
        {
            GameObject shipRoot = new GameObject("FarShip");
            shipRoot.transform.SetParent(c.arena.transform, false);
            shipRoot.transform.localPosition = p;
            shipRoot.transform.localRotation = Quaternion.Euler(0f, yaw, 0f);
            shipRoot.transform.localScale = Vector3.one * scale;

            MeshBuilder hull = new MeshBuilder();
            Color dark = new Color(0.45f, 0.3f, 0.2f);
            hull.Box(new Vector3(0f, 0.6f, 0f), new Vector3(9f, 1.8f, 3.2f), dark, 0.4f);
            hull.Box(new Vector3(-3.6f, 1.9f, 0f), new Vector3(2.2f, 1.0f, 3.2f), dark, 0.4f);
            Vector3 b0 = new Vector3(4.5f, 1.5f, -1.6f), b1 = new Vector3(4.5f, 1.5f, 1.6f), tip = new Vector3(6.6f, 1.6f, 0f);
            Vector3 d0 = new Vector3(4.5f, -0.3f, -1.6f), d1 = new Vector3(4.5f, -0.3f, 1.6f), dt = new Vector3(6.0f, -0.1f, 0f);
            hull.Tri(b0, b1, tip, Vector2.zero, Vector2.up, Vector2.one, dark);
            hull.Quad(d0, b0, tip, dt, dark);
            hull.Quad(dt, tip, b1, d1, dark);
            hull.Cylinder(new Vector3(0.6f, 1.5f, 0f), 0.14f, 0.1f, 8.5f, 6, new Color(0.6f, 0.45f, 0.3f));
            hull.Cylinder(new Vector3(-2.6f, 1.5f, 0f), 0.12f, 0.09f, 6.5f, 6, new Color(0.6f, 0.45f, 0.3f));
            hull.Beam(new Vector3(4.8f, 1.6f, 0f), new Vector3(8f, 3.4f, 0f), 0.08f, 5, new Color(0.6f, 0.45f, 0.3f));
            Mesh hm = c.arena.Own(hull.Build("c3d_farship", c.light));
            MeshRenderer hr = c.Obj("Hull", hm, Combat3DAssets.Lit("wood"), 0);
            hr.transform.SetParent(shipRoot.transform, false);

            MeshBuilder sails = new MeshBuilder();
            Color cream = Color.white;
            SailPanel(sails, new Vector3(0.6f, 3.2f, 0f), 3.4f, 2.4f, cream);
            SailPanel(sails, new Vector3(0.6f, 6.0f, 0f), 2.8f, 2.0f, cream);
            SailPanel(sails, new Vector3(-2.6f, 3.4f, 0f), 2.6f, 2.0f, cream);
            Mesh sm = c.arena.Own(sails.Build("c3d_farsails", c.light));
            MeshRenderer sr = c.Obj("Sails", sm, Combat3DAssets.Lit("canvas", true), 0);
            sr.transform.SetParent(shipRoot.transform, false);

            c.arena.AddBob(shipRoot.transform, 0.18f, 1.6f, 0.9f);
        }

        /// <summary>Vela abombada (plano perpendicular a la eslora del barco).</summary>
        private static void SailPanel(MeshBuilder b, Vector3 bottomCenter, float width, float height, Color col)
        {
            int cols = 4;
            for (int i = 0; i < cols; i++)
            {
                float u0 = (float)i / cols, u1 = (float)(i + 1) / cols;
                float z0 = (u0 - 0.5f) * width, z1 = (u1 - 0.5f) * width;
                float bulge0 = Mathf.Sin(u0 * Mathf.PI) * 0.45f, bulge1 = Mathf.Sin(u1 * Mathf.PI) * 0.45f;
                Vector3 a = bottomCenter + new Vector3(bulge0, 0f, z0), d = bottomCenter + new Vector3(bulge1, 0f, z1);
                Vector3 bb = a + Vector3.up * height + Vector3.left * bulge0 * 0.4f, cc = d + Vector3.up * height + Vector3.left * bulge1 * 0.4f;
                b.Quad(a, bb, cc, d, col, new Vector2(u0, 0f), new Vector2(u1, 1f));
            }
        }

        private static void Mast(Ctx c, Vector3 p, float height, float scale)
        {
            MeshBuilder wood = c.G("wood");
            wood.Cylinder(p, 0.26f * scale, 0.16f * scale, height, 10, Color.white, true, true, false, 1f, 8f);
            float[] yards = { 0.36f, 0.64f, 0.88f };
            float[] widths = { 7.5f, 6.0f, 4.0f };
            for (int i = 0; i < yards.Length; i++)
            {
                float y = height * yards[i];
                float w = widths[i] * scale;
                wood.Beam(p + new Vector3(0f, y, -w * 0.5f), p + new Vector3(0f, y, w * 0.5f), 0.1f * scale, 6, Color.white);
                float next = i + 1 < yards.Length ? height * yards[i + 1] : height;
                float sailH = (next - y) * 0.86f;
                Sail(c, p + new Vector3(0f, y - 0.05f, 0f), w * 0.92f, sailH, i);
            }
            // Cofa y jarcia hacia las bordas
            wood.Cylinder(p + Vector3.up * height * 0.7f, 0.7f * scale, 0.7f * scale, 0.14f, 10, new Color(0.9f, 0.8f, 0.65f), true, true, true);
            MeshBuilder rope = c.G("white");
            Color ropeCol = new Color(0.45f, 0.36f, 0.26f);
            for (int s = -1; s <= 1; s += 2)
            {
                for (int k = 0; k < 3; k++)
                {
                    Vector3 top = p + new Vector3(0f, height * 0.68f, 0f);
                    Vector3 bottom = new Vector3(p.x - 1.2f + k * 1.2f, 0.95f, 4.6f * s);
                    rope.Beam(bottom, top, 0.025f, 4, ropeCol);
                }
            }
            Flag(c, p + Vector3.up * (height + 1.2f), 1.8f, 1.1f, -1f);
            wood.Cylinder(p + Vector3.up * height, 0.05f, 0.05f, 1.3f, 5, Color.white);
        }

        /// <summary>Vela grande colgada de una verga (cuelga hacia abajo y se hincha con el viento).</summary>
        private static void Sail(Ctx c, Vector3 yardCenter, float width, float height, int seed)
        {
            const int cols = 6, rows = 5;
            List<Vector3> pos = new List<Vector3>();
            List<Color> colors = new List<Color>();
            List<Vector2> uv = new List<Vector2>();
            List<float> weight = new List<float>();
            List<int> tris = new List<int>();
            for (int y = 0; y <= rows; y++)
            {
                for (int x = 0; x <= cols; x++)
                {
                    float u = (float)x / cols, v = (float)y / rows;   // v = 0 arriba (verga)
                    float bulge = Mathf.Sin(u * Mathf.PI) * Mathf.Sin(Mathf.Min(1f, v * 1.2f) * Mathf.PI * 0.5f) * 0.9f;
                    pos.Add(yardCenter + new Vector3(-bulge, -v * height, (u - 0.5f) * width));
                    float shade = 0.9f + 0.1f * Mathf.Sin(u * Mathf.PI);
                    colors.Add(new Color(shade, shade * 0.97f, shade * 0.92f));
                    uv.Add(new Vector2(u, 1f - v));
                    weight.Add(Mathf.Sin(u * Mathf.PI) * v);
                }
            }
            for (int y = 0; y < rows; y++)
            {
                for (int x = 0; x < cols; x++)
                {
                    int i0 = y * (cols + 1) + x, i1 = i0 + 1, i2 = i0 + cols + 1, i3 = i2 + 1;
                    tris.Add(i0); tris.Add(i1); tris.Add(i3);
                    tris.Add(i0); tris.Add(i3); tris.Add(i2);
                }
            }
            Mesh mesh = c.arena.Own(new Mesh { name = "c3d_sail" });
            mesh.SetVertices(pos); mesh.SetColors(colors); mesh.SetUVs(0, uv); mesh.SetTriangles(tris, 0);
            mesh.RecalculateBounds();
            mesh.bounds = new Bounds(mesh.bounds.center, mesh.bounds.size + Vector3.one * 2f);
            mesh.MarkDynamic();
            c.Obj("Sail", mesh, Combat3DAssets.Lit("canvas", true), 0);
            c.arena.AddCloth(new Combat3DArena.Cloth(mesh, pos.ToArray(), colors.ToArray(), weight.ToArray(), Vector3.left, 0.35f, 2.5f, 1.6f + seed * 0.3f));
        }

        private static void Cannon(Ctx c, Vector3 p, float yaw)
        {
            MeshBuilder wood = c.G("wood");
            wood.SetTRS(p, Quaternion.Euler(0f, yaw, 0f), Vector3.one);
            wood.Box(new Vector3(0f, 0.28f, 0f), new Vector3(0.8f, 0.36f, 1.1f), Color.white);
            wood.ResetTransform();
            MeshBuilder iron = c.G("white");
            iron.SetTRS(p, Quaternion.Euler(0f, yaw, 0f), Vector3.one);
            Color col = new Color(0.2f, 0.2f, 0.23f);
            iron.Beam(new Vector3(0f, 0.62f, -0.55f), new Vector3(0f, 0.68f, 0.95f), 0.2f, 10, col);
            iron.Sphere(new Vector3(0f, 0.62f, -0.6f), Vector3.one * 0.24f, 8, 4, col, false);
            foreach (float s in new[] { -1f, 1f })
                foreach (float z in new[] { -0.35f, 0.35f })
                {
                    iron.SetTRS(p + Quaternion.Euler(0f, yaw, 0f) * new Vector3(s * 0.42f, 0.16f, z), Quaternion.Euler(0f, yaw, 90f), Vector3.one);
                    iron.Cylinder(new Vector3(0f, -0.04f, 0f), 0.16f, 0.16f, 0.08f, 8, new Color(0.35f, 0.25f, 0.16f), true, true, true);
                }
            iron.ResetTransform();
        }

        private static void Crystals(Ctx c, Vector3 p, Color col, int seed)
        {
            MeshBuilder b = c.G("crystal");
            System.Random rnd = new System.Random(seed);
            for (int i = 0; i < 7; i++)
            {
                float h = 0.8f + (float)rnd.NextDouble() * 1.8f;
                Quaternion tilt = Quaternion.Euler(((float)rnd.NextDouble() - 0.5f) * 50f, (float)rnd.NextDouble() * 360f, ((float)rnd.NextDouble() - 0.5f) * 50f);
                Vector3 at = p + new Vector3(((float)rnd.NextDouble() - 0.5f) * 1.4f, 0f, ((float)rnd.NextDouble() - 0.5f) * 1.4f);
                b.SetTRS(at, tilt, Vector3.one);
                b.Cylinder(Vector3.zero, 0.16f + h * 0.05f, 0.14f + h * 0.04f, h * 0.75f, 6, col * 1.25f, false, false);
                b.Cone(Vector3.up * h * 0.75f, 0.14f + h * 0.04f, h * 0.3f, 6, col * 1.5f);
            }
            b.ResetTransform();
            MeshRenderer glow = c.FxBillboard("CrystalGlow", "softcircle", true, new Color(col.r, col.g, col.b, 0.45f), p + Vector3.up * 1.0f, new Vector2(4.5f, 4.5f), false);
            c.arena.AddPulse(glow, new Color(col.r, col.g, col.b, 0.45f), 1.6f, 0.55f);
        }

        private static void MineRails(Ctx c, Vector3 from, Vector3 to)
        {
            MeshBuilder wood = c.G("wood");
            MeshBuilder iron = c.G("white");
            Vector3 dir = (to - from).normalized;
            Vector3 side = Vector3.Cross(Vector3.up, dir).normalized;
            float len = Vector3.Distance(from, to);
            for (float t = 0.4f; t < len; t += 0.8f)
            {
                Vector3 p = from + dir * t;
                wood.Beam(p - side * 0.65f + Vector3.up * 0.05f, p + side * 0.65f + Vector3.up * 0.05f, 0.07f, 4, new Color(0.7f, 0.6f, 0.5f));
            }
            iron.Beam(from + side * 0.45f + Vector3.up * 0.12f, to + side * 0.45f + Vector3.up * 0.12f, 0.04f, 4, new Color(0.45f, 0.42f, 0.44f));
            iron.Beam(from - side * 0.45f + Vector3.up * 0.12f, to - side * 0.45f + Vector3.up * 0.12f, 0.04f, 4, new Color(0.45f, 0.42f, 0.44f));
        }

        private static void MineCart(Ctx c, Vector3 p, float yaw)
        {
            MeshBuilder iron = c.G("white");
            Color body = new Color(0.4f, 0.32f, 0.26f), dark = new Color(0.2f, 0.2f, 0.22f);
            iron.SetTRS(p, Quaternion.Euler(0f, yaw, 0f), Vector3.one);
            iron.Box(new Vector3(0f, 0.55f, 0f), new Vector3(1.5f, 0.12f, 1.0f), body);
            iron.Box(new Vector3(0.72f, 0.85f, 0f), new Vector3(0.08f, 0.6f, 1.0f), body);
            iron.Box(new Vector3(-0.72f, 0.85f, 0f), new Vector3(0.08f, 0.6f, 1.0f), body);
            iron.Box(new Vector3(0f, 0.85f, 0.48f), new Vector3(1.5f, 0.6f, 0.08f), body);
            iron.Box(new Vector3(0f, 0.85f, -0.48f), new Vector3(1.5f, 0.6f, 0.08f), body);
            iron.Sphere(new Vector3(0f, 1.05f, 0f), new Vector3(0.6f, 0.3f, 0.38f), 7, 4, new Color(0.3f, 0.28f, 0.3f), true, 0.3f, 9);
            iron.ResetTransform();
            foreach (float sx in new[] { -0.5f, 0.5f })
                foreach (float sz in new[] { -0.52f, 0.52f })
                {
                    iron.SetTRS(p + Quaternion.Euler(0f, yaw, 0f) * new Vector3(sx, 0.3f, sz), Quaternion.Euler(90f, yaw, 0f), Vector3.one);
                    iron.Cylinder(new Vector3(0f, -0.04f, 0f), 0.22f, 0.22f, 0.08f, 10, dark, true, true, true);
                }
            iron.ResetTransform();
        }

        private static void Ferns(Ctx c, Vector3[] spots, float scale)
        {
            MeshBuilder b = c.G("fern", true, 0.5f);
            for (int s = 0; s < spots.Length; s++)
            {
                Vector3 p = spots[s];
                for (int i = 0; i < 6; i++)
                {
                    float yaw = i * 60f + s * 17f;
                    Vector3 dir = Quaternion.Euler(0f, yaw, 0f) * Vector3.forward;
                    Vector3 side = Vector3.Cross(Vector3.up, dir).normalized * 0.22f * scale;
                    Vector3 tip = p + dir * 0.9f * scale + Vector3.up * 0.75f * scale;
                    b.Quad(p - side, tip - side * 0.4f, tip + side * 0.4f, p + side, Color.white);
                }
            }
        }

        // ================================================================ Contexto de construcción

        private class Ctx
        {
            public readonly Combat3DArena arena;
            public BakeLight light;
            private readonly Dictionary<string, MeshBuilder> groups = new Dictionary<string, MeshBuilder>();
            private readonly Dictionary<string, (string tex, bool twoSided, float cutoff)> groupMats = new Dictionary<string, (string, bool, float)>();

            public Ctx(Combat3DArena arena)
            {
                this.arena = arena;
                light = BakeLight.Make(Vector3.up, Color.white * 0.6f, Color.white * 0.5f, Color.white * 0.4f);
            }

            /// <summary>Grupo de piezas estáticas que comparten material (se juntan en una malla).</summary>
            public MeshBuilder G(string tex, bool twoSided = false, float cutoff = 0f)
            {
                string key = tex + (twoSided ? "|2" : "") + (cutoff > 0f ? "|c" : "");
                if (!groups.TryGetValue(key, out MeshBuilder b))
                {
                    b = new MeshBuilder();
                    groups[key] = b;
                    groupMats[key] = (tex, twoSided, cutoff);
                }
                return b;
            }

            public void Flush()
            {
                foreach (KeyValuePair<string, MeshBuilder> kv in groups)
                {
                    if (kv.Value.VertexCount == 0) continue;
                    var info = groupMats[kv.Key];
                    Mesh mesh = arena.Own(kv.Value.Build("c3d_" + kv.Key, light));
                    Obj("Static_" + kv.Key, mesh, Combat3DAssets.Lit(info.tex, info.twoSided, info.cutoff), 0);
                }
                groups.Clear();
            }

            public MeshRenderer Obj(string name, Mesh mesh, Material mat, int sortingOrder)
            {
                GameObject go = new GameObject(name);
                go.transform.SetParent(arena.transform, false);
                go.AddComponent<MeshFilter>().sharedMesh = mesh;
                MeshRenderer r = go.AddComponent<MeshRenderer>();
                r.sharedMaterial = mat;
                r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
                r.receiveShadows = false;
                r.sortingOrder = sortingOrder;
                return r;
            }

            /// <summary>Quad con textura de efectos que mira a la cámara (sol, nubes, llamas, brillos).</summary>
            public MeshRenderer FxBillboard(string name, string tex, bool additive, Color color, Vector3 localPos, Vector2 size, bool yawOnly)
            {
                MeshRenderer r = Obj(name, Combat3DAssets.Quad, Combat3DAssets.Fx(tex, additive), 10);
                r.transform.localPosition = localPos;
                r.transform.localScale = new Vector3(size.x, size.y, 1f);
                Combat3DAssets.SetColor(r, new MaterialPropertyBlock(), color);
                arena.AddBillboard(r.transform, yawOnly);
                return r;
            }

            /// <summary>Calcomanía tumbada sobre el suelo (marcas del ring, estrellas de mar, luz de antorchas).</summary>
            public MeshRenderer GroundDecal(string tex, bool additive, Color color, Vector3 localPos, float size, float yaw = 0f)
            {
                MeshRenderer r = Obj("Decal_" + tex, Combat3DAssets.GroundQuad, Combat3DAssets.Fx(tex, additive), 5);
                r.transform.localPosition = localPos;
                r.transform.localRotation = Quaternion.Euler(0f, yaw, 0f);
                r.transform.localScale = new Vector3(size, 1f, size);
                Combat3DAssets.SetColor(r, new MaterialPropertyBlock(), color);
                return r;
            }
        }
    }
}
