﻿using System.Collections.Generic;
using UnityEngine;

namespace PirateSurvival.Combat3D
{
    public enum ArenaTheme { Beach, Jungle, Cave, Deck }

    /// <summary>
    /// Escenario 3D ya construido (Combat3DArenaBuilder). Anima el mar, las telas, las palmeras, las antorchas,
    /// las nubes y los cristales con el reloj del combate, y destruye al final todas las mallas y materiales que creó.
    /// </summary>
    public class Combat3DArena : MonoBehaviour
    {
        // Puestos de los luchadores (coordenadas locales de la arena)
        public static readonly Vector3 PlayerSpot = new Vector3(-2.8f, 0f, 0f);
        public static readonly Vector3 EnemySpot = new Vector3(2.8f, 0f, 0f);
        public static readonly Vector3 EnemyEntrySpot = new Vector3(9f, 0f, 3.5f);

        public ArenaTheme Theme { get; set; }
        public Color ClearColor { get; set; } = Color.black;
        public Color FogColor { get; set; } = Color.gray;
        public float FogStart { get; set; } = 20f;
        public float FogEnd { get; set; } = 120f;
        public float FogMax { get; set; } = 0.85f;
        /// <summary>Altura del suelo en los puestos (la cubierta del barco está a 0, la arena puede tener relieve).</summary>
        public float GroundY { get; set; }
        public Color DustColor { get; set; } = new Color(0.9f, 0.8f, 0.6f, 0.7f);

        public Camera ViewCamera { get; set; }
        public Combat3DVFX Vfx { get; set; }

        private readonly List<Object> owned = new List<Object>();
        private readonly List<WaterSurface> waters = new List<WaterSurface>();
        private readonly List<Cloth> cloths = new List<Cloth>();
        private readonly List<Sway> sways = new List<Sway>();
        private readonly List<Billboard> billboards = new List<Billboard>();
        private readonly List<Flicker> flickers = new List<Flicker>();
        private readonly List<Bob> bobs = new List<Bob>();
        private readonly List<Drift> drifts = new List<Drift>();
        private readonly List<Ember> embers = new List<Ember>();
        private readonly List<Pulse> pulses = new List<Pulse>();
        private readonly List<FoamRing> foams = new List<FoamRing>();
        private MaterialPropertyBlock block;

        // ------------------------------------------------------------------ Registro (lo usa el constructor)

        public T Own<T>(T asset) where T : Object
        {
            if (asset != null) owned.Add(asset);
            return asset;
        }

        public void AddWater(WaterSurface w) => waters.Add(w);
        public void AddCloth(Cloth c) => cloths.Add(c);
        public void AddSway(Transform t, float amplitude, float speed, float phase) => sways.Add(new Sway { t = t, baseRot = t.localRotation, amp = amplitude, speed = speed, phase = phase });
        public void AddBillboard(Transform t, bool yawOnly) => billboards.Add(new Billboard { t = t, yawOnly = yawOnly });
        public void AddFlicker(Transform t, Renderer r, Color baseColor, float amount) => flickers.Add(new Flicker { t = t, r = r, baseScale = t.localScale, baseColor = baseColor, amount = amount, seed = Random.value * 100f });
        public void AddBob(Transform t, float height, float roll, float speed) => bobs.Add(new Bob { t = t, basePos = t.localPosition, baseRot = t.localRotation, height = height, roll = roll, speed = speed, phase = Random.value * 6f });
        public void AddDrift(Transform t, Vector3 velocity, float wrapRadius) => drifts.Add(new Drift { t = t, vel = velocity, wrap = wrapRadius });
        public void AddEmber(Vector3 localPos, Color color, float rate) => embers.Add(new Ember { pos = localPos, color = color, rate = rate, timer = Random.value / rate });
        public void AddPulse(Renderer r, Color baseColor, float speed, float min) => pulses.Add(new Pulse { r = r, baseColor = baseColor, speed = speed, min = min, phase = Random.value * 6f });
        public void AddFoam(Transform t, float speed, float phase, Renderer r, Color c) => foams.Add(new FoamRing { t = t, baseScale = t.localScale, speed = speed, phase = phase, r = r, color = c });

        /// <summary>Altura del suelo bajo un punto local (para pies y polvo).</summary>
        public Vector3 Ground(Vector3 local) => new Vector3(local.x, GroundY, local.z);

        public Vector3 World(Vector3 local) => transform.TransformPoint(local);

        // ------------------------------------------------------------------ Ciclo

        private void OnEnable()
        {
            ApplyFog();
        }

        public void ApplyFog()
        {
            Shader.SetGlobalColor("_C3DFogColor", FogColor);
            Shader.SetGlobalVector("_C3DFogParams", new Vector4(FogStart, FogEnd, FogMax, 0f));
        }

        private void Update()
        {
            float dt = Combat3DTime.Delta;
            float t = Combat3DTime.Now;
            if (block == null) block = new MaterialPropertyBlock();

            for (int i = 0; i < waters.Count; i++) waters[i].Animate(t);
            for (int i = 0; i < cloths.Count; i++) cloths[i].Animate(t);
            for (int i = 0; i < foams.Count; i++)
            {
                FoamRing f = foams[i];
                if (f.t == null) continue;
                float k = Mathf.Sin(t * f.speed + f.phase);
                f.t.localScale = new Vector3(f.baseScale.x * (1f + k * 0.03f), f.baseScale.y, f.baseScale.z * (1f + k * 0.03f));
                Color c = f.color; c.a *= 0.55f + 0.45f * (k * 0.5f + 0.5f);
                Combat3DAssets.SetColor(f.r, block, c);
            }

            for (int i = 0; i < sways.Count; i++)
            {
                Sway s = sways[i];
                if (s.t == null) continue;
                float a = Mathf.Sin(t * s.speed + s.phase) * s.amp;
                float b = Mathf.Sin(t * s.speed * 0.63f + s.phase * 1.7f) * s.amp * 0.6f;
                s.t.localRotation = s.baseRot * Quaternion.Euler(a, 0f, b);
            }

            for (int i = 0; i < bobs.Count; i++)
            {
                Bob b = bobs[i];
                if (b.t == null) continue;
                float k = t * b.speed + b.phase;
                b.t.localPosition = b.basePos + Vector3.up * Mathf.Sin(k) * b.height;
                b.t.localRotation = b.baseRot * Quaternion.Euler(Mathf.Sin(k * 0.8f) * b.roll, 0f, Mathf.Cos(k * 0.6f) * b.roll * 0.6f);
            }

            for (int i = 0; i < drifts.Count; i++)
            {
                Drift d = drifts[i];
                if (d.t == null) continue;
                Vector3 p = d.t.localPosition + d.vel * dt;
                Vector2 flat = new Vector2(p.x, p.z);
                if (flat.magnitude > d.wrap) { flat = -flat.normalized * (d.wrap - 1f); p.x = flat.x; p.z = flat.y; }
                d.t.localPosition = p;
            }

            for (int i = 0; i < flickers.Count; i++)
            {
                Flicker f = flickers[i];
                if (f.t == null) continue;
                float n = Mathf.PerlinNoise(t * 7f, f.seed) - 0.5f;
                float n2 = Mathf.PerlinNoise(f.seed, t * 11f) - 0.5f;
                f.t.localScale = new Vector3(f.baseScale.x * (1f + n2 * f.amount * 0.6f), f.baseScale.y * (1f + n * f.amount), f.baseScale.z);
                if (f.r != null)
                {
                    Color c = f.baseColor; c.a *= 0.85f + n * 0.3f;
                    Combat3DAssets.SetColor(f.r, block, c);
                }
            }

            for (int i = 0; i < pulses.Count; i++)
            {
                Pulse p = pulses[i];
                if (p.r == null) continue;
                float k = Mathf.Lerp(p.min, 1f, Mathf.Sin(t * p.speed + p.phase) * 0.5f + 0.5f);
                Color c = p.baseColor; c.a *= k;
                Combat3DAssets.SetColor(p.r, block, c);
            }

            if (Vfx != null && dt > 0f)
            {
                for (int i = 0; i < embers.Count; i++)
                {
                    Ember e = embers[i];
                    e.timer -= dt;
                    if (e.timer > 0f) continue;
                    e.timer += 1f / e.rate * Random.Range(0.6f, 1.4f);
                    Vfx.Ember(transform.TransformPoint(e.pos), e.color);
                }
            }
        }

        private void LateUpdate()
        {
            if (ViewCamera == null) return;
            Vector3 camPos = ViewCamera.transform.position;
            for (int i = 0; i < billboards.Count; i++)
            {
                Billboard b = billboards[i];
                if (b.t == null) continue;
                Vector3 dir = b.t.position - camPos;
                if (b.yawOnly) dir.y = 0f;
                if (dir.sqrMagnitude < 1e-6f) continue;
                b.t.rotation = Quaternion.LookRotation(dir.normalized, Vector3.up);
            }
        }

        private void OnDestroy()
        {
            for (int i = 0; i < owned.Count; i++)
                if (owned[i] != null) Destroy(owned[i]);
            owned.Clear();
        }

        // ------------------------------------------------------------------ Tipos animados

        private class Sway { public Transform t; public Quaternion baseRot; public float amp, speed, phase; }
        private class Billboard { public Transform t; public bool yawOnly; }
        private class Flicker { public Transform t; public Renderer r; public Vector3 baseScale; public Color baseColor; public float amount, seed; }
        private class Bob { public Transform t; public Vector3 basePos; public Quaternion baseRot; public float height, roll, speed, phase; }
        private class Drift { public Transform t; public Vector3 vel; public float wrap; }
        private class Ember { public Vector3 pos; public Color color; public float rate, timer; }
        private class Pulse { public Renderer r; public Color baseColor; public float speed, min, phase; }
        private class FoamRing { public Transform t; public Vector3 baseScale; public float speed, phase; public Renderer r; public Color color; }

        /// <summary>
        /// Mar radial animado: anillos de vértices desde 'innerRadius' (bajo la isla) hasta el horizonte,
        /// olas por suma de senos y color por distancia (turquesa en la orilla, azul profundo lejos) y cresta.
        /// </summary>
        public class WaterSurface
        {
            private readonly Mesh mesh;
            private readonly Vector3[] basePos;
            private readonly Vector3[] pos;
            private readonly Color[] baseCol;
            private readonly Color[] col;
            private readonly float amplitude;
            private readonly Material material;
            private readonly Vector2 scroll;

            public WaterSurface(Mesh mesh, Vector3[] basePositions, Color[] baseColors, float amplitude, Material material, Vector2 scroll)
            {
                this.mesh = mesh;
                basePos = basePositions;
                pos = (Vector3[])basePositions.Clone();
                baseCol = baseColors;
                col = (Color[])baseColors.Clone();
                this.amplitude = amplitude;
                this.material = material;
                this.scroll = scroll;
            }

            public void Animate(float t)
            {
                if (mesh == null) return;
                for (int i = 0; i < basePos.Length; i++)
                {
                    Vector3 p = basePos[i];
                    float fade = Mathf.Clamp01(new Vector2(p.x, p.z).magnitude / 25f) * 0.7f + 0.3f;
                    float h = Mathf.Sin(p.x * 0.21f + t * 1.3f) * 0.55f + Mathf.Sin(p.z * 0.17f - t * 1.05f + p.x * 0.05f) * 0.45f
                              + Mathf.Sin((p.x + p.z) * 0.43f + t * 2.1f) * 0.22f;
                    h *= amplitude * fade;
                    pos[i] = new Vector3(p.x, p.y + h, p.z);
                    float crest = Mathf.Clamp01(h / Mathf.Max(0.0001f, amplitude) * 0.9f);
                    Color c = baseCol[i];
                    col[i] = new Color(Mathf.Min(1f, c.r + crest * 0.16f), Mathf.Min(1f, c.g + crest * 0.18f), Mathf.Min(1f, c.b + crest * 0.14f), c.a);
                }
                mesh.vertices = pos;
                mesh.colors = col;
                if (material != null) material.mainTextureOffset = scroll * t;
            }
        }

        /// <summary>Tela fijada por el borde izquierdo (bandera) o por arriba (vela) que ondea con el viento.</summary>
        public class Cloth
        {
            private readonly Mesh mesh;
            private readonly Vector3[] basePos;
            private readonly Vector3[] pos;
            private readonly Color[] baseCol;
            private readonly Color[] col;
            private readonly float[] weight;   // 0 = clavado, 1 = libre
            private readonly Vector3 normal;
            private readonly float amplitude, frequency, speed;

            public Cloth(Mesh mesh, Vector3[] basePositions, Color[] baseColors, float[] weights, Vector3 normal, float amplitude, float frequency, float speed)
            {
                this.mesh = mesh;
                basePos = basePositions;
                pos = (Vector3[])basePositions.Clone();
                baseCol = baseColors;
                col = (Color[])baseColors.Clone();
                weight = weights;
                this.normal = normal;
                this.amplitude = amplitude;
                this.frequency = frequency;
                this.speed = speed;
            }

            public void Animate(float t)
            {
                if (mesh == null) return;
                for (int i = 0; i < basePos.Length; i++)
                {
                    float w = weight[i];
                    float phase = w * frequency - t * speed;
                    float d = (Mathf.Sin(phase) * 0.75f + Mathf.Sin(phase * 2.3f + 1.3f) * 0.25f) * amplitude * w;
                    pos[i] = basePos[i] + normal * d;
                    float shade = 0.84f + 0.16f * Mathf.Cos(phase);
                    Color c = baseCol[i];
                    col[i] = new Color(c.r * shade, c.g * shade, c.b * shade, c.a);
                }
                mesh.vertices = pos;
                mesh.colors = col;
            }
        }
    }
}
