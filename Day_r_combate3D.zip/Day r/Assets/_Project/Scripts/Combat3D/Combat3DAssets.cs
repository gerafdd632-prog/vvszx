﻿using System.Collections.Generic;
using UnityEngine;

namespace PirateSurvival.Combat3D
{
    /// <summary>
    /// Texturas y materiales del combate 3D, todo generado por código y cacheado (se crean una vez por sesión).
    /// Shaders propios en Resources/Shaders (Combat3DLit opaco con luz horneada, Combat3DFx transparente).
    /// Si faltaran, se usan shaders de URP/Unity que también existen en cualquier proyecto.
    /// </summary>
    public static class Combat3DAssets
    {
        private static Shader litShader, fxShader;
        private static bool litIsCustom, fxIsCustom;
        private static readonly Dictionary<string, Texture2D> Textures = new Dictionary<string, Texture2D>();
        private static readonly Dictionary<string, Material> SharedMaterials = new Dictionary<string, Material>();
        private static readonly Dictionary<Sprite, OutlinedSprite> Outlined = new Dictionary<Sprite, OutlinedSprite>();
        private static Mesh quadMesh, groundQuadMesh;

        public struct OutlinedSprite
        {
            public Texture2D texture;
            public Vector2 pivot01;   // pivote normalizado (pies)
            public float aspect;      // ancho / alto
        }

        // ================================================================ Shaders y materiales

        private static void EnsureShaders()
        {
            if (litShader == null)
            {
                litShader = Shader.Find("PirateSurvival/Combat3DLit");
                litIsCustom = litShader != null;
                if (litShader == null) litShader = Shader.Find("Universal Render Pipeline/Particles/Unlit");
                if (litShader == null) litShader = Shader.Find("Sprites/Default");
                if (!litIsCustom) Debug.LogWarning("[Combat3D] Falta el shader PirateSurvival/Combat3DLit (Resources/Shaders): se usa uno de respaldo.");
            }
            if (fxShader == null)
            {
                fxShader = Shader.Find("PirateSurvival/Combat3DFx");
                fxIsCustom = fxShader != null;
                if (fxShader == null) fxShader = Shader.Find("Sprites/Default");
            }
        }

        /// <summary>Material opaco nuevo (el que lo pide lo destruye si es por instancia).</summary>
        public static Material NewLit(Texture tex, Color tint, bool doubleSided = false, float cutoff = 0f)
        {
            EnsureShaders();
            Material m = new Material(litShader);
            m.mainTexture = tex != null ? tex : White;
            m.color = tint;
            if (litIsCustom)
            {
                m.SetFloat("_Cull", doubleSided ? 0f : 2f);
                m.SetFloat("_Cutoff", cutoff);
                if (cutoff > 0f) m.renderQueue = 2450; // AlphaTest
            }
            else if (cutoff > 0f && m.HasProperty("_Cutoff"))
            {
                m.SetFloat("_Cutoff", cutoff);
                m.EnableKeyword("_ALPHATEST_ON");
            }
            return m;
        }

        /// <summary>Material opaco compartido (no destruir).</summary>
        public static Material Lit(string texKey, bool doubleSided = false, float cutoff = 0f)
        {
            string key = "lit_" + texKey + (doubleSided ? "_2s" : "") + (cutoff > 0f ? "_cut" : "");
            if (SharedMaterials.TryGetValue(key, out Material m) && m != null) return m;
            m = NewLit(Tex(texKey), Color.white, doubleSided, cutoff);
            m.name = key;
            SharedMaterials[key] = m;
            return m;
        }

        /// <summary>Material transparente nuevo (aditivo para brillos y fuego).</summary>
        public static Material NewFx(Texture tex, bool additive)
        {
            EnsureShaders();
            Material m = new Material(fxShader);
            m.mainTexture = tex != null ? tex : White;
            m.color = Color.white;
            if (fxIsCustom)
            {
                m.SetFloat("_SrcBlend", (float)UnityEngine.Rendering.BlendMode.SrcAlpha);
                m.SetFloat("_DstBlend", additive ? (float)UnityEngine.Rendering.BlendMode.One : (float)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
            }
            m.renderQueue = additive ? 3100 : 3000;
            return m;
        }

        /// <summary>Material transparente compartido por textura y mezcla (no destruir).</summary>
        public static Material Fx(string texKey, bool additive)
        {
            string key = "fx_" + texKey + (additive ? "_add" : "_alpha");
            if (SharedMaterials.TryGetValue(key, out Material m) && m != null) return m;
            m = NewFx(Tex(texKey), additive);
            m.name = key;
            SharedMaterials[key] = m;
            return m;
        }

        /// <summary>Fija el color de un renderer sin crear materiales (MaterialPropertyBlock).</summary>
        public static void SetColor(Renderer r, MaterialPropertyBlock block, Color c)
        {
            r.GetPropertyBlock(block);
            block.SetColor("_Color", c);
            block.SetColor("_BaseColor", c);
            r.SetPropertyBlock(block);
        }

        // ================================================================ Mallas básicas

        /// <summary>Quad 1x1 centrado, mirando a -Z (para billboards).</summary>
        public static Mesh Quad
        {
            get
            {
                if (quadMesh != null) return quadMesh;
                quadMesh = new Mesh { name = "c3d_quad" };
                quadMesh.vertices = new[] { new Vector3(-0.5f, -0.5f, 0f), new Vector3(-0.5f, 0.5f, 0f), new Vector3(0.5f, 0.5f, 0f), new Vector3(0.5f, -0.5f, 0f) };
                quadMesh.uv = new[] { new Vector2(0f, 0f), new Vector2(0f, 1f), new Vector2(1f, 1f), new Vector2(1f, 0f) };
                quadMesh.colors = new[] { Color.white, Color.white, Color.white, Color.white };
                quadMesh.triangles = new[] { 0, 1, 2, 0, 2, 3 };
                quadMesh.RecalculateBounds();
                return quadMesh;
            }
        }

        /// <summary>Quad 1x1 tumbado en el suelo (plano XZ), visible desde arriba.</summary>
        public static Mesh GroundQuad
        {
            get
            {
                if (groundQuadMesh != null) return groundQuadMesh;
                groundQuadMesh = new Mesh { name = "c3d_groundquad" };
                groundQuadMesh.vertices = new[] { new Vector3(-0.5f, 0f, -0.5f), new Vector3(-0.5f, 0f, 0.5f), new Vector3(0.5f, 0f, 0.5f), new Vector3(0.5f, 0f, -0.5f) };
                groundQuadMesh.uv = new[] { new Vector2(0f, 0f), new Vector2(0f, 1f), new Vector2(1f, 1f), new Vector2(1f, 0f) };
                groundQuadMesh.colors = new[] { Color.white, Color.white, Color.white, Color.white };
                groundQuadMesh.triangles = new[] { 0, 1, 2, 0, 2, 3 };
                groundQuadMesh.RecalculateBounds();
                return groundQuadMesh;
            }
        }

        // ================================================================ Texturas

        public static Texture2D White => Tex("white");

        public static Texture2D Tex(string key)
        {
            if (Textures.TryGetValue(key, out Texture2D t) && t != null) return t;
            t = Build(key);
            t.name = "c3d_" + key;
            Textures[key] = t;
            return t;
        }

        private static Texture2D Build(string key)
        {
            switch (key)
            {
                case "softcircle": return Gen(64, 64, false, FilterMode.Bilinear, (u, v) =>
                {
                    float d = Mathf.Clamp01(Dist(u, v) * 2f);
                    float a = 1f - d; return new Color(1f, 1f, 1f, a * a);
                });
                case "ring": return Gen(128, 128, false, FilterMode.Bilinear, (u, v) =>
                {
                    float d = Dist(u, v) * 2f;
                    float band = Mathf.Clamp01(1f - Mathf.Abs(d - 0.86f) / 0.1f);
                    float inner = Mathf.Clamp01(1f - Mathf.Abs(d - 0.7f) / 0.04f) * 0.45f;
                    return new Color(1f, 1f, 1f, Mathf.Max(band * band, inner) * (d < 1f ? 1f : 0f));
                });
                case "spark": return Gen(64, 64, false, FilterMode.Bilinear, (u, v) =>
                {
                    float x = Mathf.Abs(u - 0.5f) * 2f, y = Mathf.Abs(v - 0.5f) * 2f;
                    float d = Mathf.Sqrt(x * x + y * y);
                    float cross = Mathf.Clamp01(1f - x * 7f) * Mathf.Clamp01(1f - y) + Mathf.Clamp01(1f - y * 7f) * Mathf.Clamp01(1f - x);
                    float core = Mathf.Clamp01(1f - d * 2.2f);
                    return new Color(1f, 1f, 1f, Mathf.Clamp01(cross * 0.9f + core * core * 1.2f));
                });
                case "streak": return Gen(64, 16, false, FilterMode.Bilinear, (u, v) =>
                {
                    float y = Mathf.Abs(v - 0.5f) * 2f;
                    float x = u; // cola a la izquierda, cabeza brillante a la derecha
                    return new Color(1f, 1f, 1f, Mathf.Clamp01(1f - y) * Mathf.Clamp01(x * 1.4f) * Mathf.Clamp01((1f - x) * 8f));
                });
                case "slash": return Gen(128, 128, false, FilterMode.Bilinear, (u, v) =>
                {
                    float x = (u - 0.5f) * 2f, y = (v - 0.5f) * 2f;
                    float r = Mathf.Sqrt(x * x + y * y);
                    float ang = Mathf.Atan2(y, x) * Mathf.Rad2Deg; // -180..180, arco a la derecha
                    if (Mathf.Abs(ang) > 105f) return Color.clear;
                    float along = 1f - Mathf.Abs(ang) / 105f;                 // 1 en el centro del arco
                    float thick = 0.18f * along + 0.02f;
                    float band = Mathf.Clamp01(1f - Mathf.Abs(r - 0.78f) / thick);
                    float edge = Mathf.Clamp01(1f - Mathf.Abs(r - (0.78f + thick * 0.6f)) / 0.04f);
                    float a = Mathf.Clamp01(band * band * along + edge * along);
                    return new Color(1f, 1f, 1f, a);
                });
                case "claw": return Gen(64, 64, false, FilterMode.Bilinear, (u, v) =>
                {
                    float a = 0f;
                    for (int i = -1; i <= 1; i++)
                    {
                        float lx = u - 0.5f - i * 0.22f + (v - 0.5f) * 0.35f;
                        float w = 0.05f * Mathf.Sin(v * Mathf.PI);
                        a = Mathf.Max(a, Mathf.Clamp01(1f - Mathf.Abs(lx) / Mathf.Max(0.005f, w)) * Mathf.Sin(v * Mathf.PI));
                    }
                    return new Color(1f, 1f, 1f, a);
                });
                case "smoke": return Gen(64, 64, false, FilterMode.Bilinear, (u, v) =>
                {
                    float d = Dist(u, v) * 2f;
                    float n = Fbm(u * 4f, v * 4f, 7, 4, 4);
                    float a = Mathf.Clamp01((1f - d) * 1.6f - (1f - n) * 0.7f);
                    return new Color(1f, 1f, 1f, a * a);
                });
                case "flame": return Gen(32, 64, false, FilterMode.Bilinear, (u, v) =>
                {
                    float x = (u - 0.5f) * 2f;
                    float width = Mathf.Sin(Mathf.Clamp01(v * 1.05f) * Mathf.PI) * (1f - v * 0.55f);
                    float a = Mathf.Clamp01(1f - Mathf.Abs(x) / Mathf.Max(0.01f, width));
                    a *= Mathf.Clamp01(v * 6f);
                    Color hot = Color.Lerp(new Color(1f, 0.98f, 0.75f), new Color(1f, 0.55f, 0.1f), Mathf.Clamp01(Mathf.Abs(x) * 1.4f + v * 0.6f));
                    hot.a = a * a;
                    return hot;
                });
                case "plus": return Gen(32, 32, true, FilterMode.Point, (u, v) =>
                {
                    float x = Mathf.Abs(u - 0.5f), y = Mathf.Abs(v - 0.5f);
                    bool on = (x < 0.12f && y < 0.38f) || (y < 0.12f && x < 0.38f);
                    return on ? Color.white : Color.clear;
                });
                case "bubble": return Gen(32, 32, false, FilterMode.Bilinear, (u, v) =>
                {
                    float d = Dist(u, v) * 2f;
                    float rim = Mathf.Clamp01(1f - Mathf.Abs(d - 0.8f) / 0.18f);
                    float hl = Mathf.Clamp01(1f - Dist(u - 0.15f, v - 0.15f) * 7f);
                    return new Color(1f, 1f, 1f, Mathf.Clamp01(rim * 0.9f + hl + 0.12f * (d < 0.9f ? 1f : 0f)));
                });
                case "star5": return Gen(32, 32, true, FilterMode.Point, (u, v) =>
                {
                    float x = u - 0.5f, y = v - 0.5f;
                    float ang = Mathf.Atan2(y, x);
                    float r = Mathf.Sqrt(x * x + y * y);
                    float lim = 0.22f + 0.22f * Mathf.Pow(Mathf.Abs(Mathf.Cos(ang * 2.5f)), 3f);
                    return r < lim ? Color.white : Color.clear;
                });
                case "sand": return Gen(128, 128, true, FilterMode.Point, (u, v) =>
                {
                    float n = Fbm(u * 6f, v * 6f, 1, 6, 6);
                    Color c = Color.Lerp(new Color(0.86f, 0.74f, 0.53f), new Color(0.98f, 0.9f, 0.7f), n);
                    float g = Hash((int)(u * 128), (int)(v * 128), 3);
                    if (g > 0.93f) c *= 0.88f; else if (g < 0.04f) c = Color.Lerp(c, Color.white, 0.4f);
                    float ripple = Mathf.Sin((u * 3f + Fbm(u * 2f, v * 2f, 2, 2, 2) * 1.5f + v * 0.6f) * Mathf.PI * 6f);
                    c *= 1f + ripple * 0.03f;
                    c.a = 1f; return c;
                });
                case "grass": return Gen(128, 128, true, FilterMode.Point, (u, v) =>
                {
                    float n = Fbm(u * 5f, v * 5f, 4, 5, 5);
                    Color c = Color.Lerp(new Color(0.27f, 0.5f, 0.2f), new Color(0.45f, 0.7f, 0.28f), n);
                    float g = Hash((int)(u * 128), (int)(v * 128), 5);
                    if (g > 0.9f) c = Color.Lerp(c, new Color(0.62f, 0.82f, 0.36f), 0.6f);
                    else if (g < 0.08f) c *= 0.82f;
                    c.a = 1f; return c;
                });
                case "dirt": return Gen(128, 128, true, FilterMode.Point, (u, v) =>
                {
                    float n = Fbm(u * 6f, v * 6f, 6, 6, 6);
                    Color c = Color.Lerp(new Color(0.42f, 0.3f, 0.2f), new Color(0.62f, 0.46f, 0.3f), n);
                    if (Hash((int)(u * 128), (int)(v * 128), 7) > 0.94f) c = Color.Lerp(c, new Color(0.7f, 0.68f, 0.64f), 0.7f);
                    c.a = 1f; return c;
                });
                case "rock": return Gen(128, 128, true, FilterMode.Point, (u, v) =>
                {
                    float n = Fbm(u * 5f, v * 5f, 8, 5, 5);
                    float cr = Mathf.Abs(Fbm(u * 3f + 9f, v * 3f, 9, 3, 3) - 0.5f);
                    Color c = Color.Lerp(new Color(0.42f, 0.42f, 0.46f), new Color(0.66f, 0.65f, 0.68f), n);
                    if (cr < 0.025f) c *= 0.62f;
                    c.a = 1f; return c;
                });
                case "caverock": return Gen(128, 128, true, FilterMode.Point, (u, v) =>
                {
                    float n = Fbm(u * 5f, v * 5f, 10, 5, 5);
                    float cr = Mathf.Abs(Fbm(u * 3f, v * 3f + 4f, 11, 3, 3) - 0.5f);
                    Color c = Color.Lerp(new Color(0.26f, 0.22f, 0.24f), new Color(0.46f, 0.4f, 0.4f), n);
                    if (cr < 0.03f) c *= 0.55f;
                    c.a = 1f; return c;
                });
                case "planks": return Gen(128, 128, true, FilterMode.Point, (u, v) =>
                {
                    int plank = Mathf.FloorToInt(v * 6f);
                    float pv = v * 6f - plank;
                    float off = Hash(plank, 0, 12) * 0.7f;
                    float grain = Fbm((u + off) * 10f, v * 60f, 13, 10, 60);
                    Color c = Color.Lerp(new Color(0.42f, 0.27f, 0.15f), new Color(0.62f, 0.42f, 0.24f), grain * 0.8f + Hash(plank, 1, 14) * 0.25f);
                    if (pv < 0.07f || pv > 0.95f) c *= 0.45f;                               // junta entre tablones
                    float end = Mathf.Repeat(u + off, 1f);
                    if (end < 0.012f) c *= 0.5f;                                             // testa
                    if ((Mathf.Abs(end - 0.04f) < 0.012f || Mathf.Abs(end - 0.96f) < 0.012f) && Mathf.Abs(pv - 0.5f) < 0.12f) c = new Color(0.2f, 0.18f, 0.16f); // clavos
                    c.a = 1f; return c;
                });
                case "bark": return Gen(32, 64, true, FilterMode.Point, (u, v) =>
                {
                    float ring = Mathf.Repeat(v * 8f + Fbm(u * 3f, v * 3f, 15, 3, 3) * 0.4f, 1f);
                    Color c = Color.Lerp(new Color(0.42f, 0.3f, 0.18f), new Color(0.6f, 0.45f, 0.28f), Fbm(u * 6f, v * 2f, 16, 6, 2));
                    if (ring < 0.14f) c *= 0.68f;
                    c.a = 1f; return c;
                });
                case "wood": return Gen(64, 64, true, FilterMode.Point, (u, v) =>
                {
                    float grain = Fbm(u * 3f, v * 24f, 17, 3, 24);
                    Color c = Color.Lerp(new Color(0.45f, 0.29f, 0.16f), new Color(0.64f, 0.44f, 0.26f), grain);
                    c.a = 1f; return c;
                });
                case "water": return Gen(128, 128, true, FilterMode.Bilinear, (u, v) =>
                {
                    float n1 = Fbm(u * 4f, v * 4f, 18, 4, 4);
                    float n2 = Fbm(u * 4f + 3.1f, v * 4f + 1.7f, 19, 4, 4);
                    float caustic = Mathf.Clamp01(1f - Mathf.Abs(n1 - n2) * 9f);
                    float c = 0.82f + caustic * 0.35f;
                    return new Color(c, c, c, 1f);
                });
                case "canvas": return Gen(64, 64, true, FilterMode.Point, (u, v) =>
                {
                    float n = Fbm(u * 8f, v * 8f, 20, 8, 8);
                    Color c = Color.Lerp(new Color(0.86f, 0.8f, 0.66f), new Color(0.97f, 0.93f, 0.82f), n);
                    if (Mathf.Repeat(v * 4f, 1f) < 0.04f) c *= 0.8f; // costuras
                    c.a = 1f; return c;
                });
                case "flag": return Gen(64, 40, true, FilterMode.Point, (u, v) =>
                {
                    Color c = new Color(0.08f, 0.07f, 0.09f);
                    // Dos sables cruzados y una calavera simple (bandera pirata genérica)
                    float x = u - 0.5f, y = (v - 0.5f) * 0.625f;
                    bool blade1 = Mathf.Abs(x * 0.62f - y) < 0.022f && Mathf.Abs(x) < 0.3f;
                    bool blade2 = Mathf.Abs(x * 0.62f + y) < 0.022f && Mathf.Abs(x) < 0.3f;
                    bool head = (x * x) / 0.012f + ((y - 0.06f) * (y - 0.06f)) / 0.006f < 1f;
                    bool eye = ((x - 0.045f) * (x - 0.045f) + (y - 0.065f) * (y - 0.065f) < 0.0005f) || ((x + 0.045f) * (x + 0.045f) + (y - 0.065f) * (y - 0.065f) < 0.0005f);
                    if (blade1 || blade2 || head) c = new Color(0.95f, 0.93f, 0.86f);
                    if (eye) c = new Color(0.08f, 0.07f, 0.09f);
                    c.a = 1f; return c;
                });
                case "frond": return Gen(32, 128, true, FilterMode.Point, (u, v) =>
                {
                    // Hoja de palmera: nervio central y foliolos a los lados, la punta se estrecha
                    float x = Mathf.Abs(u - 0.5f) * 2f;
                    float width = Mathf.Sin(Mathf.Clamp01(v) * Mathf.PI * 0.9f + 0.15f) * (1f - v * 0.5f);
                    bool leaflet = Mathf.Repeat(v * 22f - x * 2.2f, 1f) < 0.72f;
                    bool inside = x < width && (leaflet || x < 0.12f);
                    if (!inside) return Color.clear;
                    Color c = Color.Lerp(new Color(0.2f, 0.52f, 0.18f), new Color(0.42f, 0.74f, 0.26f), Mathf.Clamp01(1f - x * 0.8f + v * 0.2f));
                    if (x < 0.07f) c = new Color(0.55f, 0.66f, 0.3f);
                    return c;
                });
                case "fern": return Gen(32, 64, true, FilterMode.Point, (u, v) =>
                {
                    float x = Mathf.Abs(u - 0.5f) * 2f;
                    float width = (1f - v) * 0.95f;
                    bool leaflet = Mathf.Repeat(v * 14f - x * 1.6f, 1f) < 0.7f;
                    if (!(x < width && (leaflet || x < 0.1f))) return Color.clear;
                    return Color.Lerp(new Color(0.18f, 0.45f, 0.16f), new Color(0.38f, 0.66f, 0.24f), 1f - x);
                });
                case "cloud": return Gen(128, 64, false, FilterMode.Bilinear, (u, v) =>
                {
                    float a = 0f;
                    a = Mathf.Max(a, Blob(u, v, 0.32f, 0.42f, 0.22f, 0.3f));
                    a = Mathf.Max(a, Blob(u, v, 0.55f, 0.52f, 0.26f, 0.4f));
                    a = Mathf.Max(a, Blob(u, v, 0.75f, 0.4f, 0.2f, 0.28f));
                    a *= 0.75f + Fbm(u * 6f, v * 3f, 21, 6, 3) * 0.4f;
                    float shade = Mathf.Lerp(0.82f, 1f, Mathf.Clamp01(v * 1.6f));
                    return new Color(shade, shade, Mathf.Min(1f, shade + 0.04f), Mathf.Clamp01(a));
                });
                case "crystal": return Gen(16, 32, true, FilterMode.Point, (u, v) =>
                {
                    float c = 0.75f + 0.25f * Mathf.Clamp01(1f - Mathf.Abs(u - 0.35f) * 4f);
                    return new Color(c, c, c, 1f);
                });
                default: return Gen(4, 4, false, FilterMode.Point, (u, v) => Color.white);
            }
        }

        /// <summary>Degradado vertical para el cielo (u ignorado, v = altura en la cúpula).</summary>
        public static Texture2D SkyGradient(string key, Color horizon, Color mid, Color zenith)
        {
            string k = "sky_" + key;
            if (Textures.TryGetValue(k, out Texture2D t) && t != null) return t;
            t = Gen(4, 256, false, FilterMode.Bilinear, (u, v) =>
            {
                Color c = v < 0.35f ? Color.Lerp(horizon, mid, v / 0.35f) : Color.Lerp(mid, zenith, (v - 0.35f) / 0.65f);
                c.a = 1f; return c;
            });
            t.wrapMode = TextureWrapMode.Clamp;
            t.name = "c3d_" + k;
            Textures[k] = t;
            return t;
        }

        // ================================================================ Sprite con contorno

        /// <summary>
        /// Copia el sprite (aunque su textura no sea legible) añadiendo un contorno oscuro de 1 px.
        /// Así los personajes de pixel art se leen bien sobre cualquier fondo 3D.
        /// </summary>
        public static OutlinedSprite Outline(Sprite s)
        {
            if (s == null)
            {
                return new OutlinedSprite { texture = White, pivot01 = new Vector2(0.5f, 0f), aspect = 1f };
            }
            if (Outlined.TryGetValue(s, out OutlinedSprite cached) && cached.texture != null) return cached;

            Rect r;
            try { r = s.packed ? s.textureRect : s.rect; }
            catch (System.Exception) { r = s.rect; } // sprite empaquetado en modo "Tight"
            int w = Mathf.Max(1, Mathf.RoundToInt(r.width)), h = Mathf.Max(1, Mathf.RoundToInt(r.height));
            Color32[] src = ReadSpritePixels(s, Mathf.RoundToInt(r.x), Mathf.RoundToInt(r.y), w, h);

            const int pad = 2;
            int W = w + pad * 2, H = h + pad * 2;
            Color32[] dst = new Color32[W * H];
            Color32 outline = new Color32(24, 16, 20, 255);
            for (int y = 0; y < H; y++)
            {
                for (int x = 0; x < W; x++)
                {
                    int sx = x - pad, sy = y - pad;
                    Color32 c = Sample(src, w, h, sx, sy);
                    if (c.a > 127) { c.a = 255; dst[y * W + x] = c; continue; }
                    bool near = false;
                    for (int oy = -1; oy <= 1 && !near; oy++)
                        for (int ox = -1; ox <= 1 && !near; ox++)
                            if ((ox != 0 || oy != 0) && Sample(src, w, h, sx + ox, sy + oy).a > 127) near = true;
                    dst[y * W + x] = near ? outline : new Color32(0, 0, 0, 0);
                }
            }

            Texture2D tex = new Texture2D(W, H, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Point;
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.SetPixels32(dst);
            tex.Apply(false, false);
            tex.name = "c3d_outlined_" + s.name;

            Vector2 pivotPx = s.pivot; // relativo al rect del sprite
            OutlinedSprite result = new OutlinedSprite
            {
                texture = tex,
                pivot01 = new Vector2((pivotPx.x + pad) / W, (pivotPx.y + pad) / H),
                aspect = (float)W / H
            };
            Outlined[s] = result;
            return result;
        }

        private static Color32 Sample(Color32[] px, int w, int h, int x, int y)
        {
            if (x < 0 || y < 0 || x >= w || y >= h) return new Color32(0, 0, 0, 0);
            return px[y * w + x];
        }

        private static Color32[] ReadSpritePixels(Sprite s, int x, int y, int w, int h)
        {
            Texture2D tex = s.texture;
            if (tex != null && tex.isReadable)
            {
                try
                {
                    Color[] c = tex.GetPixels(x, y, w, h);
                    Color32[] r = new Color32[c.Length];
                    for (int i = 0; i < c.Length; i++) r[i] = c[i];
                    return r;
                }
                catch (System.Exception) { /* se intenta por GPU */ }
            }

            // Textura no legible (PNG importado): copia por GPU a una textura temporal y se lee de vuelta
            Color32[] result = new Color32[w * h];
            if (tex == null) return result;
            RenderTexture rt = RenderTexture.GetTemporary(tex.width, tex.height, 0, RenderTextureFormat.ARGB32, RenderTextureReadWrite.Default);
            RenderTexture prev = RenderTexture.active;
            try
            {
                Graphics.Blit(tex, rt);
                RenderTexture.active = rt;
                Texture2D tmp = new Texture2D(w, h, TextureFormat.RGBA32, false);
                tmp.ReadPixels(new Rect(x, y, w, h), 0, 0, false);
                tmp.Apply(false, false);
                result = tmp.GetPixels32();
                Object.Destroy(tmp);
            }
            catch (System.Exception e)
            {
                Debug.LogWarning("[Combat3D] No se pudo leer el sprite '" + s.name + "': " + e.Message);
            }
            finally
            {
                RenderTexture.active = prev;
                RenderTexture.ReleaseTemporary(rt);
            }
            return result;
        }

        // ================================================================ Utilidades de generación

        private delegate Color PixelFn(float u, float v);

        private static Texture2D Gen(int w, int h, bool repeat, FilterMode filter, PixelFn fn)
        {
            Texture2D t = new Texture2D(w, h, TextureFormat.RGBA32, repeat);
            t.filterMode = filter;
            t.wrapMode = repeat ? TextureWrapMode.Repeat : TextureWrapMode.Clamp;
            Color[] px = new Color[w * h];
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++)
                    px[y * w + x] = fn((x + 0.5f) / w, (y + 0.5f) / h);
            t.SetPixels(px);
            t.Apply(repeat, false);
            return t;
        }

        private static float Dist(float u, float v) => Mathf.Sqrt((u - 0.5f) * (u - 0.5f) + (v - 0.5f) * (v - 0.5f));

        private static float Blob(float u, float v, float cx, float cy, float rx, float ry)
        {
            float dx = (u - cx) / rx, dy = (v - cy) / ry;
            return Mathf.Clamp01(1f - Mathf.Sqrt(dx * dx + dy * dy)) * 1.6f;
        }

        public static float Hash(int x, int y, int seed)
        {
            unchecked
            {
                uint h = (uint)(x * 374761393 + y * 668265263 + seed * 982451653);
                h = (h ^ (h >> 13)) * 1274126177u;
                h ^= h >> 16;
                return (h & 0xFFFFFF) / 16777216f;
            }
        }

        /// <summary>Ruido de valor suave. Con px/py &gt; 0 es periódico (para texturas que se repiten sin costuras).</summary>
        public static float Noise(float x, float y, int seed, int px = 0, int py = 0)
        {
            int xi = Mathf.FloorToInt(x), yi = Mathf.FloorToInt(y);
            float xf = x - xi, yf = y - yi;
            float u = xf * xf * (3f - 2f * xf), v = yf * yf * (3f - 2f * yf);
            int x0 = Wrap(xi, px), x1 = Wrap(xi + 1, px), y0 = Wrap(yi, py), y1 = Wrap(yi + 1, py);
            float a = Hash(x0, y0, seed), b = Hash(x1, y0, seed), c = Hash(x0, y1, seed), d = Hash(x1, y1, seed);
            return Mathf.Lerp(Mathf.Lerp(a, b, u), Mathf.Lerp(c, d, u), v);
        }

        /// <summary>Ruido fractal en [0,1]. x = u * px (frecuencia entera = periodo de la primera octava).</summary>
        private static float Fbm(float x, float y, int seed, int px, int py)
        {
            float sum = 0f, amp = 0.5f, norm = 0f;
            for (int o = 0; o < 3; o++)
            {
                int m = 1 << o;
                sum += Noise(x * m, y * m, seed + o * 31, px * m, py * m) * amp;
                norm += amp;
                amp *= 0.5f;
            }
            return sum / norm;
        }

        private static int Wrap(int a, int m) => m > 0 ? Mod(a, m) : a;

        private static int Mod(int a, int m) => ((a % m) + m) % m;
    }
}
