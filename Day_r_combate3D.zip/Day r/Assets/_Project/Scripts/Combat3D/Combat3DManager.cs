﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PirateSurvival.Core;
using PirateSurvival.Combat;
using PirateSurvival.Player;
using PirateSurvival.Inventory;

namespace PirateSurvival.Combat3D
{
    /// <summary>Cómo ataca un rival en la arena 3D (animación y efecto).</summary>
    public enum EnemyStyle { Melee, Slash, Ranged, Fire, Charge, Swoop, Leap, Scuttle }

    public enum Combat3DOutcome { Won, Lost, Fled }

    /// <summary>Rival del combate 3D (sale de un BattleUnit de EnemyLibrary o de una criatura del mapa).</summary>
    public class Combat3DFighter
    {
        public string name = "Rival";
        public int maxHp = 30, hp = 30;
        public int defense;
        public float damageReduction;
        public int damage = 6;
        public float accuracy = 0.85f, crit = 0.08f, evasion;
        public CombatDamageType damageType = CombatDamageType.Blunt;
        public EnemyStyle style = EnemyStyle.Melee;
        public string attackName = "un golpe";
        public bool appliesStatus;
        public StatusType status;
        public float statusChance;
        public int statusTurns = 2;
        public int xp, bounty, playerBountyOnDefeat;
        public Sprite sprite;
        public float height = 2f;
        public bool flies, boss, logia, rubber, animal;

        public static Combat3DFighter FromUnit(BattleUnit u)
        {
            BattleWeapon w = u.weapon ?? BattleWeapon.Fists();
            Combat3DFighter f = new Combat3DFighter
            {
                name = u.name,
                maxHp = Mathf.Max(1, u.maxHp),
                hp = Mathf.Max(1, u.maxHp),
                defense = u.defense,
                damageReduction = u.damageReduction,
                damage = Mathf.Max(1, w.damage + u.attackBonus),
                accuracy = Mathf.Clamp(w.accuracy, 0.4f, 0.98f),
                crit = w.critChance,
                damageType = w.damageType,
                attackName = string.IsNullOrEmpty(w.name) ? "un golpe" : w.name,
                xp = u.xpReward,
                bounty = u.bounty,
                playerBountyOnDefeat = u.playerBountyOnDefeat,
                sprite = u.sprite,
                logia = u.isLogia,
                rubber = u.rubber
            };
            if (w.hasStatus)
            {
                f.appliesStatus = true;
                f.status = w.status;
                f.statusChance = w.statusChance;
                f.statusTurns = Mathf.Max(1, w.statusTurns);
            }
            string n = (u.name ?? "").ToLowerInvariant();
            if (n.Contains("araña")) { f.style = EnemyStyle.Leap; f.height = 1.3f; f.animal = true; }
            else if (n.Contains("murciélago")) { f.style = EnemyStyle.Swoop; f.height = 1.2f; f.flies = true; f.evasion = 0.08f; f.animal = true; }
            else if (w.damageType == CombatDamageType.Fire) f.style = EnemyStyle.Fire;
            else if (w.maxRange > 1) f.style = EnemyStyle.Ranged;
            else if (w.damageType == CombatDamageType.Slash) f.style = EnemyStyle.Slash;
            else f.style = EnemyStyle.Melee;
            f.boss = n.Contains("capitán") || n.Contains("capitan");
            if (f.boss) f.height = 2.4f;
            return f;
        }
    }

    /// <summary>Todo lo que necesita un combate 3D: rivales (se enfrentan uno tras otro), escenario, reglas y avisos.</summary>
    public class Combat3DSetup
    {
        public readonly List<Combat3DFighter> enemies = new List<Combat3DFighter>();
        public ArenaTheme theme = ArenaTheme.Beach;
        public bool canFlee = true;
        public string introText;
        /// <summary>Posición del enfrentamiento en el mapa 2D (para apartar al jugador si huye).</summary>
        public Vector2 worldSource;
        /// <summary>Si es false, la experiencia la da quien abre el combate (las criaturas al morir).</summary>
        public bool grantXp = true;
        /// <summary>Se llama al ganar, antes de la pantalla de resultado: entrega el botín y devuelve las líneas a mostrar.</summary>
        public Func<List<string>> onVictoryRewards;
        public Action<Combat3DOutcome> onFinished;
    }

    /// <summary>
    /// Director del combate 3D por turnos (estilo JRPG / One Piece):
    ///  - Construye la arena lejos del mapa 2D, apaga la cámara y el HUD del mapa y los restaura al final.
    ///  - Rivales en cadena (el siguiente entra al caer el anterior), con estilos de ataque distintos.
    ///  - Técnicas físicas variadas (golpe rápido, tajo, mazazo, disparo con munición, patada giratoria, cabezazo,
    ///    embestida, guardia con contraataque), técnicas de Fruta (puño catapulta, lluvia de puños, martillo, Haki)
    ///    y mochila (curas reales del inventario). Estados: sangrado, veneno, quemadura y aturdimiento.
    ///  - El rival puede cargar un golpe brutal (avisa un turno antes), ponerse en guardia o, si es jefe, curarse.
    ///  - Al terminar sincroniza vida y energía con el jugador del mapa, da experiencia y avisa a quien lo abrió.
    /// El tiempo del combate se congela con la pausa (Combat3DTime) y no toca Time.timeScale.
    /// </summary>
    public class Combat3DManager : MonoBehaviour
    {
        public static Combat3DManager Instance { get; private set; }

        public bool IsInCombat3D { get; private set; }
        public bool CanStartBattle => !IsInCombat3D && GameState.IsPlaying && !GameState.InBattle && Time.unscaledTime >= cooldownUntil;

        private static readonly Vector3 ArenaOrigin = new Vector3(-4000f, 0f, 0f);
        private const float CooldownSeconds = 2.5f;

        // Escena
        private Combat3DSetup setup;
        private Combat3DArena arena;
        private Combat3DCamera cam;
        private Combat3DVFX vfx;
        private Combat3DUI ui;
        private Combat3DCharacter hero, foe;
        private int enemyIndex;
        private Combat3DFighter E => setup.enemies[enemyIndex];

        // Jugador
        private PlayerStats stats;
        private PlayerProgress progress;
        private DevilFruitManager fruit;
        private Sprite heroSprite;
        private string heroName;
        private float hp, maxHp, st, maxSt;
        private int xpBonus;

        // Estado del combate
        private readonly Dictionary<StatusType, int> heroStatus = new Dictionary<StatusType, int>();
        private readonly Dictionary<StatusType, int> foeStatus = new Dictionary<StatusType, int>();
        private bool guarding, heroStunned, foeStunned, foeCharging, foeGuarding, foeHealed;
        private int hakiTurns, turn, xpEarned, bountyEarned;
        private Combat3DOutcome outcome;
        private bool decided, finishing, continuePressed;

        // Entrada
        private bool awaitingInput;
        private Func<IEnumerator> pending;
        private List<MoveOption> currentMoves = new List<MoveOption>();

        // Mundo 2D oculto durante el combate
        private Camera worldCam;
        private readonly List<Canvas> hiddenCanvases = new List<Canvas>();
        private Coroutine loop;
        private float cooldownUntil;

        private class MoveOption
        {
            public Combat3DMenuEntry entry;
            public float cost;
            public string blocked;
            public Func<IEnumerator> run;
        }

        private static readonly Color Gold = new Color(1f, 0.84f, 0.3f);
        private static readonly Color DmgColor = new Color(1f, 0.35f, 0.25f);
        private static readonly Color HitOrange = new Color(1f, 0.65f, 0.2f);

        // ================================================================ Ciclo de vida

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
        }

        private void Update()
        {
            Combat3DTime.Tick();
            // Si se carga otra partida o se vuelve al menú en mitad del combate, se desmonta sin aplicar nada
            if (IsInCombat3D && !finishing && GameState.Current != GameScreen.Battle && GameState.Current != GameScreen.Paused)
            {
                Debug.LogWarning("[Combat3D] El estado del juego cambió durante el combate: se cierra la arena sin aplicar resultados.");
                Abort();
            }
        }

        /// <summary>Compatibilidad: un rival suelto con vida y recompensa dadas.</summary>
        public void StartBattle3D(string enemyName, int enemyHp, int enemyBounty, Sprite enemySprite, Action<bool> onComplete)
        {
            Combat3DSetup s = new Combat3DSetup();
            s.enemies.Add(new Combat3DFighter { name = enemyName, maxHp = Mathf.Max(1, enemyHp), hp = Mathf.Max(1, enemyHp), bounty = enemyBounty, sprite = enemySprite, damage = 8 });
            s.onFinished = o => onComplete?.Invoke(o == Combat3DOutcome.Won);
            StartBattle3D(s);
        }

        /// <summary>Abre un combate. Devuelve false si ahora no se puede (otro combate, menú, jugador desmayado...).</summary>
        public bool StartBattle3D(Combat3DSetup s)
        {
            if (s == null || s.enemies.Count == 0 || !CanStartBattle) return false;
            stats = FindAnyObjectByType<PlayerStats>();
            if (stats == null || stats.IsDead || stats.IsFainted) return false;

            setup = s;
            progress = stats.GetComponent<PlayerProgress>();
            fruit = stats.GetComponent<DevilFruitManager>();
            hp = stats.CurrentHealth; maxHp = stats.MaxHealth;
            st = stats.CurrentStamina; maxSt = stats.MaxStamina;
            xpBonus = progress != null ? Mathf.Min(8, progress.Experience / 60) : 0;
            heroName = string.IsNullOrEmpty(CharacterArt.PlayerName) ? "Náufrago" : CharacterArt.PlayerName;
            Transform visual = stats.transform.Find("Visual");
            SpriteRenderer vsr = visual != null ? visual.GetComponent<SpriteRenderer>() : null;
            heroSprite = vsr != null && vsr.sprite != null ? vsr.sprite : CharacterArt.GetPlayerSprite();

            enemyIndex = 0;
            heroStatus.Clear(); foeStatus.Clear();
            guarding = heroStunned = foeStunned = foeCharging = foeGuarding = foeHealed = false;
            hakiTurns = 0; turn = 0; xpEarned = 0; bountyEarned = 0;
            decided = finishing = continuePressed = false;
            awaitingInput = false; pending = null;

            IsInCombat3D = true;
            GameState.InBattle = true;
            GameState.Set(GameScreen.Battle);
            Combat3DTime.Reset();
            loop = StartCoroutine(Run());
            return true;
        }

        // ================================================================ Montaje y desmontaje

        private void BuildScene()
        {
            // Ocultar el mundo 2D: su cámara y los lienzos del HUD (los menús, por encima, siguen funcionando)
            worldCam = Camera.main;
            if (worldCam != null) worldCam.enabled = false;
            hiddenCanvases.Clear();
            foreach (Canvas c in FindObjectsByType<Canvas>(FindObjectsSortMode.None))
            {
                if (c == null || !c.isRootCanvas || !c.enabled || c.renderMode == RenderMode.WorldSpace || c.sortingOrder >= 50) continue;
                c.enabled = false;
                hiddenCanvases.Add(c);
            }

            arena = Combat3DArenaBuilder.Build(setup.theme, ArenaOrigin);

            GameObject camObj = new GameObject("Combat3D_Camera");
            camObj.transform.SetParent(arena.transform, false);
            cam = camObj.AddComponent<Combat3DCamera>();
            cam.Cam.backgroundColor = arena.ClearColor;

            GameObject vfxObj = new GameObject("Combat3D_VFX");
            vfxObj.transform.SetParent(arena.transform, false);
            vfx = vfxObj.AddComponent<Combat3DVFX>();
            vfx.Cam = cam.Cam;
            arena.ViewCamera = cam.Cam;
            arena.Vfx = vfx;

            hero = SpawnFighter("Hero", Combat3DArena.PlayerSpot, heroName, heroSprite, 2.0f, true, false);
            foe = SpawnFighter("Foe", Combat3DArena.EnemySpot, E.name, E.sprite, E.height, false, E.flies);
            cam.SetFighters(hero, foe);
            cam.SetEntryPoint(arena.World(Combat3DArena.EnemyEntrySpot));

            GameObject uiObj = new GameObject("Combat3D_UI");
            ui = uiObj.AddComponent<Combat3DUI>();
            ui.Build();
            ui.WorldCamera = cam.Cam;
            ui.OnCommand = HandleCommand;
            ui.OnMove = HandleMove;
            ui.OnBack = HandleBack;
            ui.OnContinue = () => continuePressed = true;
        }

        private Combat3DCharacter SpawnFighter(string objName, Vector3 localSpot, string displayName, Sprite sprite, float height, bool isPlayer, bool flies)
        {
            GameObject go = new GameObject(objName);
            go.transform.SetParent(arena.transform, false);
            go.transform.localPosition = new Vector3(localSpot.x, arena.GroundY, localSpot.z);
            Combat3DCharacter c = go.AddComponent<Combat3DCharacter>();
            c.Setup(displayName, sprite, height, isPlayer, flies, vfx, cam.Cam);
            return c;
        }

        private void Cleanup()
        {
            // Para todas las animaciones en curso (si se llama desde Finish, el resto de Finish no tiene más esperas)
            StopAllCoroutines();
            loop = null;
            if (arena != null) Destroy(arena.gameObject);
            if (ui != null) Destroy(ui.gameObject);
            arena = null; ui = null; cam = null; vfx = null; hero = null; foe = null;
            if (worldCam != null) worldCam.enabled = true;
            worldCam = null;
            foreach (Canvas c in hiddenCanvases) if (c != null) c.enabled = true;
            hiddenCanvases.Clear();
            GameState.InBattle = false;
            IsInCombat3D = false;
            awaitingInput = false;
            pending = null;
        }

        /// <summary>Desmonta el combate sin aplicar resultados (cargar partida, volver al menú).</summary>
        public void Abort()
        {
            finishing = true;
            Cleanup();
            cooldownUntil = Time.unscaledTime + CooldownSeconds;
            finishing = false;
        }

        // ================================================================ Bucle principal

        private IEnumerator Run()
        {
            BuildScene();
            RefreshHud();
            ui.SnapBars();
            cam.Shot(CameraShot.Intro, true);
            StartCoroutine(ui.FadeTo(0f, 0.6f));
            ui.Versus(heroName, E.name);
            ui.SetDialogue(!string.IsNullOrEmpty(setup.introText) ? setup.introText : $"¡{E.name} te corta el paso!", "Combate");
            Sfx(a => a.PlayTurnStart());
            if (E.flies || E.animal) vfx.Dust(foe.Feet, 8, 0.6f, arena.DustColor);
            yield return Combat3DTime.Wait(2.7f);

            while (!decided)
            {
                yield return PlayerTurn();
                if (decided) break;
                if (E.hp <= 0) { yield return FoeDefeated(); continue; }

                yield return EnemyTurn();
                if (decided) break;
                if (hp <= 0f) { outcome = Combat3DOutcome.Lost; decided = true; break; }
                if (E.hp <= 0) yield return FoeDefeated();
            }

            switch (outcome)
            {
                case Combat3DOutcome.Won: yield return VictorySequence(); break;
                case Combat3DOutcome.Lost: yield return DefeatSequence(); break;
                default: break; // la huida ya se animó
            }
            yield return Finish();
        }

        private IEnumerator Finish()
        {
            finishing = true;
            yield return ui.FadeTo(1f, 0.4f);
            Combat3DOutcome result = outcome;
            float finalHp = Mathf.Max(0f, hp), finalSt = Mathf.Clamp(st, 0f, maxSt);
            Combat3DSetup s = setup;
            Cleanup();
            GameState.Set(GameScreen.Playing);
            finishing = false;
            cooldownUntil = Time.unscaledTime + CooldownSeconds;

            if (stats != null)
            {
                if (result == Combat3DOutcome.Lost)
                {
                    stats.TakeDamage(stats.CurrentHealth + 1f, DeathCause.Combat);
                }
                else
                {
                    float diff = finalHp - stats.CurrentHealth;
                    if (diff > 0.01f) stats.Heal(diff);
                    else if (diff < -0.01f) stats.TakeDamage(-diff, DeathCause.Combat);
                    stats.ModifyStamina(finalSt - stats.CurrentStamina);
                }
            }

            if (result == Combat3DOutcome.Won)
            {
                if (s.grantXp && progress != null)
                {
                    progress.AddExperience(xpEarned);
                    if (bountyEarned > 0) progress.AddPlayerBounty(bountyEarned);
                }
                if (s.grantXp && xpEarned > 0) GameEvents.TriggerNotificationMessage($"¡Victoria! +{xpEarned} de experiencia.");
            }
            else if (result == Combat3DOutcome.Fled)
            {
                MovePlayerAway(s.worldSource);
                GameEvents.TriggerNotificationMessage("Has huido del combate.");
            }

            try { s.onFinished?.Invoke(result); }
            catch (Exception e) { Debug.LogException(e); }
        }

        /// <summary>Tras huir, aparta al jugador del rival (si ese punto no es seguro, a la última posición segura).</summary>
        private void MovePlayerAway(Vector2 source)
        {
            if (stats == null) return;
            Vector2 heroPos = stats.transform.position;
            Vector2 away = heroPos - source;
            if (away.sqrMagnitude < 0.01f) away = Vector2.down;
            Rigidbody2D rb = stats.GetComponent<Rigidbody2D>();
            Vector2 target = heroPos + away.normalized * 1.8f;
            if (!SafePositionTracker.IsValidLandPosition(target, rb))
            {
                SafePositionTracker tracker = stats.GetComponent<SafePositionTracker>();
                target = tracker != null && tracker.HasSafePosition ? tracker.LastSafeLandPosition : heroPos;
            }
            if (rb != null)
            {
                rb.position = target;
                rb.linearVelocity = Vector2.zero;
            }
            stats.transform.position = target;
        }

        // ================================================================ Turno del jugador

        private IEnumerator PlayerTurn()
        {
            turn++;
            guarding = false;
            hero.SetGuard(false);
            hero.SetTurnActive(true);
            foe.SetTurnActive(false);

            yield return TickStatuses(true);
            if (hp <= 0f) { outcome = Combat3DOutcome.Lost; decided = true; yield break; }

            if (hakiTurns > 0)
            {
                hakiTurns--;
                if (hakiTurns == 0)
                {
                    hero.SetAura(null);
                    hero.SetTint(Color.white);
                    ui.Popup(hero.Head, "El Haki se disipa", new Color(0.8f, 0.7f, 1f), 0.6f);
                }
            }
            st = Mathf.Min(maxSt, st + 6f);
            RefreshHud();

            if (heroStunned)
            {
                heroStunned = false;
                hero.SetStunned(false);
                cam.Shot(CameraShot.OnPlayer);
                ui.Popup(hero.Head, "¡ATURDIDO!", new Color(1f, 0.9f, 0.4f), 1f);
                ui.SetDialogue($"{heroName} está aturdido y pierde el turno...", heroName);
                yield return Combat3DTime.Wait(1.5f);
                yield break;
            }

            cam.Shot(CameraShot.Command, false, 3.2f);
            ui.Banner("¡TU TURNO!", Gold);
            Sfx(a => a.PlayTurnStart());
            ShowCommands();

            pending = null;
            awaitingInput = true;
            while (pending == null) yield return null;
            awaitingInput = false;
            ui.HideMenus();
            Func<IEnumerator> action = pending;
            pending = null;
            yield return action();
            hero.ResetPose();
            hero.SetTurnActive(false);
            RefreshHud();
        }

        private void ShowCommands()
        {
            ui.SetDialogue($"¿Qué hará {heroName}?  (energía {Mathf.FloorToInt(st)} / {Mathf.FloorToInt(maxSt)})", heroName);
            ui.ShowCommands(HasFruit, ConsumableItems().Count, setup.canFlee);
        }

        private bool HasFruit => fruit != null && fruit.HasFruit;

        private void HandleCommand(int index)
        {
            if (!awaitingInput || pending != null) return;
            switch (index)
            {
                case 0:
                    OpenMoves(PhysicalMoves(), $"Elige un golpe. Energía: {Mathf.FloorToInt(st)}.");
                    break;
                case 1:
                    if (!HasFruit)
                    {
                        ui.SetDialogue("Aún no has comido ninguna Fruta del Diablo. Solo cuentas con tus puños, tus armas y tu ingenio.", "Combate");
                        Sfx(a => a.PlayDeny());
                        return;
                    }
                    OpenMoves(FruitMoves(), $"Técnicas de la {DevilFruitManager.DisplayName(fruit.FruitId)}. Energía: {Mathf.FloorToInt(st)}.");
                    break;
                case 2:
                    List<MoveOption> bag = BagMoves();
                    if (bag.Count == 0)
                    {
                        ui.SetDialogue("No llevas comida, bebida ni medicinas en la mochila.", "Mochila");
                        Sfx(a => a.PlayDeny());
                        return;
                    }
                    OpenMoves(bag, "¿Qué quieres usar? (usar un objeto gasta el turno)");
                    break;
                case 3:
                    if (!setup.canFlee)
                    {
                        ui.SetDialogue("¡No hay escapatoria en este combate!", "Combate");
                        Sfx(a => a.PlayDeny());
                        return;
                    }
                    pending = FleeRoutine;
                    break;
            }
        }

        private void OpenMoves(List<MoveOption> moves, string prompt)
        {
            currentMoves = moves;
            List<Combat3DMenuEntry> entries = new List<Combat3DMenuEntry>();
            foreach (MoveOption m in moves) entries.Add(m.entry);
            ui.ShowMoves(entries);
            ui.SetDialogue(prompt, heroName);
        }

        private void HandleMove(int index)
        {
            if (!awaitingInput || pending != null || index < 0 || index >= currentMoves.Count) return;
            MoveOption m = currentMoves[index];
            if (!string.IsNullOrEmpty(m.blocked))
            {
                ui.SetDialogue(m.blocked, heroName);
                Sfx(a => a.PlayDeny());
                return;
            }
            if (st + 0.01f < m.cost)
            {
                ui.SetDialogue($"No te queda energía para eso (necesitas {Mathf.CeilToInt(m.cost)}, tienes {Mathf.FloorToInt(st)}). Ponte en guardia para recuperarla.", heroName);
                Sfx(a => a.PlayDeny());
                return;
            }
            st -= m.cost;
            RefreshHud();
            pending = m.run;
        }

        private void HandleBack()
        {
            if (!awaitingInput || pending != null) return;
            ShowCommands();
        }

        // ------------------------------------------------------------------ Catálogo de golpes

        private MoveOption Move(string name, string detail, Color tint, float cost, Func<IEnumerator> run, string blocked = null)
        {
            bool affordable = st + 0.01f >= cost;
            return new MoveOption
            {
                entry = new Combat3DMenuEntry
                {
                    name = name,
                    detail = blocked != null ? blocked : affordable ? detail : $"Falta energía ({Mathf.CeilToInt(cost)})",
                    tint = tint,
                    enabled = blocked == null && affordable
                },
                cost = cost,
                blocked = blocked,
                run = run
            };
        }

        private static string Info(int dmg, float cost, float acc, string extra = null)
        {
            string s = $"{dmg} daño · {Mathf.CeilToInt(cost)} EN · {Mathf.RoundToInt(acc * 100f)}%";
            return string.IsNullOrEmpty(extra) ? s : s + " · " + extra;
        }

        private List<MoveOption> PhysicalMoves()
        {
            List<MoveOption> list = new List<MoveOption>();
            ItemData weapon = InventoryManager.Instance != null ? InventoryManager.Instance.CurrentEquippedTool : null;
            if (weapon != null && weapon.combatDamage > 0)
            {
                bool ranged = weapon.combatMaxRange > 1 || !string.IsNullOrEmpty(weapon.ammoItemId);
                if (ranged)
                {
                    int ammo = string.IsNullOrEmpty(weapon.ammoItemId) || InventoryManager.Instance == null ? -1 : InventoryManager.Instance.CountItem(weapon.ammoItemId);
                    string block = ammo == 0 ? "Sin munición" : null;
                    int power = weapon.combatDamage + 4;
                    list.Add(Move("Disparo: " + weapon.itemName, Info(power, 5f, weapon.combatAccuracy, ammo > 0 ? "munición x" + ammo : null),
                        new Color(1f, 0.9f, 0.7f), 5f, () => ShootRoutine(weapon, power), block));
                }
                else if (weapon.combatDamageType == CombatDamageType.Slash)
                {
                    int power = weapon.combatDamage + 6;
                    list.Add(Move("Tajo: " + weapon.itemName, Info(power, 9f, Mathf.Max(0.8f, weapon.combatAccuracy), "sangra"),
                        new Color(0.85f, 0.92f, 1f), 9f, () => SlashRoutine(weapon, power)));
                }
                else
                {
                    int power = weapon.combatDamage + 7;
                    list.Add(Move("Mazazo: " + weapon.itemName, Info(power, 10f, Mathf.Max(0.78f, weapon.combatAccuracy), "aturde"),
                        new Color(1f, 0.85f, 0.65f), 10f, () => SmashRoutine(weapon, power)));
                }
            }
            list.Add(Move("Golpe rápido", Info(6 + xpBonus, 6f, 0.95f, "x2"), new Color(1f, 0.75f, 0.6f), 6f, JabRoutine));
            list.Add(Move("Patada giratoria", Info(15 + xpBonus, 12f, 0.85f, "derriba"), new Color(1f, 0.8f, 0.5f), 12f, SpinKickRoutine));
            list.Add(Move("Cabezazo", Info(11 + xpBonus, 9f, 0.8f, "aturde"), new Color(1f, 0.7f, 0.7f), 9f, HeadbuttRoutine));
            if (list.Count < 4)
                list.Add(Move("Embestida", Info(12 + xpBonus, 10f, 0.9f, "rompe guardia"), new Color(0.95f, 0.8f, 0.6f), 10f, TackleRoutine));
            list.Add(Move("Guardia", "-60% daño · +15 EN · contraataca", new Color(0.65f, 0.9f, 1f), 0f, GuardRoutine));
            return list;
        }

        private List<MoveOption> FruitMoves()
        {
            bool haki = hakiTurns > 0;
            List<MoveOption> list = new List<MoveOption>
            {
                Move("Puño catapulta", Info(20 + xpBonus, 12f, 0.92f), new Color(0.88f, 0.72f, 1f), 12f, CatapultRoutine),
                Move("Lluvia de puños", "8 golpes de 4 · 22 EN · 85% c/u", new Color(0.95f, 0.65f, 0.95f), 22f, BarrageRoutine),
                Move("Martillo elástico", Info(26 + xpBonus, 18f, 0.82f, "aturde"), new Color(0.8f, 0.6f, 1f), 18f, HammerRoutine),
                Move("Haki de armadura", "+35% daño 3 turnos · 15 EN", new Color(0.7f, 0.6f, 0.85f), 15f, HakiRoutine, haki ? "El Haki ya está activo" : null)
            };
            return list;
        }

        private List<ItemData> ConsumableItems()
        {
            List<ItemData> list = new List<ItemData>();
            if (InventoryManager.Instance == null) return list;
            HashSet<string> seen = new HashSet<string>();
            foreach (InventorySlot slot in InventoryManager.Instance.Slots)
            {
                if (slot == null || slot.IsEmpty || slot.ItemData == null) continue;
                ItemData it = slot.ItemData;
                if (it.itemType != ItemType.Food && it.itemType != ItemType.Drink && it.itemType != ItemType.Medicine) continue;
                if (seen.Add(it.itemId)) list.Add(it);
            }
            return list;
        }

        private List<MoveOption> BagMoves()
        {
            List<MoveOption> list = new List<MoveOption>();
            List<ItemData> items = ConsumableItems();
            // Primero lo que más cura
            items.Sort((a, b) => b.healthRestore.CompareTo(a.healthRestore));
            for (int i = 0; i < items.Count && i < 5; i++)
            {
                ItemData it = items[i];
                int count = InventoryManager.Instance != null ? InventoryManager.Instance.CountItem(it.itemId) : 1;
                List<string> parts = new List<string>();
                if (Mathf.Abs(it.healthRestore) > 0.01f) parts.Add($"{(it.healthRestore > 0 ? "+" : "")}{Mathf.RoundToInt(it.healthRestore)} PV");
                if (it.staminaRestore > 0.01f) parts.Add($"+{Mathf.RoundToInt(it.staminaRestore)} EN");
                if (it.curesPoison) parts.Add("cura veneno");
                if (it.curesBleeding) parts.Add("corta sangrado");
                if (parts.Count == 0) parts.Add(it.itemType == ItemType.Drink ? "quita la sed" : "quita el hambre");
                parts.Add("x" + count);
                ItemData captured = it;
                list.Add(Move(it.itemName, string.Join(" · ", parts), new Color(0.7f, 1f, 0.75f), 0f, () => UseItemRoutine(captured)));
            }
            return list;
        }

        // ------------------------------------------------------------------ Resolución de daño

        private Vector3 DuelDir
        {
            get
            {
                Vector3 d = foe.Home - hero.Home; d.y = 0f;
                return d.sqrMagnitude > 0.01f ? d.normalized : Vector3.right;
            }
        }

        /// <summary>Punto delante del rival para los golpes cuerpo a cuerpo.</summary>
        private Vector3 InFrontOfFoe => foe.Home - DuelDir * (0.85f + E.height * 0.18f);
        private Vector3 InFrontOfHero => hero.Home + DuelDir * 1.0f;
        private Vector3 Shoulder => hero.Chest + DuelDir * 0.3f + Vector3.up * 0.15f;

        private bool RollHeroHit(float accuracy)
        {
            float evade = E.evasion + (foeGuarding ? 0.05f : 0f);
            return UnityEngine.Random.value < Mathf.Clamp(accuracy - evade, 0.05f, 0.99f);
        }

        private int RollHeroDamage(int power, float critChance, CombatDamageType type, bool physical, out bool crit, out string note)
        {
            note = null;
            float dmg = (power + xpBonus) * UnityEngine.Random.Range(0.9f, 1.1f);
            if (hakiTurns > 0) dmg *= 1.35f;
            crit = UnityEngine.Random.value < critChance;
            if (crit) dmg *= 1.6f;
            if (E.rubber && (type == CombatDamageType.Blunt || type == CombatDamageType.Pierce)) { dmg *= 0.5f; note = "¡Rebota en su cuerpo de goma!"; }
            if (E.logia && physical && hakiTurns <= 0) { dmg *= 0.2f; note = "¡El golpe atraviesa su cuerpo! (necesitas Haki)"; }
            if (foeGuarding) dmg *= 0.55f;
            dmg = dmg * (1f - Mathf.Clamp01(E.damageReduction)) - E.defense;
            return Mathf.Max(1, Mathf.RoundToInt(dmg));
        }

        /// <summary>Aplica daño al rival con todo el espectáculo: números, chispas, temblor, hit-stop y sonido.</summary>
        private void DamageFoe(int dmg, bool crit, Color spark, float force, string sound)
        {
            if (E.hp <= 0) return;
            E.hp = Mathf.Max(0, E.hp - dmg);
            Vector3 at = foe.Chest;
            ui.Popup(at, crit ? $"¡CRÍTICO! {dmg}" : dmg.ToString(), crit ? Gold : Color.white, crit ? 1.35f : 0.75f + force * 0.2f);
            foe.Hit(hero.Feet, force, crit ? new Color(1f, 0.95f, 0.6f) : Color.white);
            vfx.HitSpark(at, spark, Mathf.Clamp(0.7f + force * 0.4f + (crit ? 0.4f : 0f), 0.5f, 2.2f));
            cam.Shake(0.22f + force * 0.18f + (crit ? 0.25f : 0f));
            if (crit || force >= 1.5f)
            {
                Combat3DTime.HitStop(crit ? 0.1f : 0.07f);
                ui.Flash(Color.white, crit ? 0.35f : 0.2f);
                cam.Kick(-4f);
            }
            if (crit) Sfx(a => a.PlayCrit());
            else PlaySound(sound);
            RefreshHud();
        }

        private void FoeMiss()
        {
            StartCoroutine(foe.Dodge(hero.Feet));
            ui.Popup(foe.Head, "¡FALLO!", new Color(0.7f, 0.9f, 1f), 0.9f);
            Sfx(a => a.PlayMiss());
        }

        private void TryStunFoe(float chance)
        {
            if (E.hp <= 0 || UnityEngine.Random.value >= chance) return;
            foeStunned = true;
            foe.SetStunned(true);
            ui.Popup(foe.Head + Vector3.up * 0.3f, "¡ATURDIDO!", new Color(1f, 0.92f, 0.4f), 0.9f);
        }

        private void TryBleedFoe(float chance)
        {
            if (E.hp <= 0 || UnityEngine.Random.value >= chance) return;
            foeStatus[StatusType.Bleeding] = Mathf.Max(3, foeStatus.TryGetValue(StatusType.Bleeding, out int t) ? t : 0);
            ui.Popup(foe.Head + Vector3.up * 0.3f, "¡SANGRA!", new Color(1f, 0.4f, 0.4f), 0.85f);
            vfx.BleedDrops(foe.Chest);
        }

        // ------------------------------------------------------------------ Golpes físicos

        private IEnumerator JabRoutine()
        {
            ui.SetDialogue($"¡{heroName} lanza una ráfaga de golpes rápidos!", heroName);
            cam.Shot(CameraShot.Action);
            vfx.Dust(hero.Feet, 5, 0.4f, arena.DustColor);
            yield return hero.MoveTo(InFrontOfFoe, 0.22f, 0.12f, true, 10f);
            for (int i = 0; i < 2; i++)
            {
                yield return hero.Windup(foe.Feet, 0.07f, 0.12f);
                if (RollHeroHit(0.95f))
                {
                    int dmg = RollHeroDamage(6, 0.08f, CombatDamageType.Blunt, true, out bool crit, out string note);
                    DamageFoe(dmg, crit, HitOrange, i == 0 ? 0.6f : 0.85f, "blunt");
                    if (note != null && i == 0) ui.SetDialogue(note, "Combate");
                }
                else FoeMiss();
                hero.ResetPose();
                yield return Combat3DTime.Wait(0.16f);
                if (E.hp <= 0) break;
            }
            yield return Combat3DTime.Wait(0.18f);
            yield return hero.ReturnHome(0.28f, 0.35f);
        }

        private IEnumerator SlashRoutine(ItemData weapon, int power)
        {
            ui.SetDialogue($"¡{heroName} descarga un tajo con {weapon.itemName}!", heroName);
            cam.Shot(CameraShot.PlayerFocus, true);
            yield return hero.Windup(foe.Feet, 0.28f, 0.3f);
            cam.Shot(CameraShot.Action, true);
            yield return hero.MoveTo(InFrontOfFoe, 0.16f, 0.08f, true, 14f);
            if (RollHeroHit(Mathf.Max(0.8f, weapon.combatAccuracy)))
            {
                vfx.Slash(foe.Chest, new Color(0.7f, 0.9f, 1f), 30f, 1.2f);
                int dmg = RollHeroDamage(power, weapon.combatCritChance + 0.1f, CombatDamageType.Slash, true, out bool crit, out string note);
                DamageFoe(dmg, crit, new Color(0.75f, 0.9f, 1f), 1.1f, "slash");
                TryBleedFoe(0.3f);
                if (note != null) ui.SetDialogue(note, "Combate");
                yield return Combat3DTime.Wait(0.09f);
                vfx.Slash(foe.Chest + Vector3.up * 0.15f, new Color(0.85f, 0.95f, 1f), -40f, 1.0f, true);
            }
            else
            {
                vfx.Slash(foe.Chest + DuelDir * 0.6f, new Color(0.7f, 0.9f, 1f), 30f, 1.0f);
                FoeMiss();
            }
            hero.ResetPose();
            yield return Combat3DTime.Wait(0.3f);
            yield return hero.ReturnHome(0.3f, 0.3f);
        }

        private IEnumerator SmashRoutine(ItemData weapon, int power)
        {
            ui.SetDialogue($"¡{heroName} levanta {weapon.itemName} y lo deja caer con todas sus fuerzas!", heroName);
            cam.Shot(CameraShot.Action);
            yield return hero.MoveTo(InFrontOfFoe, 0.24f, 0f, true, 8f);
            yield return hero.Windup(foe.Feet, 0.2f, 0.2f);
            yield return hero.MoveTo(InFrontOfFoe, 0.22f, 0.9f, false, -10f);
            if (RollHeroHit(Mathf.Max(0.78f, weapon.combatAccuracy)))
            {
                int dmg = RollHeroDamage(power, weapon.combatCritChance, CombatDamageType.Blunt, true, out bool crit, out string note);
                DamageFoe(dmg, crit, HitOrange, 1.6f, "blunt");
                vfx.GroundRing(foe.Feet, new Color(1f, 0.85f, 0.5f), 4.5f);
                vfx.Dust(foe.Feet, 12, 0.9f, arena.DustColor, 1.3f);
                TryStunFoe(0.25f);
                if (note != null) ui.SetDialogue(note, "Combate");
            }
            else
            {
                vfx.Dust(InFrontOfFoe, 10, 0.7f, arena.DustColor);
                FoeMiss();
            }
            hero.ResetPose();
            yield return Combat3DTime.Wait(0.35f);
            yield return hero.ReturnHome(0.32f, 0.35f);
        }

        private IEnumerator ShootRoutine(ItemData weapon, int power)
        {
            bool sling = weapon.itemName.ToLowerInvariant().Contains("tirachinas");
            if (!string.IsNullOrEmpty(weapon.ammoItemId) && InventoryManager.Instance != null)
                InventoryManager.Instance.ConsumeItemById(weapon.ammoItemId, 1);
            ui.SetDialogue($"¡{heroName} apunta con {weapon.itemName} y dispara!", heroName);
            cam.Shot(CameraShot.PlayerFocus, true);
            yield return hero.Windup(foe.Feet, 0.3f, 0.12f);
            Vector3 muzzle = hero.Chest + DuelDir * 0.6f;
            vfx.MuzzleFlash(muzzle, DuelDir);
            if (sling) Sfx(a => a.PlaySlingshot()); else Sfx(a => a.PlayGunshot());
            cam.Shake(sling ? 0.1f : 0.3f);
            cam.Shot(CameraShot.Action, true);
            bool hit = RollHeroHit(weapon.combatAccuracy);
            Vector3 target = hit ? foe.Chest : foe.Chest + Vector3.Cross(Vector3.up, DuelDir) * 1.4f + Vector3.up * 0.4f;
            yield return vfx.Projectile(muzzle, target, sling ? ProjectileKind.Pellet : ProjectileKind.Bullet, sling ? 24f : 45f, () =>
            {
                if (hit)
                {
                    int dmg = RollHeroDamage(power, weapon.combatCritChance + 0.05f, CombatDamageType.Pierce, true, out bool crit, out string note);
                    DamageFoe(dmg, crit, new Color(1f, 0.85f, 0.45f), 1.0f, "hit");
                    if (note != null) ui.SetDialogue(note, "Combate");
                }
                else FoeMiss();
            });
            hero.ResetPose();
            yield return Combat3DTime.Wait(0.4f);
        }

        private IEnumerator SpinKickRoutine()
        {
            ui.SetDialogue($"¡{heroName} salta y lanza una PATADA GIRATORIA!", heroName);
            cam.Shot(CameraShot.Action);
            vfx.Dust(hero.Feet, 8, 0.5f, arena.DustColor);
            StartCoroutine(hero.Spin(0.46f, 2f));
            yield return hero.MoveTo(InFrontOfFoe, 0.46f, 1.4f, true);
            if (RollHeroHit(0.85f))
            {
                int dmg = RollHeroDamage(15, 0.12f, CombatDamageType.Blunt, true, out bool crit, out string note);
                DamageFoe(dmg, crit, HitOrange, 1.5f, "blunt");
                vfx.GroundRing(foe.Feet, new Color(1f, 0.9f, 0.6f), 4f);
                if (UnityEngine.Random.value < 0.2f) TryStunFoe(1f);
                if (note != null) ui.SetDialogue(note, "Combate");
            }
            else FoeMiss();
            yield return Combat3DTime.Wait(0.3f);
            yield return hero.ReturnHome(0.4f, 0.8f);
        }

        private IEnumerator HeadbuttRoutine()
        {
            ui.SetDialogue($"¡{heroName} carga de cabeza con un CABEZAZO!", heroName);
            cam.Shot(CameraShot.PlayerFocus, true);
            yield return hero.Windup(foe.Feet, 0.3f, 0.35f);
            cam.Shot(CameraShot.Action, true);
            yield return hero.MoveTo(InFrontOfFoe, 0.2f, 0f, true, 26f);
            if (RollHeroHit(0.8f))
            {
                int dmg = RollHeroDamage(11, 0.1f, CombatDamageType.Blunt, true, out bool crit, out string note);
                DamageFoe(dmg, crit, new Color(1f, 0.95f, 0.5f), 1.3f, "blunt");
                vfx.Stars(foe.Head);
                TryStunFoe(0.35f);
                // El cabezazo también duele
                hp = Mathf.Max(1f, hp - 3f);
                ui.Popup(hero.Head, "3", DmgColor, 0.7f);
                hero.Flash(Color.white, 0.6f);
                if (note != null) ui.SetDialogue(note, "Combate");
            }
            else FoeMiss();
            hero.ResetPose();
            RefreshHud();
            yield return Combat3DTime.Wait(0.3f);
            yield return hero.ReturnHome(0.3f, 0.25f);
        }

        private IEnumerator TackleRoutine()
        {
            ui.SetDialogue($"¡{heroName} toma carrerilla y EMBISTE!", heroName);
            cam.Shot(CameraShot.Action);
            yield return hero.MoveTo(hero.Home - DuelDir * 1.4f, 0.22f, 0f, false, -8f);
            vfx.Dust(hero.Feet, 8, 0.5f, arena.DustColor, 1.2f);
            yield return hero.MoveTo(InFrontOfFoe + DuelDir * 0.35f, 0.2f, 0f, true, 20f);
            if (RollHeroHit(0.9f))
            {
                bool brokeGuard = foeGuarding;
                int dmg = RollHeroDamage(12, 0.1f, CombatDamageType.Blunt, true, out bool crit, out string note);
                if (brokeGuard) { dmg = Mathf.RoundToInt(dmg * 1.8f); foeGuarding = false; foe.SetGuard(false); }
                DamageFoe(dmg, crit, HitOrange, 1.7f, "blunt");
                vfx.Dust(foe.Feet, 10, 0.8f, arena.DustColor, 1.4f);
                if (brokeGuard) ui.SetDialogue("¡Rompes su guardia!", "Combate");
                else if (note != null) ui.SetDialogue(note, "Combate");
            }
            else FoeMiss();
            hero.ResetPose();
            yield return Combat3DTime.Wait(0.3f);
            yield return hero.ReturnHome(0.35f, 0.3f);
        }

        private IEnumerator GuardRoutine()
        {
            guarding = true;
            hero.SetGuard(true);
            st = Mathf.Min(maxSt, st + 15f);
            RefreshHud();
            cam.Shot(CameraShot.PlayerFocus);
            vfx.Aura(hero.Feet, new Color(0.5f, 0.85f, 1f), 10);
            ui.Popup(hero.Head, "+15 EN", new Color(0.5f, 0.85f, 1f), 0.8f);
            Sfx(a => a.PlayShield());
            ui.SetDialogue($"{heroName} se pone en GUARDIA. Recibirá mucho menos daño y puede contraatacar.", heroName);
            yield return Combat3DTime.Wait(1.0f);
        }

        // ------------------------------------------------------------------ Técnicas de la Fruta

        private IEnumerator CatapultRoutine()
        {
            bool haki = hakiTurns > 0;
            ui.Banner("¡PUÑO CATAPULTA!", new Color(0.9f, 0.7f, 1f));
            ui.SetDialogue($"¡{heroName} estira el brazo hacia atrás... y lo suelta como una catapulta!", heroName);
            cam.Shot(CameraShot.PlayerFocus, true);
            yield return hero.Windup(foe.Feet, 0.25f, 0.25f);
            cam.Shot(CameraShot.Action, true);
            bool hit = RollHeroHit(0.92f);
            Vector3 target = hit ? foe.Chest : foe.Chest + Vector3.Cross(Vector3.up, DuelDir) * 1.2f;
            yield return vfx.StretchPunch(Shoulder, target, haki, 0.2f, 0.14f, 0.1f, 0.2f, 0.42f, () =>
            {
                if (hit)
                {
                    int dmg = RollHeroDamage(20, 0.15f, haki ? CombatDamageType.Haki : CombatDamageType.Blunt, !haki, out bool crit, out string note);
                    DamageFoe(dmg, crit, haki ? new Color(0.8f, 0.3f, 1f) : HitOrange, 1.6f, "blunt");
                    if (note != null) ui.SetDialogue(note, "Combate");
                }
                else FoeMiss();
            });
            hero.ResetPose();
            yield return Combat3DTime.Wait(0.3f);
        }

        private IEnumerator BarrageRoutine()
        {
            bool haki = hakiTurns > 0;
            ui.Banner("¡LLUVIA DE PUÑOS!", new Color(0.95f, 0.6f, 0.95f));
            ui.SetDialogue($"¡{heroName} desata una LLUVIA DE PUÑOS imposible de seguir con la vista!", heroName);
            cam.Shot(CameraShot.Action);
            yield return hero.Windup(foe.Feet, 0.18f, 0.15f);
            Vector3 side = Vector3.Cross(Vector3.up, DuelDir);
            int running = 0;
            for (int i = 0; i < 8; i++)
            {
                Vector3 jitter = side * UnityEngine.Random.Range(-0.35f, 0.35f) + Vector3.up * UnityEngine.Random.Range(-0.3f, 0.35f);
                bool hit = RollHeroHit(0.85f);
                Vector3 target = foe.Chest + jitter * 1.4f + (hit ? Vector3.zero : side * 0.9f);
                running++;
                StartCoroutine(RunAndCount(vfx.StretchPunch(Shoulder + jitter * 0.4f, target, haki, 0.04f, 0.08f, 0.02f, 0.09f, 0.32f, () =>
                {
                    if (E.hp <= 0) return;
                    if (hit)
                    {
                        int dmg = RollHeroDamage(4, 0.05f, haki ? CombatDamageType.Haki : CombatDamageType.Blunt, !haki, out bool crit, out _);
                        DamageFoe(dmg, crit, haki ? new Color(0.8f, 0.3f, 1f) : HitOrange, 0.35f, "blunt");
                    }
                    else ui.Popup(foe.Head, "fallo", new Color(0.7f, 0.9f, 1f), 0.6f);
                }), () => running--));
                yield return Combat3DTime.Wait(0.07f);
            }
            while (running > 0) yield return null;
            hero.ResetPose();
            yield return Combat3DTime.Wait(0.35f);
        }

        private IEnumerator RunAndCount(IEnumerator routine, Action done)
        {
            yield return routine;
            done();
        }

        private IEnumerator HammerRoutine()
        {
            bool haki = hakiTurns > 0;
            ui.Banner("¡MARTILLO ELÁSTICO!", new Color(0.85f, 0.6f, 1f));
            ui.SetDialogue($"¡El brazo de {heroName} sube hasta el cielo... y cae como un martillo!", heroName);
            cam.Shot(CameraShot.Intro, false, 3f);
            bool hit = RollHeroHit(0.82f);
            Vector3 target = hit ? foe.Feet + Vector3.up * 0.6f : foe.Feet + Vector3.Cross(Vector3.up, DuelDir) * 1.5f;
            yield return vfx.HammerArm(Shoulder, target, haki, () =>
            {
                vfx.GroundRing(hit ? foe.Feet : target, new Color(1f, 0.85f, 0.6f), 6f);
                vfx.Dust(hit ? foe.Feet : target, 16, 1.1f, arena.DustColor, 1.6f);
                cam.Shake(0.5f);
                if (hit)
                {
                    int dmg = RollHeroDamage(26, 0.12f, haki ? CombatDamageType.Haki : CombatDamageType.Blunt, !haki, out bool crit, out string note);
                    DamageFoe(dmg, crit, haki ? new Color(0.8f, 0.3f, 1f) : HitOrange, 2f, "blunt");
                    Sfx(a => a.PlayExplosion());
                    TryStunFoe(0.25f);
                    if (note != null) ui.SetDialogue(note, "Combate");
                }
                else FoeMiss();
            });
            yield return Combat3DTime.Wait(0.4f);
        }

        private IEnumerator HakiRoutine()
        {
            hakiTurns = 4; // este turno + 3 de efecto
            ui.Banner("HAKI DE ARMADURA", new Color(0.75f, 0.55f, 1f));
            ui.SetDialogue($"{heroName} endurece su cuerpo con HAKI. Sus golpes harán un 35% más de daño durante 3 turnos.", heroName);
            cam.Shot(CameraShot.PlayerFocus, true);
            hero.SetAura(new Color(0.55f, 0.25f, 0.9f));
            hero.SetTint(new Color(0.78f, 0.72f, 0.88f));
            hero.Flash(new Color(0.6f, 0.3f, 1f), 0.8f);
            vfx.Aura(hero.Feet, new Color(0.6f, 0.3f, 1f), 14);
            vfx.GroundRing(hero.Feet, new Color(0.6f, 0.3f, 1f), 3.5f);
            Sfx(a => a.PlayShield());
            cam.Shake(0.2f);
            yield return Combat3DTime.Wait(1.2f);
        }

        // ------------------------------------------------------------------ Mochila y huida

        private IEnumerator UseItemRoutine(ItemData item)
        {
            if (InventoryManager.Instance == null || !InventoryManager.Instance.ConsumeItemById(item.itemId, 1))
            {
                ui.SetDialogue("Ese objeto ya no está en la mochila.", "Mochila");
                yield return Combat3DTime.Wait(0.8f);
                yield break;
            }
            float before = hp;
            hp = Mathf.Clamp(hp + item.healthRestore, 1f, maxHp);
            st = Mathf.Clamp(st + item.staminaRestore, 0f, maxSt);
            if (stats != null)
            {
                if (item.hungerRestore != 0f) stats.ModifyHunger(item.hungerRestore);
                if (item.thirstRestore != 0f) stats.ModifyThirst(item.thirstRestore);
            }
            List<string> cured = new List<string>();
            if (item.curesPoison && heroStatus.Remove(StatusType.Poisoned)) cured.Add("veneno");
            if (item.curesBleeding && heroStatus.Remove(StatusType.Bleeding)) cured.Add("sangrado");

            cam.Shot(CameraShot.PlayerFocus);
            vfx.HealBurst(hero.Feet);
            int gained = Mathf.RoundToInt(hp - before);
            if (gained > 0) ui.Popup(hero.Head, "+" + gained + " PV", new Color(0.5f, 1f, 0.55f), 1.1f);
            else if (gained < 0) ui.Popup(hero.Head, gained.ToString(), DmgColor, 0.9f);
            if (item.staminaRestore > 0f) ui.Popup(hero.Chest, "+" + Mathf.RoundToInt(item.staminaRestore) + " EN", new Color(0.5f, 0.85f, 1f), 0.8f);
            if (item.itemType == ItemType.Drink) Sfx(a => a.PlayDrink());
            else if (item.itemType == ItemType.Medicine) Sfx(a => a.PlayItemUse());
            else Sfx(a => a.PlayEat());
            RefreshHud();
            string msg = $"{heroName} usa {item.itemName}.";
            if (gained > 0) msg += $" Recupera {gained} PV.";
            if (cured.Count > 0) msg += " Se cura: " + string.Join(" y ", cured) + ".";
            ui.SetDialogue(msg, "Mochila");
            yield return Combat3DTime.Wait(1.3f);
        }

        private IEnumerator FleeRoutine()
        {
            float chance = Mathf.Clamp(0.45f + 0.35f * (1f - (float)E.hp / Mathf.Max(1, E.maxHp)) + (E.boss ? -0.25f : 0f), 0.15f, 0.9f);
            cam.Shot(CameraShot.Action);
            if (UnityEngine.Random.value < chance)
            {
                ui.SetDialogue($"¡{heroName} pone pies en polvorosa!", heroName);
                Sfx(a => a.PlayMiss());
                vfx.Dust(hero.Feet, 10, 0.6f, arena.DustColor, 1.2f);
                yield return hero.MoveTo(hero.Home - DuelDir * 9f + Vector3.Cross(Vector3.up, DuelDir) * 2f, 0.9f, 0.2f, true, -12f);
                outcome = Combat3DOutcome.Fled;
                decided = true;
            }
            else
            {
                ui.SetDialogue($"¡{E.name} te corta la retirada!", E.name);
                yield return hero.MoveTo(hero.Home - DuelDir * 1.5f, 0.2f);
                hero.Hit(foe.Feet, 0.5f, Color.white);
                Sfx(a => a.PlayDeny());
                yield return Combat3DTime.Wait(0.4f);
                yield return hero.ReturnHome(0.25f);
            }
        }

        // ================================================================ Turno del rival

        private IEnumerator EnemyTurn()
        {
            foe.SetTurnActive(true);
            hero.SetTurnActive(false);
            if (foeGuarding) { foeGuarding = false; foe.SetGuard(false); }

            yield return TickStatuses(false);
            if (E.hp <= 0) yield break;

            if (foeStunned)
            {
                foeStunned = false;
                foe.SetStunned(false);
                cam.Shot(CameraShot.EnemyFocus);
                ui.SetDialogue($"{E.name} está aturdido y no puede atacar.", E.name);
                vfx.Stars(foe.Head);
                yield return Combat3DTime.Wait(1.4f);
                foe.SetTurnActive(false);
                yield break;
            }

            ui.Banner("TURNO RIVAL", new Color(1f, 0.5f, 0.45f));
            yield return Combat3DTime.Wait(0.5f);

            if (foeCharging)
            {
                foeCharging = false;
                foe.SetAura(null);
                ui.SetDialogue($"¡{E.name} suelta su ATAQUE CARGADO!", E.name);
                yield return EnemyAttack(1.8f, -0.08f, true);
            }
            else if (E.boss && !foeHealed && E.hp < E.maxHp * 0.4f)
            {
                foeHealed = true;
                int heal = Mathf.RoundToInt(E.maxHp * 0.25f);
                E.hp = Mathf.Min(E.maxHp, E.hp + heal);
                cam.Shot(CameraShot.EnemyFocus);
                ui.SetDialogue($"{E.name} echa un largo trago de ron y recupera fuerzas.", E.name);
                vfx.HealBurst(foe.Feet);
                ui.Popup(foe.Head, "+" + heal, new Color(0.5f, 1f, 0.55f), 1f);
                Sfx(a => a.PlayDrink());
                RefreshHud();
                yield return Combat3DTime.Wait(1.4f);
            }
            else if (turn >= 2 && UnityEngine.Random.value < 0.2f)
            {
                foeCharging = true;
                foe.SetAura(new Color(1f, 0.3f, 0.2f));
                cam.Shot(CameraShot.EnemyFocus);
                ui.SetDialogue($"¡{E.name} se está preparando para un golpe brutal! Ponte en guardia o atácale primero.", E.name);
                vfx.Aura(foe.Feet, new Color(1f, 0.35f, 0.2f), 12);
                foe.Flash(new Color(1f, 0.3f, 0.2f), 0.7f);
                Sfx(a => a.PlayShield());
                yield return Combat3DTime.Wait(1.6f);
            }
            else if (!E.animal && UnityEngine.Random.value < 0.1f)
            {
                foeGuarding = true;
                foe.SetGuard(true);
                cam.Shot(CameraShot.EnemyFocus);
                ui.SetDialogue($"{E.name} se cubre y espera tu ataque.", E.name);
                Sfx(a => a.PlayShield());
                yield return Combat3DTime.Wait(1.1f);
            }
            else
            {
                ui.SetDialogue($"¡{E.name} ataca con {E.attackName}!", E.name);
                yield return EnemyAttack(1f, 0f, false);
            }
            foe.ResetPose();
            foe.SetTurnActive(false);
            RefreshHud();
        }

        private IEnumerator EnemyAttack(float mult, float accDelta, bool heavy)
        {
            Vector3 approach = InFrontOfHero;
            Vector3 side = Vector3.Cross(Vector3.up, DuelDir);
            bool hit = UnityEngine.Random.value < Mathf.Clamp(E.accuracy + accDelta, 0.1f, 0.97f);

            switch (E.style)
            {
                case EnemyStyle.Ranged:
                case EnemyStyle.Fire:
                {
                    cam.Shot(CameraShot.EnemyFocus, true);
                    yield return foe.Windup(hero.Feet, 0.35f, 0.15f);
                    Vector3 muzzle = foe.Chest - DuelDir * 0.6f;
                    bool fire = E.style == EnemyStyle.Fire;
                    if (fire) vfx.BurnFlames(foe.Feet); else { vfx.MuzzleFlash(muzzle, -DuelDir); Sfx(a => a.PlayGunshot()); }
                    cam.Shot(CameraShot.Action, true);
                    Vector3 target = hit ? hero.Chest : hero.Chest + side * 1.3f + Vector3.up * 0.3f;
                    yield return vfx.Projectile(muzzle, target, fire ? ProjectileKind.Fireball : ProjectileKind.Bullet, fire ? 13f : 42f,
                        () => ResolveEnemyHit(hit, mult, heavy, false, fire ? new Color(1f, 0.5f, 0.1f) : new Color(1f, 0.85f, 0.4f)));
                    yield return Combat3DTime.Wait(0.5f);
                    break;
                }
                case EnemyStyle.Charge:
                {
                    cam.Shot(CameraShot.Action);
                    yield return foe.MoveTo(foe.Home + DuelDir * 1.6f, 0.3f, 0f, false, 8f);
                    vfx.Dust(foe.Feet, 10, 0.6f, arena.DustColor, 1.2f);
                    Sfx(a => a.PlayHit());
                    yield return foe.MoveTo(approach - DuelDir * 0.3f, 0.24f, 0f, true, -18f);
                    vfx.Dust(hero.Feet, 8, 0.6f, arena.DustColor);
                    ResolveEnemyHit(hit, mult, heavy, true, HitOrange);
                    yield return Combat3DTime.Wait(0.3f);
                    yield return foe.ReturnHome(0.4f, 0.3f);
                    break;
                }
                case EnemyStyle.Swoop:
                {
                    cam.Shot(CameraShot.Action);
                    yield return foe.MoveTo(Vector3.Lerp(foe.Home, approach, 0.4f) + side * 1.2f, 0.3f, 1.5f, false);
                    yield return foe.MoveTo(approach, 0.18f, 0.4f, true);
                    if (hit) vfx.Claw(hero.Chest, new Color(1f, 0.85f, 0.85f));
                    ResolveEnemyHit(hit, mult, heavy, true, new Color(1f, 0.6f, 0.6f));
                    yield return Combat3DTime.Wait(0.25f);
                    yield return foe.ReturnHome(0.4f, 1.2f);
                    break;
                }
                case EnemyStyle.Leap:
                {
                    if (!heavy && UnityEngine.Random.value < 0.35f)
                    {
                        // Escupe veneno a distancia
                        cam.Shot(CameraShot.EnemyFocus, true);
                        ui.SetDialogue($"¡{E.name} escupe un chorro de veneno!", E.name);
                        yield return foe.Windup(hero.Feet, 0.3f, 0.2f);
                        cam.Shot(CameraShot.Action, true);
                        Vector3 target = hit ? hero.Chest : hero.Chest + side * 1.2f;
                        yield return vfx.Projectile(foe.Chest, target, ProjectileKind.Venom, 11f,
                            () => ResolveEnemyHit(hit, 0.8f, false, false, new Color(0.5f, 0.95f, 0.3f), StatusType.Poisoned, 0.6f));
                        yield return Combat3DTime.Wait(0.4f);
                    }
                    else
                    {
                        cam.Shot(CameraShot.Action);
                        yield return foe.Windup(hero.Feet, 0.2f, 0.2f);
                        yield return foe.MoveTo(approach, 0.38f, 1.6f, true);
                        if (hit) vfx.Claw(hero.Chest, new Color(0.9f, 1f, 0.8f));
                        ResolveEnemyHit(hit, mult, heavy, true, new Color(0.7f, 1f, 0.5f));
                        yield return Combat3DTime.Wait(0.25f);
                        yield return foe.ReturnHome(0.38f, 1.0f);
                    }
                    break;
                }
                case EnemyStyle.Scuttle:
                {
                    cam.Shot(CameraShot.Action);
                    Vector3 mid = Vector3.Lerp(foe.Home, approach, 0.5f);
                    yield return foe.MoveTo(Vector3.Lerp(foe.Home, mid, 0.5f) + side * 0.8f, 0.16f);
                    yield return foe.MoveTo(mid - side * 0.8f, 0.16f);
                    yield return foe.MoveTo(approach, 0.16f, 0.1f);
                    if (hit) vfx.Claw(hero.Chest, new Color(1f, 0.7f, 0.6f));
                    ResolveEnemyHit(hit, mult, heavy, true, new Color(1f, 0.6f, 0.4f));
                    yield return Combat3DTime.Wait(0.25f);
                    yield return foe.ReturnHome(0.3f);
                    break;
                }
                default: // Melee y Slash
                {
                    cam.Shot(CameraShot.EnemyFocus, true);
                    yield return foe.Windup(hero.Feet, heavy ? 0.45f : 0.3f, 0.3f);
                    cam.Shot(CameraShot.Action, true);
                    yield return foe.MoveTo(approach, 0.2f, 0.1f, true, -14f);
                    if (E.style == EnemyStyle.Slash) vfx.Slash(hero.Chest, new Color(1f, 0.75f, 0.7f), 150f, heavy ? 1.5f : 1.15f, true);
                    ResolveEnemyHit(hit, mult, heavy, true, E.style == EnemyStyle.Slash ? new Color(1f, 0.8f, 0.8f) : HitOrange);
                    yield return Combat3DTime.Wait(0.3f);
                    yield return foe.ReturnHome(0.32f, 0.3f);
                    break;
                }
            }
        }

        /// <summary>Resultado de un ataque rival sobre el jugador (en el instante del impacto).</summary>
        private void ResolveEnemyHit(bool hit, float mult, bool heavy, bool melee, Color spark, StatusType? forcedStatus = null, float forcedChance = 0f)
        {
            if (!hit)
            {
                StartCoroutine(hero.Dodge(foe.Feet));
                ui.Popup(hero.Head, "¡ESQUIVADO!", new Color(0.6f, 0.9f, 1f), 0.9f);
                Sfx(a => a.PlayMiss());
                return;
            }
            float dmg = E.damage * UnityEngine.Random.Range(0.85f, 1.15f) * mult;
            bool crit = UnityEngine.Random.value < E.crit;
            if (crit) dmg *= 1.5f;
            if (guarding) dmg *= 0.4f;
            int d = Mathf.Max(1, Mathf.RoundToInt(dmg));
            hp = Mathf.Max(0f, hp - d);

            cam.Shot(CameraShot.OnPlayer, true, 6f);
            ui.Popup(hero.Chest, crit ? $"¡CRÍTICO! {d}" : d.ToString(), crit ? Gold : DmgColor, crit || heavy ? 1.3f : 0.95f);
            hero.Hit(foe.Feet, heavy ? 1.6f : 1f, new Color(1f, 0.6f, 0.6f));
            vfx.HitSpark(hero.Chest, spark, heavy ? 1.7f : 1f);
            cam.Shake(heavy ? 0.6f : 0.32f);
            ui.Flash(new Color(1f, 0.2f, 0.15f), heavy ? 0.35f : 0.18f);
            if (heavy || crit) Combat3DTime.HitStop(0.09f);
            if (guarding) ui.Popup(hero.Head, "¡BLOQUEADO!", new Color(0.6f, 0.9f, 1f), 0.75f);
            if (E.damageType == CombatDamageType.Slash) Sfx(a => a.PlaySlash()); else Sfx(a => a.PlayHit());

            // Estados
            if (forcedStatus.HasValue && UnityEngine.Random.value < forcedChance) ApplyHeroStatus(forcedStatus.Value, 3);
            else if (E.appliesStatus && !guarding && UnityEngine.Random.value < E.statusChance) ApplyHeroStatus(E.status, E.statusTurns);
            if (E.style == EnemyStyle.Fire && !guarding && UnityEngine.Random.value < 0.4f) ApplyHeroStatus(StatusType.Burning, 2);

            // Contraataque desde la guardia
            if (guarding && melee && hp > 0f && UnityEngine.Random.value < 0.35f)
                StartCoroutine(Counter());

            RefreshHud();
        }

        private IEnumerator Counter()
        {
            yield return Combat3DTime.Wait(0.2f);
            if (E.hp <= 0 || hp <= 0f) yield break;
            ui.Popup(hero.Head + Vector3.up * 0.3f, "¡CONTRAATAQUE!", Gold, 0.9f);
            int dmg = RollHeroDamage(6, 0.1f, CombatDamageType.Blunt, true, out bool crit, out _);
            DamageFoe(dmg, crit, HitOrange, 1f, "blunt");
        }

        private void ApplyHeroStatus(StatusType type, int turns)
        {
            switch (type)
            {
                case StatusType.Stunned:
                case StatusType.KnockedDown:
                case StatusType.Immobilized:
                    heroStunned = true;
                    hero.SetStunned(true);
                    ui.Popup(hero.Head + Vector3.up * 0.3f, "¡DERRIBADO!", new Color(1f, 0.9f, 0.4f), 0.9f);
                    break;
                case StatusType.Bleeding:
                case StatusType.Poisoned:
                case StatusType.Burning:
                    heroStatus[type] = Mathf.Max(turns, heroStatus.TryGetValue(type, out int t) ? t : 0);
                    ui.Popup(hero.Head + Vector3.up * 0.3f, type == StatusType.Bleeding ? "¡SANGRAS!" : type == StatusType.Poisoned ? "¡ENVENENADO!" : "¡QUEMADO!",
                        type == StatusType.Poisoned ? new Color(0.6f, 1f, 0.4f) : new Color(1f, 0.5f, 0.3f), 0.9f);
                    break;
            }
        }

        /// <summary>Daño por estados al empezar el turno de cada bando.</summary>
        private IEnumerator TickStatuses(bool heroSide)
        {
            Dictionary<StatusType, int> set = heroSide ? heroStatus : foeStatus;
            if (set.Count == 0) yield break;
            Combat3DCharacter who = heroSide ? hero : foe;
            List<StatusType> keys = new List<StatusType>(set.Keys);
            foreach (StatusType s in keys)
            {
                int dmg = s == StatusType.Bleeding ? 3 : s == StatusType.Poisoned ? 4 : 5;
                if (heroSide) hp = Mathf.Max(0f, hp - dmg);
                else E.hp = Mathf.Max(0, E.hp - dmg);
                string label = s == StatusType.Bleeding ? "sangrado" : s == StatusType.Poisoned ? "veneno" : "quemadura";
                ui.Popup(who.Chest, $"{dmg} ({label})", s == StatusType.Poisoned ? new Color(0.6f, 1f, 0.4f) : DmgColor, 0.8f);
                who.Flash(s == StatusType.Poisoned ? new Color(0.5f, 1f, 0.3f) : new Color(1f, 0.3f, 0.2f), 0.6f);
                if (s == StatusType.Bleeding) vfx.BleedDrops(who.Chest);
                else if (s == StatusType.Poisoned) vfx.PoisonPuff(who.Chest);
                else vfx.BurnFlames(who.Feet);
                set[s] = set[s] - 1;
                if (set[s] <= 0) set.Remove(s);
            }
            RefreshHud();
            yield return Combat3DTime.Wait(0.8f);
        }

        // ================================================================ Rival derrotado, victoria y derrota

        private IEnumerator FoeDefeated()
        {
            foe.SetTurnActive(false);
            foe.SetAura(null);
            foe.SetGuard(false);
            xpEarned += E.xp;
            bountyEarned += E.playerBountyOnDefeat;
            cam.Shot(CameraShot.OnEnemy);
            ui.SetDialogue($"¡{E.name} ha sido derrotado!", "Combate");
            Sfx(a => a.PlayLevelUp());
            yield return foe.Faint();
            yield return Combat3DTime.Wait(0.5f);

            if (enemyIndex + 1 >= setup.enemies.Count)
            {
                outcome = Combat3DOutcome.Won;
                decided = true;
                yield break;
            }

            // Entra el siguiente rival
            Combat3DCharacter old = foe;
            enemyIndex++;
            foeStatus.Clear();
            foeStunned = foeCharging = foeGuarding = foeHealed = false;
            foe = SpawnFighter("Foe" + enemyIndex, Combat3DArena.EnemySpot, E.name, E.sprite, E.height, false, E.flies);
            Vector3 entry = arena.World(Combat3DArena.EnemyEntrySpot);
            foe.PlaceAt(entry);
            cam.SetEnemy(foe);
            cam.SetEntryPoint(entry);
            cam.Shot(CameraShot.EnemyEntry);
            Destroy(old.gameObject);
            RefreshHud();
            ui.SnapBars(true);
            ui.SetDialogue($"¡{E.name} entra en combate!", E.name);
            vfx.Dust(entry, 8, 0.6f, arena.DustColor);
            yield return foe.EnterFrom(entry, 0.9f);
            vfx.Dust(foe.Feet, 10, 0.7f, arena.DustColor);
            cam.Shake(0.15f);
            yield return Combat3DTime.Wait(0.8f);
        }

        private IEnumerator VictorySequence()
        {
            hero.SetTurnActive(false);
            hero.SetAura(null);
            hero.SetGuard(false);
            cam.Shot(CameraShot.Victory, false, 2.5f);
            ui.Banner("¡VICTORIA!", Gold);
            Sfx(a => a.PlayVictory());
            StartCoroutine(hero.Celebrate());
            ui.SetDialogue($"¡{heroName} gana el combate!", heroName);
            yield return Combat3DTime.Wait(1.6f);

            List<string> lines = new List<string>();
            if (setup.grantXp && xpEarned > 0) lines.Add($"+{xpEarned} de experiencia");
            if (setup.grantXp && bountyEarned > 0) lines.Add($"Tu recompensa sube {bountyEarned:N0} berries");
            if (setup.onVictoryRewards != null)
            {
                try
                {
                    List<string> loot = setup.onVictoryRewards();
                    if (loot != null) lines.AddRange(loot);
                }
                catch (Exception e) { Debug.LogException(e); }
            }
            lines.Add($"Vida: {Mathf.CeilToInt(hp)} / {Mathf.RoundToInt(maxHp)}");
            ui.ShowResult(true, "¡VICTORIA!", string.Join("\n", lines));
            continuePressed = false;
            while (!continuePressed) yield return null;
            hero.StopCelebrating();
        }

        private IEnumerator DefeatSequence()
        {
            hero.SetTurnActive(false);
            cam.Shot(CameraShot.Defeat, false, 2f);
            ui.SetDialogue($"{heroName} se desploma sin fuerzas...", heroName);
            Sfx(a => a.PlayDefeat());
            yield return hero.Faint();
            yield return Combat3DTime.Wait(0.8f);
            ui.ShowResult(false, "HAS CAÍDO", $"{E.name} ha podido contigo.\nEl mar no perdona a los débiles...");
            continuePressed = false;
            while (!continuePressed) yield return null;
        }

        // ================================================================ HUD

        private void RefreshHud()
        {
            if (ui == null) return;
            string badge = hakiTurns > 0 ? "HAKI" : guarding ? "GUARDIA" : HasFruit ? "FRUTA" : "";
            ui.SetPlayer(heroName, heroSprite, hp, maxHp, st, maxSt, badge, StatusText(heroStatus, heroStunned), "");
            string eBadge = E.boss ? "JEFE" : foeGuarding ? "GUARDIA" : foeCharging ? "CARGANDO" : "";
            string extra = E.bounty > 0 ? $"Se busca: {E.bounty:N0} B" : "";
            ui.SetEnemy(E.name, E.sprite, E.hp, E.maxHp, eBadge, StatusText(foeStatus, foeStunned), extra, enemyIndex, setup.enemies.Count);
        }

        private static string StatusText(Dictionary<StatusType, int> set, bool stunned)
        {
            List<string> parts = new List<string>();
            foreach (KeyValuePair<StatusType, int> kv in set)
            {
                string n = kv.Key == StatusType.Bleeding ? "Sangrado" : kv.Key == StatusType.Poisoned ? "Veneno" : kv.Key == StatusType.Burning ? "Quemadura" : kv.Key.ToString();
                parts.Add($"{n} ({kv.Value})");
            }
            if (stunned) parts.Add("Aturdido");
            return string.Join(" · ", parts);
        }

        // ================================================================ Sonido

        private static void Sfx(Action<AudioManager> play)
        {
            if (AudioManager.Instance != null) play(AudioManager.Instance);
        }

        private static void PlaySound(string kind)
        {
            switch (kind)
            {
                case "slash": Sfx(a => a.PlaySlash()); break;
                case "hit": Sfx(a => a.PlayHit()); break;
                default: Sfx(a => a.PlayBlunt()); break;
            }
        }
    }
}
