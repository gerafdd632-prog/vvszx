﻿using System.Collections;
using UnityEngine;

namespace PirateSurvival.Combat3D
{
    /// <summary>
    /// Luchador en la arena 3D: el sprite de pixel art (con contorno) en un panel que mira a la cámara, con sombra,
    /// anillo de equipo, respiración, vuelo, y animaciones de combate: carrera, salto en arco, giro, embestida,
    /// retroceso al recibir, esquiva con imágenes residuales, guardia con escudo, aura, mareo, desmayo y celebración.
    /// La raíz del objeto se queda en su puesto; las animaciones mueven el cuerpo con desplazamientos.
    /// </summary>
    public class Combat3DCharacter : MonoBehaviour
    {
        public string DisplayName { get; private set; }
        public bool IsPlayer { get; private set; }
        public float Height { get; private set; } = 2f;
        public bool Flies { get; private set; }
        public bool Fainted { get; private set; }

        private Transform body;
        private Mesh bodyMesh;
        private Material bodyMat;
        private Texture bodyTex;
        private Transform shadow;
        private MeshRenderer ring;
        private Color ringColor;
        private Transform shield;
        private MeshRenderer shieldRenderer;
        private Combat3DVFX vfx;
        private Camera cam;
        private MaterialPropertyBlock block;

        // Canales de animación (se suman)
        private Vector3 moveOffset;     // carreras, saltos, esquivas (mundo)
        private Vector3 hitOffset;      // retroceso al recibir (mundo)
        private float jumpY;
        private float spin;             // grados extra de giro sobre sí mismo
        private float lean;             // inclinación lateral en pantalla
        private float squash;           // >0 aplasta, <0 estira
        private float faint;            // 0..1 caída
        private float flash;
        private Color flashColor = Color.white;
        private float alpha = 1f;
        private bool active;
        private bool guarding;
        private Color? auraColor;
        private bool stunned;
        private float fxTimer;
        private bool celebrating;

        public Vector3 Feet => transform.position + moveOffset + hitOffset + Vector3.up * jumpY;
        public Vector3 Chest => Feet + Vector3.up * (Height * 0.5f + HoverHeight);
        public Vector3 Head => Feet + Vector3.up * (Height * 0.85f + HoverHeight);
        public Vector3 Home => transform.position;
        private float HoverHeight => Flies ? 0.9f + Mathf.Sin(Combat3DTime.Now * 3.6f) * 0.15f : 0f;
        public Transform BodyTransform => body;
        public Mesh BodyMesh => bodyMesh;
        public Texture BodyTexture => bodyTex;

        public void Setup(string displayName, Sprite sprite, float height, bool isPlayer, bool flies, Combat3DVFX effects, Camera viewCamera)
        {
            DisplayName = displayName;
            IsPlayer = isPlayer;
            Height = Mathf.Max(0.5f, height);
            Flies = flies;
            vfx = effects;
            cam = viewCamera;
            block = new MaterialPropertyBlock();
            ringColor = isPlayer ? new Color(0.35f, 1f, 0.6f, 0.75f) : new Color(1f, 0.35f, 0.3f, 0.75f);

            // Cuerpo: panel con el sprite contorneado, pivote en los pies
            Combat3DAssets.OutlinedSprite os = Combat3DAssets.Outline(sprite);
            bodyTex = os.texture;
            float h = Height, w = Height * os.aspect;
            float px = os.pivot01.x * w, py = os.pivot01.y * h;
            bodyMesh = new Mesh { name = "c3d_body_" + displayName };
            bodyMesh.vertices = new[] { new Vector3(-px, -py, 0f), new Vector3(-px, h - py, 0f), new Vector3(w - px, h - py, 0f), new Vector3(w - px, -py, 0f) };
            bodyMesh.uv = new[] { new Vector2(0f, 0f), new Vector2(0f, 1f), new Vector2(1f, 1f), new Vector2(1f, 0f) };
            bodyMesh.colors = new[] { Color.white, Color.white, Color.white, Color.white };
            bodyMesh.triangles = new[] { 0, 1, 2, 0, 2, 3 };
            bodyMesh.RecalculateBounds();

            GameObject b = new GameObject("Body");
            b.transform.SetParent(transform, false);
            b.AddComponent<MeshFilter>().sharedMesh = bodyMesh;
            MeshRenderer br = b.AddComponent<MeshRenderer>();
            bodyMat = Combat3DAssets.NewLit(bodyTex, Color.white, true, 0.5f);
            bodyMat.SetFloat("_FogAmount", 0.25f);
            br.sharedMaterial = bodyMat;
            br.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            body = b.transform;

            // Sombra suave en el suelo
            GameObject s = new GameObject("Shadow");
            s.transform.SetParent(transform, false);
            s.AddComponent<MeshFilter>().sharedMesh = Combat3DAssets.GroundQuad;
            MeshRenderer sr = s.AddComponent<MeshRenderer>();
            sr.sharedMaterial = Combat3DAssets.Fx("softcircle", false);
            sr.sortingOrder = 6;
            Combat3DAssets.SetColor(sr, block, new Color(0f, 0f, 0.02f, 0.55f));
            shadow = s.transform;

            // Anillo de equipo
            GameObject r = new GameObject("TeamRing");
            r.transform.SetParent(transform, false);
            r.transform.localPosition = Vector3.up * 0.03f;
            r.AddComponent<MeshFilter>().sharedMesh = Combat3DAssets.GroundQuad;
            ring = r.AddComponent<MeshRenderer>();
            ring.sharedMaterial = Combat3DAssets.Fx("ring", true);
            ring.sortingOrder = 7;
            float rs = Mathf.Clamp(Height * 1.1f, 1.4f, 2.8f);
            r.transform.localScale = new Vector3(rs, 1f, rs);
            Combat3DAssets.SetColor(ring, block, ringColor);
        }

        public void SetCamera(Camera c) => cam = c;
        public void SetTurnActive(bool on) => active = on;
        public void SetGuard(bool on) => guarding = on;
        public void SetAura(Color? color) => auraColor = color;
        public void SetStunned(bool on) => stunned = on;
        public void SetTint(Color c) { if (bodyMat != null) bodyMat.color = c; }

        public void Flash(Color c, float amount = 1f)
        {
            flashColor = c;
            flash = Mathf.Max(flash, amount);
        }

        // ================================================================ Bucle visual

        private void LateUpdate()
        {
            float dt = Combat3DTime.Delta;
            float t = Combat3DTime.Now;
            if (body == null) return;

            float breath = Fainted ? 0f : Mathf.Sin(t * 3.2f + (IsPlayer ? 0f : 1.3f)) * 0.025f;
            float hover = HoverHeight;
            body.position = transform.position + moveOffset + hitOffset + Vector3.up * (jumpY + hover);

            // Panel mirando a la cámara (solo giro horizontal) + giro propio + inclinación + caída
            Vector3 dir = cam != null ? body.position - cam.transform.position : Vector3.forward;
            dir.y = 0f;
            if (dir.sqrMagnitude < 1e-5f) dir = Vector3.forward;
            body.rotation = Quaternion.LookRotation(dir.normalized, Vector3.up) * Quaternion.Euler(0f, spin, 0f) * Quaternion.Euler(faint * 82f, 0f, lean);

            float sq = squash;
            body.localScale = new Vector3(1f - breath * 0.5f + sq * 0.6f, 1f + breath - sq, 1f);

            // Sombra: se encoge al saltar o volar
            float lift = jumpY + hover;
            Vector3 feetGround = transform.position + moveOffset + hitOffset;
            shadow.position = new Vector3(feetGround.x, transform.position.y + 0.04f, feetGround.z);
            float ss = Mathf.Clamp(Height * 0.75f, 0.8f, 2.2f) * Mathf.Lerp(1f, 0.55f, Mathf.Clamp01(lift / 2.5f));
            shadow.localScale = new Vector3(ss, 1f, ss * 0.8f);

            // Anillo del turno
            if (ring != null)
            {
                ring.transform.position = new Vector3(feetGround.x, transform.position.y + 0.05f, feetGround.z);
                ring.transform.rotation = Quaternion.Euler(0f, t * 40f, 0f);
                float a = Fainted ? 0f : active ? 0.55f + Mathf.Sin(t * 6f) * 0.25f : 0.22f;
                Combat3DAssets.SetColor(ring, block, new Color(ringColor.r, ringColor.g, ringColor.b, a));
            }

            // Destello al recibir
            if (flash > 0f)
            {
                flash = Mathf.Max(0f, flash - dt * 6f);
                bodyMat.SetColor("_FlashColor", flashColor);
                bodyMat.SetFloat("_Flash", flash);
            }

            // Escudo de guardia
            UpdateShield(t);

            // Auras y mareo
            fxTimer -= dt;
            if (fxTimer <= 0f && vfx != null && !Fainted)
            {
                fxTimer = 0.12f;
                if (auraColor.HasValue) vfx.Aura(Feet + Vector3.up * hover, auraColor.Value, 2);
                if (stunned && Random.value < 0.35f) vfx.Stars(Head + Vector3.up * 0.2f);
            }
        }

        private void UpdateShield(float t)
        {
            if (!guarding && shield == null) return;
            if (shield == null)
            {
                GameObject s = new GameObject("GuardShield");
                s.transform.SetParent(transform, false);
                s.AddComponent<MeshFilter>().sharedMesh = Combat3DAssets.Quad;
                shieldRenderer = s.AddComponent<MeshRenderer>();
                shieldRenderer.sharedMaterial = Combat3DAssets.Fx("ring", true);
                shieldRenderer.sortingOrder = 15;
                shield = s.transform;
            }
            shield.gameObject.SetActive(guarding);
            if (!guarding) return;
            shield.position = Chest + (cam != null ? (cam.transform.position - Chest).normalized * 0.25f : Vector3.zero);
            if (cam != null) shield.rotation = Quaternion.LookRotation(shield.position - cam.transform.position, Vector3.up);
            float s2 = Height * 1.25f * (1f + Mathf.Sin(t * 5f) * 0.04f);
            shield.localScale = new Vector3(s2, s2, 1f);
            Combat3DAssets.SetColor(shieldRenderer, block, new Color(0.4f, 0.85f, 1f, 0.55f + Mathf.Sin(t * 7f) * 0.15f));
        }

        // ================================================================ Animaciones (corrutinas)

        private static float Ease(float k) => k * k * (3f - 2f * k);

        /// <summary>Lleva los pies a 'worldTarget' en 'dur' segundos con un arco opcional. ghosts = imágenes residuales.</summary>
        public IEnumerator MoveTo(Vector3 worldTarget, float dur, float arc = 0f, bool ghosts = false, float leanDeg = 0f)
        {
            Vector3 start = moveOffset;
            Vector3 end = worldTarget - transform.position;
            end.y = 0f;
            float t = 0f, ghostTimer = 0f;
            while (t < dur)
            {
                float dt = Combat3DTime.Delta;
                t += dt;
                float k = Mathf.Clamp01(t / Mathf.Max(0.001f, dur));
                moveOffset = Vector3.Lerp(start, end, Ease(k));
                jumpY = arc * 4f * k * (1f - k);
                lean = leanDeg * Mathf.Sin(k * Mathf.PI);
                ghostTimer -= dt;
                if (ghosts && ghostTimer <= 0f && vfx != null)
                {
                    ghostTimer = 0.035f;
                    vfx.Ghost(body, bodyMesh, bodyTex, IsPlayer ? new Color(0.6f, 0.9f, 1f) : new Color(1f, 0.6f, 0.5f));
                }
                yield return null;
            }
            moveOffset = end;
            jumpY = 0f;
            lean = 0f;
        }

        public IEnumerator ReturnHome(float dur, float arc = 0f) => MoveTo(transform.position, dur, arc);

        /// <summary>Carga del golpe: se echa hacia atrás encogiéndose.</summary>
        public IEnumerator Windup(Vector3 towards, float dur, float amount = 0.35f)
        {
            Vector3 back = -(towards - Feet);
            back.y = 0f;
            back = back.sqrMagnitude > 0.001f ? back.normalized : Vector3.zero;
            Vector3 start = moveOffset;
            float t = 0f;
            while (t < dur)
            {
                t += Combat3DTime.Delta;
                float k = Mathf.Clamp01(t / dur);
                moveOffset = start + back * amount * Ease(k);
                squash = 0.12f * Ease(k);
                yield return null;
            }
            squash = -0.08f; // al soltar se estira
        }

        public void ResetPose()
        {
            squash = 0f;
            lean = 0f;
            spin = 0f;
        }

        /// <summary>Giro completo sobre sí mismo (patada giratoria, celebración).</summary>
        public IEnumerator Spin(float dur, float turns)
        {
            float t = 0f;
            while (t < dur)
            {
                t += Combat3DTime.Delta;
                spin = Mathf.Lerp(0f, 360f * turns, Ease(Mathf.Clamp01(t / dur)));
                yield return null;
            }
            spin = 0f;
        }

        /// <summary>Recibe un golpe: destello, retroceso desde 'fromPos' y vibración.</summary>
        public void Hit(Vector3 fromPos, float force, Color flashCol)
        {
            Flash(flashCol, 1f);
            StartCoroutine(HitRoutine(fromPos, force));
        }

        private IEnumerator HitRoutine(Vector3 fromPos, float force)
        {
            Vector3 away = Feet - fromPos;
            away.y = 0f;
            away = away.sqrMagnitude > 0.001f ? away.normalized : (IsPlayer ? Vector3.left : Vector3.right);
            float t = 0f, dur = 0.38f + force * 0.12f;
            while (t < dur)
            {
                t += Combat3DTime.Delta;
                float k = Mathf.Clamp01(t / dur);
                float push = Mathf.Sin(Mathf.Min(1f, k * 1.6f) * Mathf.PI * 0.5f) * (1f - Mathf.Max(0f, k - 0.5f) * 2f);
                float shake = (1f - k) * 0.06f * force;
                hitOffset = away * push * 0.55f * force + new Vector3(Random.Range(-shake, shake), 0f, Random.Range(-shake, shake));
                lean = (IsPlayer ? 12f : -12f) * force * (1f - k);
                squash = 0.1f * force * (1f - k);
                yield return null;
            }
            hitOffset = Vector3.zero;
            lean = 0f;
            squash = 0f;
        }

        /// <summary>Esquiva lateral rápida con imágenes residuales.</summary>
        public IEnumerator Dodge(Vector3 attackerPos)
        {
            Vector3 toAtt = attackerPos - Feet; toAtt.y = 0f;
            Vector3 side = Vector3.Cross(Vector3.up, toAtt.normalized);
            if (Random.value < 0.5f) side = -side;
            Vector3 start = Feet;
            yield return MoveTo(start + side * 1.1f, 0.12f, 0.35f, true, IsPlayer ? -15f : 15f);
            yield return Combat3DTime.Wait(0.12f);
            yield return MoveTo(start, 0.2f, 0f, false);
        }

        public IEnumerator Hop(int count, float height)
        {
            for (int i = 0; i < count; i++)
            {
                float t = 0f;
                while (t < 0.32f)
                {
                    t += Combat3DTime.Delta;
                    float k = Mathf.Clamp01(t / 0.32f);
                    jumpY = height * 4f * k * (1f - k);
                    squash = k < 0.15f ? 0.12f : -0.06f;
                    yield return null;
                }
                jumpY = 0f;
                squash = 0f;
            }
        }

        /// <summary>Celebración en bucle (victoria) hasta que se llame a StopCelebrating.</summary>
        public IEnumerator Celebrate()
        {
            celebrating = true;
            while (celebrating && !Fainted)
            {
                yield return Hop(2, 0.45f);
                yield return Spin(0.35f, 1f);
                yield return Combat3DTime.Wait(0.5f);
            }
        }

        public void StopCelebrating() => celebrating = false;

        public IEnumerator Faint()
        {
            Fainted = true;
            active = false;
            guarding = false;
            auraColor = null;
            stunned = false;
            float t = 0f;
            if (Flies)
            {
                // Los voladores caen al suelo
                while (t < 0.35f)
                {
                    t += Combat3DTime.Delta;
                    jumpY = Mathf.Lerp(0f, -0.9f, t / 0.35f);
                    yield return null;
                }
                Flies = false;
                jumpY = 0f;
                t = 0f;
            }
            while (t < 0.5f)
            {
                t += Combat3DTime.Delta;
                faint = Ease(Mathf.Clamp01(t / 0.5f));
                yield return null;
            }
            if (vfx != null) vfx.Dust(Feet, 10, 0.6f, new Color(0.85f, 0.78f, 0.65f, 0.7f));
            t = 0f;
            while (t < 0.6f)
            {
                t += Combat3DTime.Delta;
                alpha = 1f - Mathf.Clamp01(t / 0.6f) * 0.5f;
                if (bodyMat != null) bodyMat.color = new Color(alpha, alpha, alpha, 1f);
                yield return null;
            }
        }

        /// <summary>Entrada en escena desde lejos (siguiente rival).</summary>
        public IEnumerator EnterFrom(Vector3 worldStart, float dur)
        {
            moveOffset = worldStart - transform.position;
            moveOffset.y = 0f;
            yield return MoveTo(transform.position, dur, 0.4f, false);
        }

        public void PlaceAt(Vector3 worldPos)
        {
            moveOffset = worldPos - transform.position;
            moveOffset.y = 0f;
        }

        private void OnDestroy()
        {
            if (bodyMesh != null) Destroy(bodyMesh);
            if (bodyMat != null) Destroy(bodyMat);
        }
    }
}
