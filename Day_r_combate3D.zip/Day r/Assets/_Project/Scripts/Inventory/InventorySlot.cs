﻿using System;
using UnityEngine;

namespace PirateSurvival.Inventory
{
    /// <summary>
    /// Modelo de datos de un hueco individual en el inventario.
    /// </summary>
    [Serializable]
    public class InventorySlot
    {
        [SerializeField] private ItemData itemData;
        [SerializeField] private int quantity;
        [SerializeField] private int durability; // solo para objetos con maxDurability > 0

        public ItemData ItemData => itemData;
        public int Quantity => quantity;
        public bool IsEmpty => itemData == null || quantity <= 0;
        public int Durability => durability;

        public InventorySlot()
        {
            itemData = null;
            quantity = 0;
        }

        public InventorySlot(ItemData item, int count)
        {
            itemData = item;
            quantity = count;
        }

        public void Set(ItemData item, int count)
        {
            Set(item, count, 0);
        }

        /// <summary>savedDurability 0 = nueva (máxima).</summary>
        public void Set(ItemData item, int count, int savedDurability)
        {
            itemData = item;
            quantity = count;
            int max = item != null ? item.maxDurability : 0;
            durability = savedDurability > 0 ? Math.Min(savedDurability, max > 0 ? max : savedDurability) : max;
        }

        public void SetDurability(int value)
        {
            durability = value;
        }

        public void Clear()
        {
            itemData = null;
            quantity = 0;
            durability = 0;
        }

        public int AddQuantity(int amount)
        {
            if (itemData == null) return amount;

            int availableSpace = itemData.maxStackSize - quantity;
            int amountToAdd = Math.Min(amount, availableSpace);

            quantity += amountToAdd;
            return amount - amountToAdd; // Devuelve el sobrante si se excede el stack
        }

        public bool RemoveQuantity(int amount)
        {
            if (quantity < amount) return false;

            quantity -= amount;
            if (quantity <= 0)
            {
                Clear();
            }
            return true;
        }

        public float GetTotalWeight()
        {
            if (IsEmpty) return 0f;
            return itemData.weight * quantity;
        }
    }
}
