﻿using UnityEngine;

namespace PirateSurvival.Inventory
{
    public enum ItemType
    {
        Food,
        Drink,
        Material,
        Tool,
        Weapon,
        Medicine,
        DevilFruit
    }

    /// <summary>Tipo de daño en combate. Importa contra ciertos poderes (p. ej. la goma resiste golpes y balas).</summary>
    public enum CombatDamageType
    {
        Blunt,
        Slash,
        Pierce,
        Fire,
        Explosion,
        Haki
    }

    public enum ToolType
    {
        None,
        Axe,
        Pickaxe,
        Cutlass
    }

    /// <summary>
    /// Definición de datos de un objeto mediante ScriptableObject en 2D.
    /// Valida que las herramientas y armas no puedan apilarse (maxStackSize = 1) para proteger la lógica de equipamiento (A2.15).
    /// </summary>
    [CreateAssetMenu(fileName = "NewItem", menuName = "Pirate Survival/Item Data")]
    public class ItemData : ScriptableObject
    {
        [Header("Información Básica")]
        public string itemId;
        public string id => itemId;
        public string itemName;
        [TextArea(2, 4)]
        public string description;
        public Sprite icon;
        public ItemType itemType;
        public GameObject worldPrefab; // Prefab 2D para soltar en el mundo (con SpriteRenderer y Collider2D)
        [Tooltip("Objeto importante (Fruta del Diablo, misión, pieza de barco...): nunca desaparece del suelo por el despawn genérico")]
        public bool neverDespawn = false;

        [Header("Propiedades Físicas")]
        [Tooltip("Peso por unidad en kilogramos")]
        public float weight = 0.5f;
        [Tooltip("Capacidad máxima de apilado en un solo hueco (Forzado a 1 en herramientas/armas)")]
        public int maxStackSize = 20;

        [Header("Efectos de Consumible (Comida / Bebida)")]
        public float healthRestore = 0f;
        public float hungerRestore = 0f;
        public float thirstRestore = 0f;
        public float staminaRestore = 0f;
        public float temperatureChange = 0f;

        [Header("Propiedades de Herramienta / Arma")]
        public ToolType toolType = ToolType.None;
        public float resourceDamage = 10f; // Daño contra recursos del entorno (árboles o rocas)
        public GameObject equippedPrefab; // Prefab 2D que se acopla visualmente al jugador

        [Header("Combate Táctico (0 de daño = no sirve como arma)")]
        public int combatDamage = 0;
        public int combatMinRange = 1;
        public int combatMaxRange = 1;
        public int combatApCost = 2;
        [Range(0f, 1f)] public float combatAccuracy = 0.85f;
        [Range(0f, 1f)] public float combatCritChance = 0.05f;
        public CombatDamageType combatDamageType = CombatDamageType.Blunt;
        public CombatDamageType damageType => combatDamageType;
        [Tooltip("Usos en combate antes de romperse (0 = indestructible)")]
        public int maxDurability = 0;
        [Tooltip("itemId de la munición que consume cada ataque (vacío = no usa)")]
        public string ammoItemId = "";
        [Tooltip("Arma de Kairoseki: anula a los usuarios de Fruta del Diablo")]
        public bool kairoseki = false;

        [Header("Medicina")]
        public bool curesBleeding = false;
        public bool curesPoison = false;

        [Header("Fruta del Diablo")]
        [Tooltip("Id de la fruta en DevilFruitManager (p. ej. \"elastica\")")]
        public string devilFruitId = "";

        private void OnValidate()
        {
            if (string.IsNullOrEmpty(itemId))
            {
                itemId = name;
            }

            // Bug A2.15 resuelto: Herramientas y armas nunca deben apilarse
            if (itemType == ItemType.Tool || itemType == ItemType.Weapon)
            {
                maxStackSize = 1;
            }
            else if (maxStackSize < 1)
            {
                maxStackSize = 1;
            }

            if (weight < 0f) weight = 0f;
        }
    }
}
