﻿using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using PirateSurvival.Core;

namespace PirateSurvival.Inventory.UI
{
    /// <summary>
    /// Casilla de inventario 2D sin dependencias de TextMeshPro (Item B, Punto 8).
    /// Soporta arrastre seguro sin iconos huérfanos, clic para equipar/usar, Shift-clic para soltar,
    /// y eventos de puntero (hover) para mostrar tooltip con nombre, descripción y peso.
    /// </summary>
    public class InventorySlotUI : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler, IDropHandler, IPointerClickHandler, IPointerEnterHandler, IPointerExitHandler
    {
        [Header("Elementos de UI Estándar")]
        [SerializeField] private Image iconImage;
        [SerializeField] private Text quantityText;
        [SerializeField] private GameObject selectionBorder;

        private int slotIndex;
        private Canvas canvas;
        private static GameObject dragIconClone;

        public int SlotIndex => slotIndex;

        public void Initialize(int index, Canvas parentCanvas)
        {
            slotIndex = index;
            canvas = parentCanvas;
        }

        public void UpdateSlot(InventorySlot slot)
        {
            if (slot == null || slot.IsEmpty)
            {
                if (iconImage != null)
                {
                    iconImage.enabled = false;
                    iconImage.sprite = null;
                }
                if (quantityText != null) quantityText.text = string.Empty;
                if (selectionBorder != null) selectionBorder.SetActive(false);
            }
            else
            {
                if (iconImage != null)
                {
                    iconImage.enabled = true;
                    iconImage.sprite = slot.ItemData.icon;
                }
                if (quantityText != null)
                {
                    quantityText.text = slot.Quantity > 1 ? slot.Quantity.ToString() : string.Empty;
                }

                bool isEquipped = (InventoryManager.Instance != null && InventoryManager.Instance.EquippedSlotIndex == slotIndex);
                if (selectionBorder != null)
                {
                    selectionBorder.SetActive(isEquipped);
                }
            }
        }

        public void OnBeginDrag(PointerEventData eventData)
        {
            if (InventoryManager.Instance == null || canvas == null) return;
            if (slotIndex >= InventoryManager.Instance.Slots.Count) return;

            var slot = InventoryManager.Instance.Slots[slotIndex];
            if (slot.IsEmpty || slot.ItemData == null) return;

            CleanupDragIcon();

            dragIconClone = new GameObject("DragIcon", typeof(RectTransform), typeof(CanvasGroup), typeof(Image));
            dragIconClone.transform.SetParent(canvas.transform, false);
            dragIconClone.transform.SetAsLastSibling();

            Image cloneImg = dragIconClone.GetComponent<Image>();
            cloneImg.sprite = slot.ItemData.icon;
            cloneImg.raycastTarget = false;

            RectTransform cloneRect = dragIconClone.GetComponent<RectTransform>();
            cloneRect.sizeDelta = new Vector2(48, 48);
            cloneRect.position = eventData.position;

            CanvasGroup group = dragIconClone.GetComponent<CanvasGroup>();
            group.alpha = 0.75f;
            group.blocksRaycasts = false;
        }

        public void OnDrag(PointerEventData eventData)
        {
            if (dragIconClone != null)
            {
                dragIconClone.transform.position = eventData.position;
            }
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            CleanupDragIcon();
        }

        public void OnDrop(PointerEventData eventData)
        {
            GameObject dragged = eventData.pointerDrag;
            if (dragged != null)
            {
                InventorySlotUI sourceSlot = dragged.GetComponent<InventorySlotUI>();
                if (sourceSlot != null && sourceSlot != this && InventoryManager.Instance != null)
                {
                    InventoryManager.Instance.SwapOrCombineSlots(sourceSlot.SlotIndex, slotIndex);
                }
            }
        }

        public void OnPointerClick(PointerEventData eventData)
        {
            if (InventoryManager.Instance == null) return;

            // Shift + Clic: Soltar objeto al suelo
            if (GameInput.IsShiftHeld())
            {
                InventoryManager.Instance.DropItem(slotIndex, 1);
            }
            else
            {
                // Clic simple: Usar o Equipar
                InventoryManager.Instance.UseItem(slotIndex);
            }
        }

        public void OnPointerEnter(PointerEventData eventData)
        {
            if (InventoryManager.Instance == null || slotIndex >= InventoryManager.Instance.Slots.Count) return;

            var slot = InventoryManager.Instance.Slots[slotIndex];
            if (!slot.IsEmpty && slot.ItemData != null)
            {
                InventoryUI invUI = GetComponentInParent<InventoryUI>();
                if (invUI == null) invUI = FindAnyObjectByType<InventoryUI>();
                if (invUI != null)
                {
                    invUI.ShowTooltip(slot.ItemData, eventData.position);
                }
            }
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            InventoryUI invUI = GetComponentInParent<InventoryUI>();
            if (invUI == null) invUI = FindAnyObjectByType<InventoryUI>();
            if (invUI != null)
            {
                invUI.HideTooltip();
            }
        }

        /// <summary>
        /// Punto 8: Limpia cualquier icono huérfano de arrastre al cerrar el panel o cancelar.
        /// </summary>
        public static void CleanupDragIcon()
        {
            if (dragIconClone != null)
            {
                Destroy(dragIconClone);
                dragIconClone = null;
            }
        }

        private void OnDisable()
        {
            CleanupDragIcon();
        }
    }
}
