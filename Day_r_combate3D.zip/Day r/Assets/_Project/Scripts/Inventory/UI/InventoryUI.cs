﻿using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.UI;
using PirateSurvival.Core;
using PirateSurvival.Player;
using PirateSurvival.Crafting;
using PirateSurvival.Story;
using PirateSurvival.UI;

namespace PirateSurvival.Inventory.UI
{
    /// <summary>
    /// Mochila al estilo Day R con estética pirata. Cuatro pestañas:
    ///  - MOCHILA: equipo en la mano, estado del jugador, rejilla de objetos con estado y peso, ficha del objeto con acciones.
    ///  - FABRICAR: categorías, recetas (con estación y materiales que tienes/faltan) y botón de fabricar con tiempo.
    ///  - DIARIO: capítulo y objetivos de la historia, tripulación.
    ///  - SE BUSCA: tu cartel de recompensa de la Marina y tus poderes.
    /// [Tab]/[I] abre y cierra, [Esc] cierra. Clic selecciona, doble clic usa o equipa.
    /// Se construye solo por código (GameUIBuilder solo crea el objeto).
    /// </summary>
    public class InventoryUI : MonoBehaviour
    {
        private enum Tab { Bag, Craft, Journal, Wanted }

        public enum ItemRarity { Common, Rare, Epic, Legendary }

        public static ItemRarity GetRarity(ItemData item)
        {
            if (item == null) return ItemRarity.Common;
            if (item.id == "itemFruta" || item.id == "itemKairoseki" || item.id == "sombrero_paja" || item.id == "espada_meito")
                return ItemRarity.Legendary;
            if (item.itemType == ItemType.Weapon && item.combatDamage >= 18)
                return ItemRarity.Epic;
            if (item.id.Contains("katana") || item.id.Contains("fusil") || item.id == "itemLingote" || item.id == "itemCarneAsada" || item.id == "ron_pirata")
                return ItemRarity.Epic;
            if (item.itemType == ItemType.Tool || item.itemType == ItemType.Weapon || item.itemType == ItemType.Medicine || item.id == "itemMineral" || item.id == "itemCarbon" || item.id == "itemAzufre")
                return ItemRarity.Rare;
            return ItemRarity.Common;
        }

        public static Color RarityColor(ItemRarity rarity)
        {
            switch (rarity)
            {
                case ItemRarity.Legendary: return new Color(1f, 0.82f, 0.22f); // Golden amber
                case ItemRarity.Epic: return new Color(0.76f, 0.40f, 1f);       // Royal purple
                case ItemRarity.Rare: return new Color(0.24f, 0.75f, 1f);       // Azure cyan
                default: return new Color(0.68f, 0.74f, 0.82f);                 // Slate steel
            }
        }

        public static string RarityLabel(ItemRarity rarity)
        {
            switch (rarity)
            {
                case ItemRarity.Legendary: return "★ LEGENDARIO";
                case ItemRarity.Epic: return "◆ ÉPICO";
                case ItemRarity.Rare: return "▲ RARO";
                default: return "● COMÚN";
            }
        }

        private class SlotView
        {
            public Image bg, icon, durFill, typeBadge, rarityBorder, selectHighlight;
            public GameObject durBar, equippedMark, qtyBadge;
            public Text qty;
        }

        private class RecipeRow
        {
            public Button button;
            public Image bg, icon, rarityBorder, selectHighlight;
            public Text name, info;
        }

        private const int Columns = 5;
        private const float SlotSize = 112f;
        private const float SlotGap = 8f;
        private const int MaxRecipeRows = 11;

        public static InventoryUI Instance { get; private set; }
        /// <summary>Frame en el que ESC cerró la mochila; el menú de pausa lo usa para no abrirse en el mismo pulso.</summary>
        public static int CancelConsumedFrame = -1;

        public bool IsOpen => isOpen;

        private bool isOpen;
        private Tab tab = Tab.Bag;
        private PlayerStats playerStats;
        private PlayerProgress progress;

        private GameObject root;
        private readonly RectTransform[] pages = new RectTransform[4];
        private readonly Button[] tabButtons = new Button[4];
        private Text statusText;
        private float statusTimer;

        // Mochila
        private readonly List<SlotView> slotViews = new List<SlotView>();
        private int selected = -1;
        private int lastClickIndex = -1;
        private float lastClickTime;
        private Image detailIcon, equippedIcon, equippedDurFill, weightFill;
        private Text detailName, detailType, detailDesc, detailStats, equippedName, weightText;
        private Button useBtn, equipBtn, dropOneBtn, dropAllBtn, unequipBtn;
        private readonly Image[] statFills = new Image[4];
        private readonly Text[] statTexts = new Text[4];

        // Fabricar
        private RecipeCategory? category;
        private readonly Button[] categoryButtons = new Button[8];
        private readonly List<Recipe> visibleRecipes = new List<Recipe>();
        private readonly RecipeRow[] recipeRows = new RecipeRow[MaxRecipeRows];
        private Recipe selectedRecipe;
        private Recipe craftingRecipe; // la receta que se está fabricando (no cambia aunque se pulse otra)
        private Image recipeIcon, craftProgressFill;
        private Text recipeName, recipeDesc, recipeStation, recipeIngredients, recipeTime;
        private Button craftBtn;
        private bool crafting;
        private float craftTimer;
        private Text stationBanner;

        // Diario
        private Text journalChapter, journalSteps, journalCrew;

        // Se busca
        private Image posterPortrait;
        private Text posterBounty, wantedStats;

        // ================================================================== Ciclo de vida

        private void Awake()
        {
            Instance = this;
            Build();
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        private void OnEnable()
        {
            GameEvents.OnInventoryUpdated += RefreshAll;
            GameEvents.OnEquippedToolChanged += HandleEquippedChanged;
            GameEvents.OnPlayerDeath += HandlePlayerDeath;
            GameEvents.OnPlayerFaint += HandlePlayerFaint;
            GameEvents.OnNotificationMessage += ShowStatus;
        }

        private void OnDisable()
        {
            GameEvents.OnInventoryUpdated -= RefreshAll;
            GameEvents.OnEquippedToolChanged -= HandleEquippedChanged;
            GameEvents.OnPlayerDeath -= HandlePlayerDeath;
            GameEvents.OnPlayerFaint -= HandlePlayerFaint;
            GameEvents.OnNotificationMessage -= ShowStatus;
        }

        private void HandleEquippedChanged(string id) => RefreshAll();
        private void HandlePlayerDeath() => CloseInventory();
        private void HandlePlayerFaint(bool fainted) { if (fainted && isOpen) CloseInventory(); }

        private void Update()
        {
            if (GameInput.IsInventoryTogglePressed()) ToggleInventory();

            if (!isOpen) return;

            // Con una confirmación abierta (p. ej. comer la Fruta) ESC es para la confirmación, no para la mochila
            if (!GameInput.ModalBlocked && GameInput.IsCancelPressed())
            {
                CancelConsumedFrame = Time.frameCount;
                CloseInventory();
                return;
            }

            if (statusTimer > 0f)
            {
                statusTimer -= Time.unscaledDeltaTime;
                if (statusTimer <= 0f) statusText.text = string.Empty;
            }

            if (crafting) UpdateCrafting();
            else if (tab == Tab.Bag) RefreshPlayerStats();
        }

        // ================================================================== Abrir / cerrar

        public void ToggleInventory()
        {
            if (isOpen) CloseInventory();
            else OpenInventory();
        }

        public void OpenInventory()
        {
            if (playerStats == null) playerStats = FindAnyObjectByType<PlayerStats>();
            if (progress == null && playerStats != null) progress = playerStats.GetComponent<PlayerProgress>();
            if (playerStats != null && (playerStats.IsDead || playerStats.IsFainted)) return;
            if (!GameState.IsPlaying) return;

            isOpen = true;
            root.SetActive(true);
            GameEvents.TriggerInventoryToggle(true);
            ShowTab(tab);
        }

        /// <summary>Abre directamente en Fabricar (al usar una mesa de trabajo, hoguera o forja).</summary>
        public void OpenCrafting(RecipeCategory? initialCategory = null)
        {
            tab = Tab.Craft;
            if (initialCategory.HasValue) category = initialCategory.Value;
            if (!isOpen) OpenInventory();
            else ShowTab(Tab.Craft);
        }

        public void CloseInventory(bool suppressEvent = false)
        {
            bool wasOpen = isOpen;
            isOpen = false;
            crafting = false;
            if (craftProgressFill != null) craftProgressFill.fillAmount = 0f;
            if (root != null) root.SetActive(false);
            if (!suppressEvent && wasOpen) GameEvents.TriggerInventoryToggle(false);
        }

        private void ShowTab(Tab t)
        {
            tab = t;
            for (int i = 0; i < pages.Length; i++)
            {
                bool active = i == (int)t;
                pages[i].gameObject.SetActive(active);
                Text label = tabButtons[i].GetComponentInChildren<Text>();
                if (label != null)
                {
                    label.color = active ? PirateTheme.GoldText : PirateTheme.Cream;
                    label.fontSize = active ? 27 : 24;
                }
                Image btnImg = tabButtons[i].GetComponent<Image>();
                if (btnImg != null)
                {
                    btnImg.color = active ? new Color(1f, 0.95f, 0.72f) : new Color(0.72f, 0.65f, 0.58f);
                }
                tabButtons[i].transform.localScale = active ? new Vector3(1.04f, 1.08f, 1f) : Vector3.one;
            }
            RefreshAll();
        }

        private void ShowStatus(string message)
        {
            if (!isOpen || statusText == null) return;
            statusText.text = message;
            statusTimer = 4f;
        }

        // ================================================================== Refresco

        private void RefreshAll()
        {
            if (!isOpen) return;
            switch (tab)
            {
                case Tab.Bag: RefreshBag(); break;
                case Tab.Craft: RefreshCraft(); break;
                case Tab.Journal: RefreshJournal(); break;
                case Tab.Wanted: RefreshWanted(); break;
            }
        }

        private void RefreshBag()
        {
            InventoryManager inv = InventoryManager.Instance;
            if (inv == null) return;
            IReadOnlyList<InventorySlot> slots = inv.Slots;

            for (int i = 0; i < slotViews.Count; i++)
            {
                SlotView v = slotViews[i];
                bool has = i < slots.Count && !slots[i].IsEmpty;
                v.icon.enabled = has;
                v.qty.text = has && slots[i].Quantity > 1 ? slots[i].Quantity.ToString() : string.Empty;
                if (v.qtyBadge != null) v.qtyBadge.SetActive(has && slots[i].Quantity > 1);
                v.equippedMark.SetActive(has && inv.EquippedSlotIndex == i);

                bool isSelected = (i == selected);
                if (v.selectHighlight != null) v.selectHighlight.gameObject.SetActive(isSelected);
                v.bg.color = isSelected ? new Color(1f, 0.96f, 0.78f) : Color.white;

                if (!has)
                {
                    if (v.typeBadge != null) v.typeBadge.enabled = false;
                    v.durBar.SetActive(false);
                    if (v.rarityBorder != null) v.rarityBorder.gameObject.SetActive(false);
                    continue;
                }

                ItemData item = slots[i].ItemData;
                v.icon.sprite = item.icon;
                ItemRarity rarity = GetRarity(item);
                Color rCol = RarityColor(rarity);

                if (v.rarityBorder != null)
                {
                    v.rarityBorder.gameObject.SetActive(true);
                    v.rarityBorder.color = new Color(rCol.r, rCol.g, rCol.b, 0.45f);
                    Outline bo = v.rarityBorder.GetComponent<Outline>();
                    if (bo != null) bo.effectColor = new Color(rCol.r, rCol.g, rCol.b, 0.88f);
                }

                if (v.typeBadge != null)
                {
                    v.typeBadge.enabled = true;
                    v.typeBadge.color = CategoryColor(item.itemType);
                }
                bool wears = item.maxDurability > 0;
                v.durBar.SetActive(wears);
                if (wears)
                {
                    float k = Mathf.Clamp01((float)slots[i].Durability / item.maxDurability);
                    v.durFill.fillAmount = k;
                    v.durFill.color = Color.Lerp(new Color(0.85f, 0.2f, 0.15f), new Color(0.3f, 0.8f, 0.3f), k);
                }
            }

            // Equipado
            ItemData eq = inv.CurrentEquippedTool;
            equippedIcon.enabled = eq != null;
            equippedIcon.sprite = eq != null ? eq.icon : null;
            equippedName.text = eq != null ? eq.itemName : "Nada en la mano";
            bool eqWears = eq != null && eq.maxDurability > 0 && inv.EquippedSlotIndex >= 0 && inv.EquippedSlotIndex < slots.Count;
            equippedDurFill.transform.parent.gameObject.SetActive(eqWears);
            if (eqWears) equippedDurFill.fillAmount = Mathf.Clamp01((float)slots[inv.EquippedSlotIndex].Durability / eq.maxDurability);
            unequipBtn.gameObject.SetActive(eq != null);

            // Peso
            float w = inv.CalculateTotalWeight(), max = inv.MaxCarryWeight;
            weightFill.fillAmount = Mathf.Clamp01(w / Mathf.Max(0.01f, max));
            weightFill.color = w > max * 0.9f ? new Color(0.8f, 0.2f, 0.15f) : new Color(0.55f, 0.38f, 0.2f);
            weightText.text = $"Carga  {w:0.0} / {max:0} kg";

            RefreshDetail();
            RefreshPlayerStats();
        }

        private void RefreshDetail()
        {
            InventoryManager inv = InventoryManager.Instance;
            InventorySlot slot = inv != null && selected >= 0 && selected < inv.Slots.Count ? inv.Slots[selected] : null;
            bool has = slot != null && !slot.IsEmpty;
            detailIcon.enabled = has;
            useBtn.gameObject.SetActive(false);
            equipBtn.gameObject.SetActive(false);
            dropOneBtn.gameObject.SetActive(has);
            dropAllBtn.gameObject.SetActive(has && slot.Quantity > 1);
            if (!has)
            {
                detailName.text = "Elige un objeto";
                detailName.color = PirateTheme.Ink;
                detailType.text = string.Empty;
                detailDesc.text = "Haz clic en una casilla para inspeccionar sus atributos.\nDoble clic para usar o equipar de inmediato.";
                detailStats.text = string.Empty;
                return;
            }

            ItemData item = slot.ItemData;
            ItemRarity rarity = GetRarity(item);
            Color rColor = RarityColor(rarity);

            detailIcon.sprite = item.icon;
            detailName.text = item.itemName;
            detailName.color = rColor;
            detailType.text = $"{RarityLabel(rarity)}  |  [{TypeName(item.itemType).ToUpper()}]";
            detailType.color = rColor;
            detailDesc.text = item.description;
            detailStats.text = StatsText(item, slot);

            string use = UseVerb(item.itemType);
            if (use != null)
            {
                useBtn.gameObject.SetActive(true);
                useBtn.GetComponentInChildren<Text>().text = use;
            }
            if (item.itemType == ItemType.Tool || item.itemType == ItemType.Weapon)
            {
                equipBtn.gameObject.SetActive(true);
                bool equipped = inv.EquippedSlotIndex == selected;
                equipBtn.GetComponentInChildren<Text>().text = equipped ? "Desequipar" : "Equipar";
            }
        }

        private void RefreshPlayerStats()
        {
            if (playerStats == null) return;
            SetStat(0, playerStats.CurrentHealth, playerStats.MaxHealth, "Vida");
            SetStat(1, playerStats.CurrentHunger, playerStats.MaxHunger, "Hambre");
            SetStat(2, playerStats.CurrentThirst, playerStats.MaxThirst, "Sed");
            SetStat(3, playerStats.CurrentStamina, playerStats.MaxStamina, "Energía");
        }

        private void SetStat(int i, float value, float max, string label)
        {
            statFills[i].fillAmount = Mathf.Clamp01(value / Mathf.Max(1f, max));
            statTexts[i].text = $"{label}  {value:0}/{max:0}";
        }

        private void RefreshCraft()
        {
            InventoryManager inv = InventoryManager.Instance;
            Vector2 pos = playerStats != null ? (Vector2)playerStats.transform.position : Vector2.zero;

            if (stationBanner != null)
            {
                StationType nearby = StationType.None;
                if (CraftingStation.All != null)
                {
                    foreach (var s in CraftingStation.All)
                    {
                        if (s != null && s.IsInRange(pos)) { nearby = s.Type; break; }
                    }
                }
                if (nearby != StationType.None)
                {
                    stationBanner.text = $"<color=#27AE60><b>⚒️ ESTACIÓN ACTIVA: {CraftingStation.DisplayName(nearby).ToUpper()} [✔ CERCA]</b></color>";
                }
                else
                {
                    stationBanner.text = "<color=#C9933B><b>🎒 MOCHILA: Fabricación básica a mano</b></color>";
                }
            }

            visibleRecipes.Clear();
            foreach (Recipe r in RecipeBook.All)
            {
                if (category.HasValue && r.category != category.Value) continue;
                visibleRecipes.Add(r);
            }
            if (selectedRecipe == null || !visibleRecipes.Contains(selectedRecipe))
                selectedRecipe = visibleRecipes.Count > 0 ? visibleRecipes[0] : null;

            // Resaltar categoría activa
            for (int c = 0; c < categoryButtons.Length; c++)
            {
                if (categoryButtons[c] == null) continue;
                bool isActive = (c == 0 && !category.HasValue) || (category.HasValue && (int)category.Value == c - 1);
                Image img = categoryButtons[c].GetComponent<Image>();
                if (img != null) img.color = isActive ? new Color(1f, 0.92f, 0.55f) : Color.white;
                Text txt = categoryButtons[c].GetComponentInChildren<Text>();
                if (txt != null) txt.color = isActive ? PirateTheme.Ink : PirateTheme.Cream;
            }

            for (int i = 0; i < MaxRecipeRows; i++)
            {
                RecipeRow row = recipeRows[i];
                bool show = i < visibleRecipes.Count;
                row.button.gameObject.SetActive(show);
                if (!show) continue;
                Recipe r = visibleRecipes[i];
                ItemData result = ItemDatabase.Get(r.resultId);
                row.icon.sprite = result != null ? result.icon : null;
                row.icon.enabled = row.icon.sprite != null;
                bool known = CraftingSystem.IsKnown(r);
                ItemRarity rarity = GetRarity(result);
                Color rCol = RarityColor(rarity);
                row.name.text = known ? (result != null ? result.itemName : r.resultId) : "???";
                row.name.color = known ? rCol : new Color(0.65f, 0.65f, 0.65f);

                if (row.rarityBorder != null)
                {
                    row.rarityBorder.gameObject.SetActive(known && result != null);
                    Outline bo = row.rarityBorder.GetComponent<Outline>();
                    if (bo != null) bo.effectColor = new Color(rCol.r, rCol.g, rCol.b, 0.85f);
                }

                bool ready = known && CraftingSystem.CanCraft(r, inv, pos, out _);
                if (!known)
                {
                    row.info.text = "<color=#95A5A6>[🔒 BLOQUEADA]</color>";
                }
                else if (ready)
                {
                    row.info.text = "<color=#2ECC71><b>[✔ LISTO]</b></color>";
                }
                else if (r.station != StationType.None && !CraftingSystem.HasStation(r, pos))
                {
                    row.info.text = $"<color=#F39C12>[⚒️ {CraftingStation.DisplayName(r.station)}]</color>";
                }
                else
                {
                    row.info.text = "<color=#E74C3C>[✖ FALTAN MATS]</color>";
                }

                bool isSel = (r == selectedRecipe);
                if (row.selectHighlight != null) row.selectHighlight.gameObject.SetActive(isSel);
                row.bg.color = isSel ? new Color(1f, 0.95f, 0.78f) : Color.white;
            }

            RefreshRecipeDetail(inv, pos);
        }

        private void RefreshRecipeDetail(InventoryManager inv, Vector2 pos)
        {
            Recipe r = selectedRecipe;
            if (r == null)
            {
                recipeIcon.enabled = false;
                recipeName.text = "Sin recetas";
                recipeDesc.text = recipeStation.text = recipeIngredients.text = recipeTime.text = string.Empty;
                craftBtn.interactable = false;
                return;
            }
            ItemData result = ItemDatabase.Get(r.resultId);
            bool known = CraftingSystem.IsKnown(r);
            ItemRarity rarity = GetRarity(result);
            Color rColor = RarityColor(rarity);

            recipeIcon.enabled = result != null && result.icon != null;
            recipeIcon.sprite = result != null ? result.icon : null;
            recipeIcon.color = known ? Color.white : new Color(0f, 0f, 0f, 0.6f);

            string qtyTag = r.resultQuantity > 1 ? $"  x{r.resultQuantity}" : "";
            recipeName.text = known
                ? $"<color=#{ColorUtility.ToHtmlStringRGB(rColor)}>{(result != null ? result.itemName : r.resultId)}</color>{qtyTag}\n<size=19><color=#{ColorUtility.ToHtmlStringRGB(rColor)}>{RarityLabel(rarity)}</color></size>"
                : "Receta desconocida";
            recipeDesc.text = known ? (result != null ? result.description : "") : "Tetsu el herrero te enseñará los secretos de la forja.";

            bool station = CraftingSystem.HasStation(r, pos);
            recipeStation.text = r.station == StationType.None
                ? "<b>🏛️ LUGAR:</b> A mano en cualquier sitio"
                : $"<b>🏛️ ESTACIÓN:</b> {CraftingStation.DisplayName(r.station)} — " + (station ? "<color=#27AE60><b>[✔ ESTÁS CERCA]</b></color>" : "<color=#C0392B><b>[✖ ACÉRCATE A UNA]</b></color>");

            StringBuilder sb = new StringBuilder("<b>MATERIALES REQUERIDOS:</b>\n");
            foreach (Ingredient ing in r.ingredients)
            {
                int have = inv != null ? inv.CountItem(ing.itemId) : 0;
                bool enough = have >= ing.quantity;
                string icon = enough ? "✔" : "✖";
                string color = enough ? "#27AE60" : "#C0392B";
                string name = ItemDatabase.NameOf(ing.itemId);
                sb.Append($"  <color={color}><b>{icon} [{have}/{ing.quantity}] {name}</b></color>");
                if (!enough) sb.Append($" <color=#E74C3C><i>(faltan {ing.quantity - have})</i></color>");
                sb.Append('\n');
            }
            recipeIngredients.text = sb.ToString();
            recipeTime.text = $"⏱️ Tiempo de forja: {r.seconds:0.0} s";
            bool canCraft = !crafting && CraftingSystem.CanCraft(r, inv, pos, out _);
            craftBtn.interactable = canCraft;
            Text craftBtnLabel = craftBtn.GetComponentInChildren<Text>();
            if (craftBtnLabel != null)
                craftBtnLabel.text = crafting ? "FABRICANDO..." : (canCraft ? "FABRICAR" : "NO DISPONIBLE");
        }

        private void RefreshJournal()
        {
            StoryManager s = StoryManager.Instance;
            if (s == null || s.Steps == null)
            {
                journalChapter.text = "Diario";
                journalSteps.text = "Sin historia.";
                journalCrew.text = string.Empty;
                return;
            }
            journalChapter.text = s.ChapterTitle;
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < s.Steps.Count; i++)
            {
                QuestStep st = s.Steps[i];
                if (i < s.CurrentIndex || s.StepDone(st.id))
                {
                    sb.Append($"<color=#9BE07A>[hecho]  {st.title}</color>\n");
                }
                else if (i == s.CurrentIndex)
                {
                    sb.Append($"<color=#FFD75A><b>>> {st.title}</b></color>\n<i>{st.objective}</i>\n");
                    break;
                }
            }
            journalSteps.text = sb.ToString();

            CrewManager crew = playerStats != null ? playerStats.GetComponent<CrewManager>() : null;
            StringBuilder cb = new StringBuilder("<b>TRIPULACIÓN</b>\n");
            cb.Append("  Tú — Capitán\n");
            if (crew != null)
                foreach (CrewMemberData m in crew.Members) cb.Append($"  {m.name} — {m.role}\n");
            cb.Append("\n<b>CONSEJOS</b>\n  [E] interactuar · [Tab] mochila\n  Doble clic: usar o equipar\n  Mesa y forja: acércate y abre Fabricar\n  [F5] guardar · [F9] cargar");
            journalCrew.text = cb.ToString();
        }

        private void RefreshWanted()
        {
            int bounty = progress != null ? progress.Bounty : 0;
            posterBounty.text = bounty > 0 ? $"B {FormatBerries(bounty)} -" : "B 0 -";
            posterPortrait.sprite = GameSprites.Get("c_player", () => CharacterArt.Draw(CharacterArt.Castaway()));
            posterPortrait.enabled = posterPortrait.sprite != null;

            StringBuilder sb = new StringBuilder();
            DevilFruitManager fruit = playerStats != null ? playerStats.GetComponent<DevilFruitManager>() : null;
            sb.Append("<b>FRUTA DEL DIABLO</b>\n  ");
            sb.Append(fruit != null && fruit.HasFruit ? DevilFruitManager.DisplayName(fruit.FruitId) + " (no puedes nadar)" : "Ninguna");
            HakiManager haki = playerStats != null ? playerStats.GetComponent<HakiManager>() : null;
            sb.Append("\n\n<b>HAKI</b>\n  ");
            if (haki != null && (haki.Has(HakiType.Observation) || haki.Has(HakiType.Armament) || haki.Has(HakiType.Conqueror)))
            {
                if (haki.Has(HakiType.Observation)) sb.Append("Observación  ");
                if (haki.Has(HakiType.Armament)) sb.Append("Armadura  ");
                if (haki.Has(HakiType.Conqueror)) sb.Append("Rey");
            }
            else sb.Append("Aún dormido");
            sb.Append("\n\n<b>EXPERIENCIA</b>\n  ").Append(progress != null ? progress.Experience : 0);
            sb.Append("\n\n<b>BANDAS DERROTADAS</b>\n  ").Append(progress != null ? progress.DefeatedList.Count : 0);
            sb.Append("\n\n<i>Cada victoria contra la Marina o contra piratas famosos sube tu recompensa.</i>");
            wantedStats.text = sb.ToString();
        }

        // ================================================================== Acciones

        private void OnSlotClicked(int index)
        {
            bool doubleClick = index == lastClickIndex && Time.unscaledTime - lastClickTime < 0.35f;
            lastClickIndex = index;
            lastClickTime = Time.unscaledTime;
            selected = index;
            if (doubleClick) UseSelected(true);
            RefreshBag();
        }

        private void UseSelected(bool allowEquip)
        {
            InventoryManager inv = InventoryManager.Instance;
            if (inv == null || selected < 0 || selected >= inv.Slots.Count || inv.Slots[selected].IsEmpty) return;
            ItemType t = inv.Slots[selected].ItemData.itemType;
            if (t == ItemType.Material) return;
            if (!allowEquip && (t == ItemType.Tool || t == ItemType.Weapon)) return;
            inv.UseItem(selected); // herramientas y armas: alterna equipar / desequipar
        }

        private void Drop(bool all)
        {
            InventoryManager inv = InventoryManager.Instance;
            if (inv == null || selected < 0 || selected >= inv.Slots.Count || inv.Slots[selected].IsEmpty) return;
            inv.DropItem(selected, all ? inv.Slots[selected].Quantity : 1);
        }

        private void StartCraft()
        {
            InventoryManager inv = InventoryManager.Instance;
            Vector2 pos = playerStats != null ? (Vector2)playerStats.transform.position : Vector2.zero;
            if (selectedRecipe == null || crafting) return;
            if (!CraftingSystem.CanCraft(selectedRecipe, inv, pos, out string reason))
            {
                ShowStatus(reason);
                return;
            }
            crafting = true;
            craftingRecipe = selectedRecipe;
            craftTimer = 0f;
            craftBtn.interactable = false;
        }

        private void UpdateCrafting()
        {
            craftTimer += Time.unscaledDeltaTime;
            float total = craftingRecipe != null ? Mathf.Max(0.1f, craftingRecipe.seconds) : 0.1f;
            craftProgressFill.fillAmount = Mathf.Clamp01(craftTimer / total);
            if (craftTimer < total) return;

            crafting = false;
            craftProgressFill.fillAmount = 0f;
            InventoryManager inv = InventoryManager.Instance;
            Vector2 pos = playerStats != null ? (Vector2)playerStats.transform.position : Vector2.zero;
            bool ok = CraftingSystem.Craft(craftingRecipe, inv, pos, out string message);
            if (ok && AudioManager.Instance != null) AudioManager.Instance.PlayCraftSuccess();
            craftingRecipe = null;
            ShowStatus(message);
            RefreshCraft();
        }

        // ================================================================== Construcción

        private void Build()
        {
            root = new GameObject("Canvas_Backpack");
            root.transform.SetParent(transform, false);
            Canvas canvas = root.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 30; // encima del HUD, debajo de diálogos (40), combate (50) y menús (100)
            CanvasScaler scaler = root.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;
            root.AddComponent<GraphicRaycaster>();

            Image dim = UIFactory.Box(root.transform, "Dim", new Color(0.02f, 0.03f, 0.06f, 0.6f), false);
            UIFactory.Stretch(dim.rectTransform);

            RectTransform content = PirateTheme.Panel(root.transform, "Backpack", out RectTransform panel);
            UIFactory.Place(panel, new Vector2(0.5f, 0.5f), new Vector2(0f, 0f), new Vector2(1660f, 940f));

            // Pestañas
            string[] names = { "🎒 MOCHILA", "⚒️ FABRICAR", "📜 DIARIO", "☠️ SE BUSCA" };
            for (int i = 0; i < 4; i++)
            {
                Tab t = (Tab)i;
                Button b = PirateTheme.WoodButton(content, names[i], new Vector2(256f, 60f), () => ShowTab(t), 24);
                UIFactory.Place((RectTransform)b.transform, new Vector2(0f, 1f), new Vector2(i * 268f, 0f), new Vector2(256f, 60f));
                tabButtons[i] = b;
            }
            Button close = PirateTheme.WoodButton(content, "X", new Vector2(64f, 60f), () => CloseInventory(), 28);
            UIFactory.Place((RectTransform)close.transform, new Vector2(1f, 1f), Vector2.zero, new Vector2(64f, 60f));

            statusText = UIFactory.Label(content, "", 22, PirateTheme.Ink, TextAnchor.LowerCenter, FontStyle.Bold, false);
            UIFactory.Place(statusText.rectTransform, new Vector2(0.5f, 0f), new Vector2(0f, -22f), new Vector2(1200f, 30f));

            for (int i = 0; i < 4; i++)
            {
                pages[i] = UIFactory.NewRect(names[i], content);
                UIFactory.Stretch(pages[i], 0, 18, 0, 80);
            }

            BuildBagPage(pages[0]);
            BuildCraftPage(pages[1]);
            BuildJournalPage(pages[2]);
            BuildWantedPage(pages[3]);

            root.SetActive(false);
        }

        private void BuildBagPage(RectTransform page)
        {
            // --- Columna izquierda: equipo y estado
            Header(page, "EN LA MANO", 0f, 0f, 360f);
            Image eqFrame = PirateTheme.Inset(page, "EquippedFrame");
            Place(eqFrame.rectTransform, 0f, 50f, 130f, 130f);
            equippedIcon = Icon(eqFrame.transform, 18f);
            equippedName = PirateTheme.InkText(page, "", 24, TextAnchor.UpperLeft, FontStyle.Bold);
            Place(equippedName.rectTransform, 145f, 56f, 220f, 70f);
            Image eqBar = Bar(page, 145f, 132f, 210f, 14f, out equippedDurFill);
            eqBar.name = "EquippedDurability";
            unequipBtn = PirateTheme.WoodButton(page, "Guardar", new Vector2(150f, 44f), () =>
            {
                if (InventoryManager.Instance != null) InventoryManager.Instance.UnequipTool();
            }, 20);
            Place((RectTransform)unequipBtn.transform, 145f, 150f, 150f, 44f);

            Header(page, "ESTADO", 0f, 222f, 360f);
            Color[] colors = { new Color(0.8f, 0.2f, 0.2f), new Color(0.85f, 0.55f, 0.15f), new Color(0.2f, 0.55f, 0.85f), new Color(0.85f, 0.75f, 0.2f) };
            for (int i = 0; i < 4; i++)
            {
                Bar(page, 0f, 276f + i * 62f, 350f, 34f, out statFills[i]);
                statFills[i].color = colors[i];
                statTexts[i] = UIFactory.Label(statFills[i].transform.parent, "", 19, Color.white, TextAnchor.MiddleLeft, FontStyle.Bold);
                UIFactory.Stretch(statTexts[i].rectTransform, 12, 0, 0, 0);
            }

            // --- Centro: rejilla
            float gridX = 390f;
            Header(page, "MOCHILA", gridX, 0f, Columns * (SlotSize + SlotGap));
            int total = InventoryManager.Instance != null ? InventoryManager.Instance.Slots.Count : 20;
            for (int i = 0; i < total; i++)
            {
                int idx = i;
                int col = i % Columns, row = i / Columns;
                Image bg = PirateTheme.Inset(page, $"Slot_{i}");
                Place(bg.rectTransform, gridX + col * (SlotSize + SlotGap), 50f + row * (SlotSize + SlotGap), SlotSize, SlotSize);
                Button b = bg.gameObject.AddComponent<Button>();
                b.transition = Selectable.Transition.None;
                b.onClick.AddListener(() => OnSlotClicked(idx));

                SlotView v = new SlotView { bg = bg };

                // Marco de rareza
                Image rBorder = UIFactory.Box(bg.transform, "RarityBorder", Color.clear, false);
                UIFactory.Stretch(rBorder.rectTransform, 0, 0, 0, 0);
                Outline bo = rBorder.gameObject.AddComponent<Outline>();
                bo.effectDistance = new Vector2(2.5f, 2.5f);
                bo.effectColor = Color.clear;
                v.rarityBorder = rBorder;

                // Resalte de selección
                Image sel = UIFactory.Box(bg.transform, "SelectHighlight", Color.clear, false);
                UIFactory.Stretch(sel.rectTransform, -2, -2, -2, -2);
                Outline so = sel.gameObject.AddComponent<Outline>();
                so.effectDistance = new Vector2(3f, 3f);
                so.effectColor = new Color(1f, 0.85f, 0.2f, 0.95f);
                v.selectHighlight = sel;
                sel.gameObject.SetActive(false);

                v.icon = Icon(bg.transform, 16f);
                Image catTag = UIFactory.Box(bg.transform, "CatTag", Color.clear);
                UIFactory.Place(catTag.rectTransform, new Vector2(0f, 1f), new Vector2(8f, -8f), new Vector2(10f, 10f));
                v.typeBadge = catTag;

                // Pastilla oscura para cantidad
                GameObject qb = new GameObject("QtyBadge", typeof(RectTransform));
                qb.transform.SetParent(bg.transform, false);
                Image qbImg = qb.AddComponent<Image>();
                qbImg.color = new Color(0.08f, 0.08f, 0.12f, 0.85f);
                UIFactory.Place((RectTransform)qb.transform, new Vector2(1f, 0f), new Vector2(-6f, 6f), new Vector2(40f, 24f));
                ((RectTransform)qb.transform).pivot = new Vector2(1f, 0f);
                v.qty = UIFactory.Label(qb.transform, "", 16, Color.white, TextAnchor.MiddleCenter, FontStyle.Bold);
                UIFactory.Stretch(v.qty.rectTransform);
                v.qtyBadge = qb;
                qb.SetActive(false);

                Image dur = Bar(bg.transform, 12f, 98f, SlotSize - 24f, 7f, out v.durFill);
                v.durBar = dur.gameObject;
                Text mark = UIFactory.Label(bg.transform, "EQ", 12, PirateTheme.GoldText, TextAnchor.UpperRight, FontStyle.Bold);
                UIFactory.Place(mark.rectTransform, new Vector2(1f, 1f), new Vector2(-6f, -6f), new Vector2(24f, 18f));
                Outline markOutline = mark.gameObject.AddComponent<Outline>();
                markOutline.effectColor = new Color(0.12f, 0.06f, 0.02f, 1f);
                v.equippedMark = mark.gameObject;
                slotViews.Add(v);
            }
            int rows = Mathf.CeilToInt(total / (float)Columns);
            float weightY = 60f + rows * (SlotSize + SlotGap);
            Bar(page, gridX, weightY, Columns * (SlotSize + SlotGap) - SlotGap, 32f, out weightFill);
            weightText = UIFactory.Label(weightFill.transform.parent, "", 20, Color.white, TextAnchor.MiddleCenter, FontStyle.Bold);

            // --- Derecha: ficha del objeto
            float dx = 1020f;
            Header(page, "FICHA", dx, 0f, 560f);
            Image iconFrame = PirateTheme.Inset(page, "DetailIcon");
            Place(iconFrame.rectTransform, dx, 50f, 150f, 150f);
            detailIcon = Icon(iconFrame.transform, 20f);
            detailName = PirateTheme.InkText(page, "", 28, TextAnchor.UpperLeft, FontStyle.Bold);
            Place(detailName.rectTransform, dx + 168f, 54f, 390f, 72f);
            detailType = PirateTheme.InkText(page, "", 20, TextAnchor.UpperLeft, FontStyle.Italic);
            detailType.color = PirateTheme.InkSoft;
            Place(detailType.rectTransform, dx + 168f, 130f, 390f, 30f);
            detailDesc = PirateTheme.InkText(page, "", 21);
            Place(detailDesc.rectTransform, dx, 214f, 560f, 120f);
            detailStats = PirateTheme.InkText(page, "", 21);
            detailStats.supportRichText = true;
            Place(detailStats.rectTransform, dx, 340f, 560f, 230f);

            useBtn = PirateTheme.WoodButton(page, "Usar", new Vector2(270f, 56f), new Color(0.35f, 0.72f, 0.38f), () => UseSelected(false), 22);
            Place((RectTransform)useBtn.transform, dx, 590f, 270f, 56f);
            equipBtn = PirateTheme.WoodButton(page, "Equipar", new Vector2(270f, 56f), new Color(0.32f, 0.58f, 0.88f), () => UseSelected(true), 22);
            Place((RectTransform)equipBtn.transform, dx + 288f, 590f, 270f, 56f);
            dropOneBtn = PirateTheme.WoodButton(page, "Tirar 1", new Vector2(270f, 50f), new Color(0.72f, 0.55f, 0.42f), () => Drop(false), 20);
            Place((RectTransform)dropOneBtn.transform, dx, 660f, 270f, 50f);
            dropAllBtn = PirateTheme.WoodButton(page, "Tirar todo", new Vector2(270f, 50f), new Color(0.75f, 0.32f, 0.28f), () => Drop(true), 20);
            Place((RectTransform)dropAllBtn.transform, dx + 288f, 660f, 270f, 50f);
        }

        private void BuildCraftPage(RectTransform page)
        {
            Header(page, "CATEGORÍAS", 0f, 0f, 240f);
            string[] cats = { "✨ Todas", "🪵 Materiales", "⛏️ Herramientas", "⚔️ Espadas", "💊 Medicina", "🍖 Cocina", "🛡️ Armaduras", "💣 Munición" };
            for (int i = 0; i < cats.Length; i++)
            {
                int idx = i;
                Button b = PirateTheme.WoodButton(page, cats[i], new Vector2(240f, 48f), () =>
                {
                    if (crafting) return;
                    category = idx == 0 ? (RecipeCategory?)null : (RecipeCategory)(idx - 1);
                    selectedRecipe = null;
                    RefreshCraft();
                }, 19);
                Place((RectTransform)b.transform, 0f, 45f + i * 54f, 240f, 48f);
                categoryButtons[i] = b;
            }

            float lx = 270f;
            Header(page, "RECETAS", lx, 0f, 600f);

            // Banner de estación de trabajo activa
            stationBanner = UIFactory.Label(page, "", 18, PirateTheme.Ink, TextAnchor.MiddleLeft, FontStyle.Bold);
            Place(stationBanner.rectTransform, lx, 44f, 600f, 26f);

            for (int i = 0; i < MaxRecipeRows; i++)
            {
                int idx = i;
                Image bg = PirateTheme.Inset(page, $"Recipe_{i}");
                Place(bg.rectTransform, lx, 74f + i * 58f, 600f, 54f);
                Button b = bg.gameObject.AddComponent<Button>();
                b.transition = Selectable.Transition.None;
                b.onClick.AddListener(() =>
                {
                    if (!crafting && idx < visibleRecipes.Count) { selectedRecipe = visibleRecipes[idx]; RefreshCraft(); }
                });
                RecipeRow row = new RecipeRow { button = b, bg = bg };

                Image rBorder = UIFactory.Box(bg.transform, "RowBorder", Color.clear, false);
                UIFactory.Stretch(rBorder.rectTransform, 0, 0, 0, 0);
                Outline bo = rBorder.gameObject.AddComponent<Outline>();
                bo.effectDistance = new Vector2(2f, 2f);
                bo.effectColor = Color.clear;
                row.rarityBorder = rBorder;

                Image sel = UIFactory.Box(bg.transform, "RowSel", Color.clear, false);
                UIFactory.Stretch(sel.rectTransform, -1, -1, -1, -1);
                Outline so = sel.gameObject.AddComponent<Outline>();
                so.effectDistance = new Vector2(2.5f, 2.5f);
                so.effectColor = new Color(1f, 0.85f, 0.2f, 0.95f);
                row.selectHighlight = sel;
                sel.gameObject.SetActive(false);

                row.icon = UIFactory.Box(bg.transform, "Icon", Color.white, false);
                row.icon.preserveAspect = true;
                row.icon.raycastTarget = false;
                UIFactory.Place(row.icon.rectTransform, new Vector2(0f, 0.5f), new Vector2(10f, 0f), new Vector2(38f, 38f));
                row.name = UIFactory.Label(bg.transform, "", 20, Color.white, TextAnchor.MiddleLeft, FontStyle.Bold);
                UIFactory.Stretch(row.name.rectTransform, 58, 0, 180, 0);
                row.info = UIFactory.Label(bg.transform, "", 18, PirateTheme.Cream, TextAnchor.MiddleRight, FontStyle.Bold, false);
                UIFactory.Stretch(row.info.rectTransform, 0, 0, 14, 0);
                recipeRows[i] = row;
            }

            float dx = 900f;
            Header(page, "FABRICACIÓN", dx, 0f, 680f);
            Image iconFrame = PirateTheme.Inset(page, "RecipeIcon");
            Place(iconFrame.rectTransform, dx, 50f, 150f, 150f);
            recipeIcon = Icon(iconFrame.transform, 20f);
            recipeName = PirateTheme.InkText(page, "", 28, TextAnchor.UpperLeft, FontStyle.Bold);
            Place(recipeName.rectTransform, dx + 170f, 54f, 500f, 80f);
            recipeDesc = PirateTheme.InkText(page, "", 20);
            Place(recipeDesc.rectTransform, dx + 170f, 120f, 500f, 100f);
            recipeStation = PirateTheme.InkText(page, "", 21);
            recipeStation.supportRichText = true;
            Place(recipeStation.rectTransform, dx, 230f, 680f, 34f);
            recipeIngredients = PirateTheme.InkText(page, "", 23);
            recipeIngredients.supportRichText = true;
            Place(recipeIngredients.rectTransform, dx, 280f, 680f, 200f);
            recipeTime = PirateTheme.InkText(page, "", 20, TextAnchor.UpperLeft, FontStyle.Italic);
            Place(recipeTime.rectTransform, dx, 490f, 680f, 30f);

            Bar(page, dx, 540f, 680f, 24f, out craftProgressFill);
            craftProgressFill.color = new Color(0.95f, 0.75f, 0.25f);
            craftProgressFill.fillAmount = 0f;
            craftBtn = PirateTheme.WoodButton(page, "FABRICAR", new Vector2(380f, 72f), StartCraft, 30);
            Place((RectTransform)craftBtn.transform, dx + 150f, 590f, 380f, 72f);
        }

        private void BuildJournalPage(RectTransform page)
        {
            journalChapter = PirateTheme.Title(page, "", 40);
            Place(journalChapter.rectTransform, 0f, 0f, 1000f, 60f);
            journalChapter.alignment = TextAnchor.MiddleLeft;
            Image left = PirateTheme.Inset(page, "Steps");
            Place(left.rectTransform, 0f, 70f, 980f, 660f);
            journalSteps = UIFactory.Label(left.transform, "", 25, PirateTheme.Cream, TextAnchor.UpperLeft, FontStyle.Normal, false);
            journalSteps.supportRichText = true;
            journalSteps.lineSpacing = 1.15f;
            UIFactory.Stretch(journalSteps.rectTransform, 30, 24, 30, 24);

            Image right = PirateTheme.Inset(page, "Crew");
            Place(right.rectTransform, 1010f, 70f, 570f, 660f);
            journalCrew = UIFactory.Label(right.transform, "", 23, PirateTheme.Cream, TextAnchor.UpperLeft, FontStyle.Normal, false);
            journalCrew.supportRichText = true;
            UIFactory.Stretch(journalCrew.rectTransform, 26, 24, 26, 24);
        }

        private void BuildWantedPage(RectTransform page)
        {
            // Cartel de "Se busca"
            RectTransform posterInner = PirateTheme.Panel(page, "Poster", out RectTransform poster);
            Place(poster, 160f, 0f, 560f, 740f);
            Text wanted = UIFactory.Label(posterInner, "SE BUSCA", 76, PirateTheme.Ink, TextAnchor.UpperCenter, FontStyle.Bold, false);
            UIFactory.Place(wanted.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, 0f), new Vector2(480f, 90f));
            Image photoFrame = PirateTheme.Inset(posterInner, "Photo");
            UIFactory.Place(photoFrame.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, -96f), new Vector2(380f, 330f));
            Image photoBg = UIFactory.Box(photoFrame.transform, "Sky", new Color(0.78f, 0.72f, 0.58f), false);
            UIFactory.Stretch(photoBg.rectTransform, 12, 12, 12, 12);
            posterPortrait = Icon(photoFrame.transform, 30f);
            Text alive = UIFactory.Label(posterInner, "VIVO O MUERTO", 34, PirateTheme.Ink, TextAnchor.MiddleCenter, FontStyle.Bold, false);
            UIFactory.Place(alive.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, -436f), new Vector2(480f, 44f));
            Text who = UIFactory.Label(posterInner, "«EL NÁUFRAGO DE ISLA CORAL»", 22, PirateTheme.InkSoft, TextAnchor.MiddleCenter, FontStyle.Bold, false);
            UIFactory.Place(who.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, -482f), new Vector2(480f, 34f));
            posterBounty = UIFactory.Label(posterInner, "", 46, PirateTheme.Ink, TextAnchor.MiddleCenter, FontStyle.Bold, false);
            UIFactory.Place(posterBounty.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, -530f), new Vector2(480f, 64f));
            Text marine = UIFactory.Label(posterInner, "MARINA", 26, PirateTheme.InkSoft, TextAnchor.LowerRight, FontStyle.Bold, false);
            UIFactory.Stretch(marine.rectTransform, 0, 0, 10, 0);

            Image stats = PirateTheme.Inset(page, "PirateStats");
            Place(stats.rectTransform, 800f, 40f, 640f, 640f);
            wantedStats = UIFactory.Label(stats.transform, "", 24, PirateTheme.Cream, TextAnchor.UpperLeft, FontStyle.Normal, false);
            wantedStats.supportRichText = true;
            UIFactory.Stretch(wantedStats.rectTransform, 30, 24, 30, 24);
        }

        // ================================================================== Utilidades de UI

        /// <summary>Coloca desde la esquina superior izquierda de la página (y hacia abajo).</summary>
        private static void Place(RectTransform r, float x, float y, float w, float h)
        {
            UIFactory.Place(r, new Vector2(0f, 1f), new Vector2(x, -y), new Vector2(w, h));
        }

        private static void Header(Transform page, string text, float x, float y, float w)
        {
            Text t = PirateTheme.Title(page, text, 28);
            t.alignment = TextAnchor.MiddleLeft;
            Place(t.rectTransform, x, y, w, 40f);
        }

        private static Image Icon(Transform parent, float margin)
        {
            Image img = UIFactory.Box(parent, "Icon", Color.white, false);
            img.preserveAspect = true;
            img.raycastTarget = false;
            img.enabled = false;
            UIFactory.Stretch(img.rectTransform, margin, margin, margin, margin);
            return img;
        }

        /// <summary>Barra horizontal (fondo oscuro + relleno). Devuelve el fondo; 'fill' es el relleno.</summary>
        private static Image Bar(Transform parent, float x, float y, float w, float h, out Image fill)
        {
            Image bg = UIFactory.Box(parent, "Bar", new Color(0.18f, 0.11f, 0.06f, 0.9f), false);
            bg.raycastTarget = false;
            Place(bg.rectTransform, x, y, w, h);
            fill = UIFactory.Box(bg.transform, "Fill", new Color(0.55f, 0.38f, 0.2f), false);
            fill.type = Image.Type.Filled;
            fill.fillMethod = Image.FillMethod.Horizontal;
            fill.raycastTarget = false;
            UIFactory.Stretch(fill.rectTransform, 2, 2, 2, 2);
            return bg;
        }

        private static string TypeName(ItemType t)
        {
            switch (t)
            {
                case ItemType.Food: return "Comida";
                case ItemType.Drink: return "Bebida";
                case ItemType.Material: return "Material";
                case ItemType.Tool: return "Herramienta";
                case ItemType.Weapon: return "Arma";
                case ItemType.Medicine: return "Medicina";
                case ItemType.DevilFruit: return "Fruta del Diablo";
                default: return t.ToString();
            }
        }

        private static string UseVerb(ItemType t)
        {
            switch (t)
            {
                case ItemType.Food: return "Comer";
                case ItemType.Drink: return "Beber";
                case ItemType.Medicine: return "Usar";
                case ItemType.DevilFruit: return "Comer...";
                default: return null;
            }
        }

        private static string DamageTypeName(CombatDamageType t)
        {
            switch (t)
            {
                case CombatDamageType.Slash: return "Corte";
                case CombatDamageType.Pierce: return "Perforación";
                case CombatDamageType.Blunt: return "Contundente";
                case CombatDamageType.Fire: return "Fuego";
                case CombatDamageType.Explosion: return "Explosión";
                case CombatDamageType.Haki: return "Haki";
                default: return t.ToString();
            }
        }

        public static Color CategoryColor(ItemType type) => type switch
        {
            ItemType.Weapon => new Color(0.92f, 0.28f, 0.24f),
            ItemType.Tool => new Color(0.24f, 0.78f, 0.95f),
            ItemType.Medicine => new Color(0.28f, 0.88f, 0.38f),
            ItemType.Food or ItemType.Drink => new Color(0.98f, 0.65f, 0.18f),
            ItemType.Material => new Color(0.75f, 0.55f, 0.35f),
            ItemType.DevilFruit => new Color(0.85f, 0.45f, 1.0f),
            _ => new Color(0.6f, 0.6f, 0.6f)
        };

        private static string StatsText(ItemData item, InventorySlot slot)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($"<color=#705845><b>⚖️ Peso:</b></color> <b>{item.weight:0.0} kg</b>");
            if (slot.Quantity > 1) sb.Append($" <color=#88705C>(Total x{slot.Quantity}: {item.weight * slot.Quantity:0.0} kg)</color>");
            sb.Append("\n\n");

            bool hasSurvival = false;
            if (item.healthRestore > 0f) { sb.Append($"<color=#2E7D32><b>❤️ +{item.healthRestore:0}</b> Salud</color>   "); hasSurvival = true; }
            if (item.hungerRestore > 0f) { sb.Append($"<color=#E65100><b>🍗 +{item.hungerRestore:0}</b> Hambre</color>   "); hasSurvival = true; }
            if (item.thirstRestore > 0f) { sb.Append($"<color=#0277BD><b>💧 +{item.thirstRestore:0}</b> Sed</color>   "); hasSurvival = true; }
            if (item.staminaRestore > 0f) { sb.Append($"<color=#F57F17><b>⚡ +{item.staminaRestore:0}</b> Energía</color>   "); hasSurvival = true; }
            if (item.curesBleeding) { sb.Append("<color=#C62828><b>🩸 Corta Hemorragia</b></color>   "); hasSurvival = true; }
            if (item.curesPoison) { sb.Append("<color=#6A1B9A><b>🧪 Cura Veneno</b></color>   "); hasSurvival = true; }
            if (hasSurvival) sb.Append("\n\n");

            if (item.combatDamage > 0)
            {
                sb.Append($"<color=#B71C1C><b>⚔️ Daño de Combate:</b></color> <b>{item.combatDamage}</b> ({DamageTypeName(item.combatDamageType)})\n");
                sb.Append($"<color=#D84315>⚡ Coste AP:</color> <b>{item.combatApCost}</b>   ");
                sb.Append($"<color=#1565C0>🎯 Puntería:</color> <b>{item.combatAccuracy * 100f:0}%</b>   ");
                sb.Append($"<color=#AD1457>💥 Crítico:</color> <b>{item.combatCritChance * 100f:0}%</b>\n");
                if (item.combatMaxRange > 1)
                    sb.Append($"<color=#4E342E>🏹 Alcance táctico:</color> <b>{item.combatMinRange}-{item.combatMaxRange} casillas</b>\n");
                if (!string.IsNullOrEmpty(item.ammoItemId))
                    sb.Append($"<color=#E65100>💣 Munición:</color> <b>{ItemDatabase.NameOf(item.ammoItemId)}</b>\n");
            }

            if (item.kairoseki)
                sb.Append("<color=#00838F><b>⚓ Kairoseki:</b> anula el poder de Frutas del Diablo</color>\n");

            if (item.itemType == ItemType.Tool || item.itemType == ItemType.Weapon)
            {
                if (item.resourceDamage > 0)
                    sb.Append($"<color=#4E342E>⛏️ Eficacia en tala/minería:</color> <b>+{item.resourceDamage:0}</b>\n");
            }

            if (!string.IsNullOrEmpty(item.devilFruitId))
            {
                sb.Append("<color=#6A1B9A><b>🍈 Fruta del Diablo:</b> Otorga poderes legendarios de Akuma no Mi</color>\n");
                sb.Append("<color=#C62828><b>🌊 Maldición Marina:</b> Impide nadar en agua profunda</color>\n");
            }

            if (item.maxDurability > 0)
            {
                float pct = Mathf.Clamp01((float)slot.Durability / item.maxDurability);
                string col = pct > 0.5f ? "#2E7D32" : (pct > 0.25f ? "#F57F17" : "#C62828");
                sb.Append($"\n<color=#5D4037>🛡️ Durabilidad:</color> <color={col}><b>{slot.Durability} / {item.maxDurability}</b> ({pct * 100f:0}%)</color>");
            }
            else if (item.itemType == ItemType.Weapon)
            {
                sb.Append("\n<color=#2E7D32>🛡️ Durabilidad: <b>Indestructible</b></color>");
            }

            return sb.ToString();
        }

        private static string FormatBerries(int value)
        {
            string digits = value.ToString();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < digits.Length; i++)
            {
                if (i > 0 && (digits.Length - i) % 3 == 0) sb.Append('.');
                sb.Append(digits[i]);
            }
            return sb.ToString();
        }

        public void ShowTooltip(ItemData item, Vector2 position)
        {
            if (item == null) return;
        }

        public void HideTooltip()
        {
        }
    }
}
