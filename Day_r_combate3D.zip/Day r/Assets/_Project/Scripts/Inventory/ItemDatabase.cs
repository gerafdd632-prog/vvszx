﻿using System.Collections.Generic;

namespace PirateSurvival.Inventory
{
    /// <summary>Registro global de objetos por itemId (lo rellena GameBootstrap al crear el catálogo).</summary>
    public static class ItemDatabase
    {
        private static readonly Dictionary<string, ItemData> ById = new Dictionary<string, ItemData>();

        public static void Register(IEnumerable<ItemData> items)
        {
            ById.Clear();
            foreach (ItemData item in items)
            {
                if (item != null && !string.IsNullOrEmpty(item.itemId)) ById[item.itemId] = item;
            }
        }

        public static ItemData Get(string itemId)
        {
            if (string.IsNullOrEmpty(itemId)) return null;
            return ById.TryGetValue(itemId, out ItemData item) && item != null ? item : null;
        }

        public static string NameOf(string itemId)
        {
            ItemData item = Get(itemId);
            return item != null ? item.itemName : itemId;
        }
    }
}
