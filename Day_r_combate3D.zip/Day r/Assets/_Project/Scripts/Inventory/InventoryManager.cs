﻿using System.Collections.Generic;
using UnityEngine;
using PirateSurvival.Core;
using PirateSurvival.Player;
using PirateSurvival.Interaction;

namespace PirateSurvival.Inventory
{
    /// <summary>
    /// Administrador central del inventario en 2D.
    /// Utiliza WorldItemFactory para soltar objetos con física (Item D),
    /// sincroniza el equipamiento con la UI y garantiza la integridad de datos.
    /// </summary>
    public class InventoryManager : MonoBehaviour
    {
        public static InventoryManager Instance { get; private set; }

        [Header("Configuración de Capacidad")]
        [Tooltip("Número total de casillas")]
        [SerializeField] private int totalSlots = 20;
        [Tooltip("Límite de peso en kilogramos")]
        [SerializeField] private float maxCarryWeight = 45f;

        [Header("Referencias del Jugador 2D")]
        [SerializeField] private PlayerStats playerStats;
        [SerializeField] private Transform dropPoint;
        [SerializeField] private Transform toolSocket;

        [Header("Huecos de Inventario")]
        [SerializeField] private List<InventorySlot> slots = new List<InventorySlot>();

        private GameObject currentEquippedInstance;
        private ItemData currentEquippedTool;
        private int equippedSlotIndex = -1;

        public IReadOnlyList<InventorySlot> Slots => slots;
        public float MaxCarryWeight => maxCarryWeight;
        public ItemData CurrentEquippedTool => currentEquippedTool;
        public int EquippedSlotIndex => equippedSlotIndex;

        private void OnValidate()
        {
            if (totalSlots <= 0) totalSlots = 20;
            if (maxCarryWeight <= 0) maxCarryWeight = 45f;
        }

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(this);
                return;
            }
            Instance = this;

            InitializeSlots();

            if (playerStats == null)
            {
                playerStats = GetComponent<PlayerStats>();
            }
        }

        private void Start()
        {
            NotifyInventoryChanged();
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        private void InitializeSlots()
        {
            if (slots.Count == totalSlots) return;

            slots.Clear();
            for (int i = 0; i < totalSlots; i++)
            {
                slots.Add(new InventorySlot());
            }
        }

        public float CalculateTotalWeight()
        {
            float total = 0f;
            for (int i = 0; i < slots.Count; i++)
            {
                total += slots[i].GetTotalWeight();
            }
            return total;
        }

        public int TryAddPartial(ItemData item, int requestedQuantity)
        {
            if (item == null || requestedQuantity <= 0) return 0;

            float currentWeight = CalculateTotalWeight();
            float availableWeight = Mathf.Max(0f, maxCarryWeight - currentWeight);
            int maxByWeight = requestedQuantity;

            if (item.weight > 0.001f)
            {
                maxByWeight = Mathf.FloorToInt(availableWeight / item.weight);
            }

            int amountToConsider = Mathf.Min(requestedQuantity, maxByWeight);
            if (amountToConsider <= 0) return 0;

            int availableSlotCapacity = 0;
            for (int i = 0; i < slots.Count; i++)
            {
                if (slots[i].IsEmpty)
                {
                    availableSlotCapacity += item.maxStackSize;
                }
                else if (slots[i].ItemData.itemId == item.itemId)
                {
                    availableSlotCapacity += (item.maxStackSize - slots[i].Quantity);
                }
            }

            int finalAddAmount = Mathf.Min(amountToConsider, availableSlotCapacity);
            if (finalAddAmount <= 0) return 0;

            int remaining = finalAddAmount;

            for (int i = 0; i < slots.Count; i++)
            {
                if (!slots[i].IsEmpty && slots[i].ItemData.itemId == item.itemId)
                {
                    remaining = slots[i].AddQuantity(remaining);
                    if (remaining <= 0) break;
                }
            }

            if (remaining > 0)
            {
                for (int i = 0; i < slots.Count; i++)
                {
                    if (slots[i].IsEmpty)
                    {
                        slots[i].Set(item, 0);
                        remaining = slots[i].AddQuantity(remaining);
                        if (remaining <= 0) break;
                    }
                }
            }

            NotifyInventoryChanged();
            return finalAddAmount;
        }

        public bool AddItem(ItemData item, int quantity = 1)
        {
            if (item == null || quantity <= 0) return false;

            float incomingWeight = item.weight * quantity;
            if ((CalculateTotalWeight() + incomingWeight) > maxCarryWeight)
            {
                GameEvents.TriggerNotificationMessage("¡Peso máximo superado!");
                return false;
            }

            int availableSlotCapacity = 0;
            for (int i = 0; i < slots.Count; i++)
            {
                if (slots[i].IsEmpty)
                {
                    availableSlotCapacity += item.maxStackSize;
                }
                else if (slots[i].ItemData.itemId == item.itemId)
                {
                    availableSlotCapacity += (item.maxStackSize - slots[i].Quantity);
                }
            }

            if (availableSlotCapacity < quantity)
            {
                GameEvents.TriggerNotificationMessage("¡Inventario lleno!");
                return false;
            }

            int added = TryAddPartial(item, quantity);
            return added == quantity;
        }

        public void UseItem(int slotIndex)
        {
            // Inconsciente, muerto o con una confirmación abierta no se usa nada (evita curarse desmayado o pedir dos veces la Fruta)
            if (playerStats != null && (playerStats.IsDead || playerStats.IsFainted)) return;
            if (GameInput.ModalBlocked) return;
            if (slotIndex < 0 || slotIndex >= slots.Count) return;
            InventorySlot slot = slots[slotIndex];
            if (slot.IsEmpty) return;

            ItemData item = slot.ItemData;

            if (item.itemType == ItemType.Food || item.itemType == ItemType.Drink)
            {
                if (playerStats != null)
                {
                    // Punto 14: No consumir comida/bebida si la estadística ya está al máximo
                    if (item.itemType == ItemType.Food && item.hungerRestore > 0f && playerStats.CurrentHunger >= playerStats.MaxHunger - 0.1f)
                    {
                        GameEvents.TriggerNotificationMessage("¡No tienes hambre!");
                        return;
                    }

                    if (item.itemType == ItemType.Drink && item.thirstRestore > 0f && playerStats.CurrentThirst >= playerStats.MaxThirst - 0.1f)
                    {
                        GameEvents.TriggerNotificationMessage("¡No tienes sed!");
                        return;
                    }

                    // Paso 0.13: Permite efectos negativos (daño, deshidratación, etc.)
                    if (item.healthRestore > 0f) playerStats.Heal(item.healthRestore);
                    else if (item.healthRestore < 0f) playerStats.TakeDamage(-item.healthRestore, DeathCause.Poison);

                    if (item.hungerRestore != 0f) playerStats.ModifyHunger(item.hungerRestore);
                    if (item.thirstRestore != 0f) playerStats.ModifyThirst(item.thirstRestore);
                    if (item.staminaRestore != 0f) playerStats.ModifyStamina(item.staminaRestore);
                    if (item.temperatureChange != 0f) playerStats.ModifyTemperature(item.temperatureChange);
                }

                slot.RemoveQuantity(1);
                VerifyEquippedSlot();
                NotifyInventoryChanged();
            }
            else if (item.itemType == ItemType.Medicine)
            {
                PlayerWounds wounds = playerStats != null ? playerStats.GetComponent<PlayerWounds>() : null;
                bool useful = item.healthRestore > 0f && playerStats != null && playerStats.CurrentHealth < playerStats.MaxHealth - 0.1f;
                if (wounds != null && ((item.curesBleeding && wounds.IsBleeding) || (item.curesPoison && wounds.IsPoisoned))) useful = true;
                if (!useful)
                {
                    GameEvents.TriggerNotificationMessage("No lo necesitas ahora.");
                    return;
                }

                if (playerStats != null && item.healthRestore > 0f) playerStats.Heal(item.healthRestore);
                if (wounds != null)
                {
                    if (item.curesBleeding) wounds.CureBleeding();
                    if (item.curesPoison) wounds.CurePoison();
                }
                slot.RemoveQuantity(1);
                VerifyEquippedSlot();
                NotifyInventoryChanged();
            }
            else if (item.itemType == ItemType.DevilFruit)
            {
                DevilFruitManager fruit = playerStats != null ? playerStats.GetComponent<DevilFruitManager>() : null;
                if (fruit == null) return;
                if (fruit.HasFruit)
                {
                    GameEvents.TriggerNotificationMessage("Ya tienes un poder. Una segunda fruta te destrozaría el cuerpo.");
                    return;
                }

                // Irreversible: nunca con un solo clic. La UI pide confirmación y llama a ConfirmEatDevilFruit.
                int index = slotIndex;
                bool asked = GameEvents.RequestConfirmation(
                    $"¿Comer la {item.itemName}?\nObtendrás su poder permanentemente, pero perderás la capacidad de nadar con normalidad.",
                    "Comer", "Cancelar", () => ConfirmEatDevilFruit(index, item));
                if (!asked) Debug.LogWarning("[InventoryManager] No hay UI de confirmación: la Fruta del Diablo no se come sin confirmar.");
            }
            else if (item.itemType == ItemType.Tool || item.itemType == ItemType.Weapon)
            {
                if (currentEquippedTool == item && equippedSlotIndex == slotIndex)
                {
                    UnequipTool();
                }
                else
                {
                    EquipTool(item, slotIndex);
                }
            }
        }

        /// <summary>
        /// Se llama tras confirmar. Revalida todo: la casilla puede haber cambiado mientras el diálogo estaba abierto.
        /// </summary>
        public void ConfirmEatDevilFruit(int slotIndex, ItemData expected)
        {
            if (slotIndex < 0 || slotIndex >= slots.Count) return;
            InventorySlot slot = slots[slotIndex];
            if (slot.IsEmpty || slot.ItemData != expected || expected.itemType != ItemType.DevilFruit) return;
            if (playerStats == null || playerStats.IsDead) return;

            DevilFruitManager fruit = playerStats.GetComponent<DevilFruitManager>();
            if (fruit == null || fruit.HasFruit) return;

            fruit.Eat(expected.devilFruitId);
            slot.RemoveQuantity(1);
            VerifyEquippedSlot();
            NotifyInventoryChanged();
        }

        /// <summary>
        /// Equipa la herramienta/arma de una casilla concreta. Valida TODO antes de tocar el equipo actual:
        /// si la llamada no es válida devuelve false y conserva lo que ya estaba equipado.
        /// </summary>
        public bool EquipTool(ItemData tool, int slotIndex)
        {
            // Punto 14: EquipTool(null) no debe lanzar excepción
            if (tool == null)
            {
                Debug.LogWarning("[InventoryManager] EquipTool: objeto nulo.");
                return false;
            }
            if (slotIndex < 0 || slotIndex >= slots.Count)
            {
                Debug.LogWarning($"[InventoryManager] EquipTool: casilla {slotIndex} fuera de rango para '{tool.itemId}'.");
                return false;
            }
            InventorySlot slot = slots[slotIndex];
            if (slot.IsEmpty || slot.Quantity <= 0 || slot.ItemData != tool)
            {
                Debug.LogWarning($"[InventoryManager] EquipTool: la casilla {slotIndex} no contiene '{tool.itemId}'.");
                return false;
            }
            if (tool.itemType != ItemType.Tool && tool.itemType != ItemType.Weapon)
            {
                Debug.LogWarning($"[InventoryManager] EquipTool: '{tool.itemId}' no es herramienta ni arma.");
                return false;
            }

            UnequipTool();
            currentEquippedTool = tool;
            equippedSlotIndex = slotIndex;

            if (tool.equippedPrefab != null && toolSocket != null)
            {
                currentEquippedInstance = Instantiate(tool.equippedPrefab, toolSocket);
                currentEquippedInstance.SetActive(true);
                currentEquippedInstance.transform.localPosition = Vector3.zero;
                currentEquippedInstance.transform.localRotation = Quaternion.identity;
            }

            GameEvents.TriggerEquippedToolChanged(tool.itemId);
            NotifyInventoryChanged();
            return true;
        }

        public void UnequipTool()
        {
            if (currentEquippedInstance != null)
            {
                Destroy(currentEquippedInstance);
                currentEquippedInstance = null;
            }
            currentEquippedTool = null;
            equippedSlotIndex = -1;

            GameEvents.TriggerEquippedToolChanged(string.Empty);
            NotifyInventoryChanged();
        }

        private void VerifyEquippedSlot()
        {
            if (equippedSlotIndex < 0) return;

            if (equippedSlotIndex >= slots.Count || slots[equippedSlotIndex].IsEmpty || slots[equippedSlotIndex].ItemData != currentEquippedTool)
            {
                UnequipTool();
            }
        }

        /// <summary>
        /// Item D y Punto 14: Utiliza WorldItemFactory.Spawn con un vector idéntico y normalizado para posición e impulso.
        /// </summary>
        public bool DropItem(int slotIndex, int amount = 1)
        {
            if (slotIndex < 0 || slotIndex >= slots.Count) return false;
            InventorySlot slot = slots[slotIndex];
            if (slot.IsEmpty) return false;

            ItemData item = slot.ItemData;
            int dropAmount = Mathf.Min(amount, slot.Quantity);
            slot.RemoveQuantity(dropAmount);

            // Vector compartido para evitar desincronización de ángulo de spawn e impulso
            Vector2 dir;
            Vector2 spawnPos;
            if (dropPoint != null)
            {
                spawnPos = dropPoint.position;
                dir = ((Vector2)dropPoint.position - (Vector2)transform.position).normalized;
                if (dir.sqrMagnitude < 0.001f) dir = Vector2.down;
            }
            else
            {
                dir = Random.insideUnitCircle.normalized;
                if (dir.sqrMagnitude < 0.001f) dir = Vector2.down;
                spawnPos = (Vector2)transform.position + dir * 0.8f;
            }

            Vector2 impulse = dir * 3.5f;

            WorldItemFactory.Spawn(item, dropAmount, spawnPos, impulse);

            VerifyEquippedSlot();
            NotifyInventoryChanged();
            return true;
        }

        public void SwapSlots(int fromIndex, int toIndex) => SwapOrCombineSlots(fromIndex, toIndex);

        public void SwapOrCombineSlots(int fromIndex, int toIndex)
        {
            if (fromIndex == toIndex) return;
            if (fromIndex < 0 || fromIndex >= slots.Count || toIndex < 0 || toIndex >= slots.Count) return;

            InventorySlot fromSlot = slots[fromIndex];
            InventorySlot toSlot = slots[toIndex];

            if (fromSlot.IsEmpty) return;

            bool wasFromEquipped = (equippedSlotIndex == fromIndex);
            bool wasToEquipped = (equippedSlotIndex == toIndex);

            if (toSlot.IsEmpty)
            {
                toSlot.Set(fromSlot.ItemData, fromSlot.Quantity, fromSlot.Durability);
                fromSlot.Clear();

                if (wasFromEquipped) equippedSlotIndex = toIndex;
            }
            else if (fromSlot.ItemData.itemId == toSlot.ItemData.itemId)
            {
                int remaining = toSlot.AddQuantity(fromSlot.Quantity);
                if (remaining <= 0)
                {
                    fromSlot.Clear();
                    if (wasFromEquipped) equippedSlotIndex = toIndex;
                }
                else
                {
                    fromSlot.Set(fromSlot.ItemData, remaining, fromSlot.Durability);
                }
            }
            else
            {
                ItemData tempItem = toSlot.ItemData;
                int tempQty = toSlot.Quantity;
                int tempDur = toSlot.Durability;

                toSlot.Set(fromSlot.ItemData, fromSlot.Quantity, fromSlot.Durability);
                fromSlot.Set(tempItem, tempQty, tempDur);

                if (wasFromEquipped) equippedSlotIndex = toIndex;
                else if (wasToEquipped) equippedSlotIndex = fromIndex;
            }

            VerifyEquippedSlot();
            NotifyInventoryChanged();
        }

        public void LoadSlot(int index, ItemData item, int quantity, int durability = 0)
        {
            if (index >= 0 && index < slots.Count)
            {
                if (item != null && quantity > 0)
                {
                    slots[index].Set(item, quantity, durability);
                }
                else
                {
                    slots[index].Clear();
                }
            }
        }

        public int CountItem(string itemId)
        {
            int total = 0;
            for (int i = 0; i < slots.Count; i++)
                if (!slots[i].IsEmpty && slots[i].ItemData.itemId == itemId) total += slots[i].Quantity;
            return total;
        }

        public int GetItemCount(string itemId) => CountItem(itemId);

        public bool ConsumeItemById(string itemId, int amount = 1)
        {
            if (CountItem(itemId) < amount) return false;
            for (int i = slots.Count - 1; i >= 0 && amount > 0; i--)
            {
                if (slots[i].IsEmpty || slots[i].ItemData.itemId != itemId) continue;
                int take = Mathf.Min(amount, slots[i].Quantity);
                slots[i].RemoveQuantity(take);
                amount -= take;
            }
            NotifyInventoryChanged();
            return true;
        }

        /// <summary>Desgasta un arma/herramienta. Devuelve true si se ha roto (y desaparece del inventario).</summary>
        public bool WearItem(ItemData item, int amount = 1)
        {
            if (item == null || item.maxDurability <= 0) return false;
            int idx = equippedSlotIndex >= 0 && equippedSlotIndex < slots.Count && slots[equippedSlotIndex].ItemData == item
                ? equippedSlotIndex
                : slots.FindIndex(s => !s.IsEmpty && s.ItemData == item);
            if (idx < 0) return false;

            InventorySlot slot = slots[idx];
            slot.SetDurability(slot.Durability - amount);
            if (slot.Durability > 0) return false;

            slot.Clear();
            GameEvents.TriggerNotificationMessage($"¡Tu {item.itemName} se ha roto!");
            NotifyInventoryChanged();
            return true;
        }

        public void NotifyInventoryChanged()
        {
            VerifyEquippedSlot();
            GameEvents.TriggerInventoryUpdated();
            GameEvents.TriggerWeightChanged(CalculateTotalWeight(), maxCarryWeight);
        }
    }
}
