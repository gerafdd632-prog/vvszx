﻿using System;
using UnityEngine;
using UnityEngine.EventSystems;

namespace PirateSurvival.Combat
{
    /// <summary>Puente de eventos de puntero para la UI de combate (casillas y botones).</summary>
    public class BattleHover : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerClickHandler
    {
        public Action onEnter;
        public Action onExit;
        public Action onClick;

        public void OnPointerEnter(PointerEventData e) => onEnter?.Invoke();
        public void OnPointerExit(PointerEventData e) => onExit?.Invoke();
        public void OnPointerClick(PointerEventData e)
        {
            if (e.button == PointerEventData.InputButton.Left) onClick?.Invoke();
        }
    }
}
