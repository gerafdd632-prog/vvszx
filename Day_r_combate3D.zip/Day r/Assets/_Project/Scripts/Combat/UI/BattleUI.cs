﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using PirateSurvival.Core;
using PirateSurvival.Inventory;
using PirateSurvival.UI;

namespace PirateSurvival.Combat
{
    /// <summary>
    /// Interfaz del combate táctico al estilo Day R Survival:
    /// Tablero táctico oscuro con marco de acero y remaches, celdas de batería de AP, tarjeta militar de arma equipada
    /// con durabilidad y munición, terminal táctica con registro multilínea, evaluación de objetivos con probabilidad
    /// de impacto y coberturas, textos flotantes con rebote elástico (punch scale), sacudida de pantalla en impactos
    /// críticos y soporte completo de atajos de teclado y audio procedural.
    /// </summary>
    public class BattleUI : MonoBehaviour
    {
        private enum Mode { Move, Attack, Strong, Ability }

        private const float Tile = 84f;
        private const int MaxAbilityButtons = 6;
        private const int MaxApPips = 8;
        private static readonly Color MoveTint = new Color(0.18f, 0.75f, 1f, 0.38f);
        private static readonly Color RangeTint = new Color(1f, 0.65f, 0.18f, 0.25f);
        private static readonly Color TargetTint = new Color(1f, 0.2f, 0.2f, 0.55f);
        private static readonly Color ObjectTint = new Color(1f, 0.8f, 0.2f, 0.5f);
        private static readonly Color AbilityTint = new Color(0.75f, 0.35f, 1f, 0.4f);
        private static readonly Color AreaTint = new Color(0.9f, 0.45f, 1f, 0.65f);

        private class UnitView
        {
            public RectTransform rt;
            public RectTransform body;
            public Image hpFill;
            public GameObject activeFrame;
            public Text tag;
            public Vector2 target;
            public bool placed;
            public float shake;
            public Vector2 lunge;
            public float phase;
            public float facing = 1f;
        }

        private BattleManager battle;
        private GameObject root;
        private RectTransform board, unitLayer, fxLayer;
        private Image[,] cells;
        private Image[,] overlays;
        private Image[,] props;
        private BattleArt.Ground groundStyle;
        private int fireFrame;
        private float fireTimer;
        private Text[,] cellTexts;
        private readonly Dictionary<BattleUnit, UnitView> views = new Dictionary<BattleUnit, UnitView>();

        // Inspección táctica superior (Estilo Day R)
        private Text targetName, targetDetail, targetHitChance, targetDamageEst, targetCoverInfo;
        private Image targetHpFill, targetAvatar;

        // Terminal táctica / Registro multilínea
        private readonly List<string> combatLogHistory = new List<string>();
        private Text logTerminalText;
        private Text infoText;

        // Panel inferior / Módulo de arma y supervivencia Day R
        private Image weaponIconImg;
        private Text weaponNameText, weaponDamageText, weaponRangeText, weaponAmmoText, weaponDurabilityText;
        private Image weaponDurabilityFill;
        private Text apText, hpText, staminaText, statusText;
        private Image hpFill, staminaFill;
        private readonly Image[] apPips = new Image[MaxApPips];
        private int previewApCost = 0;

        // Botones de acción y habilidades
        private Button moveBtn, attackBtn, strongBtn, defendBtn, swapBtn, fleeBtn, endBtn;
        private GameObject moveMark, attackMark, strongMark;
        private readonly Button[] abilityButtons = new Button[MaxAbilityButtons];
        private readonly GameObject[] abilityMarks = new GameObject[MaxAbilityButtons];
        private readonly Button[] itemButtons = new Button[3];
        private readonly ItemData[] itemSlots = new ItemData[3];

        // Panel de resultados Day R
        private GameObject resultPanel;
        private Text resultTitle;
        private Text resultXpText, resultBountyText;
        private Image resultHealthFill, resultXpFill;
        private Text resultHealthText, resultHungerText, resultThirstText, resultStaminaText, resultWarningText;
        private RectTransform resultLootContainer;
        private Text resultLootEmptyText;
        private readonly List<GameObject> resultLootCards = new List<GameObject>();

        // Sacudida de impacto
        private float boardShakeDuration = 0f;
        private Vector2 boardBasePos = new Vector2(0, 62f);

        // Banner cinemático de cambio de turno
        private GameObject turnBannerObj;
        private Text turnBannerTitle, turnBannerSub;
        private Coroutine turnBannerRoutine;

        private Mode mode = Mode.Move;
        private BattleAbility selectedAbility;
        private BattleUnit selected;
        private bool hasHover;
        private Vector2Int hoverTile;
        private bool hoveringTile;

        public static BattleUI Create(BattleManager battle, Transform parent)
        {
            GameObject go = new GameObject("BattleUI");
            go.transform.SetParent(parent, false);
            BattleUI ui = go.AddComponent<BattleUI>();
            ui.battle = battle;
            ui.Build();
            return ui;
        }

        private void OnEnable() { GameEvents.OnNotificationMessage += Log; }
        private void OnDisable() { GameEvents.OnNotificationMessage -= Log; }

        private BattleUnit Actor => battle.Current != null && battle.Current.playerControlled ? battle.Current : battle.Player;

        // ================================================================ API para BattleManager

        public void Open()
        {
            mode = Mode.Move;
            selectedAbility = null;
            selected = null;
            hasHover = false;
            hoveringTile = false;
            previewApCost = 0;
            combatLogHistory.Clear();
            resultPanel.SetActive(false);
            BuildBoard();
            root.SetActive(true);
            Refresh();
        }

        public void Close()
        {
            if (root != null) root.SetActive(false);
        }

        public void Log(string message)
        {
            if (string.IsNullOrEmpty(message)) return;
            combatLogHistory.Add(message);
            if (combatLogHistory.Count > 5) combatLogHistory.RemoveAt(0);

            if (logTerminalText != null)
            {
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                for (int i = 0; i < combatLogHistory.Count; i++)
                {
                    bool isLatest = (i == combatLogHistory.Count - 1);
                    string col = isLatest ? "#FFE082" : "#90A4AE";
                    sb.AppendLine($"<color={col}>> {combatLogHistory[i]}</color>");
                }
                logTerminalText.text = sb.ToString().TrimEnd();
            }
        }

        public void ShowResult(BattleResultData data)
        {
            if (data == null) return;
            resultTitle.text = data.victory ? "¡VICTORIA EN COMBATE!" : "DERROTA EN COMBATE";
            resultTitle.color = data.victory ? DayRCombatTheme.ApGold : DayRCombatTheme.DangerRed;

            // Experiencia
            resultXpText.text = $"<color=#69F0AE>+{data.xpGained} EXP</color>  (Total: {data.totalXp})";
            if (resultXpFill != null) resultXpFill.fillAmount = Mathf.Clamp01((data.totalXp % 100) / 100f);

            // Recompensa / Bounty
            if (data.bountyIncrease > 0)
                resultBountyText.text = $"<color=#FFD54F>RECOMPENSA: +{data.bountyIncrease:N0} Berries</color>  (Total: {data.totalBounty:N0} B)";
            else
                resultBountyText.text = data.totalBounty > 0 ? $"Recompensa actual: {data.totalBounty:N0} Berries" : "Sin precio por tu cabeza";

            // Salud
            float hpRatio = Mathf.Clamp01(data.currentHealth / Mathf.Max(1f, data.maxHealth));
            if (resultHealthFill != null)
            {
                resultHealthFill.fillAmount = hpRatio;
                resultHealthFill.color = hpRatio > 0.5f ? DayRCombatTheme.TacticalGreen : hpRatio > 0.25f ? DayRCombatTheme.TacticalAmber : DayRCombatTheme.DangerRed;
            }
            string lossText = data.healthLost > 0 ? $" <color=#FF5252>(-{data.healthLost:0})</color>" : "";
            resultHealthText.text = $"SALUD: {data.currentHealth:0} / {data.maxHealth:0} PV{lossText}";

            // Vitals
            resultHungerText.text = $"Hambre: {data.hunger:0}";
            resultThirstText.text = $"Sed: {data.thirst:0}";
            resultStaminaText.text = $"Energía: {data.stamina:0}";

            // Heridas
            if (data.isBleeding && data.isPoisoned)
                resultWarningText.text = "<color=#FF5252>! ¡SANGRADO Y VENENO ACTIVOS! Usa vendas y medicina de inmediato.</color>";
            else if (data.isBleeding)
                resultWarningText.text = "<color=#FF5252>! ¡HERIDA SANGRANTE ACTIVA! Aplica una venda al salir.</color>";
            else if (data.isPoisoned)
                resultWarningText.text = "<color=#CE93D8>! ¡CUERPO ENVENENADO! Usa medicina para neutralizarlo.</color>";
            else
                resultWarningText.text = "<color=#81C784>OK Sin heridas críticas abiertas.</color>";

            // Botín
            foreach (GameObject go in resultLootCards) Destroy(go);
            resultLootCards.Clear();

            bool hasLoot = data.loot != null && data.loot.Count > 0;
            resultLootEmptyText.gameObject.SetActive(!hasLoot);
            if (hasLoot)
            {
                for (int i = 0; i < data.loot.Count && i < 6; i++)
                {
                    LootReward reward = data.loot[i];
                    if (reward.item == null) continue;

                    GameObject cardObj = new GameObject($"Loot_{i}", typeof(RectTransform));
                    cardObj.transform.SetParent(resultLootContainer, false);
                    RectTransform rt = (RectTransform)cardObj.transform;
                    rt.sizeDelta = new Vector2(144, 134);

                    Image cardBg = cardObj.AddComponent<Image>();
                    cardBg.sprite = DayRCombatTheme.WeaponCardFrame();
                    cardBg.type = Image.Type.Sliced;
                    cardBg.color = DayRCombatTheme.SlateMedium;

                    // Icono del objeto
                    Image icon = UIFactory.Box(rt, "Icon", Color.white, false);
                    icon.sprite = reward.item.icon;
                    icon.preserveAspect = true;
                    UIFactory.Place(icon.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -10), new Vector2(58, 58));

                    // Cantidad
                    Text qty = UIFactory.Label(icon.transform, reward.quantity > 1 ? $"x{reward.quantity}" : "", 16, DayRCombatTheme.ApGold, TextAnchor.LowerRight, FontStyle.Bold);
                    UIFactory.Stretch(qty.rectTransform, 0, -4, 4, 0);

                    // Nombre
                    Text name = UIFactory.Label(rt, reward.item.itemName, 14, Color.white, TextAnchor.MiddleCenter, FontStyle.Bold, false);
                    name.horizontalOverflow = HorizontalWrapMode.Wrap;
                    UIFactory.Place(name.rectTransform, new Vector2(0.5f, 0f), new Vector2(0, 10), new Vector2(134, 42));

                    resultLootCards.Add(cardObj);
                }
            }

            resultPanel.SetActive(true);
            resultPanel.transform.SetAsLastSibling();
            // El sonido de victoria/derrota lo pone BattleManager (aquí sonaría dos veces)
        }

        public void ShowResult(string title, string body)
        {
            ShowResult(new BattleResultData
            {
                victory = title.Contains("VICTORIA") || title.Contains("Victoria"),
                title = title,
                healthLost = 0,
                currentHealth = Actor != null ? Actor.hp : 100,
                maxHealth = Actor != null ? Actor.maxHp : 100,
                hunger = 100, thirst = 100, stamina = 100
            });
        }

        public void ShowFloat(BattleUnit unit, string text, Color color)
        {
            if (unit == null) return;
            bool isDmg = text.StartsWith("-");
            // Crítico = cifra de daño en el color dorado que usa BattleManager para los críticos (no estados como "Aturdido")
            bool isCrit = isDmg && color.r > 0.9f && color.g > 0.8f && color.b < 0.35f;

            if (isDmg && views.TryGetValue(unit, out UnitView v))
            {
                v.shake = isCrit ? 0.5f : 0.3f;
                if (isCrit) TriggerBoardShake(0.35f);
            }
            if (isCrit) text = "¡CRÍTICO! " + text;
            // Los sonidos de golpe, fallo, guardia, recarga y objetos los pone BattleManager

            ShowFloatAt(unit.pos, text, color);
        }

        public void ShowFloatAt(Vector2Int tile, string text, Color color)
        {
            if (fxLayer == null) return;
            bool isCrit = text.Contains("CRÍTICO");
            int fontSize = isCrit ? 32 : 26;

            // Sombra/borde de texto para máxima legibilidad estilo cómic/táctico
            Text shadow = UIFactory.Label(fxLayer, text, fontSize, new Color(0.05f, 0.05f, 0.08f, 0.9f), TextAnchor.MiddleCenter, FontStyle.Bold);
            UIFactory.Place(shadow.rectTransform, Vector2.zero, CellPos(tile) + new Vector2(2f, Tile * 0.55f - 2f), new Vector2(300, 48));
            shadow.rectTransform.pivot = new Vector2(0.5f, 0.5f);

            Text t = UIFactory.Label(fxLayer, text, fontSize, isCrit ? DayRCombatTheme.ApGold : color, TextAnchor.MiddleCenter, FontStyle.Bold);
            UIFactory.Place(t.rectTransform, Vector2.zero, CellPos(tile) + new Vector2(0f, Tile * 0.55f), new Vector2(300, 48));
            t.rectTransform.pivot = new Vector2(0.5f, 0.5f);

            StartCoroutine(PunchFloatRoutine(t, shadow, isCrit));
        }

        private void TriggerBoardShake(float duration)
        {
            boardShakeDuration = Mathf.Max(boardShakeDuration, duration);
        }

        public void FlashTiles(List<Vector2Int> tiles, Color color)
        {
            if (fxLayer == null) return;
            foreach (Vector2Int p in tiles)
            {
                if (!battle.Grid.InBounds(p)) continue;
                Image f = UIFactory.Box(fxLayer, "Flash", color);
                UIFactory.Place(f.rectTransform, Vector2.zero, CellPos(p), new Vector2(Tile - 4, Tile - 4));
                f.rectTransform.pivot = new Vector2(0.5f, 0.5f);
                f.raycastTarget = false;
                StartCoroutine(FadeRoutine(f, 0.5f));
            }
        }

        public void AttackFx(BattleUnit attacker, Vector2Int target)
        {
            FlashTiles(new List<Vector2Int> { target }, new Color(1f, 1f, 1f, 0.55f));
            TriggerBoardShake(0.20f);

            if (attacker != null && views.TryGetValue(attacker, out UnitView v))
            {
                Vector2 dir = ((Vector2)(target - attacker.pos)).normalized;
                v.lunge = dir * Tile * 0.42f;
                if (Mathf.Abs(dir.x) > 0.1f) v.facing = Mathf.Sign(dir.x);
            }

            if (fxLayer != null && attacker != null)
            {
                StartCoroutine(SpawnCombatHitFx(attacker, target));
            }
        }

        private IEnumerator SpawnCombatHitFx(BattleUnit attacker, Vector2Int target)
        {
            BattleWeapon w = attacker.weapon;
            bool isRanged = w != null && w.IsRanged;
            bool isSlash = w != null && w.damageType == CombatDamageType.Slash;

            GameObject fxObj = new GameObject("HitFx", typeof(RectTransform));
            fxObj.transform.SetParent(fxLayer, false);
            RectTransform rt = (RectTransform)fxObj.transform;
            rt.pivot = new Vector2(0.5f, 0.5f);
            Image img = fxObj.AddComponent<Image>();
            img.raycastTarget = false;

            if (isSlash)
            {
                img.sprite = BattleArt.SlashFx();
                UIFactory.Place(rt, Vector2.zero, CellPos(target), new Vector2(Tile * 1.35f, Tile * 1.35f));
                Vector2 diff = target - attacker.pos;
                float angle = Mathf.Atan2(diff.y, diff.x) * Mathf.Rad2Deg - 45f;
                rt.localRotation = Quaternion.Euler(0, 0, angle);
                img.color = new Color(0.92f, 0.98f, 1f, 0.95f);
            }
            else if (isRanged)
            {
                img.sprite = BattleArt.SparksFx();
                UIFactory.Place(rt, Vector2.zero, CellPos(target), new Vector2(Tile * 1.15f, Tile * 1.15f));
                img.color = new Color(1f, 0.92f, 0.45f, 1f);
            }
            else
            {
                img.sprite = BattleArt.HitRingFx();
                UIFactory.Place(rt, Vector2.zero, CellPos(target), new Vector2(Tile * 1.15f, Tile * 1.15f));
                img.color = new Color(1f, 0.85f, 0.35f, 0.95f);
            }

            float duration = 0.28f;
            float t = 0f;
            Vector3 startScale = Vector3.one * 0.6f;
            Vector3 endScale = Vector3.one * 1.25f;
            Color baseCol = img.color;

            while (t < duration && fxObj != null)
            {
                t += Time.unscaledDeltaTime;
                float p = t / duration;
                rt.localScale = Vector3.Lerp(startScale, endScale, Mathf.Sqrt(p));
                img.color = new Color(baseCol.r, baseCol.g, baseCol.b, baseCol.a * (1f - p * p));
                yield return null;
            }

            if (fxObj != null) Destroy(fxObj);
        }

        public void AbilityFx(BattleAbility ab, BattleUnit user, List<Vector2Int> area)
        {
            Color c;
            switch (ab.animation)
            {
                case "stretch": c = ab.damageType == CombatDamageType.Fire ? new Color(1f, 0.45f, 0.1f, 0.85f) : new Color(1f, 0.82f, 0.65f, 0.85f); break;
                case "spin": c = new Color(1f, 0.92f, 0.4f, 0.8f); break;
                case "slash": c = new Color(0.85f, 0.95f, 1f, 0.85f); break;
                case "dash": c = new Color(0.4f, 0.85f, 1f, 0.75f); break;
                case "shockwave": c = new Color(0.6f, 0.2f, 0.9f, 0.85f); break;
                default: c = new Color(0.4f, 0.3f, 0.65f, 0.85f); break;
            }
            var tiles = new List<Vector2Int>(area) { user.pos };
            FlashTiles(tiles, c);
            TriggerBoardShake(0.25f);
        }

        public void Refresh()
        {
            if (battle == null || battle.Player == null || overlays == null) return;
            if (mode == Mode.Ability && (selectedAbility == null || !Actor.abilities.Contains(selectedAbility))) mode = Mode.Move;
            UpdateUnits();
            UpdateHighlights();
            UpdateTopPanel();
            UpdateBottomBar();
            if (!hasHover) infoText.text = DefaultHint();
        }

        // ================================================================ Entrada y Atajos de Teclado

        private void Update()
        {
            if (root == null || !root.activeSelf || battle == null || battle.Grid == null) return;
            float dt = Time.unscaledDeltaTime;
            float time = Time.unscaledTime;

            // Sacudida de pantalla / tablero táctico al recibir impactos
            if (boardShakeDuration > 0f)
            {
                boardShakeDuration -= dt;
                float shakeX = Mathf.Sin(time * 80f) * 7f * (boardShakeDuration / 0.35f);
                float shakeY = Mathf.Cos(time * 65f) * 5f * (boardShakeDuration / 0.35f);
                board.anchoredPosition = boardBasePos + new Vector2(shakeX, shakeY);
            }
            else
            {
                board.anchoredPosition = boardBasePos;
            }

            // Animación de fuego
            fireTimer += dt;
            if (fireTimer > 0.2f && props != null)
            {
                fireTimer = 0f;
                fireFrame++;
                BattleGrid g = battle.Grid;
                for (int x = 0; x < g.Width; x++)
                    for (int y = 0; y < g.Height; y++)
                        if (g.Get(new Vector2Int(x, y)) == TileType.Fire) PaintTile(x, y, TileType.Fire);
            }

            // Animación de unidades en combate (bobbing, lunge, shake)
            foreach (KeyValuePair<BattleUnit, UnitView> kv in views)
            {
                UnitView v = kv.Value;
                if (!v.rt.gameObject.activeSelf) continue;
                v.rt.anchoredPosition = Vector2.Lerp(v.rt.anchoredPosition, v.target, 1f - Mathf.Exp(-14f * dt));

                bool active = battle.Current == kv.Key;
                float bob = Mathf.Abs(Mathf.Sin(time * (active ? 6f : 2.4f) + v.phase)) * (active ? 7f : 2.5f);
                Vector2 shakeOffset = Vector2.zero;
                if (v.shake > 0f)
                {
                    v.shake -= dt;
                    shakeOffset = new Vector2(Mathf.Sin(time * 70f) * 6f, 0f);
                }
                v.lunge = Vector2.Lerp(v.lunge, Vector2.zero, 1f - Mathf.Exp(-9f * dt));
                v.body.anchoredPosition = new Vector2(0f, 10f + bob) + shakeOffset + v.lunge;
                v.body.localScale = new Vector3(v.facing, 1f, 1f);
            }

            // Atajos de teclado estilo Day R / táctico
            HandleHotkeys();
        }

        private void HandleHotkeys()
        {
            // Con la pausa abierta (ESC) las teclas son del menú, no del combate
            if (GameState.Current != GameScreen.Battle) return;

            if (resultPanel != null && resultPanel.activeSelf)
            {
                if (GameInput.IsBattleKeyPressed(BattleKey.Confirm))
                {
                    AudioManager.Instance.PlayUiClick();
                    battle.FinishAndReturn();
                }
                return;
            }
            if (!battle.CanAct) return;

            if (GameInput.IsBattleKeyPressed(BattleKey.Move)) { SetMode(Mode.Move); AudioManager.Instance.PlayUiClick(); }
            else if (GameInput.IsBattleKeyPressed(BattleKey.Attack))
            {
                if (Actor != null && Actor.weapon != null && Actor.weapon.needsReload && !Actor.loaded) battle.PlayerReload();
                else SetMode(Mode.Attack);
                AudioManager.Instance.PlayUiClick();
            }
            else if (GameInput.IsBattleKeyPressed(BattleKey.Strong)) { SetMode(Mode.Strong); AudioManager.Instance.PlayUiClick(); }
            else if (GameInput.IsBattleKeyPressed(BattleKey.Defend)) { battle.PlayerDefend(); AudioManager.Instance.PlayUiClick(); }
            else if (GameInput.IsBattleKeyPressed(BattleKey.Swap)) { battle.PlayerSwapWeapon(); AudioManager.Instance.PlayUiClick(); }
            else if (GameInput.IsBattleKeyPressed(BattleKey.Reload)) { battle.PlayerReload(); AudioManager.Instance.PlayUiClick(); }
            else if (GameInput.IsBattleKeyPressed(BattleKey.Flee)) { battle.PlayerFlee(); AudioManager.Instance.PlayUiClick(); }
            else if (GameInput.IsBattleKeyPressed(BattleKey.EndTurn)) { battle.PlayerEndTurn(); AudioManager.Instance.PlayUiClick(); }
        }

        private void OnCellClick(Vector2Int p)
        {
            if (!battle.CanAct) return;
            BattleUnit actor = Actor;
            BattleUnit u = battle.UnitAt(p);

            if (mode == Mode.Ability)
            {
                if (battle.AbilityTargets(actor, selectedAbility).Contains(p))
                {
                    battle.PlayerUseAbility(selectedAbility, p);
                    mode = Mode.Move;
                }
                else
                {
                    SetMode(Mode.Move);
                }
                return;
            }

            if (u != null && u.faction == Faction.Enemy)
            {
                selected = u;
                bool strong = (mode == Mode.Strong);
                if (battle.CanAttack(actor, u, strong))
                {
                    battle.PlayerAttack(u, strong);
                }
                else if (mode == Mode.Move && battle.CanAttack(actor, u, false))
                {
                    // Smart auto-attack: si el jugador hace clic en un enemigo a su alcance en modo movimiento, ataca de inmediato
                    battle.PlayerAttack(u, false);
                }
                else
                {
                    // Feedback visual inmediato y sonoro para que el jugador sepa con precisión por qué no alcanza o no puede atacar
                    string reason = GetAttackFailureReason(actor, u, strong);
                    ShowFloatAt(u.pos, reason, new Color(1f, 0.45f, 0.45f));
                    if (AudioManager.Instance != null) AudioManager.Instance.PlayCraftFailed();
                }
                Refresh();
                return;
            }

            if (battle.Grid.IsDestructible(p))
            {
                bool strong = (mode == Mode.Strong);
                if (battle.CanAttackObject(actor, p, strong))
                {
                    battle.PlayerAttackObject(p, strong);
                    return;
                }
                else if (mode == Mode.Move && battle.CanAttackObject(actor, p, false))
                {
                    battle.PlayerAttackObject(p, false);
                    return;
                }
            }

            if (mode == Mode.Move)
            {
                Dictionary<Vector2Int, int> reach = battle.ReachableFrom(actor, actor.ap, out _);
                if (reach.ContainsKey(p) && p != actor.pos)
                {
                    battle.PlayerMove(p);
                }
                else if (battle.Grid.IsPassable(p) && battle.UnitAt(p) == null)
                {
                    ShowFloatAt(p, "¡Demasiado lejos!", new Color(1f, 0.85f, 0.35f));
                    if (AudioManager.Instance != null) AudioManager.Instance.PlayCraftFailed();
                }
            }
            else
            {
                SetMode(Mode.Move);
            }
        }

        private string GetAttackFailureReason(BattleUnit attacker, BattleUnit target, bool strong)
        {
            if (attacker == null || target == null) return "Inválido";
            if (!target.Alive) return "Caído";
            int cost = battle.AttackCost(attacker, strong);
            if (attacker.ap < cost) return $"¡Sin AP! ({attacker.ap}/{cost})";
            if (strong && attacker.Stamina < BattleManager.StrongStaminaCost) return "¡Sin Stamina!";
            if (attacker.weapon != null && attacker.weapon.needsReload && !attacker.loaded) return "¡Sin recargar! [R]";
            if (attacker.weapon != null && !string.IsNullOrEmpty(attacker.weapon.ammoItemId) && attacker.stats != null)
            {
                if (InventoryManager.Instance != null && InventoryManager.Instance.GetItemCount(attacker.weapon.ammoItemId) <= 0)
                    return "¡Sin munición!";
            }
            int dist = BattleGrid.Distance(attacker.pos, target.pos);
            if (dist < attacker.weapon.minRange) return $"¡Muy cerca! (Mín: {attacker.weapon.minRange})";
            if (dist > attacker.weapon.maxRange) return $"¡Lejos! ({dist}/{attacker.weapon.maxRange})";
            if (!battle.Grid.HasLineOfSight(attacker.pos, target.pos)) return "¡Línea bloqueada!";
            return "Imposible";
        }

        private void OnCellHover(Vector2Int p)
        {
            hasHover = true;
            hoveringTile = true;
            hoverTile = p;
            BattleUnit actor = Actor;
            BattleUnit u = battle.UnitAt(p);

            if (mode == Mode.Ability)
            {
                UpdateHighlights();
                infoText.text = AbilityHoverText(actor, p);
                return;
            }

            if (u != null)
            {
                if (u.faction == Faction.Enemy) { selected = u; UpdateTopPanel(); }
                bool strong = mode == Mode.Strong;
                if (u.faction == Faction.Enemy && mode != Mode.Move && battle.CanAttack(actor, u, strong))
                {
                    battle.EstimateDamage(actor, u, strong, out int min, out int max);
                    float chance = battle.HitChance(actor, actor.pos, u, strong);
                    string logia = max <= 0 ? "   (¡Logia! tu ataque le atraviesa)" : "";
                    infoText.text = $"{u.name}: impacto {chance * 100f:0}%   |   daño {min}-{max}   |   coste {battle.AttackCost(actor, strong)} AP" +
                                    (strong ? $" + {BattleManager.StrongStaminaCost:0} energía" : "") + logia;
                }
                else
                {
                    string why = u.faction == Faction.Enemy && mode != Mode.Move ? "   (fuera de alcance, sin línea de visión o sin AP)" : "";
                    string states = u.statuses.Count > 0 ? "   |   " + StatusEffectSystem.Describe(u) : "";
                    string traits = (u.isLogia ? "   |   Logia" : "") + (u.isFruitUser ? "   |   Usuario de Fruta" : "");
                    infoText.text = $"{u.name}: {u.Hp}/{u.MaxHp} PV   |   {u.weapon.name}, alcance {u.weapon.minRange}-{u.weapon.maxRange}{traits}{states}{why}";
                }
                return;
            }

            if (mode != Mode.Move && battle.Grid.IsDestructible(p))
            {
                bool ok = battle.CanAttackObject(actor, p, mode == Mode.Strong);
                infoText.text = $"{TileName(battle.Grid.Get(p))} ({battle.Grid.ObjectHp(p)} PV){(ok ? $": atacar cuesta {battle.AttackCost(actor, mode == Mode.Strong)} AP" : ": fuera de alcance")}";
                return;
            }

            if (mode == Mode.Move && battle.CanAct)
            {
                Dictionary<Vector2Int, int> reach = battle.ReachableFrom(actor, actor.ap, out _);
                if (reach.TryGetValue(p, out int cost) && cost > 0)
                {
                    infoText.text = $"Mover aquí: {cost} AP" + TileWarning(battle.Grid.Get(p));
                    return;
                }
            }
            infoText.text = TileDescription(battle.Grid.Get(p));
        }

        private string AbilityHoverText(BattleUnit actor, Vector2Int p)
        {
            BattleAbility ab = selectedAbility;
            if (!battle.AbilityTargets(actor, ab).Contains(p)) return $"{ab.name}: elige una casilla morada. Clic fuera para cancelar.";
            var parts = new List<string>();
            foreach (Vector2Int t in battle.AbilityArea(actor, ab, p))
            {
                BattleUnit u = battle.UnitAt(t);
                if (u == null || u.faction == actor.faction) continue;
                if (ab.maxTargetHp > 0 && u.MaxHp > ab.maxTargetHp) { parts.Add($"{u.name}: resiste"); continue; }
                parts.Add($"{u.name}: ~{ab.damage} daño");
            }
            return parts.Count > 0 ? $"{ab.name} alcanzará a: {string.Join(", ", parts)}" : $"{ab.name}: área seleccionada.";
        }

        private void ClearHover()
        {
            hasHover = false;
            hoveringTile = false;
            previewApCost = 0;
            if (infoText != null) infoText.text = DefaultHint();
            UpdateHighlights();
            UpdateBottomBar();
        }

        private void SetMode(Mode m)
        {
            mode = m;
            if (m != Mode.Ability) selectedAbility = null;
            Refresh();
        }

        private void SelectAbility(int index)
        {
            BattleUnit actor = Actor;
            if (index >= actor.abilities.Count || !battle.CanAct) return;
            BattleAbility ab = actor.abilities[index];
            if (!battle.CanUseAbility(actor, ab, out _)) return;
            if (ab.shape == AbilityShape.Self || ab.shape == AbilityShape.AroundSelf)
            {
                battle.PlayerUseAbility(ab, actor.pos);
                return;
            }
            selectedAbility = ab;
            SetMode(Mode.Ability);
        }

        private string DefaultHint()
        {
            if (!battle.CanAct) return battle.Busy ? "" : "Turno enemigo en curso...";
            switch (mode)
            {
                case Mode.Attack: return "[2] ATACAR: Selecciona un enemigo en rango (retícula roja) u obstáculo. Clic en suelo para cancelar.";
                case Mode.Strong: return "[3] GOLPE POTENTE: Daño aumentado x1.6 a cambio de energía y menor precisión.";
                case Mode.Ability: return $"{selectedAbility.name}: Elige una casilla de efecto.";
                default: return "[1] MOVER: Haz clic en una casilla táctica resaltada. Usa [2] Atacar o [Espacio] Fin de Turno.";
            }
        }

        private static string TileName(TileType t)
        {
            switch (t)
            {
                case TileType.Barrel: return "Barril";
                case TileType.ExplosiveBarrel: return "Barril de pólvora";
                case TileType.Crate: return "Caja";
                default: return t.ToString();
            }
        }

        private static string TileWarning(TileType t)
        {
            switch (t)
            {
                case TileType.Fire: return "   ¡Fuego: te quemarás!";
                case TileType.Shallow: return "   (orilla: 2 AP, te mojas; debilita a usuarios de Fruta)";
                case TileType.Bush: return "   (arbusto: 2 AP, da cobertura)";
                default: return "";
            }
        }

        private static string TileDescription(TileType t)
        {
            switch (t)
            {
                case TileType.Rock: return "Roca: Bloquea paso y línea de tiro.";
                case TileType.Tree: return "Árbol: Bloquea paso y disparos.";
                case TileType.Mast: return "Mástil: Bloquea paso y proyectiles.";
                case TileType.Cover: return "Restos de barco: Bloquean paso y otorgan cobertura (-30% daño de disparos).";
                case TileType.Barrel: return "Barril: Cobertura baja destructible.";
                case TileType.ExplosiveBarrel: return "Barril de pólvora: ¡Explosivo! Detona en cadena causando daño en área.";
                case TileType.Crate: return "Caja: Cobertura destructible.";
                case TileType.Fire: return "Fuego: Aplica quemadura continua a quien lo pise.";
                case TileType.Shallow: return "Orilla: Cuesta 2 AP. Moja y debilita severamente a usuarios de Fruta.";
                case TileType.Bush: return "Arbusto: Cuesta 2 AP. Concede cobertura de sigilo.";
                case TileType.Water: return "Mar profundo: Intransitable. Si caes con Fruta, ahogamiento garantizado.";
                default: return "Terreno táctico despejado.";
            }
        }

        // ================================================================ Renderizado y Tablero

        private Vector2 CellPos(Vector2Int p) => new Vector2((p.x + 0.5f) * Tile, (p.y + 0.5f) * Tile);

        private void UpdateUnits()
        {
            foreach (KeyValuePair<BattleUnit, UnitView> kv in views)
            {
                BattleUnit u = kv.Key;
                UnitView v = kv.Value;
                v.rt.gameObject.SetActive(u.Alive);
                if (!u.Alive) continue;
                v.target = CellPos(u.pos);
                if (!v.placed) { v.rt.anchoredPosition = v.target; v.placed = true; }
                v.hpFill.fillAmount = Mathf.Clamp01((float)u.Hp / Mathf.Max(1, u.MaxHp));
                v.activeFrame.SetActive(battle.Current == u);
                string tag = StatusEffectSystem.Codes(u);
                if (u.defending) tag = "GUARDIA " + tag;
                if (u.weapon != null && u.weapon.needsReload && !u.loaded) tag = "SIN CARGAR " + tag;
                v.tag.text = tag;
            }
        }

        private void RefreshTileColors()
        {
            BattleGrid g = battle.Grid;
            for (int x = 0; x < g.Width; x++)
                for (int y = 0; y < g.Height; y++)
                    PaintTile(x, y, g.Get(new Vector2Int(x, y)));
        }

        private void PaintTile(int x, int y, TileType t)
        {
            Sprite special = BattleArt.SpecialGround(t);
            cells[x, y].sprite = special != null ? special : BattleArt.GroundTile(groundStyle, x, y);
            float shade = (x + y) % 2 == 0 ? 1f : 0.94f;
            cells[x, y].color = new Color(shade, shade, shade, 1f);

            Sprite prop = BattleArt.Prop(t, fireFrame);
            Image pi = props[x, y];
            pi.enabled = prop != null;
            if (prop == null) return;
            pi.sprite = prop;
            pi.color = Color.white;
            bool tall = BattleArt.IsTall(t);
            RectTransform r = pi.rectTransform;
            r.anchorMin = r.anchorMax = new Vector2(0.5f, 0f);
            r.pivot = new Vector2(0.5f, 0f);
            r.anchoredPosition = new Vector2(0f, tall ? 2f : 6f);
            r.sizeDelta = tall ? new Vector2(Tile * 1.05f, Tile * 1.25f) : new Vector2(Tile * 0.82f, Tile * 0.82f);
        }

        private void UpdateHighlights()
        {
            BattleGrid g = battle.Grid;
            RefreshTileColors();
            for (int x = 0; x < g.Width; x++)
            {
                for (int y = 0; y < g.Height; y++)
                {
                    overlays[x, y].color = Color.clear;
                    cellTexts[x, y].text = string.Empty;
                    Vector2Int p = new Vector2Int(x, y);
                    if (g.IsDestructible(p)) cellTexts[x, y].text = g.ObjectHp(p).ToString();
                }
            }
            if (!battle.CanAct) return;

            BattleUnit a = Actor;
            if (a == null) return;
            if (mode == Mode.Move)
            {
                foreach (KeyValuePair<Vector2Int, int> kv in battle.ReachableFrom(a, a.ap, out _))
                {
                    if (kv.Value == 0) continue;
                    overlays[kv.Key.x, kv.Key.y].color = MoveTint;
                    cellTexts[kv.Key.x, kv.Key.y].text = kv.Value.ToString();
                }
                return;
            }

            if (mode == Mode.Ability)
            {
                foreach (Vector2Int p in battle.AbilityTargets(a, selectedAbility)) overlays[p.x, p.y].color = AbilityTint;
                if (hoveringTile && battle.AbilityTargets(a, selectedAbility).Contains(hoverTile))
                    foreach (Vector2Int p in battle.AbilityArea(a, selectedAbility, hoverTile)) overlays[p.x, p.y].color = AreaTint;
                return;
            }

            bool strong = mode == Mode.Strong;
            for (int x = 0; x < g.Width; x++)
            {
                for (int y = 0; y < g.Height; y++)
                {
                    Vector2Int c = new Vector2Int(x, y);
                    if (c == a.pos || !battle.InRange(a, a.pos, c)) continue;
                    overlays[x, y].color = battle.CanAttackObject(a, c, strong) ? ObjectTint : RangeTint;
                }
            }
            foreach (BattleUnit e in battle.Units)
            {
                if (e.faction != Faction.Enemy || !battle.CanAttack(a, e, strong)) continue;
                overlays[e.pos.x, e.pos.y].color = TargetTint;
                cellTexts[e.pos.x, e.pos.y].text = $"{battle.HitChance(a, a.pos, e, strong) * 100f:0}%";
            }
        }

        // ================================================================ Inspección de Objetivo (Day R)

        private void UpdateTopPanel()
        {
            if (selected == null || !selected.Alive)
            {
                selected = null;
                foreach (BattleUnit u in battle.Units)
                {
                    if (u.faction == Faction.Enemy && u.Alive) { selected = u; break; }
                }
            }

            if (selected == null)
            {
                targetName.text = "<color=#90A4AE>SIN OBJETIVO FIJADO</color>";
                targetDetail.text = "Todos los enemigos del sector han sido eliminados.";
                targetHpFill.fillAmount = 0f;
                targetHitChance.text = "--%";
                targetDamageEst.text = "DAÑO: --";
                targetCoverInfo.text = "ESTADO: DESPEJADO";
                if (targetAvatar != null) targetAvatar.enabled = false;
                return;
            }

            BattleWeapon w = selected.weapon ?? BattleWeapon.Fists();
            string threatBadge = selected.isLogia ? " [LOGIA]" : selected.isFruitUser ? " [USUARIO FRUTA]" : "";
            targetName.text = $"{selected.name}{threatBadge}";
            targetHpFill.fillAmount = Mathf.Clamp01((float)selected.Hp / Mathf.Max(1, selected.MaxHp));
            if (targetAvatar != null)
            {
                targetAvatar.enabled = (selected.sprite != null);
                targetAvatar.sprite = selected.sprite;
            }

            string states = StatusEffectSystem.Describe(selected);
            if (selected.defending) states = "EN GUARDIA, " + states;
            if (string.IsNullOrEmpty(states)) states = "Condición estable";
            targetDetail.text = $"PV {selected.Hp}/{selected.MaxHp}  |  Arma: {w.name} (Alcance {w.minRange}-{w.maxRange})  |  {states}";

            BattleUnit a = Actor;
            bool inRange = battle.InRange(a, a.pos, selected.pos);
            if (inRange && battle.CanAct)
            {
                bool strong = mode == Mode.Strong;
                float hit = battle.HitChance(a, a.pos, selected, strong);
                battle.EstimateDamage(a, selected, strong, out int minDmg, out int maxDmg);

                string hitCol = hit >= 0.75f ? "#69F0AE" : hit >= 0.5f ? "#FFD54F" : "#FF5252";
                targetHitChance.text = $"<color={hitCol}>{hit * 100f:0}% IMPACTO</color>";
                targetDamageEst.text = $"EST: {minDmg}-{maxDmg} DAÑO";

                bool hasCover = battle.Grid != null && battle.Grid.HasCover(selected.pos, a.pos);
                targetCoverInfo.text = hasCover ? "<color=#FFD54F>COBERTURA: -30% DAÑO</color>" : "<color=#69F0AE>BLANCO EXPUESTO</color>";
            }
            else
            {
                targetHitChance.text = "<color=#90A4AE>FUERA DE TIRO</color>";
                targetDamageEst.text = "DAÑO: --";
                bool hasCover = battle.Grid != null && battle.Grid.HasCover(selected.pos, a.pos);
                targetCoverInfo.text = hasCover ? "EN COBERTURA" : "EXPUESTO";
            }
        }

        // ================================================================ Barra de Acción y Tarjeta Day R

        private void UpdateBottomBar()
        {
            BattleUnit a = Actor;
            if (a == null) return;
            bool act = battle.CanAct;
            bool hero = a == battle.Player;

            // Batería táctica de AP
            string costText = previewApCost > 0 ? $" <color=#FF5252>(-{previewApCost} AP)</color>" : "";
            apText.text = $"AP <color=#FFD54F>{a.ap}</color> / {a.maxAp}{costText}";
            for (int i = 0; i < apPips.Length; i++)
            {
                bool exists = i < a.maxAp;
                apPips[i].gameObject.SetActive(exists);
                if (!exists) continue;

                bool isAvailable = i < a.ap;
                bool isPreviewSpent = previewApCost > 0 && i >= (a.ap - previewApCost) && i < a.ap;

                if (isPreviewSpent)
                {
                    apPips[i].color = DayRCombatTheme.DangerRed;
                }
                else
                {
                    apPips[i].color = isAvailable ? DayRCombatTheme.ApGold : DayRCombatTheme.ApEmpty;
                }
            }

            // Barras de Salud y Energía
            hpFill.fillAmount = Mathf.Clamp01((float)a.Hp / Mathf.Max(1, a.MaxHp));
            hpText.text = $"PV {a.Hp} / {a.MaxHp}";
            staminaFill.fillAmount = Mathf.Clamp01(a.Stamina / Mathf.Max(1f, a.MaxStaminaValue));
            staminaText.text = $"ENERGÍA {a.Stamina:0} / {a.MaxStaminaValue:0}";

            // Tarjeta de Arma Equipada (Day R Survival Weapon Module)
            BattleWeapon w = a.weapon ?? BattleWeapon.Fists();
            weaponNameText.text = w.name;
            Sprite wSprite = (w.item != null && w.item.icon != null) ? w.item.icon : BattleArt.Prop(TileType.Cover, 0);
            weaponIconImg.enabled = (wSprite != null);
            weaponIconImg.sprite = wSprite;

            string dmgType = w.damageType == CombatDamageType.Slash ? "Filo" :
                             w.damageType == CombatDamageType.Pierce ? "Perforante" :
                             w.damageType == CombatDamageType.Blunt ? "Impacto" :
                             w.damageType == CombatDamageType.Fire ? "Fuego" : "Físico";

            weaponDamageText.text = $"Daño: <color=#FFE082>{w.damage}</color> [{dmgType}]   Prec: {w.accuracy * 100f:0}%   Crítico: {w.critChance * 100f:0}%";
            weaponRangeText.text = $"Alcance: {w.minRange}-{w.maxRange} celdas   Coste: <color=#FFD54F>{w.apCost} AP</color>";

            // Munición y Durabilidad
            if (hero && w.item != null && !string.IsNullOrEmpty(w.ammoItemId) && InventoryManager.Instance != null)
            {
                int ammoCount = InventoryManager.Instance.CountItem(w.ammoItemId);
                weaponAmmoText.text = ammoCount > 0 ? $"Munición: <color=#69F0AE>{ammoCount}</color>" : "<color=#FF5252>¡SIN MUNICIÓN!</color>";
            }
            else
            {
                weaponAmmoText.text = w.IsRanged ? "Munición infinita" : "Arma de combate cuerpo a cuerpo";
            }

            int durCurrent = 0;
            int durMax = 0;
            if (hero && w.item != null && w.item.maxDurability > 0 && InventoryManager.Instance != null)
            {
                durMax = w.item.maxDurability;
                foreach (InventorySlot s in InventoryManager.Instance.Slots)
                {
                    if (!s.IsEmpty && s.ItemData == w.item) { durCurrent = s.Durability; break; }
                }
                float durPct = Mathf.Clamp01((float)durCurrent / durMax);
                weaponDurabilityFill.fillAmount = durPct;
                weaponDurabilityFill.color = durPct > 0.5f ? DayRCombatTheme.TacticalGreen : durPct > 0.2f ? DayRCombatTheme.TacticalAmber : DayRCombatTheme.DangerRed;
                weaponDurabilityText.text = $"Integridad: {durCurrent} / {durMax} ({durPct * 100f:0}%)";
            }
            else
            {
                weaponDurabilityFill.fillAmount = 1f;
                weaponDurabilityFill.color = DayRCombatTheme.TacticalGreen;
                weaponDurabilityText.text = "Integridad: Indestructible";
            }

            statusText.text = a.statuses.Count > 0 ? "Estados activos: " + StatusEffectSystem.Codes(a) : "Condición física óptima";

            // Botones de acción
            UIFactory.SetButtonEnabled(moveBtn, act && StatusEffectSystem.CanMove(a));
            UIFactory.SetButtonEnabled(attackBtn, act && a.ap >= battle.AttackCost(a, false) && !(w.needsReload && !a.loaded));
            UIFactory.SetButtonEnabled(strongBtn, act && a.ap >= battle.AttackCost(a, true) && a.Stamina >= BattleManager.StrongStaminaCost);
            UIFactory.SetButtonEnabled(defendBtn, act && !a.defending && a.ap >= BattleManager.DefendCost);
            UIFactory.SetButtonEnabled(swapBtn, act && hero && a.ap >= BattleManager.SwapWeaponCost && battle.OwnedWeapons().Count > 1);
            UIFactory.SetButtonEnabled(fleeBtn, battle.CanFlee(out _, out _));
            UIFactory.SetButtonEnabled(endBtn, act);

            moveMark.SetActive(mode == Mode.Move);
            attackMark.SetActive(mode == Mode.Attack);
            strongMark.SetActive(mode == Mode.Strong);

            // Habilidades de Fruta / Haki
            for (int i = 0; i < abilityButtons.Length; i++)
            {
                bool has = a.abilities != null && i < a.abilities.Count;
                abilityButtons[i].gameObject.SetActive(has);
                if (!has) continue;
                BattleAbility ab = a.abilities[i];
                if (ab == null) continue;
                int cd = a.Cooldown(ab.id);
                UIFactory.SetButtonLabel(abilityButtons[i], cd > 0 ? $"{ab.name}\n<size=15>recarga {cd}</size>" : $"{ab.name}\n<size=15>{ab.apCost} AP · {ab.staminaCost:0} En</size>");
                UIFactory.SetButtonEnabled(abilityButtons[i], act && battle.CanUseAbility(a, ab, out _));
                abilityMarks[i].SetActive(mode == Mode.Ability && selectedAbility == ab);
            }

            // Objetos rápidos
            for (int i = 0; i < itemSlots.Length; i++) itemSlots[i] = null;
            int n = 0;
            var counts = new Dictionary<ItemData, int>();
            if (InventoryManager.Instance != null)
            {
                foreach (InventorySlot slot in InventoryManager.Instance.Slots)
                {
                    if (slot.IsEmpty) continue;
                    ItemData it = slot.ItemData;
                    if (it.itemType != ItemType.Food && it.itemType != ItemType.Drink && it.itemType != ItemType.Medicine) continue;
                    if (!counts.ContainsKey(it))
                    {
                        counts[it] = 0;
                        if (n < itemSlots.Length) itemSlots[n++] = it;
                    }
                    counts[it] += slot.Quantity;
                }
            }
            for (int i = 0; i < itemButtons.Length; i++)
            {
                ItemData it = itemSlots[i];
                itemButtons[i].gameObject.SetActive(it != null);
                if (it == null) continue;
                UIFactory.SetButtonLabel(itemButtons[i], $"{it.itemName} x{counts[it]}");
                UIFactory.SetButtonEnabled(itemButtons[i], act && hero && a.ap >= BattleManager.ItemCost);
            }
        }

        // ================================================================ Construcción de la UI

        private void Build()
        {
            root = new GameObject("Canvas_Battle");
            root.transform.SetParent(transform, false);
            Canvas canvas = root.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 50;
            CanvasScaler scaler = root.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;
            root.AddComponent<GraphicRaycaster>();

            // Fondo oscuro de combate táctico (Vignette slate Day R)
            Image bg = UIFactory.Box(root.transform, "Background", new Color(0.04f, 0.06f, 0.08f, 1f), false);
            UIFactory.Stretch(bg.rectTransform);

            Image sea = UIFactory.Box(root.transform, "Sea", new Color(0.2f, 0.28f, 0.38f, 0.35f), false);
            sea.sprite = BattleArt.SpecialGround(TileType.Water);
            sea.type = Image.Type.Tiled;
            sea.pixelsPerUnitMultiplier = 1f;
            sea.raycastTarget = false;
            UIFactory.Stretch(sea.rectTransform);

            BuildTopPanel();
            BuildCombatLogTerminal();

            board = UIFactory.NewRect("Board", root.transform);
            UIFactory.Place(board, new Vector2(0.5f, 0.5f), boardBasePos, new Vector2(Tile, Tile));

            // Indicador de pistas de navegación
            Image infoBox = UIFactory.Box(root.transform, "InfoBox", DayRCombatTheme.SlateDark);
            infoBox.sprite = DayRCombatTheme.TacticalPanel();
            infoBox.type = Image.Type.Sliced;
            infoBox.raycastTarget = false;
            UIFactory.Place(infoBox.rectTransform, new Vector2(0.5f, 0f), new Vector2(0, 240), new Vector2(1600, 38));
            infoText = UIFactory.Label(infoBox.transform, "", 18, DayRCombatTheme.ApGold, TextAnchor.MiddleCenter, FontStyle.Normal, false);
            UIFactory.Stretch(infoText.rectTransform, 14, 0, 14, 0);

            BuildBottomBar();
            BuildResultPanel();

            // Banner de Turno Táctico Cinemático
            turnBannerObj = new GameObject("TurnBanner", typeof(RectTransform));
            turnBannerObj.transform.SetParent(root.transform, false);
            RectTransform bannerRt = (RectTransform)turnBannerObj.transform;
            UIFactory.Place(bannerRt, new Vector2(0.5f, 0.5f), new Vector2(0, 160f), new Vector2(680, 84));
            Image bannerBg = turnBannerObj.AddComponent<Image>();
            bannerBg.sprite = DayRCombatTheme.TacticalPanel();
            bannerBg.type = Image.Type.Sliced;
            bannerBg.color = new Color(0.08f, 0.10f, 0.14f, 0.94f);
            bannerBg.raycastTarget = false;

            turnBannerTitle = UIFactory.Label(bannerRt, "¡TU TURNO!", 30, DayRCombatTheme.ApGold, TextAnchor.MiddleCenter, FontStyle.Bold);
            UIFactory.Place(turnBannerTitle.rectTransform, new Vector2(0.5f, 0.62f), Vector2.zero, new Vector2(660, 42));
            turnBannerTitle.raycastTarget = false;

            turnBannerSub = UIFactory.Label(bannerRt, "", 16, new Color(0.85f, 0.90f, 0.95f), TextAnchor.MiddleCenter, FontStyle.Normal);
            UIFactory.Place(turnBannerSub.rectTransform, new Vector2(0.5f, 0.22f), Vector2.zero, new Vector2(660, 28));
            turnBannerSub.raycastTarget = false;

            turnBannerObj.SetActive(false);

            root.SetActive(false);
        }

        public void ShowTurnBanner(string title, Color color, string subtitle = "")
        {
            if (turnBannerObj == null) return;
            if (turnBannerRoutine != null) StopCoroutine(turnBannerRoutine);
            turnBannerRoutine = StartCoroutine(TurnBannerRoutine(title, color, subtitle));
        }

        private IEnumerator TurnBannerRoutine(string title, Color color, string subtitle)
        {
            turnBannerTitle.text = title;
            turnBannerTitle.color = color;
            turnBannerSub.text = subtitle;
            turnBannerObj.SetActive(true);
            turnBannerObj.transform.SetAsLastSibling();

            RectTransform rt = (RectTransform)turnBannerObj.transform;
            CanvasGroup cg = turnBannerObj.GetComponent<CanvasGroup>();
            if (cg == null) cg = turnBannerObj.AddComponent<CanvasGroup>();

            float duration = 1.35f;
            float elapsed = 0f;
            while (elapsed < duration && turnBannerObj != null)
            {
                elapsed += Time.unscaledDeltaTime;
                float p = elapsed / duration;

                float scale = p < 0.2f ? Mathf.Lerp(0.7f, 1.05f, p / 0.2f) : (p < 0.35f ? Mathf.Lerp(1.05f, 1f, (p - 0.2f) / 0.15f) : 1f);
                rt.localScale = new Vector3(scale, scale, 1f);

                float alpha = p < 0.7f ? 1f : Mathf.Clamp01((1f - p) / 0.3f);
                cg.alpha = alpha;

                yield return null;
            }

            if (turnBannerObj != null) turnBannerObj.SetActive(false);
        }

        private void BuildTopPanel()
        {
            // Panel superior de inspección táctica Day R
            Image top = UIFactory.Box(root.transform, "TargetPanel", DayRCombatTheme.SlateDark);
            top.sprite = DayRCombatTheme.TacticalPanel();
            top.type = Image.Type.Sliced;
            UIFactory.Place(top.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -12), new Vector2(1380, 96));
            Transform t = top.transform;

            // Retrato del enemigo fijado
            Image avBg = UIFactory.Box(t, "AvatarBg", new Color(0.05f, 0.07f, 0.1f, 1f));
            UIFactory.Place(avBg.rectTransform, new Vector2(0, 0.5f), new Vector2(48, 0), new Vector2(72, 72));
            targetAvatar = UIFactory.Box(avBg.transform, "Avatar", Color.white, false);
            UIFactory.Stretch(targetAvatar.rectTransform, 4, 4, 4, 4);
            targetAvatar.preserveAspect = true;

            // Nombre y detalles
            targetName = UIFactory.Label(t, "BLANCO FIJADO", 26, DayRCombatTheme.ApGold, TextAnchor.MiddleLeft, FontStyle.Bold);
            UIFactory.Place(targetName.rectTransform, new Vector2(0, 1), new Vector2(96, -8), new Vector2(450, 36));

            targetDetail = UIFactory.Label(t, "", 17, new Color(0.85f, 0.9f, 0.95f), TextAnchor.MiddleLeft, FontStyle.Normal, false);
            UIFactory.Place(targetDetail.rectTransform, new Vector2(0, 0), new Vector2(96, 12), new Vector2(620, 30));

            // Barra de vida del enemigo
            Image hpBg = UIFactory.Box(t, "EnemyHpBg", new Color(0.04f, 0.05f, 0.08f, 1f));
            UIFactory.Place(hpBg.rectTransform, new Vector2(0, 1), new Vector2(560, -14), new Vector2(300, 24));
            targetHpFill = StatFill(hpBg.transform, DayRCombatTheme.DangerRed);

            // Estadísticas tácticas proyectadas (Probabilidad de impacto, daño estimado, cobertura)
            targetHitChance = UIFactory.Label(t, "85% IMPACTO", 22, DayRCombatTheme.TacticalGreen, TextAnchor.MiddleCenter, FontStyle.Bold);
            UIFactory.Place(targetHitChance.rectTransform, new Vector2(1, 0.5f), new Vector2(-360, 16), new Vector2(200, 32));

            targetDamageEst = UIFactory.Label(t, "EST: 12-16 DAÑO", 17, Color.white, TextAnchor.MiddleCenter, FontStyle.Bold);
            UIFactory.Place(targetDamageEst.rectTransform, new Vector2(1, 0.5f), new Vector2(-360, -14), new Vector2(200, 26));

            targetCoverInfo = UIFactory.Label(t, "COBERTURA", 16, DayRCombatTheme.TacticalAmber, TextAnchor.MiddleCenter, FontStyle.Bold);
            UIFactory.Place(targetCoverInfo.rectTransform, new Vector2(1, 0.5f), new Vector2(-120, 0), new Vector2(220, 32));
        }

        private void BuildCombatLogTerminal()
        {
            // Terminal táctica multilínea estilo Day R
            Image termBox = UIFactory.Box(root.transform, "CombatTerminal", new Color(0.06f, 0.08f, 0.11f, 0.88f));
            termBox.sprite = DayRCombatTheme.TacticalPanel();
            termBox.type = Image.Type.Sliced;
            termBox.raycastTarget = false; // no tapa los clics sobre el tablero
            UIFactory.Place(termBox.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -114), new Vector2(1380, 74));

            logTerminalText = UIFactory.Label(termBox.transform, "", 16, new Color(0.9f, 0.94f, 1f), TextAnchor.UpperLeft, FontStyle.Normal, false);
            UIFactory.Stretch(logTerminalText.rectTransform, 16, 6, 16, 6);
            logTerminalText.lineSpacing = 1.15f;
        }

        private void BuildBoard()
        {
            foreach (Transform child in board) Destroy(child.gameObject);
            views.Clear();

            BattleGrid g = battle.Grid;
            groundStyle = BattleArt.Detect(g);
            board.sizeDelta = new Vector2(g.Width * Tile, g.Height * Tile);
            cells = new Image[g.Width, g.Height];
            overlays = new Image[g.Width, g.Height];
            props = new Image[g.Width, g.Height];
            cellTexts = new Text[g.Width, g.Height];

            // Marco táctico de acero militar Day R
            Image shadow = UIFactory.Box(board, "BoardShadow", new Color(0f, 0f, 0f, 0.6f));
            UIFactory.Stretch(shadow.rectTransform, -14, -26, -26, -14);
            shadow.raycastTarget = false;

            Image rim = UIFactory.Box(board, "BoardRim", DayRCombatTheme.SlateDark);
            rim.sprite = DayRCombatTheme.TacticalPanel();
            rim.type = Image.Type.Sliced;
            UIFactory.Stretch(rim.rectTransform, -14, -14, -14, -14);
            rim.raycastTarget = false;

            RectTransform cellLayer = UIFactory.NewRect("Cells", board);
            UIFactory.Stretch(cellLayer);
            for (int x = 0; x < g.Width; x++)
            {
                for (int y = 0; y < g.Height; y++)
                {
                    Vector2Int p = new Vector2Int(x, y);
                    Image cell = UIFactory.Box(cellLayer, $"Cell_{x}_{y}", Color.white, false);
                    UIFactory.Place(cell.rectTransform, Vector2.zero, CellPos(p), new Vector2(Tile, Tile));
                    cell.rectTransform.pivot = new Vector2(0.5f, 0.5f);
                    cells[x, y] = cell;

                    Image prop = UIFactory.Box(cell.transform, "Prop", Color.white, false);
                    prop.preserveAspect = true;
                    prop.raycastTarget = false;
                    props[x, y] = prop;

                    Image grid = UIFactory.Box(cell.transform, "Grid", Color.white, false);
                    grid.sprite = DayRCombatTheme.TacticalCellFrame();
                    UIFactory.Stretch(grid.rectTransform);
                    grid.raycastTarget = false;

                    Image ov = UIFactory.Box(cell.transform, "Overlay", Color.clear);
                    UIFactory.Stretch(ov.rectTransform);
                    ov.raycastTarget = false;
                    overlays[x, y] = ov;

                    Text t = UIFactory.Label(cell.transform, "", 18, Color.white, TextAnchor.LowerRight, FontStyle.Bold);
                    UIFactory.Stretch(t.rectTransform, 0, 2, 6, 0);
                    cellTexts[x, y] = t;

                    BattleHover h = cell.gameObject.AddComponent<BattleHover>();
                    h.onClick = () => OnCellClick(p);
                    h.onEnter = () => OnCellHover(p);
                    h.onExit = ClearHover;
                }
            }

            RefreshTileColors();

            unitLayer = UIFactory.NewRect("Units", board);
            UIFactory.Stretch(unitLayer);
            foreach (BattleUnit u in battle.Units) views[u] = BuildUnitView(u);

            fxLayer = UIFactory.NewRect("Fx", board);
            UIFactory.Stretch(fxLayer);
        }

        private UnitView BuildUnitView(BattleUnit u)
        {
            RectTransform rt = UIFactory.NewRect("Unit_" + u.name, unitLayer);
            UIFactory.Place(rt, Vector2.zero, CellPos(u.pos), new Vector2(Tile, Tile));
            rt.pivot = new Vector2(0.5f, 0.5f);

            Image frame = UIFactory.Box(rt, "ActiveFrame", new Color(1f, 0.76f, 0.18f, 0.6f));
            UIFactory.Stretch(frame.rectTransform, 3, 3, 3, 3);
            frame.raycastTarget = false;

            Image shadowImg = UIFactory.Box(rt, "Shadow", Color.white, false);
            shadowImg.sprite = BattleArt.Shadow();
            shadowImg.raycastTarget = false;
            UIFactory.Place(shadowImg.rectTransform, new Vector2(0.5f, 0f), new Vector2(0, 8), new Vector2(Tile * 0.7f, Tile * 0.22f));

            Image img = UIFactory.Box(rt, "Sprite", Color.white, false);
            img.sprite = u.sprite;
            img.preserveAspect = true;
            img.raycastTarget = false;
            RectTransform body = img.rectTransform;
            body.anchorMin = body.anchorMax = new Vector2(0.5f, 0f);
            body.pivot = new Vector2(0.5f, 0f);
            body.sizeDelta = new Vector2(Tile * 0.9f, Tile * 0.9f);
            body.anchoredPosition = new Vector2(0f, 10f);

            Image hpBg = UIFactory.Box(rt, "HpBg", new Color(0f, 0f, 0f, 0.8f), false);
            hpBg.raycastTarget = false;
            UIFactory.Place(hpBg.rectTransform, new Vector2(0.5f, 0f), new Vector2(0, 2), new Vector2(Tile - 16, 9));
            Image hp = UIFactory.Box(hpBg.transform, "Fill", u.faction == Faction.Player ? DayRCombatTheme.TacticalGreen : DayRCombatTheme.DangerRed, false);
            hp.type = Image.Type.Filled;
            hp.fillMethod = Image.FillMethod.Horizontal;
            hp.raycastTarget = false;
            UIFactory.Stretch(hp.rectTransform, 1, 1, 1, 1);

            Text tag = UIFactory.Label(rt, "", 14, new Color(0.75f, 0.9f, 1f), TextAnchor.LowerCenter, FontStyle.Bold);
            UIFactory.Place(tag.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, 22), new Vector2(Tile + 60, 22));

            return new UnitView
            {
                rt = rt, body = body, hpFill = hp, activeFrame = frame.gameObject, tag = tag,
                target = CellPos(u.pos), placed = true, phase = Random.value * 6f,
                facing = u.faction == Faction.Player ? 1f : -1f
            };
        }

        private void BuildBottomBar()
        {
            Image bar = UIFactory.Box(root.transform, "BottomBar", DayRCombatTheme.SlateDark);
            bar.sprite = DayRCombatTheme.TacticalPanel();
            bar.type = Image.Type.Sliced;
            UIFactory.Place(bar.rectTransform, new Vector2(0.5f, 0f), new Vector2(0, 10), new Vector2(1900, 224));
            Transform b = bar.transform;

            // 1. Módulo izquierdo: Tarjeta militar de arma equipada (Day R Weapon Card)
            Image wCard = UIFactory.Box(b, "WeaponCard", DayRCombatTheme.SlateMedium);
            wCard.sprite = DayRCombatTheme.WeaponCardFrame();
            wCard.type = Image.Type.Sliced;
            UIFactory.Place(wCard.rectTransform, new Vector2(0, 0.5f), new Vector2(18, 0), new Vector2(360, 200));
            Transform wc = wCard.transform;

            weaponNameText = UIFactory.Label(wc, "ARMA PRINCIPAL", 20, DayRCombatTheme.ApGold, TextAnchor.MiddleLeft, FontStyle.Bold);
            UIFactory.Place(weaponNameText.rectTransform, new Vector2(0, 1), new Vector2(14, -8), new Vector2(330, 28));

            // Icono del arma
            Image wIconBg = UIFactory.Box(wc, "IconBg", new Color(0.04f, 0.05f, 0.07f, 1f));
            UIFactory.Place(wIconBg.rectTransform, new Vector2(0, 1), new Vector2(14, -40), new Vector2(64, 64));
            weaponIconImg = UIFactory.Box(wIconBg.transform, "Icon", Color.white, false);
            UIFactory.Stretch(weaponIconImg.rectTransform, 4, 4, 4, 4);
            weaponIconImg.preserveAspect = true;

            weaponDamageText = UIFactory.Label(wc, "", 16, Color.white, TextAnchor.MiddleLeft, FontStyle.Bold, false);
            UIFactory.Place(weaponDamageText.rectTransform, new Vector2(0, 1), new Vector2(88, -40), new Vector2(260, 24));

            weaponRangeText = UIFactory.Label(wc, "", 15, new Color(0.8f, 0.85f, 0.9f), TextAnchor.MiddleLeft, FontStyle.Normal, false);
            UIFactory.Place(weaponRangeText.rectTransform, new Vector2(0, 1), new Vector2(88, -64), new Vector2(260, 22));

            weaponAmmoText = UIFactory.Label(wc, "", 15, DayRCombatTheme.TacticalGreen, TextAnchor.MiddleLeft, FontStyle.Bold, false);
            UIFactory.Place(weaponAmmoText.rectTransform, new Vector2(0, 1), new Vector2(88, -86), new Vector2(260, 22));

            // Barra de desgaste / durabilidad del arma
            Image durBg = UIFactory.Box(wc, "DurBg", new Color(0.04f, 0.05f, 0.07f, 1f));
            UIFactory.Place(durBg.rectTransform, new Vector2(0, 0), new Vector2(14, 38), new Vector2(332, 14));
            weaponDurabilityFill = StatFill(durBg.transform, DayRCombatTheme.TacticalGreen);
            weaponDurabilityText = UIFactory.Label(wc, "Integridad: 100%", 14, new Color(0.75f, 0.8f, 0.85f), TextAnchor.MiddleLeft, FontStyle.Normal, false);
            UIFactory.Place(weaponDurabilityText.rectTransform, new Vector2(0, 0), new Vector2(14, 16), new Vector2(332, 20));

            // 2. Módulo central: Estadísticas del superviviente (AP, Vida, Energía)
            Transform sMod = b;
            apText = UIFactory.Label(sMod, "AP", 24, DayRCombatTheme.ApGold, TextAnchor.MiddleLeft, FontStyle.Bold);
            UIFactory.Place(apText.rectTransform, new Vector2(0, 1), new Vector2(395, -12), new Vector2(220, 32));

            for (int i = 0; i < apPips.Length; i++)
            {
                apPips[i] = UIFactory.Box(sMod, "AP" + i, Color.white);
                apPips[i].sprite = DayRCombatTheme.BatteryPip(true);
                UIFactory.Place(apPips[i].rectTransform, new Vector2(0, 1), new Vector2(400 + i * 36, -46), new Vector2(26, 34));
            }

            Image hpBg = UIFactory.Box(sMod, "HpBg", new Color(0.03f, 0.04f, 0.07f, 1f));
            UIFactory.Place(hpBg.rectTransform, new Vector2(0, 1), new Vector2(395, -88), new Vector2(285, 26));
            hpFill = StatFill(hpBg.transform, DayRCombatTheme.TacticalGreen);
            hpText = UIFactory.Label(hpBg.transform, "PV", 16, Color.white, TextAnchor.MiddleLeft, FontStyle.Bold);
            UIFactory.Stretch(hpText.rectTransform, 10, 0, 0, 0);

            Image stBg = UIFactory.Box(sMod, "StaminaBg", new Color(0.03f, 0.04f, 0.07f, 1f));
            UIFactory.Place(stBg.rectTransform, new Vector2(0, 1), new Vector2(395, -120), new Vector2(285, 26));
            staminaFill = StatFill(stBg.transform, DayRCombatTheme.ApGold);
            staminaText = UIFactory.Label(stBg.transform, "ENERGÍA", 16, Color.black, TextAnchor.MiddleLeft, FontStyle.Bold, false);
            UIFactory.Stretch(staminaText.rectTransform, 10, 0, 0, 0);

            statusText = UIFactory.Label(sMod, "", 16, new Color(0.8f, 0.88f, 0.95f), TextAnchor.MiddleLeft, FontStyle.Bold, false);
            UIFactory.Place(statusText.rectTransform, new Vector2(0, 1), new Vector2(395, -162), new Vector2(285, 38));

            // 3. Fila de Acciones Tácticas Day R (Botones con coste de AP y atajos)
            float x = 705f;
            moveBtn = ActionButton(b, "[1] Mover\n<size=15>1 AP/celda</size>", ref x, -12f, () => SetMode(Mode.Move),
                () => "MOVER [1]: Cuesta 1 AP por casilla (2 en orilla o arbustos). Pasa por terreno despejado.", 1, out moveMark);
            attackBtn = ActionButton(b, "[2] Atacar\n<size=15>Arma</size>", ref x, -12f, () => { if (Actor != null && Actor.weapon != null && Actor.weapon.needsReload && !Actor.loaded) battle.PlayerReload(); else SetMode(Mode.Attack); },
                () => { BattleWeapon w = Actor != null ? Actor.weapon : null; return w != null ? $"ATACAR [2]: {w.name} ({w.apCost} AP, {w.accuracy * 100f:0}% precisión)." : "ATACAR [2]: Sin arma."; },
                () => Actor != null && Actor.weapon != null ? Actor.weapon.apCost : 2, out attackMark);
            strongBtn = ActionButton(b, "[3] Fuerte\n<size=15>x1.6 Daño</size>", ref x, -12f, () => SetMode(Mode.Strong),
                () => "GOLPE FUERTE [3]: x1.6 daño, pero -20% precisión y gasta 12 energía.",
                () => Actor != null ? battle.AttackCost(Actor, true) : 3, out strongMark);
            defendBtn = ActionButton(b, "[4] Guardia\n<size=15>2 AP</size>", ref x, -12f, () => battle.PlayerDefend(),
                () => "GUARDIA [4]: 2 AP. Reduce el daño recibido un 50% y prepara contraataques.", 2, out _);
            swapBtn = ActionButton(b, "[5] Cambiar\n<size=15>1 AP</size>", ref x, -12f, () => battle.PlayerSwapWeapon(),
                () => "CAMBIAR ARMA [5]: 1 AP. Rota entre las armas disponibles en tu inventario.", 1, out _);
            fleeBtn = ActionButton(b, "[F] Huir\n<size=15>Retirada</size>", ref x, -12f, () => battle.PlayerFlee(),
                () => battle.CanFlee(out string why, out float chance) ? $"RETIRADA [F]: 3 AP, {chance * 100f:0}% éxito." : $"RETIRADA [F]: Imposible ({why}).", 3, out _);

            // Fila de Habilidades
            for (int i = 0; i < abilityButtons.Length; i++)
            {
                int idx = i;
                Button ab = UIFactory.MakeButton(b, "Habilidad", new Vector2(150, 60), new Color(0.42f, 0.22f, 0.58f), () => SelectAbility(idx), 17);
                UIFactory.Place((RectTransform)ab.transform, new Vector2(0, 1), new Vector2(705 + i * 158, -82), new Vector2(150, 60));
                Image m = UIFactory.Box(ab.transform, "ModeMark", new Color(1f, 0.76f, 0.18f, 0.5f));
                UIFactory.Stretch(m.rectTransform, -4, -4, -4, -4);
                m.raycastTarget = false;
                m.transform.SetAsFirstSibling();
                m.gameObject.SetActive(false);
                abilityMarks[i] = m.gameObject;
                AddButtonHover(ab, () =>
                {
                    BattleUnit act = Actor;
                    if (act == null || idx >= act.abilities.Count) return "";
                    BattleAbility ability = act.abilities[idx];
                    string why = battle.CanUseAbility(act, ability, out string r) ? "" : $"   [No disponible: {r}]";
                    previewApCost = ability.apCost;
                    UpdateBottomBar();
                    return ability.Summary() + why;
                }, () =>
                {
                    BattleUnit act = Actor;
                    if (act == null || idx >= act.abilities.Count) return 0;
                    return act.abilities[idx].apCost;
                });
                abilityButtons[i] = ab;
            }

            // Fila de Objetos Rápidos
            Text itemsLabel = UIFactory.Label(b, "OBJETOS (2 AP):", 16, DayRCombatTheme.ApGold, TextAnchor.MiddleLeft, FontStyle.Bold);
            UIFactory.Place(itemsLabel.rectTransform, new Vector2(0, 1), new Vector2(705, -156), new Vector2(160, 36));
            for (int i = 0; i < itemButtons.Length; i++)
            {
                int idx = i;
                Button ib = UIFactory.MakeButton(b, "Objeto", new Vector2(230, 42), DayRCombatTheme.SlateMedium, () => { if (itemSlots[idx] != null) battle.PlayerUseItem(itemSlots[idx]); }, 17);
                UIFactory.Place((RectTransform)ib.transform, new Vector2(0, 1), new Vector2(870 + i * 242, -154), new Vector2(230, 42));
                AddButtonHover(ib, () => itemSlots[idx] != null ? $"{itemSlots[idx].itemName}: Cuesta 2 AP. {itemSlots[idx].description}" : "", 2);
                itemButtons[i] = ib;
            }

            // Botón FIN DEL TURNO (Destacado en rojo táctico con hotkey [Espacio])
            endBtn = UIFactory.MakeButton(b, "FIN DEL TURNO\n<size=18>[Espacio]</size>", new Vector2(220, 178), DayRCombatTheme.DangerRed, () => battle.PlayerEndTurn(), 24);
            UIFactory.Place((RectTransform)endBtn.transform, new Vector2(1, 0.5f), new Vector2(-16, 0), new Vector2(220, 178));
            AddButtonHover(endBtn, () => "FIN DEL TURNO [Espacio]: Concluye tus acciones. Los AP no consumidos se descartan.", 0);
        }

        private Button ActionButton(Transform parent, string label, ref float x, float y, UnityEngine.Events.UnityAction onClick, System.Func<string> desc, System.Func<int> getApCost, out GameObject mark)
        {
            Button btn = UIFactory.MakeButton(parent, label, new Vector2(150, 62), DayRCombatTheme.SlateMedium, onClick, 18);
            UIFactory.Place((RectTransform)btn.transform, new Vector2(0, 1), new Vector2(x, y), new Vector2(150, 62));

            Image m = UIFactory.Box(btn.transform, "ModeMark", new Color(1f, 0.76f, 0.18f, 0.5f));
            UIFactory.Stretch(m.rectTransform, -4, -4, -4, -4);
            m.raycastTarget = false;
            m.transform.SetAsFirstSibling();
            m.gameObject.SetActive(false);
            mark = m.gameObject;

            AddButtonHover(btn, desc, getApCost);
            x += 158f;
            return btn;
        }

        private Button ActionButton(Transform parent, string label, ref float x, float y, UnityEngine.Events.UnityAction onClick, System.Func<string> desc, int staticApCost, out GameObject mark)
        {
            return ActionButton(parent, label, ref x, y, onClick, desc, () => staticApCost, out mark);
        }

        private void AddButtonHover(Button btn, System.Func<string> desc, System.Func<int> getApCost)
        {
            BattleHover h = btn.gameObject.AddComponent<BattleHover>();
            h.onEnter = () =>
            {
                hasHover = true;
                previewApCost = getApCost != null ? getApCost() : 0;
                infoText.text = desc != null ? desc() : "";
                UpdateBottomBar();
            };
            h.onExit = () =>
            {
                previewApCost = 0;
                ClearHover();
            };
        }

        private void AddButtonHover(Button btn, System.Func<string> desc, int staticApCost)
        {
            AddButtonHover(btn, desc, () => staticApCost);
        }

        private static Image StatFill(Transform bg, Color color)
        {
            Image fill = UIFactory.Box(bg, "Fill", color, false);
            fill.type = Image.Type.Filled;
            fill.fillMethod = Image.FillMethod.Horizontal;
            fill.raycastTarget = false;
            UIFactory.Stretch(fill.rectTransform, 2, 2, 2, 2);
            return fill;
        }

        // ================================================================ Animaciones y Popups

        private IEnumerator PunchFloatRoutine(Text t, Text shadow, bool isCrit)
        {
            float time = 0f;
            float duration = isCrit ? 1.25f : 0.9f;
            Vector2 start = t.rectTransform.anchoredPosition;
            Vector2 shadowStart = shadow.rectTransform.anchoredPosition;
            Color c = t.color;
            Color sc = shadow.color;

            while (time < duration && t != null)
            {
                time += Time.unscaledDeltaTime;
                float progress = time / duration;

                // Punch scale: rebote elástico inicial (1.5x -> 1.0x)
                float scale = 1f;
                if (progress < 0.25f)
                {
                    float p = progress / 0.25f;
                    scale = Mathf.Lerp(1.5f, 1f, p);
                }
                t.rectTransform.localScale = new Vector3(scale, scale, 1f);
                shadow.rectTransform.localScale = new Vector3(scale, scale, 1f);

                // Desplazamiento vertical suave
                Vector2 offset = new Vector2(0f, time * 54f);
                t.rectTransform.anchoredPosition = start + offset;
                shadow.rectTransform.anchoredPosition = shadowStart + offset;

                // Desvanecimiento al final
                float alpha = 1f - Mathf.Pow(progress, 2f);
                t.color = new Color(c.r, c.g, c.b, alpha);
                shadow.color = new Color(sc.r, sc.g, sc.b, alpha * 0.9f);

                yield return null;
            }

            if (t != null) Destroy(t.gameObject);
            if (shadow != null) Destroy(shadow.gameObject);
        }

        private IEnumerator FadeRoutine(Image img, float duration)
        {
            float time = 0f;
            Color c = img.color;
            while (time < duration && img != null)
            {
                time += Time.unscaledDeltaTime;
                img.color = new Color(c.r, c.g, c.b, c.a * (1f - time / duration));
                yield return null;
            }
            if (img != null) Destroy(img.gameObject);
        }

        private void BuildResultPanel()
        {
            Image dim = UIFactory.Box(root.transform, "Result", new Color(0.02f, 0.04f, 0.07f, 0.92f), false);
            UIFactory.Stretch(dim.rectTransform);
            resultPanel = dim.gameObject;

            // Tarjeta táctica central de informe
            Image card = UIFactory.Box(dim.transform, "Card", DayRCombatTheme.SlateDark);
            card.sprite = DayRCombatTheme.TacticalPanel();
            card.type = Image.Type.Sliced;
            UIFactory.Place(card.rectTransform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(1060, 680));
            Transform ct = card.transform;

            // Encabezado
            resultTitle = UIFactory.Label(ct, "¡VICTORIA TÁCTICA!", 46, DayRCombatTheme.ApGold, TextAnchor.MiddleCenter, FontStyle.Bold);
            UIFactory.Place(resultTitle.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -26), new Vector2(980, 56));

            Text sub = UIFactory.Label(ct, "INFORME OPERATIVO POST-COMBATE // ISLA CORAL - GRAND LINE", 16, new Color(0.6f, 0.7f, 0.82f), TextAnchor.MiddleCenter, FontStyle.Normal, false);
            UIFactory.Place(sub.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -78), new Vector2(980, 24));

            // Fila 1 Izquierda: Experiencia y Rango
            Image xpPanel = UIFactory.Box(ct, "XpPanel", DayRCombatTheme.SlateMedium);
            xpPanel.sprite = DayRCombatTheme.WeaponCardFrame();
            xpPanel.type = Image.Type.Sliced;
            UIFactory.Place(xpPanel.rectTransform, new Vector2(0f, 1f), new Vector2(36, -112), new Vector2(476, 154));

            Text xpTitle = UIFactory.Label(xpPanel.transform, "RECOMPENSAS MILITARES", 16, DayRCombatTheme.ApGold, TextAnchor.UpperLeft, FontStyle.Bold);
            UIFactory.Place(xpTitle.rectTransform, new Vector2(0f, 1f), new Vector2(16, -12), new Vector2(440, 26));

            resultXpText = UIFactory.Label(xpPanel.transform, "+0 EXP", 22, Color.white, TextAnchor.MiddleLeft, FontStyle.Bold);
            UIFactory.Place(resultXpText.rectTransform, new Vector2(0f, 1f), new Vector2(16, -42), new Vector2(440, 32));

            Image xpBg = UIFactory.Box(xpPanel.transform, "XpBarBg", new Color(0.06f, 0.08f, 0.12f));
            UIFactory.Place(xpBg.rectTransform, new Vector2(0f, 1f), new Vector2(16, -78), new Vector2(444, 16));
            resultXpFill = UIFactory.Box(xpBg.transform, "Fill", DayRCombatTheme.ApCyan, false);
            resultXpFill.type = Image.Type.Filled;
            resultXpFill.fillMethod = Image.FillMethod.Horizontal;
            UIFactory.Stretch(resultXpFill.rectTransform, 2, 2, 2, 2);

            resultBountyText = UIFactory.Label(xpPanel.transform, "Recompensa Marina: 0 B", 17, new Color(1f, 0.84f, 0.35f), TextAnchor.MiddleLeft, FontStyle.Bold);
            UIFactory.Place(resultBountyText.rectTransform, new Vector2(0f, 1f), new Vector2(16, -104), new Vector2(440, 34));

            // Fila 1 Derecha: Desgaste y Supervivencia
            Image statusPanel = UIFactory.Box(ct, "StatusPanel", DayRCombatTheme.SlateMedium);
            statusPanel.sprite = DayRCombatTheme.WeaponCardFrame();
            statusPanel.type = Image.Type.Sliced;
            UIFactory.Place(statusPanel.rectTransform, new Vector2(1f, 1f), new Vector2(-36, -112), new Vector2(476, 154));

            Text statTitle = UIFactory.Label(statusPanel.transform, "ESTADO DEL SUPERVIVIENTE", 16, DayRCombatTheme.ApGold, TextAnchor.UpperLeft, FontStyle.Bold);
            UIFactory.Place(statTitle.rectTransform, new Vector2(0f, 1f), new Vector2(16, -12), new Vector2(440, 26));

            Image hpBg = UIFactory.Box(statusPanel.transform, "HpBarBg", new Color(0.06f, 0.08f, 0.12f));
            UIFactory.Place(hpBg.rectTransform, new Vector2(0f, 1f), new Vector2(16, -40), new Vector2(444, 24));
            resultHealthFill = UIFactory.Box(hpBg.transform, "Fill", DayRCombatTheme.TacticalGreen, false);
            resultHealthFill.type = Image.Type.Filled;
            resultHealthFill.fillMethod = Image.FillMethod.Horizontal;
            UIFactory.Stretch(resultHealthFill.rectTransform, 2, 2, 2, 2);
            resultHealthText = UIFactory.Label(hpBg.transform, "SALUD: 100/100 PV", 15, Color.black, TextAnchor.MiddleCenter, FontStyle.Bold);
            UIFactory.Stretch(resultHealthText.rectTransform);

            resultHungerText = UIFactory.Label(statusPanel.transform, "Hambre: 100", 15, new Color(0.95f, 0.65f, 0.2f), TextAnchor.MiddleLeft, FontStyle.Bold);
            UIFactory.Place(resultHungerText.rectTransform, new Vector2(0f, 1f), new Vector2(16, -72), new Vector2(140, 26));

            resultThirstText = UIFactory.Label(statusPanel.transform, "Sed: 100", 15, new Color(0.3f, 0.75f, 1f), TextAnchor.MiddleLeft, FontStyle.Bold);
            UIFactory.Place(resultThirstText.rectTransform, new Vector2(0f, 1f), new Vector2(160, -72), new Vector2(140, 26));

            resultStaminaText = UIFactory.Label(statusPanel.transform, "Energía: 100", 15, DayRCombatTheme.ApGold, TextAnchor.MiddleLeft, FontStyle.Bold);
            UIFactory.Place(resultStaminaText.rectTransform, new Vector2(0f, 1f), new Vector2(304, -72), new Vector2(140, 26));

            resultWarningText = UIFactory.Label(statusPanel.transform, "Sin heridas críticas.", 15, Color.white, TextAnchor.MiddleLeft, FontStyle.Normal);
            UIFactory.Place(resultWarningText.rectTransform, new Vector2(0f, 1f), new Vector2(16, -104), new Vector2(444, 34));

            // Fila 2 Central: Botín Capturado
            Image lootPanel = UIFactory.Box(ct, "LootPanel", DayRCombatTheme.SlateMedium);
            lootPanel.sprite = DayRCombatTheme.WeaponCardFrame();
            lootPanel.type = Image.Type.Sliced;
            UIFactory.Place(lootPanel.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -282), new Vector2(988, 264));

            Text lootTitle = UIFactory.Label(lootPanel.transform, "BOTÍN RECOGIDO EN EL COMBATE:", 18, DayRCombatTheme.ApGold, TextAnchor.UpperLeft, FontStyle.Bold);
            UIFactory.Place(lootTitle.rectTransform, new Vector2(0f, 1f), new Vector2(20, -14), new Vector2(500, 28));

            resultLootContainer = UIFactory.NewRect("LootGrid", lootPanel.transform);
            UIFactory.Place(resultLootContainer, new Vector2(0.5f, 0.5f), new Vector2(0, -10), new Vector2(948, 170));
            HorizontalLayoutGroup hlg = resultLootContainer.gameObject.AddComponent<HorizontalLayoutGroup>();
            hlg.spacing = 16f;
            hlg.childAlignment = TextAnchor.MiddleCenter;
            hlg.childForceExpandHeight = false;
            hlg.childForceExpandWidth = false;
            hlg.childControlWidth = false;   // respetar el tamaño de cada carta de botín
            hlg.childControlHeight = false;

            resultLootEmptyText = UIFactory.Label(lootPanel.transform, "No se encontró botín aprovechable en este sector.", 18, new Color(0.6f, 0.65f, 0.72f), TextAnchor.MiddleCenter, FontStyle.Italic);
            UIFactory.Place(resultLootEmptyText.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0, -10), new Vector2(800, 50));

            // Fila 3: Botón Continuar
            Button cont = UIFactory.MakeButton(ct, "CONTINUAR\n<size=18>[Espacio / Enter]</size>", new Vector2(380, 72), DayRCombatTheme.TacticalGreen, () => battle.FinishAndReturn(), 26);
            UIFactory.Place((RectTransform)cont.transform, new Vector2(0.5f, 0f), new Vector2(0, 24), new Vector2(380, 72));

            resultPanel.SetActive(false);
        }
    }
}
