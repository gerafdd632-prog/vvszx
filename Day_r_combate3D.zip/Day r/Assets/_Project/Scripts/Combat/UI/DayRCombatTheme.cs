﻿using UnityEngine;
using PirateSurvival.Core;

namespace PirateSurvival.Combat
{
    /// <summary>
    /// Generador de texturas y sprites procedurales estilo Day R Survival para el combate táctico:
    /// Paneles de acero militar oscuro con remaches, celdas de batería de AP, tarjetas tácticas de armamento,
    /// crucetas de apuntado y marcos de cobertura.
    /// </summary>
    public static class DayRCombatTheme
    {
        private const float Ppu = 25f;

        // Paleta táctica Day R Survival
        public static readonly Color SlateDark = new Color(0.09f, 0.11f, 0.14f, 0.96f);
        public static readonly Color SlateMedium = new Color(0.14f, 0.17f, 0.22f, 1f);
        public static readonly Color SlateLight = new Color(0.22f, 0.26f, 0.33f, 1f);
        public static readonly Color SteelBorder = new Color(0.32f, 0.36f, 0.44f, 1f);
        public static readonly Color RivetColor = new Color(0.6f, 0.65f, 0.72f, 1f);

        // Acentos tácticos
        public static readonly Color ApGold = new Color(1f, 0.76f, 0.18f, 1f);
        public static readonly Color ApCyan = new Color(0.18f, 0.85f, 1f, 1f);
        public static readonly Color ApEmpty = new Color(0.12f, 0.14f, 0.18f, 1f);
        public static readonly Color DangerRed = new Color(0.92f, 0.22f, 0.22f, 1f);
        public static readonly Color TacticalGreen = new Color(0.25f, 0.85f, 0.42f, 1f);
        public static readonly Color TacticalAmber = new Color(1f, 0.65f, 0.15f, 1f);
        public static readonly Color TacticalBlue = new Color(0.25f, 0.62f, 1f, 1f);

        /// <summary>Panel táctico de acero oscuro con remaches metálicos en las esquinas.</summary>
        public static Sprite TacticalPanel() => RuntimeSpriteCache.Get("dayr_tactical_panel", () =>
        {
            const int S = 28, B = 6;
            PixelCanvas c = new PixelCanvas(S, S);

            // Fondo slate oscuro con gradiente sutil
            for (int y = 0; y < S; y++)
                for (int x = 0; x < S; x++)
                {
                    float grad = (float)y / S * 0.08f;
                    c.Set(x, y, new Color(SlateDark.r + grad, SlateDark.g + grad, SlateDark.b + grad, 0.97f));
                }

            // Borde exterior metálico
            c.Rect(0, 0, S, 1, SteelBorder);
            c.Rect(0, S - 1, S, 1, SteelBorder);
            c.Rect(0, 0, 1, S, SteelBorder);
            c.Rect(S - 1, 0, 1, S, SteelBorder);

            // Borde interior biselado
            c.Rect(1, S - 2, S - 2, 1, SlateLight);
            c.Rect(1, 1, 1, S - 2, SlateLight);
            c.Rect(1, 1, S - 2, 1, SlateDark);
            c.Rect(S - 2, 1, 1, S - 2, SlateDark);

            // Remaches en las 4 esquinas
            int[] corners = { 3, S - 4 };
            foreach (int cx in corners)
                foreach (int cy in corners)
                {
                    c.Set(cx, cy, RivetColor);
                    c.Set(cx + 1, cy, SlateDark);
                    c.Set(cx, cy - 1, SlateDark);
                }

            Texture2D tex = c.ToTexture();
            return Sprite.Create(tex, new Rect(0, 0, S, S), new Vector2(0.5f, 0.5f), Ppu, 0, SpriteMeshType.FullRect, new Vector4(B, B, B, B));
        });

        /// <summary>Celda de batería de AP táctica (barra de energía segmentada).</summary>
        public static Sprite BatteryPip(bool active) => RuntimeSpriteCache.Get(active ? "dayr_pip_active" : "dayr_pip_empty", () =>
        {
            const int W = 20, H = 26;
            PixelCanvas c = new PixelCanvas(W, H);

            // Carcasa metálica
            c.Rect(0, 0, W, H, SlateDark);
            c.Rect(0, 0, W, 1, SteelBorder);
            c.Rect(0, H - 1, W, 1, SteelBorder);
            c.Rect(0, 0, 1, H, SteelBorder);
            c.Rect(W - 1, 0, 1, H, SteelBorder);

            // Terminal superior de batería (borne)
            c.Rect(W / 2 - 2, H - 3, 4, 2, active ? ApGold : SteelBorder);

            // Núcleo energético
            Color fill = active ? ApGold : ApEmpty;
            c.Rect(2, 2, W - 4, H - 6, fill);

            if (active)
            {
                // Brillo superior
                c.Rect(3, H - 6, W - 6, 2, Color.white);
                // Resplandor interno
                c.Rect(4, 4, W - 8, H - 10, Color.Lerp(ApGold, Color.white, 0.35f));
            }

            Texture2D tex = c.ToTexture();
            return Sprite.Create(tex, new Rect(0, 0, W, H), new Vector2(0.5f, 0.5f), Ppu);
        });

        /// <summary>Marco de tarjeta de arma equipada.</summary>
        public static Sprite WeaponCardFrame() => RuntimeSpriteCache.Get("dayr_weapon_frame", () =>
        {
            const int S = 24, B = 5;
            PixelCanvas c = new PixelCanvas(S, S);

            c.Rect(0, 0, S, S, new Color(0.08f, 0.10f, 0.13f, 0.98f));
            c.Rect(0, 0, S, 1, SteelBorder);
            c.Rect(0, S - 1, S, 1, SteelBorder);
            c.Rect(0, 0, 1, S, SteelBorder);
            c.Rect(S - 1, 0, 1, S, SteelBorder);

            // Esquinas reforzadas
            c.Rect(0, 0, 3, 3, SlateLight);
            c.Rect(S - 3, 0, 3, 3, SlateLight);
            c.Rect(0, S - 3, 3, 3, SlateLight);
            c.Rect(S - 3, S - 3, 3, 3, SlateLight);

            Texture2D tex = c.ToTexture();
            return Sprite.Create(tex, new Rect(0, 0, S, S), new Vector2(0.5f, 0.5f), Ppu, 0, SpriteMeshType.FullRect, new Vector4(B, B, B, B));
        });

        /// <summary>Cuadrícula táctica con corchetes en las esquinas (estilo visor Day R).</summary>
        public static Sprite TacticalCellFrame() => RuntimeSpriteCache.Get("dayr_cell_frame", () =>
        {
            const int S = 42;
            PixelCanvas c = new PixelCanvas(S, S);
            Color grid = new Color(0.2f, 0.35f, 0.5f, 0.32f);
            Color corner = new Color(0.4f, 0.7f, 1f, 0.65f);

            // Borde suave tenue
            c.Rect(0, 0, S, 1, grid);
            c.Rect(0, S - 1, S, 1, grid);
            c.Rect(0, 0, 1, S, grid);
            c.Rect(S - 1, 0, 1, S, grid);

            // Corchetes tácticos en las 4 esquinas
            int len = 5;
            // Superior izq
            c.Rect(1, S - 2, len, 1, corner);
            c.Rect(1, S - 1 - len, 1, len, corner);
            // Superior der
            c.Rect(S - 1 - len, S - 2, len, 1, corner);
            c.Rect(S - 2, S - 1 - len, 1, len, corner);
            // Inferior izq
            c.Rect(1, 1, len, 1, corner);
            c.Rect(1, 1, 1, len, corner);
            // Inferior der
            c.Rect(S - 1 - len, 1, len, 1, corner);
            c.Rect(S - 2, 1, 1, len, corner);

            Texture2D tex = c.ToTexture();
            return Sprite.Create(tex, new Rect(0, 0, S, S), new Vector2(0.5f, 0.5f), 16f);
        });

        /// <summary>Cruceta de apuntado táctica para objetivos enemigos.</summary>
        public static Sprite TargetingReticle() => RuntimeSpriteCache.Get("dayr_reticle", () =>
        {
            const int S = 32;
            PixelCanvas c = new PixelCanvas(S, S);
            Color red = new Color(1f, 0.22f, 0.22f, 0.95f);

            // Círculo o corchetes de retícula
            c.Rect(4, S / 2, 6, 1, red);
            c.Rect(S - 10, S / 2, 6, 1, red);
            c.Rect(S / 2, 4, 1, 6, red);
            c.Rect(S / 2, S - 10, 1, 6, red);

            c.Rect(7, 7, 3, 1, red); c.Rect(7, 7, 1, 3, red);
            c.Rect(S - 10, 7, 3, 1, red); c.Rect(S - 8, 7, 1, 3, red);
            c.Rect(7, S - 8, 3, 1, red); c.Rect(7, S - 10, 1, 3, red);
            c.Rect(S - 10, S - 8, 3, 1, red); c.Rect(S - 8, S - 10, 1, 3, red);

            c.Set(S / 2, S / 2, Color.white);

            Texture2D tex = c.ToTexture();
            return Sprite.Create(tex, new Rect(0, 0, S, S), new Vector2(0.5f, 0.5f), Ppu);
        });
    }
}
