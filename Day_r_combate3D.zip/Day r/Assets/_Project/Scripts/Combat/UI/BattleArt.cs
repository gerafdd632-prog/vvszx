﻿using UnityEngine;
using PirateSurvival.Core;

namespace PirateSurvival.Combat
{
    /// <summary>
    /// Sprites de alta definición táctica para el tablero de combate:
    /// Texturas de terreno ricas en 32x32 (arena de playa con conchas, césped tropical,
    /// cubierta de barco con remaches, oleaje caribeño) y objetos de casilla detallados
    /// (barril de pólvora con aros de hierro, restos de naufragio con cuerdas, rocas).
    /// </summary>
    public static class BattleArt
    {
        public enum Ground { Sand, Grass, Deck, Cave }

        /// <summary>El lugar se deduce del propio tablero: mástiles = barco, rocas sin agua = cueva, agua = playa, si no = bosque.</summary>
        public static Ground Detect(BattleGrid g)
        {
            bool water = false;
            int mastCount = 0;
            int rockCount = 0;
            for (int x = 0; x < g.Width; x++)
                for (int y = 0; y < g.Height; y++)
                {
                    TileType t = g.Get(new Vector2Int(x, y));
                    if (t == TileType.Mast) mastCount++;
                    if (t == TileType.Rock) rockCount++;
                    if (t == TileType.Water || t == TileType.Shallow) water = true;
                }
            if (mastCount > 0) return Ground.Deck;
            if (rockCount >= 6 && !water) return Ground.Cave;
            return water ? Ground.Sand : Ground.Grass;
        }

        public static Sprite GroundTile(Ground ground, int x, int y)
        {
            int v = (x * 7 + y * 13) % 4;
            switch (ground)
            {
                case Ground.Deck: return GameSprites.Get($"bt_deck_{y % 2}_{v}", () => DrawDeck(y % 2, v));
                case Ground.Grass: return GameSprites.Get($"bt_grass_{v}", () => DrawGrass(v));
                case Ground.Cave: return GameSprites.Get($"bt_cave_{v}", () => DrawCave(v));
                default: return GameSprites.Get($"bt_sand_{v}", () => DrawSand(v));
            }
        }

        /// <summary>Suelo bajo un objeto o casilla especial (mar, orilla). Null = suelo normal.</summary>
        public static Sprite SpecialGround(TileType t)
        {
            switch (t)
            {
                case TileType.Water: return GameSprites.Get("bt_water_tile", DrawDeepWater);
                case TileType.Shallow: return GameSprites.Get("bt_shallow_tile", DrawShallowWater);
                default: return null;
            }
        }

        /// <summary>Objeto dibujado encima del suelo, o null si la casilla está despejada.</summary>
        public static Sprite Prop(TileType t, int fireFrame)
        {
            switch (t)
            {
                case TileType.Rock: return GameSprites.Get("w_boulder_0", () => Bootstrap.WorldArt.Boulder(0));
                case TileType.Cover: return GameSprites.Get("bt_debris_prop", DrawDebrisCover);
                case TileType.Tree: return GameSprites.Get("w_tree", Bootstrap.WorldArt.Tree);
                case TileType.Bush: return GameSprites.Get("w_bush", () => Bootstrap.WorldArt.Bush(false));
                case TileType.Barrel: return GameSprites.Get("w_barrel", Bootstrap.WorldArt.Barrel);
                case TileType.ExplosiveBarrel: return GameSprites.Get("bt_powder_keg", DrawPowderKeg);
                case TileType.Crate: return GameSprites.Get("w_crate", Bootstrap.WorldArt.Crate);
                case TileType.Mast: return GameSprites.Get("bt_mast_prop", DrawShipMast);
                case TileType.Fire: return fireFrame % 2 == 0 ? Bootstrap.WorldArt.Flame(0) : Bootstrap.WorldArt.Flame(1);
                default: return null;
            }
        }

        public static bool IsTall(TileType t) => t == TileType.Tree || t == TileType.Mast;

        /// <summary>Sombra elíptica suave en el suelo para cada combatiente en el tablero táctico.</summary>
        public static Sprite Shadow() => GameSprites.Get("bt_unit_shadow", () =>
        {
            const int W = 32, H = 16;
            PixelCanvas c = new PixelCanvas(W, H);
            c.GroundShadow(W / 2, H / 2, W * 0.45f, H * 0.4f, 0.45f);
            return c.ToSprite(new Vector2(0.5f, 0.5f), 16f);
        });

        // ================================================================ GENERADORES PIXEL ART 32x32

        private static Sprite DrawSand(int variant)
        {
            const int S = 32;
            PixelCanvas c = new PixelCanvas(S, S);
            Color sandBase = new Color(0.92f, 0.81f, 0.58f);
            Color sandDark = new Color(0.85f, 0.72f, 0.49f);
            Color sandLight = new Color(0.96f, 0.88f, 0.68f);
            Color shell = new Color(0.98f, 0.94f, 0.90f);

            // Fondo con textura de dunas y grano fino
            for (int y = 0; y < S; y++)
            {
                for (int x = 0; x < S; x++)
                {
                    float ripple = Mathf.Sin((x + y * 0.5f) * 0.45f + variant) * 0.04f;
                    float grain = (PixelCanvas.Hash(x + variant * 11, y, 7) - 0.5f) * 0.08f;
                    Color col = Color.Lerp(sandDark, sandLight, 0.5f + ripple + grain);
                    c.Set(x, y, col);
                }
            }

            // Pequeñas conchas marinas o guijarros en variantes
            if (variant == 1)
            {
                c.Set(8, 12, shell); c.Set(9, 12, shell); c.Set(8, 13, sandDark);
                c.Set(22, 24, shell); c.Set(23, 24, sandDark);
            }
            else if (variant == 2)
            {
                c.Set(18, 8, shell); c.Set(19, 8, shell);
                c.Set(6, 20, new Color(0.7f, 0.6f, 0.48f)); // guijarro
            }
            else if (variant == 3)
            {
                c.Set(25, 14, shell); c.Set(14, 26, shell);
            }

            return c.ToSprite(new Vector2(0.5f, 0.5f), 16f);
        }

        private static Sprite DrawGrass(int variant)
        {
            const int S = 32;
            PixelCanvas c = new PixelCanvas(S, S);
            Color grassBase = new Color(0.28f, 0.58f, 0.24f);
            Color grassDark = new Color(0.20f, 0.46f, 0.18f);
            Color grassLight = new Color(0.38f, 0.72f, 0.32f);
            Color flower = new Color(1f, 0.88f, 0.28f);

            for (int y = 0; y < S; y++)
            {
                for (int x = 0; x < S; x++)
                {
                    float n = (PixelCanvas.Hash(x + variant * 17, y, 5) - 0.5f) * 0.12f;
                    c.Set(x, y, Color.Lerp(grassDark, grassLight, 0.5f + n));
                }
            }

            // Hojitas de hierba en relieve
            int[,] tufts = variant == 1 ? new[,] { { 6, 8 }, { 20, 18 }, { 12, 24 } }
                        : variant == 2 ? new[,] { { 14, 6 }, { 8, 20 }, { 24, 12 } }
                        : new[,] { { 10, 12 }, { 22, 22 } };

            for (int i = 0; i < tufts.GetLength(0); i++)
            {
                int tx = tufts[i, 0], ty = tufts[i, 1];
                c.Set(tx, ty, grassLight); c.Set(tx, ty + 1, grassLight);
                c.Set(tx - 1, ty, grassDark); c.Set(tx + 1, ty, grassDark);
            }

            // Flor silvestre en variante 2
            if (variant == 2)
            {
                c.Set(18, 14, flower); c.Set(19, 14, flower);
                c.Set(18, 15, Color.white);
            }

            return c.ToSprite(new Vector2(0.5f, 0.5f), 16f);
        }

        private static Sprite DrawDeck(int plankRow, int variant)
        {
            const int S = 32;
            PixelCanvas c = new PixelCanvas(S, S);
            Color woodBase = new Color(0.58f, 0.38f, 0.20f);
            Color woodDark = new Color(0.42f, 0.26f, 0.12f);
            Color woodLight = new Color(0.70f, 0.48f, 0.28f);
            Color seam = new Color(0.24f, 0.14f, 0.06f);
            Color nail = new Color(0.28f, 0.28f, 0.32f);

            // Tablones horizontales de 8 px de grosor
            for (int y = 0; y < S; y++)
            {
                bool isSeam = (y % 8 == 0);
                for (int x = 0; x < S; x++)
                {
                    if (isSeam)
                    {
                        c.Set(x, y, seam);
                    }
                    else
                    {
                        float grain = Mathf.Sin(x * 0.25f + y * 1.5f) * 0.05f + (PixelCanvas.Hash(x, y, 3) - 0.5f) * 0.06f;
                        c.Set(x, y, Color.Lerp(woodDark, woodLight, 0.5f + grain));
                    }
                }
            }

            // Clavos de hierro en los extremos de los tablones
            int[] nailXs = { 4, 27 };
            foreach (int nx in nailXs)
            {
                for (int ny = 4; ny < S; ny += 8)
                {
                    c.Set(nx, ny, nail);
                    c.Set(nx, ny + 1, Color.white * 0.6f);
                }
            }

            return c.ToSprite(new Vector2(0.5f, 0.5f), 16f);
        }

        private static Sprite DrawDeepWater()
        {
            const int S = 32;
            PixelCanvas c = new PixelCanvas(S, S);
            Color deep = new Color(0.09f, 0.28f, 0.52f);
            Color wave = new Color(0.18f, 0.45f, 0.72f);
            Color foam = new Color(0.45f, 0.75f, 0.90f);

            for (int y = 0; y < S; y++)
            {
                for (int x = 0; x < S; x++)
                {
                    float w = Mathf.Sin((x * 0.3f) + (y * 0.6f)) * 0.5f + 0.5f;
                    Color col = Color.Lerp(deep, wave, w);
                    if (y % 10 == 0 && (x % 8 < 5)) col = foam;
                    c.Set(x, y, col);
                }
            }
            return c.ToSprite(new Vector2(0.5f, 0.5f), 16f);
        }

        private static Sprite DrawShallowWater()
        {
            const int S = 32;
            PixelCanvas c = new PixelCanvas(S, S);
            Color turquoise = new Color(0.25f, 0.68f, 0.76f);
            Color lightTurq = new Color(0.42f, 0.82f, 0.88f);
            Color whiteFoam = new Color(0.92f, 0.98f, 1f, 0.85f);

            for (int y = 0; y < S; y++)
            {
                for (int x = 0; x < S; x++)
                {
                    float w = Mathf.Sin(x * 0.35f + y * 0.4f) * 0.5f + 0.5f;
                    Color col = Color.Lerp(turquoise, lightTurq, w);
                    if ((x + y) % 12 == 0) col = whiteFoam;
                    c.Set(x, y, col);
                }
            }
            return c.ToSprite(new Vector2(0.5f, 0.5f), 16f);
        }

        private static Sprite DrawPowderKeg()
        {
            const int S = 32;
            PixelCanvas c = new PixelCanvas(S, S);
            Color redWood = new Color(0.72f, 0.20f, 0.16f);
            Color redDark = new Color(0.50f, 0.12f, 0.10f);
            Color iron = new Color(0.24f, 0.26f, 0.30f);
            Color ironHighlight = new Color(0.45f, 0.48f, 0.55f);
            Color yellowSkull = new Color(1f, 0.85f, 0.25f);

            // Sombra
            c.GroundShadow(16, 4, 11, 3.5f, 0.35f);

            // Cuerpo abombado del barril rojo
            c.ShadedEllipse(16, 17, 10, 12, redWood, 0.3f, 0.4f);

            // Aros de hierro negro reforzado (arriba, centro, abajo)
            int[] hoops = { 9, 17, 24 };
            foreach (int hy in hoops)
            {
                c.Rect(7, hy, 18, 2, iron);
                c.Rect(8, hy + 1, 16, 1, ironHighlight);
            }

            // Calavera / advertencia táctica en el centro
            c.Circle(16, 17, 2.2f, yellowSkull);
            c.Set(15, 17, Color.black); c.Set(17, 17, Color.black); // ojos
            c.Rect(15, 14, 3, 1, yellowSkull); // dientes

            // Mecha en la parte superior
            c.Rect(16, 29, 2, 2, new Color(0.35f, 0.25f, 0.15f));
            c.Set(17, 31, new Color(1f, 0.6f, 0.1f)); // chispa

            c.Outline(new Color(0.15f, 0.08f, 0.05f));
            return c.ToSprite(new Vector2(0.5f, 0.12f), 16f);
        }

        private static Sprite DrawDebrisCover()
        {
            const int S = 32;
            PixelCanvas c = new PixelCanvas(S, S);
            Color wood = new Color(0.55f, 0.38f, 0.22f);
            Color woodDark = new Color(0.36f, 0.22f, 0.11f);
            Color rope = new Color(0.80f, 0.70f, 0.48f);

            c.GroundShadow(16, 4, 12, 3.5f, 0.3f);

            // Tablones cruzados formando una barricada
            c.Rect(5, 7, 22, 6, wood);
            c.Rect(5, 7, 22, 1, woodDark);
            c.Rect(7, 13, 18, 5, woodDark);
            c.Rect(7, 17, 18, 1, wood);

            // Cuerda atando los tablones
            c.Rect(11, 6, 2, 13, rope);
            c.Rect(20, 6, 2, 13, rope);

            c.Outline(new Color(0.18f, 0.10f, 0.05f));
            return c.ToSprite(new Vector2(0.5f, 0.15f), 16f);
        }

        private static Sprite DrawShipMast()
        {
            const int S = 48;
            PixelCanvas c = new PixelCanvas(28, S);
            Color mast = new Color(0.48f, 0.32f, 0.18f);
            Color mastDark = new Color(0.32f, 0.18f, 0.09f);
            Color ironRing = new Color(0.3f, 0.32f, 0.35f);
            Color rope = new Color(0.78f, 0.68f, 0.48f);

            c.GroundShadow(14, 4, 8, 3f, 0.35f);

            // Tronco vertical grueso del mástil
            c.Rect(10, 4, 8, 42, mast);
            c.Rect(10, 4, 2, 42, mastDark);

            // Abrazaderas metálicas
            c.Rect(9, 14, 10, 2, ironRing);
            c.Rect(9, 28, 10, 2, ironRing);
            c.Rect(9, 40, 10, 2, ironRing);

            // Cuerdas de jarcia diagonales
            for (int i = 0; i < 20; i++)
            {
                c.Set(10 - i / 3, 20 + i, rope);
                c.Set(17 + i / 3, 20 + i, rope);
            }

            c.Outline(new Color(0.15f, 0.08f, 0.04f));
            return c.ToSprite(new Vector2(0.5f, 0.08f), 16f);
        }

        private static Sprite DrawCave(int variant)
        {
            const int S = 32;
            PixelCanvas c = new PixelCanvas(S, S);
            Color stoneDark = new Color(0.12f, 0.12f, 0.16f);
            Color stoneMid = new Color(0.20f, 0.20f, 0.25f);
            Color stoneLight = new Color(0.28f, 0.28f, 0.34f);
            Color crystalGlow = new Color(0.40f, 0.70f, 0.95f);

            for (int y = 0; y < S; y++)
            {
                for (int x = 0; x < S; x++)
                {
                    float noise = (PixelCanvas.Hash(x + variant * 17, y, 13) - 0.5f) * 0.15f;
                    bool crack = ((x + y * 2) % 15 == 0) || ((x * 2 - y + 30) % 17 == 0);
                    Color col = crack ? stoneDark : Color.Lerp(stoneMid, stoneLight, 0.5f + noise);
                    c.Set(x, y, col);
                }
            }

            if (variant == 1)
            {
                c.Set(10, 14, crystalGlow); c.Set(11, 14, Color.white);
                c.Set(24, 8, crystalGlow);
            }
            else if (variant == 2)
            {
                c.Set(6, 22, crystalGlow);
                c.Set(20, 20, crystalGlow); c.Set(21, 20, Color.white);
            }
            else if (variant == 3)
            {
                c.Set(16, 12, new Color(0.85f, 0.40f, 0.95f));
                c.Set(26, 26, crystalGlow);
            }

            return c.ToSprite(new Vector2(0.5f, 0.5f), 16f);
        }

        /// <summary>Estela de corte afilado para ataques con armas blancas.</summary>
        public static Sprite SlashFx() => GameSprites.Get("bt_fx_slash", () =>
        {
            const int S = 48;
            PixelCanvas c = new PixelCanvas(S, S);
            Color white = new Color(1f, 1f, 1f, 0.95f);
            Color cyanGlow = new Color(0.4f, 0.85f, 1f, 0.8f);
            Color outer = new Color(0.2f, 0.5f, 0.9f, 0.4f);

            for (int i = 0; i < 36; i++)
            {
                float t = i / 36f;
                int x = 6 + Mathf.RoundToInt(t * 36f);
                int y = 42 - Mathf.RoundToInt(Mathf.Sin(t * Mathf.PI) * 22f + t * 24f);
                if (x >= 0 && x < S && y >= 0 && y < S)
                {
                    c.Set(x, y, white);
                    if (y + 1 < S) c.Set(x, y + 1, cyanGlow);
                    if (y - 1 >= 0) c.Set(x, y - 1, cyanGlow);
                    if (x + 1 < S) c.Set(x + 1, y, cyanGlow);
                    if (x - 1 >= 0) c.Set(x - 1, y, cyanGlow);
                    if (y + 2 < S) c.Set(x, y + 2, outer);
                    if (y - 2 >= 0) c.Set(x, y - 2, outer);
                }
            }
            return c.ToSprite(new Vector2(0.5f, 0.5f), 16f);
        });

        /// <summary>Destello de chispas e impacto para armas de fuego y proyectiles.</summary>
        public static Sprite SparksFx() => GameSprites.Get("bt_fx_sparks", () =>
        {
            const int S = 32;
            PixelCanvas c = new PixelCanvas(S, S);
            Color center = Color.white;
            Color fire = new Color(1f, 0.85f, 0.2f, 0.9f);
            Color orange = new Color(1f, 0.45f, 0.1f, 0.7f);

            c.Circle(16, 16, 4f, center);
            c.Circle(16, 16, 6f, fire);
            for (int d = 1; d <= 12; d++)
            {
                Color sc = d < 6 ? fire : orange;
                c.Set(16 + d, 16, sc); c.Set(16 - d, 16, sc);
                c.Set(16, 16 + d, sc); c.Set(16, 16 - d, sc);
                if (d < 9)
                {
                    c.Set(16 + d, 16 + d, sc); c.Set(16 - d, 16 + d, sc);
                    c.Set(16 + d, 16 - d, sc); c.Set(16 - d, 16 - d, sc);
                }
            }
            return c.ToSprite(new Vector2(0.5f, 0.5f), 16f);
        });

        /// <summary>Onda expansiva de impacto contundente para puñetazos y martillos.</summary>
        public static Sprite HitRingFx() => GameSprites.Get("bt_fx_hitring", () =>
        {
            const int S = 36;
            PixelCanvas c = new PixelCanvas(S, S);
            Color ring = new Color(1f, 0.95f, 0.7f, 0.9f);
            Color glow = new Color(1f, 0.65f, 0.2f, 0.5f);

            for (int y = 0; y < S; y++)
            {
                for (int x = 0; x < S; x++)
                {
                    float d = Vector2.Distance(new Vector2(x, y), new Vector2(18, 18));
                    if (Mathf.Abs(d - 12f) < 1.4f) c.Set(x, y, ring);
                    else if (Mathf.Abs(d - 12f) < 3.0f) c.Set(x, y, glow);
                }
            }
            return c.ToSprite(new Vector2(0.5f, 0.5f), 16f);
        });
    }
}
