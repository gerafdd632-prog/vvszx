﻿using System.Collections.Generic;
using PirateSurvival.Inventory;

namespace PirateSurvival.Combat
{
    public enum AbilityShape
    {
        Line,        // golpea al primero en línea recta (8 direcciones)
        AroundSelf,  // todas las casillas a 'radius' alrededor del usuario
        Dash,        // desplazamiento en línea recta hasta maxRange casillas
        Self         // potenciador sobre uno mismo
    }

    public enum AbilitySource { DevilFruit, Haki, Technique }

    /// <summary>Habilidad de combate: coste de AP y estamina, cooldown, alcance, área, daño, tipo, efecto y animación.</summary>
    public class BattleAbility
    {
        public string id;
        public string name;
        public string description;
        public AbilitySource source;
        public AbilityShape shape;
        public int apCost;
        public float staminaCost;
        public int cooldown;        // turnos propios hasta poder repetirla
        public int minRange = 1;
        public int maxRange = 1;
        public int radius = 1;
        public int damage;
        public CombatDamageType damageType = CombatDamageType.Blunt;
        public float accuracy = 0.9f;
        public int knockback;       // casillas que empuja
        public bool passesLowObstacles;  // pasa por encima de barriles/cajas/restos
        public bool hasStatus;
        public StatusType status;
        public int statusTurns;
        public float statusChance = 1f;
        public int statusIntensity = 1;
        public bool selfStatusOnly;      // el estado se aplica al usuario (potenciadores)
        public int maxTargetHp;          // >0: solo afecta a enemigos con esta vida máxima o menos (Haki del rey)
        public string animation;         // "stretch", "spin", "dash", "aura", "slash", "shockwave"

        public string Summary()
        {
            string range = shape == AbilityShape.AroundSelf ? $"área radio {radius}" :
                           shape == AbilityShape.Self ? "sobre ti" :
                           $"alcance {minRange}-{maxRange} en línea recta";
            string dmg = damage > 0 ? $", daño {damage}" : "";
            string cd = cooldown > 0 ? $", recarga {cooldown} turnos" : "";
            return $"{name}: {apCost} AP, {staminaCost:0} energía, {range}{dmg}{cd}. {description}";
        }
    }

    /// <summary>Catálogo de habilidades (frutas, Haki y técnicas de enemigos especiales).</summary>
    public static class AbilityLibrary
    {
        // --- Fruta Elástica
        public static BattleAbility ElasticPunch() => new BattleAbility
        {
            id = "elastic_punch", name = "Puñetazo Extensible", source = AbilitySource.DevilFruit, shape = AbilityShape.Line,
            apCost = 3, staminaCost = 8, cooldown = 1, minRange = 1, maxRange = 4, damage = 13, accuracy = 0.88f,
            damageType = CombatDamageType.Blunt, knockback = 1, passesLowObstacles = true, animation = "stretch",
            description = "Golpea al primero en línea recta, por encima de obstáculos bajos. Necesita línea de visión. Empuja 1 casilla."
        };

        public static BattleAbility ElasticSpin() => new BattleAbility
        {
            id = "elastic_spin", name = "Golpe Circular", source = AbilitySource.DevilFruit, shape = AbilityShape.AroundSelf,
            apCost = 4, staminaCost = 22, cooldown = 2, radius = 1, damage = 11, accuracy = 0.85f,
            damageType = CombatDamageType.Blunt, knockback = 1, animation = "spin",
            description = "Golpea a todos los enemigos y objetos que te rodean y los aparta. Agota mucho."
        };

        public static BattleAbility ElasticDash() => new BattleAbility
        {
            id = "elastic_dash", name = "Impulso Elástico", source = AbilitySource.DevilFruit, shape = AbilityShape.Dash,
            apCost = 2, staminaCost = 10, cooldown = 2, minRange = 2, maxRange = 4, animation = "dash",
            description = "Te lanzas hasta 4 casillas en línea recta. No atraviesa muros ni unidades. Sin daño."
        };

        // --- Haki (bloqueado hasta desbloquearse en HakiManager)
        public static BattleAbility HakiObservation() => new BattleAbility
        {
            id = "haki_observation", name = "Haki de Observación", source = AbilitySource.Haki, shape = AbilityShape.Self,
            apCost = 2, staminaCost = 12, cooldown = 3, hasStatus = true, status = StatusType.ObservationActive, statusTurns = 2,
            selfStatusOnly = true, animation = "aura",
            description = "Durante 2 turnos: +15% precisión y +25% de esquiva."
        };

        public static BattleAbility HakiArmament() => new BattleAbility
        {
            id = "haki_armament", name = "Haki de Armadura", source = AbilitySource.Haki, shape = AbilityShape.Self,
            apCost = 2, staminaCost = 15, cooldown = 3, hasStatus = true, status = StatusType.HakiReinforced, statusTurns = 2,
            selfStatusOnly = true, animation = "aura",
            description = "Durante 2 turnos: +40% de daño, +3 defensa y puedes golpear a usuarios de Logia."
        };

        public static BattleAbility HakiConqueror() => new BattleAbility
        {
            id = "haki_conqueror", name = "Haki del Rey", source = AbilitySource.Haki, shape = AbilityShape.AroundSelf,
            apCost = 6, staminaCost = 40, cooldown = 99, radius = 3, accuracy = 1f, hasStatus = true, status = StatusType.Stunned,
            statusTurns = 1, maxTargetHp = 30, animation = "shockwave",
            description = "Una vez por combate. Aturde a los enemigos DÉBILES (30 PV máx. o menos) en radio 3. Los fuertes lo resisten."
        };

        // --- Técnicas de enemigos especiales
        public static BattleAbility SpinningSlash() => new BattleAbility
        {
            id = "spin_slash", name = "Tajo Giratorio", source = AbilitySource.Technique, shape = AbilityShape.AroundSelf,
            apCost = 4, cooldown = 2, radius = 1, damage = 12, accuracy = 0.85f, damageType = CombatDamageType.Slash,
            hasStatus = true, status = StatusType.Bleeding, statusTurns = 3, statusChance = 0.6f, animation = "slash",
            description = "Corta a todos los que le rodean y puede hacerlos sangrar."
        };

        public static BattleAbility Charge() => new BattleAbility
        {
            id = "charge", name = "Embestida", source = AbilitySource.Technique, shape = AbilityShape.Line,
            apCost = 3, cooldown = 2, minRange = 1, maxRange = 3, damage = 10, accuracy = 0.8f, damageType = CombatDamageType.Blunt,
            knockback = 2, hasStatus = true, status = StatusType.KnockedDown, statusTurns = 1, animation = "stretch",
            description = "Carga en línea recta y lanza al objetivo 2 casillas. Cuidado con los bordes del barco."
        };

        public static BattleAbility FireFist() => new BattleAbility
        {
            id = "fire_fist", name = "Llamarada", source = AbilitySource.DevilFruit, shape = AbilityShape.Line,
            apCost = 3, cooldown = 1, minRange = 1, maxRange = 4, damage = 12, accuracy = 0.85f, damageType = CombatDamageType.Fire,
            passesLowObstacles = true, hasStatus = true, status = StatusType.Burning, statusTurns = 2, animation = "stretch",
            description = "Lanza fuego en línea recta y quema."
        };
    }
}
