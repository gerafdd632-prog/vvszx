﻿using System.Collections.Generic;
using UnityEngine;
using PirateSurvival.Inventory;
using PirateSurvival.Player;

namespace PirateSurvival.Combat
{
    public enum Faction { Player, Enemy }

    /// <summary>Arma vista desde el combate. Sale de un ItemData (campos combat*) o de una plantilla de enemigo.</summary>
    public class BattleWeapon
    {
        public string name;
        public ItemData item;          // null = puños o arma enemiga
        public int damage;
        public int minRange = 1;
        public int maxRange = 1;
        public int apCost = 2;
        public float accuracy = 0.85f;
        public float critChance = 0.05f;
        public float accuracyFalloff;  // precisión perdida por casilla más allá del alcance mínimo
        public bool needsReload;       // tras disparar hay que recargar
        public CombatDamageType damageType = CombatDamageType.Blunt;
        public bool kairoseki;
        public string ammoItemId = "";
        public bool hasStatus;         // efecto especial al impactar
        public StatusType status;
        public float statusChance;
        public int statusTurns = 2;

        public bool IsRanged => maxRange > 1;

        public static BattleWeapon Fists() => new BattleWeapon
        {
            name = "Puños", damage = 8, apCost = 2, accuracy = 0.9f, critChance = 0.05f, damageType = CombatDamageType.Blunt
        };

        public static BattleWeapon FromItem(ItemData item)
        {
            var w = new BattleWeapon
            {
                name = item.itemName,
                item = item,
                damage = item.combatDamage,
                minRange = item.combatMinRange,
                maxRange = Mathf.Max(item.combatMinRange, item.combatMaxRange),
                apCost = item.combatApCost,
                accuracy = item.combatAccuracy,
                critChance = item.combatCritChance,
                damageType = item.combatDamageType,
                kairoseki = item.kairoseki,
                ammoItemId = item.ammoItemId ?? "",
                accuracyFalloff = item.combatMaxRange > 1 ? 0.06f : 0f
            };
            // Los filos abren heridas
            if (w.damageType == CombatDamageType.Slash)
            {
                w.hasStatus = true;
                w.status = StatusType.Bleeding;
                w.statusChance = 0.25f;
                w.statusTurns = 3;
            }
            return w;
        }
    }

    /// <summary>
    /// Participante del combate. Para el jugador, la vida y la estamina viven en PlayerStats (las heridas persisten).
    /// Los compañeros guardan su estado en CrewMemberData.
    /// </summary>
    public class BattleUnit
    {
        public string name;
        public Faction faction;
        public Vector2Int pos;
        public int maxHp;
        public int hp;
        public int attackBonus;
        public int defense;
        public float damageReduction;   // escudos: fracción de daño ignorada
        public int speed;
        public int maxAp;
        public int ap;
        public float maxStamina = 60f;
        public float stamina = 60f;
        public BattleWeapon weapon;
        public bool defending;
        public bool counterAttack;      // espadachines: contraatacan cuerpo a cuerpo mientras defienden
        public bool loaded = true;
        public int xpReward;
        /// <summary>Recompensa que tiene ESTE enemigo sobre su cabeza (dato informativo, no se suma al jugador).</summary>
        public int bounty;
        /// <summary>Cuánto sube la recompensa del JUGADOR al derrotarlo (p. ej. Marines). 0 para piratas corrientes.</summary>
        public int playerBountyOnDefeat;
        /// <summary>Haki configurado por enemigo: un jefe NO lo obtiene solo por enfurecerse.</summary>
        public bool canUseArmamentHaki;
        public bool canUseObservationHaki;
        public Sprite sprite;
        public IBattleAI ai;
        public bool playerControlled;
        public bool isFruitUser;
        public bool rubber;             // goma: resiste golpes contundentes y balas
        public bool isLogia;            // los ataques físicos le atraviesan salvo Haki, Kairoseki o si está mojado
        public bool fellInSea;          // enemigo arrastrado por el mar: fuera de combate
        public PlayerStats stats;       // solo el protagonista
        public CrewMemberData crew;     // solo compañeros
        public readonly List<StatusEffect> statuses = new List<StatusEffect>();
        public readonly List<BattleAbility> abilities = new List<BattleAbility>();
        public readonly Dictionary<string, int> cooldowns = new Dictionary<string, int>();

        public int Hp => stats != null ? Mathf.CeilToInt(stats.CurrentHealth) : hp;
        public int MaxHp => stats != null ? Mathf.RoundToInt(stats.MaxHealth) : maxHp;
        public bool Alive => !fellInSea && (stats != null ? !stats.IsDead && stats.CurrentHealth > 0f : hp > 0);
        public float Stamina => stats != null ? stats.CurrentStamina : stamina;
        public float MaxStaminaValue => stats != null ? stats.MaxStamina : maxStamina;

        public void ApplyDamage(int amount, DeathCause cause = DeathCause.Combat)
        {
            if (stats != null) stats.TakeDamage(amount, cause);
            else hp = Mathf.Max(0, hp - amount);
        }

        public void Heal(float amount)
        {
            if (stats != null) stats.Heal(amount);
            else hp = Mathf.Min(maxHp, hp + Mathf.RoundToInt(amount));
        }

        public void SpendStamina(float amount)
        {
            if (stats != null) stats.ModifyStamina(-amount);
            else stamina = Mathf.Max(0f, stamina - amount);
        }

        public bool Has(StatusType t) => statuses.Exists(s => s.type == t);
        public StatusEffect Find(StatusType t) => statuses.Find(s => s.type == t);
        public int Cooldown(string abilityId) => cooldowns.TryGetValue(abilityId, out int c) ? c : 0;
    }
}
