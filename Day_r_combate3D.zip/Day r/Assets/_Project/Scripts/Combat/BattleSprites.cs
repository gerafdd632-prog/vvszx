﻿using UnityEngine;
using PirateSurvival.Core;

namespace PirateSurvival.Combat
{
    /// <summary>Sprites procedurales de los enemigos (mismo estilo pixel que el jugador).</summary>
    public static class BattleSprites
    {
        /// <summary>
        /// Sprite de un tipo de enemigo: la imagen Resources/Sprites/&lt;key&gt; (pack) si existe; si no, el pirata dibujado por código.
        /// </summary>
        public static Sprite Unit(string key, Color bandana, Color shirt, bool pistol)
        {
            return GameSprites.Get(key, () => CreatePirate(bandana, shirt, pistol));
        }

        /// <summary>Sprite cacheado: cada combinación se genera una sola vez aunque se reconstruya el mundo o se repita el combate.</summary>
        public static Sprite Pirate(Color bandana, Color shirt, bool pistol)
        {
            string key = $"pirate_{ColorUtility.ToHtmlStringRGB(bandana)}_{ColorUtility.ToHtmlStringRGB(shirt)}_{pistol}";
            return RuntimeSpriteCache.Get(key, () => CreatePirate(bandana, shirt, pistol));
        }

        private static Sprite CreatePirate(Color bandana, Color shirt, bool pistol)
        {
            Texture2D tex = new Texture2D(32, 32, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Point;
            for (int y = 0; y < 32; y++)
                for (int x = 0; x < 32; x++)
                    tex.SetPixel(x, y, Color.clear);

            Color skin = new Color(0.86f, 0.66f, 0.5f);
            Color pants = new Color(0.25f, 0.2f, 0.16f);
            Color dark = new Color(0.1f, 0.08f, 0.08f);

            Circle(tex, 16, 18, 6, skin);
            Box(tex, 10, 21, 12, 4, bandana);       // pañuelo
            Box(tex, 21, 19, 3, 2, bandana);        // nudo
            Box(tex, 13, 17, 2, 2, dark);           // parche en el ojo
            Box(tex, 12, 13, 8, 2, dark);           // barba
            Box(tex, 12, 7, 8, 8, shirt);           // camisa
            for (int x = 12; x < 20; x += 2) Box(tex, x, 9, 1, 4, Color.Lerp(shirt, Color.white, 0.5f)); // rayas
            Box(tex, 12, 1, 3, 6, pants);
            Box(tex, 17, 1, 3, 6, pants);
            if (pistol)
            {
                Box(tex, 21, 9, 6, 2, dark);        // cañón
                Box(tex, 21, 7, 2, 3, new Color(0.45f, 0.3f, 0.15f));
            }
            else
            {
                for (int i = 0; i < 8; i++) tex.SetPixel(22 + i / 2, 8 + i, new Color(0.85f, 0.88f, 0.92f)); // hoja
                Box(tex, 21, 7, 2, 2, new Color(0.9f, 0.75f, 0.2f));
            }

            tex.Apply();
            return Sprite.Create(tex, new Rect(0, 0, 32, 32), new Vector2(0.5f, 0.2f), 32f);
        }

        private static void Box(Texture2D t, int sx, int sy, int w, int h, Color c)
        {
            for (int y = sy; y < sy + h; y++)
                for (int x = sx; x < sx + w; x++)
                    if (x >= 0 && y >= 0 && x < t.width && y < t.height) t.SetPixel(x, y, c);
        }

        private static void Circle(Texture2D t, int cx, int cy, int r, Color c)
        {
            for (int y = cy - r; y <= cy + r; y++)
                for (int x = cx - r; x <= cx + r; x++)
                    if ((x - cx) * (x - cx) + (y - cy) * (y - cy) <= r * r && x >= 0 && y >= 0 && x < t.width && y < t.height) t.SetPixel(x, y, c);
        }
    }
}
