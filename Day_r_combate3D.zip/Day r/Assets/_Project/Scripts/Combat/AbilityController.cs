﻿using System.Collections.Generic;
using UnityEngine;
using PirateSurvival.Player;
using PirateSurvival.Environment;

namespace PirateSurvival.Combat
{
    /// <summary>
    /// Reúne las habilidades de combate del jugador a partir de su Fruta del Diablo y su Haki desbloqueado.
    /// </summary>
    public class AbilityController : MonoBehaviour
    {
        public List<BattleAbility> GetBattleAbilities()
        {
            var list = new List<BattleAbility>();
            DevilFruitManager fruit = GetComponent<DevilFruitManager>();
            PlayerSwimming swimming = GetComponent<PlayerSwimming>();
            bool seaBlocked = swimming != null && swimming.FruitPowersBlocked; // en el mar no hay poderes
            if (fruit != null && fruit.FruitId == DevilFruitManager.Elastic && !seaBlocked)
            {
                list.Add(AbilityLibrary.ElasticPunch());
                list.Add(AbilityLibrary.ElasticSpin());
                list.Add(AbilityLibrary.ElasticDash());
            }

            HakiManager haki = GetComponent<HakiManager>();
            if (haki != null)
            {
                if (haki.Has(HakiType.Observation)) list.Add(AbilityLibrary.HakiObservation());
                if (haki.Has(HakiType.Armament)) list.Add(AbilityLibrary.HakiArmament());
                if (haki.Has(HakiType.Conqueror)) list.Add(AbilityLibrary.HakiConqueror());
            }
            return list;
        }
    }
}
