﻿using UnityEngine;
using PirateSurvival.Inventory;

namespace PirateSurvival.Combat
{
    /// <summary>
    /// Plantillas de enemigos, cada uno con su IA. Los encuentros eligen cuáles aparecen.
    /// Kairoseki solo lo lleva la Marina de élite (no aparece en la isla inicial).
    /// </summary>
    public static class EnemyLibrary
    {
        private static Sprite Pirate(string key, Color bandana, Color shirt, bool gun) => BattleSprites.Unit(key, bandana, shirt, gun);
        private static readonly Color MarineBlue = new Color(0.2f, 0.35f, 0.75f);
        private static readonly Color MarineWhite = new Color(0.92f, 0.93f, 0.95f);

        public static BattleUnit Bandit(Vector2Int pos) => new BattleUnit
        {
            name = "Pirata Bruto", faction = Faction.Enemy, pos = pos, maxHp = 30, hp = 30, defense = 1, maxAp = 5, speed = 4,
            xpReward = 30, bounty = 500,
            weapon = new BattleWeapon { name = "Sable oxidado", damage = 8, apCost = 2, accuracy = 0.8f, critChance = 0.1f, damageType = CombatDamageType.Slash,
                hasStatus = true, status = StatusType.Bleeding, statusChance = 0.2f, statusTurns = 2 },
            sprite = Pirate("c_bandit", new Color(0.8f, 0.15f, 0.15f), new Color(0.25f, 0.3f, 0.55f), false),
            ai = new MeleeAI()
        };

        public static BattleUnit Gunner(Vector2Int pos) => new BattleUnit
        {
            name = "Pirata Tirador", faction = Faction.Enemy, pos = pos, maxHp = 24, hp = 24, defense = 0, maxAp = 5, speed = 3,
            xpReward = 30, bounty = 500,
            weapon = new BattleWeapon { name = "Pistola de chispa", damage = 12, minRange = 2, maxRange = 6, apCost = 3, accuracy = 0.85f,
                critChance = 0.1f, accuracyFalloff = 0.07f, needsReload = true, damageType = CombatDamageType.Pierce,
                hasStatus = true, status = StatusType.Bleeding, statusChance = 0.15f, statusTurns = 2 },
            sprite = Pirate("c_gunner", new Color(0.2f, 0.55f, 0.25f), new Color(0.75f, 0.7f, 0.6f), true),
            ai = new RangedAI()
        };

        public static BattleUnit Swordsman(Vector2Int pos) => new BattleUnit
        {
            name = "Espadachín", faction = Faction.Enemy, pos = pos, maxHp = 34, hp = 34, defense = 2, maxAp = 6, speed = 5,
            xpReward = 45, bounty = 1500, counterAttack = true,
            weapon = new BattleWeapon { name = "Katana", damage = 11, apCost = 2, accuracy = 0.9f, critChance = 0.15f, damageType = CombatDamageType.Slash,
                hasStatus = true, status = StatusType.Bleeding, statusChance = 0.3f, statusTurns = 3 },
            sprite = Pirate("c_swordsman", new Color(0.1f, 0.1f, 0.12f), new Color(0.85f, 0.85f, 0.8f), false),
            ai = new SwordsmanAI()
        };

        public static BattleUnit MarineRifle(Vector2Int pos) => new BattleUnit
        {
            name = "Marine", faction = Faction.Enemy, pos = pos, maxHp = 28, hp = 28, defense = 1, maxAp = 5, speed = 3,
            xpReward = 35, bounty = 0, playerBountyOnDefeat = 2000,
            weapon = new BattleWeapon { name = "Rifle", damage = 13, minRange = 2, maxRange = 7, apCost = 3, accuracy = 0.85f,
                accuracyFalloff = 0.04f, needsReload = true, damageType = CombatDamageType.Pierce },
            sprite = Pirate("c_marine", MarineWhite, MarineBlue, true),
            ai = new MarineAI(false)
        };

        public static BattleUnit MarineShield(Vector2Int pos) => new BattleUnit
        {
            name = "Marine con escudo", faction = Faction.Enemy, pos = pos, maxHp = 36, hp = 36, defense = 3, damageReduction = 0.35f,
            maxAp = 4, speed = 2, xpReward = 40, playerBountyOnDefeat = 2000,
            weapon = new BattleWeapon { name = "Porra", damage = 8, apCost = 2, accuracy = 0.85f, damageType = CombatDamageType.Blunt,
                hasStatus = true, status = StatusType.KnockedDown, statusChance = 0.2f, statusTurns = 1 },
            sprite = Pirate("c_marine_shield", MarineWhite, new Color(0.55f, 0.6f, 0.7f), false),
            ai = new MarineAI(true)
        };

        /// <summary>Marina avanzada con porra de Kairoseki: para islas posteriores.</summary>
        public static BattleUnit MarineElite(Vector2Int pos) => new BattleUnit
        {
            name = "Marine de élite", faction = Faction.Enemy, pos = pos, maxHp = 45, hp = 45, defense = 3, maxAp = 6, speed = 5,
            xpReward = 80, playerBountyOnDefeat = 5000, canUseObservationHaki = true,
            weapon = new BattleWeapon { name = "Porra de Kairoseki", damage = 10, apCost = 2, accuracy = 0.88f, damageType = CombatDamageType.Blunt, kairoseki = true },
            sprite = Pirate("c_marine_elite", MarineWhite, new Color(0.12f, 0.15f, 0.3f), false),
            ai = new MarineAI(false)
        };

        /// <summary>Jefe: dos fases, técnicas propias.</summary>
        public static BattleUnit Captain(Vector2Int pos)
        {
            var u = new BattleUnit
            {
                name = "Capitán Cuervo", faction = Faction.Enemy, pos = pos, maxHp = 70, hp = 70, defense = 2, maxAp = 6, speed = 4,
                xpReward = 150, bounty = 8000, maxStamina = 80, stamina = 80,
                weapon = new BattleWeapon { name = "Sable del capitán", damage = 11, apCost = 2, accuracy = 0.85f, critChance = 0.12f, damageType = CombatDamageType.Slash,
                    hasStatus = true, status = StatusType.Bleeding, statusChance = 0.3f, statusTurns = 3 },
                sprite = Pirate("c_captain", new Color(0.15f, 0.1f, 0.2f), new Color(0.5f, 0.1f, 0.12f), false),
                ai = new BossAI()
            };
            u.abilities.Add(AbilityLibrary.SpinningSlash());
            u.abilities.Add(AbilityLibrary.Charge());
            return u;
        }

        /// <summary>Usuario de Fruta (Logia de fuego): solo se le puede golpear con Haki, Kairoseki o si está mojado.</summary>
        public static BattleUnit FireLogia(Vector2Int pos)
        {
            var u = new BattleUnit
            {
                name = "Usuario de Fruta Ardiente", faction = Faction.Enemy, pos = pos, maxHp = 40, hp = 40, defense = 1, maxAp = 6, speed = 4,
                xpReward = 120, bounty = 12000, isFruitUser = true, isLogia = true,
                weapon = new BattleWeapon { name = "Puño ardiente", damage = 9, apCost = 2, accuracy = 0.85f, damageType = CombatDamageType.Fire,
                    hasStatus = true, status = StatusType.Burning, statusChance = 0.5f, statusTurns = 2 },
                sprite = Pirate("c_fire", new Color(1f, 0.5f, 0.1f), new Color(0.3f, 0.1f, 0.05f), false),
                ai = new BossAI()
            };
            u.abilities.Add(AbilityLibrary.FireFist());
            return u;
        }

        // ================================================================ CRIATURAS Y ENEMIGOS DE CUEVA

        public static BattleUnit CaveSpider(Vector2Int pos) => new BattleUnit
        {
            name = "Araña Venenosa", faction = Faction.Enemy, pos = pos, maxHp = 22, hp = 22, defense = 0, maxAp = 5, speed = 5,
            xpReward = 25, bounty = 200,
            weapon = new BattleWeapon { name = "Picadura ponzoñosa", damage = 6, apCost = 2, accuracy = 0.85f, critChance = 0.15f, damageType = CombatDamageType.Pierce,
                hasStatus = true, status = StatusType.Poisoned, statusChance = 0.45f, statusTurns = 3 },
            sprite = Bootstrap.WorldArt.Spider(),
            ai = new MeleeAI()
        };

        public static BattleUnit CaveBat(Vector2Int pos) => new BattleUnit
        {
            name = "Murciélago de Cueva", faction = Faction.Enemy, pos = pos, maxHp = 18, hp = 18, defense = 0, maxAp = 6, speed = 6,
            xpReward = 20, bounty = 150,
            weapon = new BattleWeapon { name = "Mordisco rápido", damage = 5, apCost = 1, accuracy = 0.88f, critChance = 0.2f, damageType = CombatDamageType.Slash,
                hasStatus = true, status = StatusType.Bleeding, statusChance = 0.35f, statusTurns = 2 },
            sprite = Bootstrap.WorldArt.Bat(),
            ai = new MeleeAI()
        };

        public static BattleUnit CaveBandit(Vector2Int pos) => new BattleUnit
        {
            name = "Saqueador de Cuevas", faction = Faction.Enemy, pos = pos, maxHp = 38, hp = 38, defense = 2, maxAp = 5, speed = 4,
            xpReward = 45, bounty = 1200,
            weapon = new BattleWeapon { name = "Pico de minero pesado", damage = 12, apCost = 2, accuracy = 0.80f, critChance = 0.15f, damageType = CombatDamageType.Blunt,
                hasStatus = true, status = StatusType.KnockedDown, statusChance = 0.25f, statusTurns = 1 },
            sprite = Pirate("c_cave_bandit", new Color(0.4f, 0.2f, 0.15f), new Color(0.18f, 0.25f, 0.32f), false),
            ai = new MeleeAI()
        };
    }
}
