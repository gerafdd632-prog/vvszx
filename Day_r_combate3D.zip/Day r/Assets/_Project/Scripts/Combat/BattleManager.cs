﻿using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using PirateSurvival.Core;
using PirateSurvival.Player;
using PirateSurvival.Inventory;
using PirateSurvival.Interaction;
using PirateSurvival.SaveSystem;

namespace PirateSurvival.Combat
{
    public struct LootReward
    {
        public ItemData item;
        public int quantity;
    }

    public class BattleResultData
    {
        public bool victory;
        public string title;
        public int xpGained;
        public int totalXp;
        public int bountyIncrease;
        public int totalBounty;
        public List<LootReward> loot = new List<LootReward>();
        public float healthLost;
        public float currentHealth;
        public float maxHealth;
        public float hunger;
        public float thirst;
        public float stamina;
        public bool isBleeding;
        public bool isPoisoned;
    }

    /// <summary>
    /// Combate táctico por casillas y puntos de acción.
    /// Al empezar congela la exploración (GameScreen.Battle). La vida, estamina, hambre, sed, objetos y armas son los reales
    /// del jugador: las consecuencias (heridas, objetos gastados, armas desgastadas) se conservan al volver al mundo.
    /// </summary>
    public class BattleManager : MonoBehaviour
    {
        public static BattleManager Instance { get; private set; }

        // Costes configurables
        public const int PlayerAp = 6;
        public const int StrongExtraAp = 1;
        public const int DefendCost = 2;
        public const int ItemCost = 2;
        public const int SwapWeaponCost = 1;
        public const int ReloadCost = 2;
        public const int FleeCost = 3;
        public const float StrongStaminaCost = 12f;
        public const float StrongDamageMult = 1.6f;
        public const float StrongAccuracyPenalty = 0.2f;
        public const float CoverPenalty = 0.3f;
        public const float StaminaPerTurn = 6f;
        // Desgaste de supervivencia por ronda: pelear cansa y da sed
        public const float HungerPerRound = 0.5f;
        public const float ThirstPerRound = 0.8f;

        public BattleGrid Grid { get; private set; }
        /// <summary>El protagonista (su vida vive en PlayerStats).</summary>
        public BattleUnit Player { get; private set; }
        /// <summary>Unidad que está jugando su turno ahora.</summary>
        public BattleUnit Current { get; private set; }
        public readonly List<BattleUnit> Units = new List<BattleUnit>();
        public bool IsActive { get; private set; }
        public bool Busy { get; private set; }
        public bool CanAct => IsActive && waitingForInput && !Busy && !over && Current != null && Current.playerControlled;

        private BattleUI ui;
        private BattleEncounter encounter;
        private PlayerStats stats;
        private bool over;
        private bool waitingForInput;
        private int round;
        private float healthAtStart;

        private void Awake() { Instance = this; }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
            if (IsActive) GameState.InBattle = false;
        }

        private void OnEnable() { GameEvents.OnPlayerDeath += HandlePlayerDeath; }
        private void OnDisable() { GameEvents.OnPlayerDeath -= HandlePlayerDeath; }

        // ================================================================ Inicio / fin

        public void StartBattle(BattleEncounter source)
        {
            if (IsActive || source == null) return;
            stats = FindAnyObjectByType<PlayerStats>();
            if (stats == null || stats.IsDead) return;

            encounter = source;
            Grid = new BattleGrid(source.Arena);
            Units.Clear();

            Player = CreateHeroUnit(source.PlayerStart);
            Units.Add(Player);
            // Enemigos antes que la tripulación: así ningún compañero se coloca en la casilla de un enemigo
            // Ningún enemigo empieza dentro de un obstáculo ni encima de otro (p. ej. arenas con restos 'W')
            HashSet<Vector2Int> taken = new HashSet<Vector2Int> { Player.pos };
            foreach (BattleUnit enemy in source.CreateEnemies())
            {
                if (!Grid.InBounds(enemy.pos) || !Grid.IsWalkable(enemy.pos) || taken.Contains(enemy.pos))
                    enemy.pos = Grid.NearestWalkable(Grid.InBounds(enemy.pos) ? enemy.pos : new Vector2Int(Grid.Width - 2, Grid.Height / 2), taken);
                taken.Add(enemy.pos);
                Units.Add(enemy);
            }
            AddCrew(source.PlayerStart);
            // Por velocidad: el más rápido actúa antes
            Units.Sort((a, b) => b.speed.CompareTo(a.speed));

            healthAtStart = stats.CurrentHealth;
            over = false;
            waitingForInput = false;
            round = 0;
            Busy = false;
            IsActive = true;
            GameState.InBattle = true;
            GameState.Set(GameScreen.Battle);

            if (ui == null) ui = BattleUI.Create(this, transform);
            ui.Open();
            ui.Log(source.IntroText);
            StartCoroutine(RoundLoop());
        }

        private BattleUnit CreateHeroUnit(Vector2Int start)
        {
            SpriteRenderer sr = stats.GetComponentInChildren<SpriteRenderer>();
            DevilFruitManager fruit = stats.GetComponent<DevilFruitManager>();
            var hero = new BattleUnit
            {
                name = "Tú", faction = Faction.Player, pos = start, stats = stats, playerControlled = true,
                defense = 2, maxAp = PlayerAp, speed = 5, weapon = CurrentHeroWeapon(),
                sprite = sr != null ? sr.sprite : null,
                isFruitUser = fruit != null && fruit.HasFruit,
                rubber = fruit != null && fruit.IsRubber
            };
            AbilityController abilities = stats.GetComponent<AbilityController>();
            if (abilities != null) hero.abilities.AddRange(abilities.GetBattleAbilities());
            return hero;
        }

        /// <summary>Compañeros de tripulación: aparecen junto al jugador, con su vida persistente.</summary>
        private void AddCrew(Vector2Int heroStart)
        {
            CrewManager crew = stats.GetComponent<CrewManager>();
            if (crew == null) return;
            foreach (CrewMemberData m in crew.Members)
            {
                if (!m.inParty || m.hp <= 0) continue;
                Vector2Int spot = Grid.NearestWalkable(heroStart, OccupiedExcept(null));
                var u = new BattleUnit
                {
                    name = m.name, faction = Faction.Player, pos = spot, crew = m, playerControlled = m.playerControlled,
                    maxHp = m.maxHp, hp = m.hp, attackBonus = m.attackBonus, defense = m.defense, maxAp = m.maxAp, speed = m.speed,
                    weapon = new BattleWeapon { name = m.weaponName, damage = m.weaponDamage, minRange = m.weaponMinRange,
                        maxRange = Mathf.Max(m.weaponMinRange, m.weaponMaxRange), apCost = m.weaponApCost, accuracy = m.weaponAccuracy,
                        accuracyFalloff = m.weaponMaxRange > 1 ? 0.05f : 0f },
                    sprite = Player.sprite
                };
                if (!u.playerControlled) u.ai = u.weapon.IsRanged ? (IBattleAI)new RangedAI() : new MeleeAI();
                Units.Add(u);
            }
        }

        /// <summary>Cierra el combate sin resultado (cargar partida, volver al menú). No cambia la pantalla de juego.</summary>
        public void AbortBattle()
        {
            if (!IsActive) return;
            StopAllCoroutines();
            Close();
        }

        private void Close()
        {
            over = true;
            IsActive = false;
            waitingForInput = false;
            Busy = false;
            Current = null;
            GameState.InBattle = false;
            if (ui != null) ui.Close();
            if (encounter != null) encounter.Disarm();
        }

        private void HandlePlayerDeath()
        {
            if (!IsActive) return;
            if (AudioManager.Instance != null) AudioManager.Instance.PlayDefeat();
            // Derrota: PlayerStats.Die ya puso GameScreen.Dead (Battle -> Dead sin pasar por Playing).
            // Aquí solo se cierra el combate; el estado lo controla quien lo decide.
            StopAllCoroutines();
            Close();
        }

        /// <summary>Heridas abiertas y estado de la tripulación pasan al mundo de exploración.</summary>
        private void PersistAfterBattle()
        {
            PlayerWounds wounds = stats.GetComponent<PlayerWounds>();
            if (wounds != null)
            {
                StatusEffect bleed = Player.Find(StatusType.Bleeding);
                if (bleed != null) wounds.AddBleeding(45f * bleed.intensity);
                StatusEffect poison = Player.Find(StatusType.Poisoned);
                if (poison != null) wounds.AddPoison(60f * poison.intensity);
            }
            foreach (BattleUnit u in Units)
            {
                // Un compañero noqueado se recupera con 1 PV: no muere de forma permanente
                if (u.crew != null) u.crew.hp = Mathf.Max(1, u.hp);
            }
        }

        // ================================================================ Bucle de turnos

        private static IEnumerator Wait(float seconds)
        {
            float t = 0f;
            while (t < seconds)
            {
                if (GameState.Current != GameScreen.Paused) t += Time.unscaledDeltaTime;
                yield return null;
            }
        }

        private IEnumerator RoundLoop()
        {
            while (!over)
            {
                round++;
                stats.ModifyHunger(-HungerPerRound);
                stats.ModifyThirst(-ThirstPerRound);

                foreach (BattleUnit unit in Units)
                {
                    if (over) yield break;
                    if (!unit.Alive) continue;

                    Current = unit;
                    unit.defending = false;
                    ui.Refresh();

                    // Daño de estados (sangrado, quemadura, veneno) y casilla (fuego, orilla)
                    foreach (StatusEffectSystem.StatusDamage dot in StatusEffectSystem.TurnStartDamage(unit))
                    {
                        ui.Log($"{unit.name} {dot.verb}: -{dot.amount}.");
                        DealDamage(unit, dot.amount, new Color(1f, 0.4f, 0.3f), dot.cause);
                        if (!IsActive) yield break;
                    }
                    if (CheckVictory()) yield break;
                    if (!unit.Alive) continue;
                    ApplyTileEffects(unit);

                    if (unit == Player && stats.IsExhausted) StatusEffectSystem.Apply(unit, StatusType.Exhausted, 1);
                    unit.ap = StatusEffectSystem.ApAtTurnStart(unit, unit.maxAp);
                    if (!unit.Has(StatusType.Kairoseki))
                    {
                        if (unit.stats != null) unit.stats.ModifyStamina(StaminaPerTurn);
                        else unit.stamina = Mathf.Min(unit.maxStamina, unit.stamina + 8f);
                    }
                    var keys = new List<string>(unit.cooldowns.Keys);
                    foreach (string k in keys) unit.cooldowns[k] = Mathf.Max(0, unit.cooldowns[k] - 1);

                    if (unit.Has(StatusType.Stunned))
                    {
                        ui.Log($"{unit.name} está aturdido y pierde el turno.");
                        ui.Refresh();
                        yield return Wait(0.8f);
                    }
                    else if (unit.playerControlled)
                    {
                        if (AudioManager.Instance != null && unit == Player) AudioManager.Instance.PlayTurnStart();
                        ui.Log(unit == Player ? $"Ronda {round}: tu turno. Tienes {unit.ap} AP." : $"Ronda {round}: turno de {unit.name} ({unit.ap} AP).");
                        ui.ShowTurnBanner(unit == Player ? "¡TU TURNO!" : $"TURNO DE {unit.name.ToUpper()}", new Color(0.2f, 0.9f, 1f), $"Ronda {round} • {unit.ap} AP disponibles");
                        waitingForInput = true;
                        ui.Refresh();
                        while (waitingForInput && !over) yield return null;
                        if (over) yield break;
                    }
                    else if (unit.ai != null)
                    {
                        ui.Log($"Turno de {unit.name}.");
                        ui.ShowTurnBanner("TURNO ENEMIGO", new Color(1f, 0.4f, 0.35f), unit.name);
                        ui.Refresh();
                        yield return Wait(0.4f);
                        yield return unit.ai.TakeTurn(unit, this);
                        if (over) yield break;
                        yield return Wait(0.25f);
                    }

                    StatusEffectSystem.TickTurnEnd(unit);
                    if (CheckVictory()) yield break;
                }
            }
        }

        private bool CheckVictory()
        {
            if (over) return true;
            foreach (BattleUnit u in Units)
                if (u.faction == Faction.Enemy && u.Alive) return false;
            Victory();
            return true;
        }

        // ================================================================ Consultas (UI e IA)

        /// <summary>Mensajes de la IA en el registro de combate.</summary>
        public void LogAi(string message) => ui.Log(message);

        public BattleUnit UnitAt(Vector2Int p)
        {
            foreach (BattleUnit u in Units)
                if (u.Alive && u.pos == p) return u;
            return null;
        }

        public List<BattleUnit> Opponents(BattleUnit of)
        {
            var list = new List<BattleUnit>();
            foreach (BattleUnit u in Units)
                if (u.Alive && u.faction != of.faction) list.Add(u);
            return list;
        }

        public BattleUnit ClosestOpponent(BattleUnit of)
        {
            BattleUnit best = null;
            int bestD = int.MaxValue;
            foreach (BattleUnit u in Opponents(of))
            {
                int d = BattleGrid.Distance(of.pos, u.pos);
                if (d < bestD) { bestD = d; best = u; }
            }
            return best;
        }

        private HashSet<Vector2Int> OccupiedExcept(BattleUnit unit)
        {
            var occupied = new HashSet<Vector2Int>();
            foreach (BattleUnit u in Units)
                if (u != unit && u.Alive) occupied.Add(u.pos);
            return occupied;
        }

        public Dictionary<Vector2Int, int> ReachableFrom(BattleUnit unit, int budget, out Dictionary<Vector2Int, Vector2Int> parents)
        {
            parents = new Dictionary<Vector2Int, Vector2Int>();
            if (!StatusEffectSystem.CanMove(unit)) return new Dictionary<Vector2Int, int> { [unit.pos] = 0 };
            return Grid.Flood(unit.pos, budget, OccupiedExcept(unit), parents);
        }

        /// <summary>Alcance y línea de visión desde una casilla hacia otra (sin mirar AP ni munición).</summary>
        public bool InRange(BattleUnit attacker, Vector2Int from, Vector2Int to)
        {
            int d = BattleGrid.Distance(from, to);
            if (d < attacker.weapon.minRange || d > attacker.weapon.maxRange) return false;
            return d <= 1 || Grid.HasLineOfSight(from, to);
        }

        public bool InAttackPosition(BattleUnit attacker, Vector2Int from, BattleUnit target) => InRange(attacker, from, target.pos);

        public int AttackCost(BattleUnit attacker, bool strong) => attacker.weapon.apCost + (strong ? StrongExtraAp : 0);

        private bool CanPayAttack(BattleUnit attacker, bool strong)
        {
            if (attacker.weapon.needsReload && !attacker.loaded) return false;
            if (attacker.ap < AttackCost(attacker, strong)) return false;
            if (strong && attacker.Stamina < StrongStaminaCost) return false;
            if (!string.IsNullOrEmpty(attacker.weapon.ammoItemId) && attacker.stats != null &&
                (InventoryManager.Instance == null || InventoryManager.Instance.CountItem(attacker.weapon.ammoItemId) <= 0)) return false;
            return true;
        }

        public bool CanAttack(BattleUnit attacker, BattleUnit target, bool strong = false)
        {
            if (target == null || !target.Alive || !attacker.Alive || attacker.faction == target.faction) return false;
            return CanPayAttack(attacker, strong) && InAttackPosition(attacker, attacker.pos, target);
        }

        public bool CanAttackObject(BattleUnit attacker, Vector2Int tile, bool strong = false)
        {
            return Grid.IsDestructible(tile) && UnitAt(tile) == null && CanPayAttack(attacker, strong) && InRange(attacker, attacker.pos, tile);
        }

        public float HitChance(BattleUnit attacker, Vector2Int from, BattleUnit target, bool strong)
        {
            BattleWeapon w = attacker.weapon;
            int d = BattleGrid.Distance(from, target.pos);
            float chance = w.accuracy - w.accuracyFalloff * Mathf.Max(0, d - w.minRange);
            if (strong) chance -= StrongAccuracyPenalty;
            if (d > 1 && Grid.HasCover(target.pos, from)) chance -= CoverPenalty;
            if (target.defending) chance -= 0.1f;
            chance += StatusEffectSystem.AccuracyMod(attacker, target);
            return Mathf.Clamp(chance, 0.05f, 0.95f);
        }

        private float RawDamage(BattleUnit attacker, int baseDamage, bool strong) =>
            (baseDamage + attacker.attackBonus) * (strong ? StrongDamageMult : 1f) * StatusEffectSystem.DamageMult(attacker);

        /// <summary>Daño final contra un objetivo: Logia, goma, defensa, guardia y escudos. 0 = le atraviesa.</summary>
        public int ResolveDamage(BattleUnit attacker, BattleUnit target, float raw, CombatDamageType type, bool kairoseki, out string note)
        {
            note = string.Empty;
            bool haki = attacker != null && attacker.Has(StatusType.HakiReinforced);
            if (target.isLogia && !target.Has(StatusType.Wet) && !kairoseki && !haki && type != CombatDamageType.Haki)
            {
                note = "le atraviesa sin hacerle nada";
                return 0;
            }
            if (target.rubber && !haki && (type == CombatDamageType.Blunt || type == CombatDamageType.Pierce))
            {
                raw *= 0.5f;
                note = type == CombatDamageType.Pierce ? "(la bala rebota en la goma)" : "(la goma amortigua el golpe)";
            }
            float dmg = raw - (target.defense + StatusEffectSystem.DefenseBonus(target));
            if (target.defending) dmg *= 0.5f;
            dmg *= 1f - target.damageReduction;
            return Mathf.Max(1, Mathf.RoundToInt(dmg));
        }

        public void EstimateDamage(BattleUnit attacker, BattleUnit target, bool strong, out int min, out int max)
        {
            float b = RawDamage(attacker, attacker.weapon.damage, strong);
            min = ResolveDamage(attacker, target, b * 0.85f, attacker.weapon.damageType, attacker.weapon.kairoseki, out _);
            max = ResolveDamage(attacker, target, b * 1.15f, attacker.weapon.damageType, attacker.weapon.kairoseki, out _);
        }

        public void EstimateAbilityDamage(BattleUnit attacker, BattleUnit target, BattleAbility ab, out int min, out int max)
        {
            float b = RawDamage(attacker, ab.damage, false);
            min = ab.damage > 0 ? ResolveDamage(attacker, target, b * 0.85f, ab.damageType, false, out _) : 0;
            max = ab.damage > 0 ? ResolveDamage(attacker, target, b * 1.15f, ab.damageType, false, out _) : 0;
        }

        // ================================================================ Efectos comunes

        private void DealDamage(BattleUnit target, int dmg, Color color, DeathCause cause = DeathCause.Combat)
        {
            ui.ShowFloat(target, $"-{dmg}", color);
            target.ApplyDamage(dmg, cause); // si es el jugador y muere, HandlePlayerDeath cierra el combate
            if (IsActive && !target.Alive) ui.Log($"{target.name} cae derrotado.");
        }

        private void ApplyStatus(BattleUnit target, StatusType type, int turns, int intensity = 1)
        {
            if (StatusEffectSystem.Apply(target, type, turns, intensity))
            {
                StatusDefinition d = StatusLibrary.Get(type);
                ui.ShowFloat(target, d.name, d.color);
            }
        }

        /// <summary>Efectos de la casilla donde está la unidad (al entrar y al empezar su turno).</summary>
        private void ApplyTileEffects(BattleUnit u)
        {
            if (!u.Alive) return;
            TileType t = Grid.Get(u.pos);
            if (t == TileType.Fire) ApplyStatus(u, StatusType.Burning, 2);
            else if (t == TileType.Shallow)
            {
                ApplyStatus(u, StatusType.Wet, 2);
                if (u.isFruitUser) ApplyStatus(u, StatusType.SeaWeakness, 1);
            }
        }

        /// <summary>Empuja a una unidad. Contra un obstáculo se golpea; hacia el mar profundo, cae al agua.</summary>
        private void Push(BattleUnit unit, Vector2Int dir, int tiles)
        {
            for (int i = 0; i < tiles && unit.Alive; i++)
            {
                Vector2Int next = unit.pos + dir;
                if (Grid.IsDeepWater(next))
                {
                    FallIntoSea(unit, next);
                    return;
                }
                if (!Grid.InBounds(next)) return;

                BattleUnit other = UnitAt(next);
                if (!Grid.IsWalkable(next) || other != null)
                {
                    ui.Log($"{unit.name} sale despedido y choca.");
                    DealDamage(unit, 4, new Color(1f, 0.6f, 0.4f));
                    if (!IsActive) return;
                    if (other != null) DealDamage(other, 3, new Color(1f, 0.6f, 0.4f));
                    else if (Grid.IsDestructible(next)) DamageObject(next, 6);
                    return;
                }
                unit.pos = next;
                ApplyTileEffects(unit);
            }
        }

        private void FallIntoSea(BattleUnit unit, Vector2Int water)
        {
            // Enemigos comunes: la corriente se los lleva (fuera de combate)
            if (unit.faction == Faction.Enemy && !(unit.ai is BossAI))
            {
                unit.fellInSea = true;
                ui.Log($"¡{unit.name} cae al mar y la corriente se lo lleva!");
                return;
            }

            if (unit.isFruitUser)
            {
                ui.Log($"¡{unit.name} cae al mar! Su Fruta lo hunde como una piedra...");
                DealDamage(unit, Mathf.Max(1, Mathf.RoundToInt(unit.MaxHp * 0.35f)), new Color(0.4f, 0.6f, 1f), DeathCause.DevilFruitDrowning);
                if (!IsActive) return;
                ApplyStatus(unit, StatusType.SeaWeakness, 2);
            }
            else
            {
                ui.Log($"¡{unit.name} cae al mar y vuelve a duras penas!");
                DealDamage(unit, 4, new Color(0.4f, 0.6f, 1f), DeathCause.Drowning);
                if (!IsActive) return;
                ApplyStatus(unit, StatusType.KnockedDown, 1);
            }
            ApplyStatus(unit, StatusType.Wet, 3);
            if (unit.Alive) unit.pos = Grid.NearestWalkable(water, OccupiedExcept(unit));
        }

        /// <summary>Daña un objeto del escenario. Los barriles de pólvora explotan (en cadena).</summary>
        private void DamageObject(Vector2Int tile, int amount)
        {
            bool explosive = Grid.Get(tile) == TileType.ExplosiveBarrel;
            if (!Grid.DamageObject(tile, amount))
            {
                ui.ShowFloatAt(tile, $"-{amount}", Color.white);
                return;
            }
            if (explosive) Explode(tile);
            else ui.Log("El objeto se rompe en pedazos.");
        }

        private void Explode(Vector2Int center)
        {
            var pending = new Queue<Vector2Int>();
            pending.Enqueue(center);
            while (pending.Count > 0)
            {
                Vector2Int c = pending.Dequeue();
                ui.Log("¡BOOM! Un barril de pólvora estalla.");
                AudioManager.Instance.PlayExplosion();
                Grid.Set(c, TileType.Fire);
                var area = new List<Vector2Int>();
                foreach (Vector2Int d in BattleGrid.Directions) area.Add(c + d);
                area.Add(c);
                ui.FlashTiles(area, new Color(1f, 0.5f, 0.1f, 0.8f));

                foreach (Vector2Int p in area)
                {
                    if (!Grid.InBounds(p)) continue;
                    BattleUnit u = UnitAt(p);
                    if (u != null)
                    {
                        int dmg = ResolveDamage(null, u, 15f, CombatDamageType.Explosion, false, out _);
                        if (dmg > 0) DealDamage(u, dmg, new Color(1f, 0.55f, 0.1f));
                        if (!IsActive) return;
                        ApplyStatus(u, StatusType.Burning, 2);
                        if (p != c) Push(u, p - c, 1);
                        if (!IsActive) return;
                    }
                    else if (p != c && Grid.IsDestructible(p))
                    {
                        bool chain = Grid.Get(p) == TileType.ExplosiveBarrel;
                        if (Grid.DamageObject(p, 10) && chain) pending.Enqueue(p);
                    }
                }
            }
        }

        // ================================================================ Acciones (corrutinas de jugador e IA)

        public IEnumerator Move(BattleUnit unit, List<Vector2Int> path)
        {
            foreach (Vector2Int step in path)
            {
                int cost = Grid.MoveCost(step);
                if (unit.ap < cost || UnitAt(step) != null || !StatusEffectSystem.CanMove(unit)) break;
                unit.pos = step;
                unit.ap -= cost;
                ApplyTileEffects(unit);
                ui.Refresh();
                yield return Wait(0.12f);
                if (!unit.Alive || !IsActive) yield break;
            }
        }

        /// <summary>
        /// Munición atómica: solo las unidades del protagonista (con PlayerStats) gastan munición del inventario.
        /// Devuelve false si el arma la necesita y no se ha podido consumir: el ataque no ocurre y no se gasta nada.
        /// </summary>
        private bool TryConsumeAmmo(BattleUnit attacker)
        {
            BattleWeapon w = attacker.weapon;
            if (string.IsNullOrEmpty(w.ammoItemId) || attacker.stats == null) return true;
            if (InventoryManager.Instance != null && InventoryManager.Instance.ConsumeItemById(w.ammoItemId)) return true;
            ui.Log("¡Sin munición!");
            Debug.LogWarning($"[BattleManager] Ataque con '{w.name}' cancelado: no se pudo consumir '{w.ammoItemId}' (el inventario cambió tras la validación).");
            return false;
        }

        public IEnumerator Attack(BattleUnit attacker, BattleUnit target, bool strong, bool isCounter = false)
        {
            BattleWeapon w = attacker.weapon;
            // Orden: (objetivo, alcance y AP ya validados por quien llama) -> munición -> AP -> descargar -> atacar
            if (!TryConsumeAmmo(attacker))
            {
                ui.Refresh();
                yield break;
            }
            if (!isCounter)
            {
                attacker.ap -= AttackCost(attacker, strong);
                if (strong) attacker.SpendStamina(StrongStaminaCost);
            }
            if (w.needsReload) attacker.loaded = false;

            ui.AttackFx(attacker, target.pos);
            float chance = HitChance(attacker, attacker.pos, target, strong);
            string verb = isCounter ? "un contraataque" : strong ? "un golpe fuerte" : w.name;
            if (Random.value > chance)
            {
                ui.Log($"{attacker.name} falla ({verb}).");
                ui.ShowFloat(target, "Falla", Color.white);
                if (AudioManager.Instance != null) AudioManager.Instance.PlayMiss();
            }
            else
            {
                bool crit = Random.value < w.critChance;
                float raw = RawDamage(attacker, w.damage, strong) * Random.Range(0.85f, 1.15f) * (crit ? 1.5f : 1f);
                int dmg = ResolveDamage(attacker, target, raw, w.damageType, w.kairoseki, out string note);
                if (dmg <= 0)
                {
                    ui.Log($"El ataque de {attacker.name} {note}. ¡Es un Logia!");
                    ui.ShowFloat(target, "Intangible", new Color(1f, 0.8f, 0.4f));
                    if (AudioManager.Instance != null) AudioManager.Instance.PlayMiss();
                }
                else
                {
                    ui.Log($"{attacker.name} golpea a {target.name} con {verb}: {dmg} de daño{(crit ? " ¡CRÍTICO!" : "")} {note}");
                    DealDamage(target, dmg, crit ? new Color(1f, 0.85f, 0.2f) : new Color(1f, 0.35f, 0.3f));
                    if (AudioManager.Instance != null)
                    {
                        if (crit) AudioManager.Instance.PlayCrit();
                        else if (w.IsRanged) AudioManager.Instance.PlayGunshot();
                        else if (w.damageType == CombatDamageType.Slash) AudioManager.Instance.PlaySlash();
                        else AudioManager.Instance.PlayBlunt();
                    }
                    if (!IsActive) yield break;

                    if (target.Alive)
                    {
                        if (w.kairoseki && target.isFruitUser) ApplyStatus(target, StatusType.Kairoseki, 2);
                        if (w.hasStatus && Random.value < w.statusChance) ApplyStatus(target, w.status, w.statusTurns);
                    }
                }
            }

            // Desgaste del arma del jugador
            if (attacker.stats != null && w.item != null && InventoryManager.Instance != null && InventoryManager.Instance.WearItem(w.item))
            {
                attacker.weapon = BattleWeapon.Fists();
                ui.Log($"¡Tu {w.name} se rompe!");
            }

            ui.Refresh();
            yield return Wait(0.5f);

            // Los espadachines en guardia responden a los golpes cuerpo a cuerpo
            if (!isCounter && IsActive && target.Alive && attacker.Alive && target.counterAttack && target.defending &&
                BattleGrid.Distance(attacker.pos, target.pos) <= 1 && target.weapon.minRange <= 1)
            {
                ui.Log($"{target.name} contraataca.");
                yield return Attack(target, attacker, false, true);
            }
        }

        public IEnumerator AttackObject(BattleUnit attacker, Vector2Int tile, bool strong)
        {
            BattleWeapon w = attacker.weapon;
            if (!TryConsumeAmmo(attacker))
            {
                ui.Refresh();
                yield break;
            }
            attacker.ap -= AttackCost(attacker, strong);
            if (strong) attacker.SpendStamina(StrongStaminaCost);
            if (w.needsReload) attacker.loaded = false;
            ui.AttackFx(attacker, tile);

            float chance = Mathf.Clamp(w.accuracy + 0.05f + StatusEffectSystem.AccuracyMod(attacker, null) - (strong ? StrongAccuracyPenalty : 0f), 0.05f, 0.98f);
            if (Random.value > chance)
            {
                ui.Log($"{attacker.name} falla.");
                ui.ShowFloatAt(tile, "Falla", Color.white);
            }
            else
            {
                int dmg = Mathf.Max(1, Mathf.RoundToInt(RawDamage(attacker, w.damage, strong)));
                DamageObject(tile, dmg);
            }
            if (attacker.stats != null && w.item != null && InventoryManager.Instance != null && InventoryManager.Instance.WearItem(w.item))
                attacker.weapon = BattleWeapon.Fists();
            ui.Refresh();
            yield return Wait(0.5f);
        }

        public IEnumerator Reload(BattleUnit unit)
        {
            unit.ap -= ReloadCost;
            unit.loaded = true;
            if (AudioManager.Instance != null) AudioManager.Instance.PlayReload();
            ui.Log($"{unit.name} recarga.");
            ui.ShowFloat(unit, "Recarga", new Color(0.7f, 0.85f, 1f));
            ui.Refresh();
            yield return Wait(0.4f);
        }

        public void Defend(BattleUnit unit)
        {
            unit.ap -= DefendCost;
            unit.defending = true;
            if (AudioManager.Instance != null) AudioManager.Instance.PlayShield();
            ui.Log(unit.counterAttack ? $"{unit.name} se pone en guardia y espera para contraatacar." : $"{unit.name} se pone en guardia.");
            ui.ShowFloat(unit, "Guardia", new Color(0.6f, 0.8f, 1f));
            ui.Refresh();
        }

        // ================================================================ Habilidades

        public bool CanUseAbility(BattleUnit u, BattleAbility ab, out string reason)
        {
            reason = string.Empty;
            if (u.Cooldown(ab.id) > 0) reason = $"recargando ({u.Cooldown(ab.id)} turnos)";
            else if (u.ap < ab.apCost) reason = "faltan AP";
            else if (u.Stamina < ab.staminaCost) reason = "falta energía";
            else if (ab.source == AbilitySource.DevilFruit && !StatusEffectSystem.CanUseFruit(u)) reason = "poder bloqueado (mar o Kairoseki)";
            else if (ab.shape == AbilityShape.Dash && !StatusEffectSystem.CanMove(u)) reason = "no puedes moverte";
            else if ((ab.shape == AbilityShape.Line || ab.shape == AbilityShape.Dash) && AbilityTargets(u, ab).Count == 0) reason = "sin objetivos";
            return reason.Length == 0;
        }

        /// <summary>Casillas que se pueden elegir al lanzar la habilidad.</summary>
        public List<Vector2Int> AbilityTargets(BattleUnit u, BattleAbility ab)
        {
            var list = new List<Vector2Int>();
            if (ab.shape == AbilityShape.Self || ab.shape == AbilityShape.AroundSelf)
            {
                list.Add(u.pos);
                return list;
            }
            foreach (Vector2Int dir in BattleGrid.Directions)
            {
                for (int step = 1; step <= ab.maxRange; step++)
                {
                    Vector2Int p = u.pos + dir * step;
                    if (!Grid.InBounds(p)) break;
                    if (ab.shape == AbilityShape.Dash)
                    {
                        if (!Grid.IsWalkable(p) || UnitAt(p) != null) break;
                        if (step >= ab.minRange) list.Add(p);
                        continue;
                    }
                    // Línea
                    if (Grid.BlocksSight(p)) break;
                    if (UnitAt(p) != null)
                    {
                        if (step >= ab.minRange) list.Add(p);
                        break;
                    }
                    if (Grid.IsLowObstacle(p) && !ab.passesLowObstacles)
                    {
                        if (step >= ab.minRange && Grid.IsDestructible(p)) list.Add(p);
                        break;
                    }
                    if (step >= ab.minRange) list.Add(p);
                }
            }
            return list;
        }

        /// <summary>Casillas afectadas si se lanza la habilidad sobre 'clicked' (para la previsualización).</summary>
        public List<Vector2Int> AbilityArea(BattleUnit u, BattleAbility ab, Vector2Int clicked)
        {
            var area = new List<Vector2Int>();
            switch (ab.shape)
            {
                case AbilityShape.Self:
                    area.Add(u.pos);
                    break;
                case AbilityShape.AroundSelf:
                    for (int x = u.pos.x - ab.radius; x <= u.pos.x + ab.radius; x++)
                        for (int y = u.pos.y - ab.radius; y <= u.pos.y + ab.radius; y++)
                        {
                            var p = new Vector2Int(x, y);
                            if (p != u.pos && Grid.InBounds(p)) area.Add(p);
                        }
                    break;
                default:
                    if (!BattleGrid.StraightDirection(u.pos, clicked, out Vector2Int dir)) break;
                    for (int step = 1; step <= ab.maxRange; step++)
                    {
                        Vector2Int p = u.pos + dir * step;
                        if (!Grid.InBounds(p) || Grid.BlocksSight(p)) break;
                        area.Add(p);
                        if (ab.shape == AbilityShape.Dash && p == clicked) break;
                        if (ab.shape == AbilityShape.Line && (UnitAt(p) != null || (Grid.IsLowObstacle(p) && !ab.passesLowObstacles))) break;
                    }
                    break;
            }
            return area;
        }

        public IEnumerator UseAbility(BattleUnit u, BattleAbility ab, Vector2Int clicked)
        {
            u.ap -= ab.apCost;
            u.SpendStamina(ab.staminaCost);
            u.cooldowns[ab.id] = ab.cooldown + 1;
            List<Vector2Int> area = AbilityArea(u, ab, clicked);
            ui.Log($"{u.name} usa {ab.name}.");
            ui.AbilityFx(ab, u, area);
            yield return Wait(0.3f);

            switch (ab.shape)
            {
                case AbilityShape.Self:
                    if (ab.hasStatus) ApplyStatus(u, ab.status, ab.statusTurns);
                    break;

                case AbilityShape.Dash:
                    foreach (Vector2Int p in area)
                    {
                        if (!Grid.IsWalkable(p) || UnitAt(p) != null) break;
                        u.pos = p;
                        ApplyTileEffects(u);
                        ui.Refresh();
                        yield return Wait(0.05f);
                    }
                    break;

                case AbilityShape.Line:
                    BattleGrid.StraightDirection(u.pos, clicked, out Vector2Int dir);
                    bool hitSomething = false;
                    foreach (Vector2Int p in area)
                    {
                        BattleUnit t = UnitAt(p);
                        if (t != null)
                        {
                            hitSomething = true;
                            if (t.faction != u.faction) AbilityHit(u, t, ab, dir);
                            break;
                        }
                        if (Grid.IsLowObstacle(p) && !ab.passesLowObstacles)
                        {
                            hitSomething = true;
                            if (Grid.IsDestructible(p)) DamageObject(p, Mathf.Max(1, ab.damage));
                            break;
                        }
                    }
                    if (!hitSomething) ui.Log("No alcanza a nadie.");
                    break;

                case AbilityShape.AroundSelf:
                    foreach (BattleUnit t in new List<BattleUnit>(Units))
                    {
                        if (!IsActive) yield break;
                        if (!t.Alive || t.faction == u.faction || BattleGrid.Distance(u.pos, t.pos) > ab.radius) continue;
                        if (ab.maxTargetHp > 0 && t.MaxHp > ab.maxTargetHp)
                        {
                            ui.Log($"{t.name} resiste la presión.");
                            continue;
                        }
                        AbilityHit(u, t, ab, new Vector2Int(System.Math.Sign(t.pos.x - u.pos.x), System.Math.Sign(t.pos.y - u.pos.y)));
                    }
                    if (ab.damage > 0)
                        foreach (Vector2Int p in area)
                            if (IsActive && Grid.IsDestructible(p) && UnitAt(p) == null) DamageObject(p, ab.damage);
                    break;
            }

            if (!IsActive) yield break;
            ui.Refresh();
            yield return Wait(0.4f);
        }

        private void AbilityHit(BattleUnit attacker, BattleUnit target, BattleAbility ab, Vector2Int dir)
        {
            float chance = Mathf.Clamp(ab.accuracy + StatusEffectSystem.AccuracyMod(attacker, target), 0.05f, 0.98f);
            if (Random.value > chance)
            {
                ui.Log($"{target.name} esquiva {ab.name}.");
                ui.ShowFloat(target, "Esquiva", Color.white);
                return;
            }
            if (ab.damage > 0)
            {
                float raw = RawDamage(attacker, ab.damage, false) * Random.Range(0.85f, 1.15f);
                int dmg = ResolveDamage(attacker, target, raw, ab.damageType, false, out string note);
                if (dmg <= 0)
                {
                    ui.Log($"{ab.name} {note}.");
                    ui.ShowFloat(target, "Intangible", new Color(1f, 0.8f, 0.4f));
                    return;
                }
                ui.Log($"{ab.name} alcanza a {target.name}: {dmg} de daño {note}");
                DealDamage(target, dmg, new Color(1f, 0.35f, 0.3f));
                if (!IsActive || !target.Alive) return;
            }
            if (ab.hasStatus && !ab.selfStatusOnly && Random.value < ab.statusChance) ApplyStatus(target, ab.status, ab.statusTurns, ab.statusIntensity);
            if (ab.knockback > 0 && target.Alive) Push(target, dir, ab.knockback);
        }

        /// <summary>Mejor uso de habilidad para la IA (más enemigos alcanzados, empujes al mar). false si no compensa.</summary>
        public bool BestAbilityFor(BattleUnit u, out BattleAbility best, out Vector2Int target)
        {
            best = null;
            target = u.pos;
            float bestScore = 0f;
            foreach (BattleAbility ab in u.abilities)
            {
                if (!CanUseAbility(u, ab, out _) || ab.shape == AbilityShape.Dash) continue;
                foreach (Vector2Int tile in AbilityTargets(u, ab))
                {
                    float score = 0f;
                    List<Vector2Int> area = AbilityArea(u, ab, tile);
                    foreach (Vector2Int p in area)
                    {
                        BattleUnit t = UnitAt(p);
                        if (t == null || t.faction == u.faction) continue;
                        if (ab.maxTargetHp > 0 && t.MaxHp > ab.maxTargetHp) continue;
                        score += Mathf.Max(ab.damage, 6);
                        if (ab.knockback > 0 && BattleGrid.StraightDirection(u.pos, p, out Vector2Int d) && Grid.IsDeepWater(p + d * ab.knockback)) score += 25f;
                        if (ab.shape == AbilityShape.Line) break; // la línea solo golpea al primero
                    }
                    if (ab.shape == AbilityShape.Self) score = 8f;
                    if (score > bestScore)
                    {
                        bestScore = score;
                        best = ab;
                        target = tile;
                    }
                }
            }
            return best != null;
        }

        // ================================================================ Acciones del jugador (desde la UI)

        public void PlayerMove(Vector2Int target)
        {
            if (!CanAct) return;
            BattleUnit u = Current;
            Dictionary<Vector2Int, int> reach = ReachableFrom(u, u.ap, out Dictionary<Vector2Int, Vector2Int> parents);
            if (!reach.ContainsKey(target) || target == u.pos) return;
            StartCoroutine(PlayerAction(Move(u, BattleGrid.BuildPath(parents, u.pos, target))));
        }

        public void PlayerAttack(BattleUnit target, bool strong)
        {
            if (!CanAct || !CanAttack(Current, target, strong)) return;
            StartCoroutine(PlayerAction(Attack(Current, target, strong)));
        }

        public void PlayerAttackObject(Vector2Int tile, bool strong)
        {
            if (!CanAct || !CanAttackObject(Current, tile, strong)) return;
            StartCoroutine(PlayerAction(AttackObject(Current, tile, strong)));
        }

        public void PlayerUseAbility(BattleAbility ab, Vector2Int tile)
        {
            if (!CanAct || !CanUseAbility(Current, ab, out _) || !AbilityTargets(Current, ab).Contains(tile)) return;
            StartCoroutine(PlayerAction(UseAbility(Current, ab, tile)));
        }

        public void PlayerReload()
        {
            if (!CanAct || !Current.weapon.needsReload || Current.loaded || Current.ap < ReloadCost) return;
            StartCoroutine(PlayerAction(Reload(Current)));
        }

        public void PlayerDefend()
        {
            if (!CanAct || Current.defending || Current.ap < DefendCost) return;
            Defend(Current);
            AfterPlayerAction();
        }

        /// <summary>Los objetos son del inventario del protagonista: solo él los usa.</summary>
        public void PlayerUseItem(ItemData item)
        {
            if (!CanAct || Current != Player || Player.ap < ItemCost || InventoryManager.Instance == null) return;
            InventoryManager inv = InventoryManager.Instance;

            if (item.itemType == ItemType.Medicine)
            {
                bool cures = (item.curesBleeding && Player.Has(StatusType.Bleeding)) || (item.curesPoison && Player.Has(StatusType.Poisoned));
                bool heals = item.healthRestore > 0f && stats.CurrentHealth < stats.MaxHealth - 0.1f;
                if (!cures && !heals)
                {
                    ui.Log("No lo necesitas ahora.");
                    return;
                }
                inv.ConsumeItemById(item.itemId);
                if (item.healthRestore > 0f) stats.Heal(item.healthRestore);
                if (item.curesBleeding) StatusEffectSystem.Remove(Player, StatusType.Bleeding);
                if (item.curesPoison) StatusEffectSystem.Remove(Player, StatusType.Poisoned);
                Player.ap -= ItemCost;
                if (AudioManager.Instance != null) AudioManager.Instance.PlayItemUse();
                ui.Log($"Usas {item.itemName}.");
                ui.ShowFloat(Player, item.healthRestore > 0 ? $"+{item.healthRestore:0}" : item.itemName, new Color(0.5f, 1f, 0.5f));
                AfterPlayerAction();
                return;
            }

            var slots = inv.Slots;
            for (int i = 0; i < slots.Count; i++)
            {
                if (slots[i].IsEmpty || slots[i].ItemData != item) continue;
                int before = slots[i].Quantity;
                inv.UseItem(i);
                // UseItem puede negarse (p. ej. "¡No tienes sed!"): solo se cobra AP si se consumió
                if (slots[i].IsEmpty || slots[i].Quantity < before)
                {
                    Player.ap -= ItemCost;
                    if (AudioManager.Instance != null) AudioManager.Instance.PlayItemUse();
                    ui.Log($"Usas {item.itemName}.");
                    ui.ShowFloat(Player, item.healthRestore > 0 ? $"+{item.healthRestore:0}" : item.itemName, new Color(0.5f, 1f, 0.5f));
                }
                AfterPlayerAction();
                return;
            }
        }

        /// <summary>Armas del protagonista: puños + cada arma distinta del inventario.</summary>
        public List<BattleWeapon> OwnedWeapons()
        {
            var list = new List<BattleWeapon> { BattleWeapon.Fists() };
            if (InventoryManager.Instance == null) return list;
            var seen = new HashSet<ItemData>();
            foreach (InventorySlot s in InventoryManager.Instance.Slots)
            {
                if (!s.IsEmpty && s.ItemData.combatDamage > 0 && seen.Add(s.ItemData))
                    list.Add(BattleWeapon.FromItem(s.ItemData));
            }
            return list;
        }

        public void PlayerSwapWeapon()
        {
            if (!CanAct || Current != Player || Player.ap < SwapWeaponCost) return;
            List<BattleWeapon> owned = OwnedWeapons();
            if (owned.Count < 2) return;
            int idx = owned.FindIndex(w => w.item == Player.weapon.item);
            BattleWeapon next = owned[(idx + 1) % owned.Count];

            // El arma elegida queda equipada también en el mundo; si no se puede equipar, no se cambia ni se gasta AP
            InventoryManager inv = InventoryManager.Instance;
            if (next.item == null)
            {
                inv.UnequipTool();
            }
            else
            {
                int slotIndex = -1;
                for (int i = 0; i < inv.Slots.Count; i++)
                {
                    if (!inv.Slots[i].IsEmpty && inv.Slots[i].ItemData == next.item) { slotIndex = i; break; }
                }
                if (slotIndex < 0 || !inv.EquipTool(next.item, slotIndex))
                {
                    ui.Log($"No puedes empuñar {next.name}.");
                    return;
                }
            }

            Player.weapon = next;
            Player.ap -= SwapWeaponCost;
            if (AudioManager.Instance != null) AudioManager.Instance.PlayUiClick();
            ui.Log($"Empuñas: {next.name}.");
            AfterPlayerAction();
        }

        /// <summary>Huir: desde un borde del tablero, 3 AP. Más difícil con enemigos pegados. Los jefes no dejan huir.</summary>
        public bool CanFlee(out string reason, out float chance)
        {
            reason = string.Empty;
            chance = 0f;
            if (!CanAct || Current != Player) { reason = "solo en tu turno"; return false; }
            if (encounter != null && !encounter.CanFlee) { reason = "no hay escapatoria"; return false; }
            Vector2Int p = Player.pos;
            bool edge = p.x == 0 || p.y == 0 || p.x == Grid.Width - 1 || p.y == Grid.Height - 1;
            if (!edge) { reason = "tienes que estar en un borde del tablero"; return false; }
            if (Player.ap < FleeCost) { reason = $"necesitas {FleeCost} AP"; return false; }
            int adjacent = 0;
            foreach (BattleUnit e in Opponents(Player))
                if (BattleGrid.Distance(e.pos, p) <= 1) adjacent++;
            chance = Mathf.Clamp01(0.8f - adjacent * 0.25f);
            return true;
        }

        public void PlayerFlee()
        {
            if (!CanFlee(out _, out float chance)) return;
            Player.ap -= FleeCost;
            if (Random.value > chance)
            {
                ui.Log("¡No consigues escapar!");
                AfterPlayerAction();
                return;
            }

            PersistAfterBattle();
            Close();
            // Alejar al jugador del enemigo en el mundo; si ese punto no es seguro (mar, roca, árbol), usar la última posición segura
            Vector2 heroPos = stats.transform.position;
            Vector2 away = heroPos - (Vector2)encounter.transform.position;
            if (away.sqrMagnitude < 0.01f) away = Vector2.left;
            Rigidbody2D rb = stats.GetComponent<Rigidbody2D>();
            Vector2 target = heroPos + away.normalized * 1.5f;
            if (!SafePositionTracker.IsValidLandPosition(target, rb))
            {
                SafePositionTracker tracker = stats.GetComponent<SafePositionTracker>();
                target = tracker != null && tracker.HasSafePosition ? tracker.LastSafeLandPosition : heroPos;
            }
            if (rb != null)
            {
                rb.position = target;
                rb.linearVelocity = Vector2.zero;
            }
            stats.transform.position = target;
            GameState.Set(GameScreen.Playing);
            GameEvents.TriggerNotificationMessage("Has huido del combate.");
        }

        public void PlayerEndTurn()
        {
            if (!CanAct) return;
            waitingForInput = false;
        }

        private BattleWeapon CurrentHeroWeapon()
        {
            ItemData equipped = InventoryManager.Instance != null ? InventoryManager.Instance.CurrentEquippedTool : null;
            return equipped != null && equipped.combatDamage > 0 ? BattleWeapon.FromItem(equipped) : BattleWeapon.Fists();
        }

        private IEnumerator PlayerAction(IEnumerator action)
        {
            Busy = true;
            ui.Refresh();
            yield return action;
            Busy = false;
            if (IsActive) AfterPlayerAction();
        }

        private void AfterPlayerAction()
        {
            if (over || CheckVictory()) return;
            if (Current != null && (Current.ap <= 0 || !Current.Alive)) waitingForInput = false;
            ui.Refresh();
        }

        // ================================================================ Victoria

        private void Victory()
        {
            over = true;
            waitingForInput = false;

            // La recompensa de cada enemigo es suya; la del jugador solo sube si derrotarlo lo convierte en más buscado (Marines)
            int xp = 0, playerBountyIncrease = 0;
            foreach (BattleUnit u in Units)
            {
                if (u.faction != Faction.Enemy) continue;
                xp += u.xpReward;
                playerBountyIncrease += u.playerBountyOnDefeat;
            }

            PlayerProgress progress = stats.GetComponent<PlayerProgress>();
            if (progress != null)
            {
                progress.AddExperience(xp);
                progress.AddPlayerBounty(playerBountyIncrease);
                if (encounter.Unique) progress.MarkDefeated(encounter.EncounterId);
            }
            PersistAfterBattle();

            List<LootReward> loot = CollectLootRewards();

            BattleResultData result = new BattleResultData
            {
                victory = true,
                title = "¡VICTORIA TÁCTICA!",
                xpGained = xp,
                totalXp = progress != null ? progress.Experience : xp,
                bountyIncrease = playerBountyIncrease,
                totalBounty = progress != null ? progress.Bounty : 0,
                loot = loot,
                healthLost = Mathf.Max(0f, healthAtStart - stats.CurrentHealth),
                currentHealth = stats.CurrentHealth,
                maxHealth = stats.MaxHealth,
                hunger = stats.CurrentHunger,
                thirst = stats.CurrentThirst,
                stamina = stats.CurrentStamina,
                isBleeding = Player.Has(StatusType.Bleeding),
                isPoisoned = Player.Has(StatusType.Poisoned)
            };

            if (AudioManager.Instance != null) AudioManager.Instance.PlayVictory();
            ui.Log("¡Victoria!");
            ui.Refresh();
            ui.ShowResult(result);
        }

        private List<LootReward> CollectLootRewards()
        {
            var list = new List<LootReward>();
            SaveManager sm = SaveManager.Instance;
            InventoryManager inv = InventoryManager.Instance;
            if (sm == null || inv == null || encounter == null) return list;

            foreach (BattleEncounter.Loot l in encounter.LootTable)
            {
                if (Random.value > l.chance) continue;
                ItemData item = sm.ItemDatabase.Find(x => x.itemId == l.itemId);
                if (item == null) item = ItemDatabase.Get(l.itemId);
                if (item == null || (l.onlyIfMissing && inv.CountItem(item.itemId) > 0)) continue;

                if (!inv.AddItem(item, l.quantity))
                    WorldItemFactory.Spawn(item, l.quantity, (Vector2)stats.transform.position + Vector2.down * 0.8f);

                list.Add(new LootReward { item = item, quantity = l.quantity });
            }
            return list;
        }

        /// <summary>Botón "Continuar" de la pantalla de resultado: vuelve a la exploración.</summary>
        public void FinishAndReturn()
        {
            Close();
            GameState.Set(GameScreen.Playing);
        }
    }
}
