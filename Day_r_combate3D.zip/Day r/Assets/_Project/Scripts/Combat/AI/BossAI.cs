﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace PirateSurvival.Combat
{
    /// <summary>
    /// Jefes y usuarios de Fruta: usan sus técnicas cuando compensan (varios rivales, empujar al mar) y cambian de fase.
    /// Fase 2 (por debajo del 50% de vida): se enfurece (+1 AP, +3 de ataque). Solo usa Haki si su BattleUnit lo tiene configurado.
    /// </summary>
    public class BossAI : IBattleAI
    {
        private bool enraged;

        public IEnumerator TakeTurn(BattleUnit self, BattleManager battle)
        {
            if (!enraged && self.hp <= self.maxHp / 2)
            {
                enraged = true;
                self.maxAp += 1;
                self.ap += 1;
                self.attackBonus += 3;
                if (self.canUseArmamentHaki)
                {
                    StatusEffectSystem.Apply(self, StatusType.HakiReinforced, 3);
                    battle.LogAi($"¡{self.name} se enfurece y recubre sus puños de Haki!");
                }
                else
                {
                    battle.LogAi($"¡{self.name} se enfurece! Ataca con más rabia.");
                }
                yield return null;
            }

            int guard = 20;
            while (guard-- > 0 && self.Alive && self.ap > 0 && battle.IsActive)
            {
                if (battle.BestAbilityFor(self, out BattleAbility ab, out Vector2Int tile))
                {
                    yield return battle.UseAbility(self, ab, tile);
                    continue;
                }

                BattleUnit target = battle.ClosestOpponent(self);
                if (target == null) yield break;
                if (battle.CanAttack(self, target))
                {
                    yield return battle.Attack(self, target, false);
                    continue;
                }
                if (BattleGrid.Distance(self.pos, target.pos) <= self.weapon.maxRange) break;

                Vector2Int best = MeleeAI.ApproachTile(self, battle, target, out Dictionary<Vector2Int, Vector2Int> parents);
                if (best == self.pos) break;
                yield return battle.Move(self, BattleGrid.BuildPath(parents, self.pos, best));
            }

            if (self.Alive && battle.IsActive && self.ap >= BattleManager.DefendCost && !enraged) battle.Defend(self);
        }
    }
}
