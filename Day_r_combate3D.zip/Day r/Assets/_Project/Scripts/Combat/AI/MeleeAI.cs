﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace PirateSurvival.Combat
{
    /// <summary>
    /// Bandido/pirata cuerpo a cuerpo: agresivo y sencillo. Va a por el rival más cercano y golpea.
    /// Muy herido y sin poder golpear, se cubre.
    /// </summary>
    public class MeleeAI : IBattleAI
    {
        public IEnumerator TakeTurn(BattleUnit self, BattleManager battle)
        {
            int guard = 20;
            while (guard-- > 0 && self.Alive && self.ap > 0 && battle.IsActive)
            {
                BattleUnit target = battle.ClosestOpponent(self);
                if (target == null) yield break;

                if (battle.CanAttack(self, target))
                {
                    yield return battle.Attack(self, target, false);
                    continue;
                }
                if (BattleGrid.Distance(self.pos, target.pos) <= self.weapon.maxRange) break; // pegado pero sin AP

                Vector2Int best = ApproachTile(self, battle, target, out Dictionary<Vector2Int, Vector2Int> parents);
                if (best == self.pos) break;
                yield return battle.Move(self, BattleGrid.BuildPath(parents, self.pos, best));
            }

            if (self.Alive && battle.IsActive && self.ap >= BattleManager.DefendCost && self.hp < self.maxHp * 0.35f)
                battle.Defend(self);
        }

        /// <summary>Casilla alcanzable que deja golpear este turno o, si no, la más cercana al objetivo.</summary>
        public static Vector2Int ApproachTile(BattleUnit self, BattleManager battle, BattleUnit target, out Dictionary<Vector2Int, Vector2Int> parents)
        {
            Dictionary<Vector2Int, int> reach = battle.ReachableFrom(self, self.ap, out parents);
            Vector2Int best = self.pos;
            int bestScore = int.MaxValue;
            foreach (KeyValuePair<Vector2Int, int> kv in reach)
            {
                int dist = BattleGrid.Distance(kv.Key, target.pos);
                bool canHitAfter = battle.InRange(self, kv.Key, target.pos) && self.ap - kv.Value >= self.weapon.apCost;
                int score = (canHitAfter ? 0 : 1000) + dist * 10 + kv.Value;
                if (score < bestScore)
                {
                    bestScore = score;
                    best = kv.Key;
                }
            }
            return best;
        }
    }
}
