﻿using System.Collections;

namespace PirateSurvival.Combat
{
    /// <summary>
    /// Cerebro de una unidad enemiga (o compañero con IA). Cada tipo de enemigo usa una implementación distinta.
    /// TakeTurn debe gastar AP en cada paso o terminar: el turno acaba cuando la corrutina acaba.
    /// </summary>
    public interface IBattleAI
    {
        IEnumerator TakeTurn(BattleUnit self, BattleManager battle);
    }
}
