﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace PirateSurvival.Combat
{
    /// <summary>
    /// Espadachín: busca el cuerpo a cuerpo, y si no puede rematar se queda en guardia para contraatacar.
    /// </summary>
    public class SwordsmanAI : IBattleAI
    {
        public IEnumerator TakeTurn(BattleUnit self, BattleManager battle)
        {
            int guard = 20;
            while (guard-- > 0 && self.Alive && self.ap > 0 && battle.IsActive)
            {
                BattleUnit target = battle.ClosestOpponent(self);
                if (target == null) yield break;

                // Guarda AP para defender y contraatacar si no quedarían para un segundo golpe
                if (battle.CanAttack(self, target) && (self.ap - self.weapon.apCost >= BattleManager.DefendCost || self.ap - self.weapon.apCost < 0 || target.Hp <= self.weapon.damage))
                {
                    yield return battle.Attack(self, target, false);
                    continue;
                }
                if (BattleGrid.Distance(self.pos, target.pos) <= 1) break;

                Vector2Int best = MeleeAI.ApproachTile(self, battle, target, out Dictionary<Vector2Int, Vector2Int> parents);
                if (best == self.pos) break;
                yield return battle.Move(self, BattleGrid.BuildPath(parents, self.pos, best));
            }

            if (self.Alive && battle.IsActive && self.ap >= BattleManager.DefendCost && !self.defending) battle.Defend(self);
        }
    }
}
