﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace PirateSurvival.Combat
{
    /// <summary>
    /// Marine. Con fusil: dispara en grupo al rival más herido (fuego concentrado) desde cobertura.
    /// Con escudo: avanza para proteger a sus compañeros, golpea si puede y siempre acaba en guardia.
    /// </summary>
    public class MarineAI : RangedAI
    {
        private readonly bool shield;

        public MarineAI(bool shieldBearer) { shield = shieldBearer; }

        protected override BattleUnit PickTarget(BattleUnit self, BattleManager battle)
        {
            BattleUnit best = null;
            float bestScore = float.MaxValue;
            foreach (BattleUnit u in battle.Opponents(self))
            {
                // Fuego concentrado: prioriza al más débil, sin ignorar la distancia
                float score = u.Hp + BattleGrid.Distance(self.pos, u.pos) * 3f;
                if (score < bestScore) { bestScore = score; best = u; }
            }
            return best;
        }

        public override IEnumerator TakeTurn(BattleUnit self, BattleManager battle)
        {
            return shield ? ShieldTurn(self, battle) : base.TakeTurn(self, battle);
        }

        private IEnumerator ShieldTurn(BattleUnit self, BattleManager battle)
        {
            BattleUnit target = battle.ClosestOpponent(self);
            if (target == null) yield break;

            if (battle.CanAttack(self, target))
            {
                yield return battle.Attack(self, target, false);
            }
            else if (BattleGrid.Distance(self.pos, target.pos) > 1)
            {
                // Avanza dejando AP para la guardia
                int budget = Mathf.Max(0, self.ap - BattleManager.DefendCost);
                Dictionary<Vector2Int, int> reach = battle.ReachableFrom(self, budget, out Dictionary<Vector2Int, Vector2Int> parents);
                Vector2Int best = self.pos;
                int bestD = BattleGrid.Distance(self.pos, target.pos);
                foreach (KeyValuePair<Vector2Int, int> kv in reach)
                {
                    int d = BattleGrid.Distance(kv.Key, target.pos);
                    if (d < bestD) { bestD = d; best = kv.Key; }
                }
                if (best != self.pos) yield return battle.Move(self, BattleGrid.BuildPath(parents, self.pos, best));
                if (battle.IsActive && battle.CanAttack(self, target) && self.ap - self.weapon.apCost >= BattleManager.DefendCost)
                    yield return battle.Attack(self, target, false);
            }

            if (self.Alive && battle.IsActive && self.ap >= BattleManager.DefendCost) battle.Defend(self);
        }
    }
}
