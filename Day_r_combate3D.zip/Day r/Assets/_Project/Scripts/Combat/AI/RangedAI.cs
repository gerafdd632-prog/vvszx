﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace PirateSurvival.Combat
{
    /// <summary>
    /// Tirador: mantiene la distancia, busca cobertura y línea de tiro, y recarga tras disparar.
    /// Si un rival está junto a un barril de pólvora, dispara al barril. Si le alcanzan cuerpo a cuerpo, retrocede.
    /// </summary>
    public class RangedAI : IBattleAI
    {
        public virtual IEnumerator TakeTurn(BattleUnit self, BattleManager battle)
        {
            int guard = 20;
            while (guard-- > 0 && self.Alive && self.ap > 0 && battle.IsActive)
            {
                BattleUnit target = PickTarget(self, battle);
                if (target == null) yield break;
                int dist = BattleGrid.Distance(self.pos, target.pos);

                if (dist < self.weapon.minRange)
                {
                    Vector2Int retreat = PickTile(self, battle, target, self.ap, true, out Dictionary<Vector2Int, Vector2Int> rParents);
                    if (retreat == self.pos) break;
                    yield return battle.Move(self, BattleGrid.BuildPath(rParents, self.pos, retreat));
                    continue;
                }

                if (self.weapon.needsReload && !self.loaded)
                {
                    if (self.ap >= BattleManager.ReloadCost)
                    {
                        yield return battle.Reload(self);
                        continue;
                    }
                    break;
                }

                // Oportunidad: barril de pólvora junto a un rival
                if (FindBarrelShot(self, battle, out Vector2Int barrel))
                {
                    battle.LogAi($"{self.name} apunta a un barril de pólvora...");
                    yield return battle.AttackObject(self, barrel, false);
                    continue;
                }

                if (battle.CanAttack(self, target))
                {
                    yield return battle.Attack(self, target, false);
                    continue;
                }

                int budget = self.ap - self.weapon.apCost;
                if (budget <= 0) break;
                Vector2Int spot = PickTile(self, battle, target, budget, false, out Dictionary<Vector2Int, Vector2Int> parents);
                if (spot == self.pos) break;
                yield return battle.Move(self, BattleGrid.BuildPath(parents, self.pos, spot));
            }
        }

        /// <summary>Por defecto el más cercano; los tiradores coordinados lo sobrescriben.</summary>
        protected virtual BattleUnit PickTarget(BattleUnit self, BattleManager battle) => battle.ClosestOpponent(self);

        private static bool FindBarrelShot(BattleUnit self, BattleManager battle, out Vector2Int barrel)
        {
            barrel = default;
            BattleGrid g = battle.Grid;
            for (int x = 0; x < g.Width; x++)
            {
                for (int y = 0; y < g.Height; y++)
                {
                    var p = new Vector2Int(x, y);
                    if (g.Get(p) != TileType.ExplosiveBarrel || !battle.CanAttackObject(self, p)) continue;
                    if (BattleGrid.Distance(self.pos, p) <= 1) continue; // no volarse a sí mismo
                    bool enemyNear = false, allyNear = false;
                    foreach (BattleUnit u in battle.Units)
                    {
                        if (!u.Alive || BattleGrid.Distance(u.pos, p) > 1) continue;
                        if (u.faction == self.faction) allyNear = true; else enemyNear = true;
                    }
                    if (enemyNear && !allyNear)
                    {
                        barrel = p;
                        return true;
                    }
                }
            }
            return false;
        }

        protected static Vector2Int PickTile(BattleUnit self, BattleManager battle, BattleUnit target, int budget, bool retreating,
            out Dictionary<Vector2Int, Vector2Int> parents)
        {
            Dictionary<Vector2Int, int> reach = battle.ReachableFrom(self, budget, out parents);
            Vector2Int best = self.pos;
            float bestScore = float.MinValue;
            foreach (KeyValuePair<Vector2Int, int> kv in reach)
            {
                Vector2Int tile = kv.Key;
                int d = BattleGrid.Distance(tile, target.pos);
                if (d < self.weapon.minRange) continue;

                bool canShoot = battle.InAttackPosition(self, tile, target);
                bool covered = battle.Grid.HasCover(tile, target.pos);
                float score = (canShoot ? battle.HitChance(self, tile, target, false) * 100f : 0f)
                              + (covered ? 25f : 0f)
                              - Mathf.Abs(d - 4) * 4f
                              - kv.Value * (retreating ? 1f : 3f)
                              - (battle.Grid.Get(tile) == TileType.Fire ? 50f : 0f);
                if (score > bestScore)
                {
                    bestScore = score;
                    best = tile;
                }
            }
            return best;
        }
    }
}
