﻿using System.Collections.Generic;
using UnityEngine;
using PirateSurvival.Bootstrap;
using PirateSurvival.Core;
using PirateSurvival.Inventory;
using PirateSurvival.Interaction;
using PirateSurvival.Player;

namespace PirateSurvival.Combat
{
    public enum CreatureKind { Crab, Boar, Bat, Rat, Spider }

    /// <summary>
    /// Fauna de la isla con combate en tiempo real: vida con barra, deambular, perseguir y morder, huir,
    /// soltar botín al morir y reaparecer pasado un tiempo en su sitio.
    ///  - Pasiva: huye al recibir un golpe.
    ///  - Defensiva (cangrejo): se defiende cuando le pegas.
    ///  - Agresiva (jabalí, rata, murciélago, araña): ataca si te acercas.
    /// </summary>
    [RequireComponent(typeof(Rigidbody2D))]
    public class Creature : MonoBehaviour, IInteractable
    {
        public enum Temper { Passive, Defensive, Aggressive }
        private enum State { Wander, Chase, Return, Dead }

        private static readonly List<Creature> Living = new List<Creature>();

        [SerializeField] private string displayName = "Bicho";
        [SerializeField] private int maxHp = 20;
        [SerializeField] private float speed = 1.6f;
        [SerializeField] private float chaseSpeed = 2.8f;
        [SerializeField] private int biteDamage = 4;
        [SerializeField] private float biteCooldown = 1.3f;
        [SerializeField] private float aggroRadius = 4f;
        [SerializeField] private float leashRadius = 8f;
        [SerializeField] private float wanderRadius = 2.5f;
        [SerializeField] private Temper temper = Temper.Aggressive;
        [SerializeField] private ItemData drop;
        [SerializeField] private int minDrop = 1;
        [SerializeField] private int maxDrop = 2;
        [SerializeField] private int experience = 3;
        [SerializeField] private float respawnSeconds = 180f;
        [SerializeField] private bool flies;

        private int hp;
        private State state = State.Wander;
        private Vector2 home, wanderTarget;
        private float wanderTimer, biteTimer, respawnTimer, flashTimer, barTimer;
        private bool provoked;
        private Vector2 knockback;
        private Rigidbody2D body;
        private static readonly RaycastHit2D[] castHits = new RaycastHit2D[6];
        private ContactFilter2D moveFilter;
        private SpriteRenderer sr;
        private CreatureKind species = CreatureKind.Crab;
        private Collider2D col;
        private Transform barRoot, barFill;
        private PlayerStats player;

        public string DisplayName => displayName;
        public bool Alive => state != State.Dead;
        public static IReadOnlyList<Creature> All => Living;

        // IInteractable
        public string GetPromptText() => $"Luchar con {displayName}";
        public void Interact(PlayerInteraction2D interactor) => TriggerBattle();
        public bool CanInteract() => state != State.Dead && GameState.IsPlaying;

        public void TriggerBattle()
        {
            if (state == State.Dead) return;
            Combat3D.Combat3DManager mgr = Combat3D.Combat3DManager.Instance;
            if (mgr == null || !mgr.CanStartBattle) return;

            Combat3D.Combat3DSetup setup = new Combat3D.Combat3DSetup
            {
                theme = species == CreatureKind.Crab ? Combat3D.ArenaTheme.Beach
                      : species == CreatureKind.Boar ? Combat3D.ArenaTheme.Jungle
                      : Combat3D.ArenaTheme.Cave,
                canFlee = true,
                worldSource = transform.position,
                grantXp = false, // la experiencia la da Die()
                introText = $"¡Un {displayName.ToLowerInvariant()} salvaje te ataca!"
            };
            setup.enemies.Add(BuildFighter());
            setup.onFinished = outcome =>
            {
                if (outcome == Combat3D.Combat3DOutcome.Won)
                {
                    Die();
                }
                else
                {
                    state = State.Return;
                    provoked = false;
                }
            };
            mgr.StartBattle3D(setup);
        }

        /// <summary>Ficha de combate 3D de esta especie (más vida y mordisco que en el mapa: el combate es por turnos).</summary>
        private Combat3D.Combat3DFighter BuildFighter()
        {
            int battleHp = Mathf.Max(20, maxHp * 2);
            Combat3D.Combat3DFighter f = new Combat3D.Combat3DFighter
            {
                name = displayName,
                maxHp = battleHp,
                hp = battleHp,
                damage = biteDamage * 2 + 2,
                accuracy = 0.85f,
                crit = 0.1f,
                sprite = sr != null ? sr.sprite : null,
                flies = flies,
                animal = true,
                xp = experience
            };
            switch (species)
            {
                case CreatureKind.Crab:
                    f.style = Combat3D.EnemyStyle.Scuttle; f.attackName = "sus pinzas"; f.height = 1.1f; f.defense = 2; f.damageType = CombatDamageType.Blunt;
                    break;
                case CreatureKind.Boar:
                    f.style = Combat3D.EnemyStyle.Charge; f.attackName = "una embestida con los colmillos"; f.height = 1.6f; f.damageType = CombatDamageType.Pierce;
                    f.appliesStatus = true; f.status = StatusType.KnockedDown; f.statusChance = 0.2f; f.statusTurns = 1;
                    break;
                case CreatureKind.Bat:
                    f.style = Combat3D.EnemyStyle.Swoop; f.attackName = "un mordisco en picado"; f.height = 1.1f; f.evasion = 0.1f; f.damageType = CombatDamageType.Slash;
                    f.appliesStatus = true; f.status = StatusType.Bleeding; f.statusChance = 0.25f; f.statusTurns = 2;
                    break;
                case CreatureKind.Rat:
                    f.style = Combat3D.EnemyStyle.Charge; f.attackName = "un mordisco rabioso"; f.height = 0.95f; f.damageType = CombatDamageType.Pierce;
                    f.appliesStatus = true; f.status = StatusType.Poisoned; f.statusChance = 0.2f; f.statusTurns = 2;
                    break;
                default:
                    f.style = Combat3D.EnemyStyle.Leap; f.attackName = "sus colmillos venenosos"; f.height = 1.3f; f.damageType = CombatDamageType.Pierce;
                    f.appliesStatus = true; f.status = StatusType.Poisoned; f.statusChance = 0.4f; f.statusTurns = 3;
                    break;
            }
            return f;
        }

        private void OnCollisionEnter2D(Collision2D collision)
        {
            if (state == State.Dead) return;
            if (collision.gameObject.CompareTag("Player") || collision.gameObject.GetComponent<PlayerStats>() != null)
            {
                TriggerBattle();
            }
        }

        private void OnTriggerEnter2D(Collider2D other)
        {
            if (state == State.Dead) return;
            if (other.CompareTag("Player") || other.GetComponent<PlayerStats>() != null)
            {
                TriggerBattle();
            }
        }

        // ------------------------------------------------------------------ Configuración

        /// <summary>Estadísticas de cada especie.</summary>
        public void Configure(CreatureKind kind, ItemData dropItem)
        {
            drop = dropItem;
            species = kind;
            switch (kind)
            {
                case CreatureKind.Crab:
                    displayName = "Cangrejo"; maxHp = 14; speed = 1.2f; chaseSpeed = 2.2f; biteDamage = 3; temper = Temper.Defensive;
                    aggroRadius = 0f; minDrop = 1; maxDrop = 2; experience = 2; respawnSeconds = 150f;
                    break;
                case CreatureKind.Boar:
                    displayName = "Jabalí"; maxHp = 34; speed = 1.4f; chaseSpeed = 3.4f; biteDamage = 7; temper = Temper.Aggressive;
                    aggroRadius = 4.5f; leashRadius = 9f; minDrop = 2; maxDrop = 3; experience = 6; respawnSeconds = 240f;
                    break;
                case CreatureKind.Bat:
                    displayName = "Murciélago"; maxHp = 9; speed = 2f; chaseSpeed = 3.6f; biteDamage = 2; temper = Temper.Aggressive;
                    aggroRadius = 4f; leashRadius = 6f; minDrop = 0; maxDrop = 0; experience = 2; respawnSeconds = 120f; flies = true;
                    break;
                case CreatureKind.Rat:
                    displayName = "Rata de bodega"; maxHp = 12; speed = 1.6f; chaseSpeed = 3.2f; biteDamage = 3; temper = Temper.Aggressive;
                    aggroRadius = 3.5f; leashRadius = 6f; minDrop = 0; maxDrop = 1; experience = 2; respawnSeconds = 150f;
                    break;
                case CreatureKind.Spider:
                    displayName = "Araña de cueva"; maxHp = 18; speed = 1.3f; chaseSpeed = 2.8f; biteDamage = 5; temper = Temper.Aggressive;
                    aggroRadius = 3.5f; leashRadius = 5f; minDrop = 0; maxDrop = 0; experience = 4; respawnSeconds = 200f;
                    break;
            }
            hp = maxHp;
        }

        private void Awake()
        {
            body = GetComponent<Rigidbody2D>();
            body.bodyType = RigidbodyType2D.Kinematic;
            body.interpolation = RigidbodyInterpolation2D.Interpolate;
            moveFilter = new ContactFilter2D { useTriggers = false }; // solo colisores sólidos (muros, rocas, edificios)
            sr = GetComponentInChildren<SpriteRenderer>();
            col = GetComponent<Collider2D>();
            hp = maxHp;
            BuildHealthBar();
            AttachShadow();
        }

        private void AttachShadow()
        {
            if (flies) return;
            GameObject shadow = new GameObject("DropShadow");
            shadow.transform.SetParent(transform, false);
            shadow.transform.localPosition = new Vector3(0f, -0.18f, 0f);
            SpriteRenderer ssr = shadow.AddComponent<SpriteRenderer>();
            ssr.sprite = WorldArt.DropShadow();
            ssr.sortingOrder = -4400;
        }

        private void Start()
        {
            home = transform.position;
            wanderTarget = home;
        }

        private void OnEnable() { if (!Living.Contains(this)) Living.Add(this); }
        private void OnDisable() { Living.Remove(this); }

        // ------------------------------------------------------------------ Bucle

        private void FixedUpdate()
        {
            if (!GameState.IsPlaying) return;
            float dt = Time.fixedDeltaTime;

            if (state == State.Dead)
            {
                respawnTimer -= dt;
                if (respawnTimer <= 0f) Respawn();
                return;
            }

            if (player == null) player = FindAnyObjectByType<PlayerStats>();
            Vector2 pos = body.position;
            Vector2 playerPos = player != null ? (Vector2)player.transform.position : pos + Vector2.one * 999f;
            float toPlayer = Vector2.Distance(pos, playerPos);
            bool playerUsable = player != null && !player.IsDead && !player.IsFainted;
            bool hostile = temper == Temper.Aggressive || (temper == Temper.Defensive && provoked);

            if (hostile && playerUsable && toPlayer < 1.35f)
            {
                TriggerBattle();
                return;
            }

            // Elegir estado
            if (state != State.Return && hostile && playerUsable && (toPlayer <= aggroRadius || provoked) && Vector2.Distance(home, playerPos) <= leashRadius)
                state = State.Chase;
            else if (state == State.Chase)
                state = State.Return;
            if (state == State.Return && Vector2.Distance(pos, home) < 0.3f) { state = State.Wander; provoked = false; }

            Vector2 target;
            float spd;
            switch (state)
            {
                case State.Chase:
                    target = playerPos;
                    spd = chaseSpeed;
                    if (toPlayer < 1.35f && playerUsable)
                    {
                        TriggerBattle();
                        return;
                    }
                    if (toPlayer < 0.6f) target = pos; // no meterse dentro del jugador
                    break;
                case State.Return:
                    target = home;
                    spd = speed * 1.5f;
                    break;
                default:
                    if (temper == Temper.Passive && provoked)
                    {
                        // Huir del jugador
                        target = pos + (pos - playerPos).normalized * 2f;
                        spd = chaseSpeed;
                        if (toPlayer > 6f) provoked = false;
                        break;
                    }
                    wanderTimer -= dt;
                    if (wanderTimer <= 0f)
                    {
                        wanderTimer = Random.Range(1.8f, 4f);
                        wanderTarget = home + Random.insideUnitCircle * wanderRadius;
                    }
                    target = wanderTarget;
                    spd = speed;
                    break;
            }

            Vector2 step = Vector2.MoveTowards(pos, target, spd * dt) - pos;
            knockback = Vector2.MoveTowards(knockback, Vector2.zero, 12f * dt);
            Vector2 next = pos + step + knockback * dt;
            if (flies) next.y += Mathf.Sin(Time.time * 8f + home.x) * 0.01f;
            else next = pos + BlockedMove(next - pos);
            body.MovePosition(next);
            if (sr != null && Mathf.Abs(step.x) > 0.001f) sr.flipX = step.x < 0f;
        }

        /// <summary>Los cuerpos cinemáticos atraviesan muros: se recorta el paso contra lo sólido que haya delante.</summary>
        private Vector2 BlockedMove(Vector2 delta)
        {
            float len = delta.magnitude;
            if (len < 0.0001f || col == null) return delta;
            int n = body.Cast(delta / len, moveFilter, castHits, len + 0.02f);
            float allowed = len;
            for (int i = 0; i < n; i++)
            {
                if (castHits[i].collider == null || castHits[i].collider.attachedRigidbody == body) continue;
                allowed = Mathf.Min(allowed, Mathf.Max(0f, castHits[i].distance - 0.02f));
            }
            if (allowed < len)
            {
                wanderTimer = 0f;           // busca otro destino en vez de empujar contra la pared
                knockback = Vector2.zero;
            }
            return delta / len * allowed;
        }

        private void Update()
        {
            if (state == State.Dead) return;
            if (flashTimer > 0f)
            {
                flashTimer -= Time.deltaTime;
                if (sr != null)
                {
                    sr.color = flashTimer > 0.08f ? new Color(1.8f, 1.8f, 1.8f, 1f) :
                               (flashTimer > 0f ? new Color(1f, 0.4f, 0.4f, 1f) : Color.white);
                }
            }
            if (sr != null && sr.transform.localScale != Vector3.one)
            {
                sr.transform.localScale = Vector3.MoveTowards(sr.transform.localScale, Vector3.one, Time.deltaTime * 3.5f);
            }
            // Barra de vida: visible tras recibir daño o con el jugador cerca y la criatura herida
            if (barTimer > 0f) barTimer -= Time.deltaTime;
            bool near = player != null && Vector2.Distance(player.transform.position, transform.position) < 3f;
            barRoot.gameObject.SetActive(barTimer > 0f || (near && hp < maxHp));
        }

        // ------------------------------------------------------------------ Daño

        /// <summary>Recibe un golpe del jugador. Inicia combate 3D estilo Pokémon.</summary>
        public bool TakeHit(int damage, Vector2 from)
        {
            if (state == State.Dead || damage <= 0) return false;
            TriggerBattle();
            return false;
        }

        private void Die()
        {
            state = State.Dead;
            respawnTimer = respawnSeconds;
            if (sr != null) { sr.enabled = false; sr.color = Color.white; }
            if (col != null) col.enabled = false;
            barRoot.gameObject.SetActive(false);

            if (drop != null && maxDrop > 0)
            {
                int n = Random.Range(minDrop, maxDrop + 1);
                if (n > 0) WorldItemFactory.Spawn(drop, n, (Vector2)transform.position, Random.insideUnitCircle.normalized * 2f);
            }
            PlayerProgress progress = player != null ? player.GetComponent<PlayerProgress>() : null;
            if (progress != null) progress.AddExperience(experience);
            GameEvents.TriggerNotificationMessage($"Has derrotado: {displayName} (+{experience} exp)");
            GameEvents.TriggerStoryEvent("mato:" + displayName);
        }

        private void Respawn()
        {
            hp = maxHp;
            state = State.Wander;
            provoked = false;
            body.position = home;
            transform.position = home;
            barFill.localScale = Vector3.one;
            if (sr != null) sr.enabled = true;
            if (col != null) col.enabled = true;
        }

        // ------------------------------------------------------------------ Barra de vida

        private void BuildHealthBar()
        {
            Sprite white = RuntimeSpriteCache.Get("fx_white", () =>
            {
                PixelCanvas c = new PixelCanvas(2, 2);
                c.Rect(0, 0, 2, 2, Color.white);
                return c.ToSprite(new Vector2(0f, 0.5f), 2f);
            });
            barRoot = new GameObject("HealthBar").transform;
            barRoot.SetParent(transform, false);
            barRoot.localPosition = new Vector3(-0.4f, 1.05f, 0f);

            SpriteRenderer bg = new GameObject("Bg").AddComponent<SpriteRenderer>();
            bg.transform.SetParent(barRoot, false);
            bg.sprite = white;
            bg.color = new Color(0f, 0f, 0f, 0.75f);
            bg.transform.localScale = new Vector3(0.8f, 0.12f, 1f);
            bg.sortingOrder = 31000;

            SpriteRenderer fill = new GameObject("Fill").AddComponent<SpriteRenderer>();
            fill.transform.SetParent(barRoot, false);
            fill.sprite = white;
            fill.color = new Color(0.9f, 0.25f, 0.2f);
            fill.sortingOrder = 31001;
            barFill = new GameObject("FillPivot").transform;
            barFill.SetParent(barRoot, false);
            fill.transform.SetParent(barFill, false);
            fill.transform.localPosition = new Vector3(0.02f, 0f, 0f);
            fill.transform.localScale = new Vector3(0.76f, 0.08f, 1f);
            barRoot.gameObject.SetActive(false);
        }
    }
}
