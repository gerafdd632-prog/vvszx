﻿using System.Collections;
using UnityEngine;

namespace PirateSurvival.Combat
{
    /// <summary>
    /// Números de daño flotantes en el mundo 2D para combates en tiempo real y recolección.
    /// Aparecen con un efecto punch-scale, flotan hacia arriba y se desvanecen suavemente.
    /// </summary>
    public class DamagePopup2D : MonoBehaviour
    {
        private TextMesh mainText;
        private TextMesh shadowText;
        private MeshRenderer mainRenderer;
        private MeshRenderer shadowRenderer;
        private float timer;
        private float duration = 0.65f;
        private Vector3 velocity;
        private Color initialColor;

        public static DamagePopup2D Spawn(Vector2 worldPos, int damage, bool isCrit, string customText = null)
        {
            GameObject go = new GameObject("DamagePopup");
            go.transform.position = (Vector3)worldPos + new Vector3(Random.Range(-0.15f, 0.15f), 0.35f, 0f);

            DamagePopup2D popup = go.AddComponent<DamagePopup2D>();
            popup.Setup(damage, isCrit, customText);
            return popup;
        }

        public static DamagePopup2D SpawnMessage(Vector2 worldPos, string message, Color color)
        {
            GameObject go = new GameObject("MessagePopup");
            go.transform.position = (Vector3)worldPos + new Vector3(0f, 0.4f, 0f);

            DamagePopup2D popup = go.AddComponent<DamagePopup2D>();
            popup.SetupMessage(message, color);
            return popup;
        }

        private void Setup(int damage, bool isCrit, string customText)
        {
            string str = customText ?? (isCrit ? $"¡{damage}!" : damage.ToString());
            Color col = isCrit ? new Color(1f, 0.86f, 0.22f) : Color.white;
            int size = isCrit ? 26 : 20;
            duration = isCrit ? 0.75f : 0.60f;
            InitRenderers(str, col, size);
            velocity = new Vector3(Random.Range(-0.4f, 0.4f), isCrit ? 2.2f : 1.7f, 0f);
            StartCoroutine(PunchRoutine(isCrit ? 1.6f : 1.3f));
        }

        private void SetupMessage(string message, Color color)
        {
            InitRenderers(message, color, 19);
            duration = 0.8f;
            velocity = new Vector3(0f, 1.4f, 0f);
            StartCoroutine(PunchRoutine(1.2f));
        }

        private void InitRenderers(string text, Color color, int fontSize)
        {
            initialColor = color;

            // Sombra
            GameObject shadowObj = new GameObject("Shadow");
            shadowObj.transform.SetParent(transform, false);
            shadowObj.transform.localPosition = new Vector3(0.025f, -0.025f, 0.01f);
            shadowText = shadowObj.AddComponent<TextMesh>();
            shadowText.text = text;
            shadowText.fontSize = fontSize;
            shadowText.characterSize = 0.08f;
            shadowText.alignment = TextAlignment.Center;
            shadowText.anchor = TextAnchor.MiddleCenter;
            shadowText.fontStyle = FontStyle.Bold;
            shadowText.color = new Color(0.05f, 0.05f, 0.08f, 0.9f);
            shadowRenderer = shadowObj.GetComponent<MeshRenderer>();
            shadowRenderer.sortingOrder = 32500;

            // Texto principal
            mainText = gameObject.AddComponent<TextMesh>();
            mainText.text = text;
            mainText.fontSize = fontSize;
            mainText.characterSize = 0.08f;
            mainText.alignment = TextAlignment.Center;
            mainText.anchor = TextAnchor.MiddleCenter;
            mainText.fontStyle = FontStyle.Bold;
            mainText.color = color;
            mainRenderer = GetComponent<MeshRenderer>();
            mainRenderer.sortingOrder = 32501;
        }

        private IEnumerator PunchRoutine(float startScale)
        {
            transform.localScale = Vector3.one * startScale;
            float punchDur = 0.12f;
            float pTimer = 0f;
            while (pTimer < punchDur)
            {
                pTimer += Time.deltaTime;
                float t = pTimer / punchDur;
                transform.localScale = Vector3.Lerp(Vector3.one * startScale, Vector3.one, t);
                yield return null;
            }
            transform.localScale = Vector3.one;
        }

        private void Update()
        {
            timer += Time.deltaTime;
            transform.position += velocity * Time.deltaTime;
            velocity = Vector3.Lerp(velocity, new Vector3(0f, 0.6f, 0f), Time.deltaTime * 3.5f);

            float alpha = Mathf.Clamp01(1f - (timer / duration));
            if (mainText != null)
            {
                Color c = initialColor;
                c.a = alpha;
                mainText.color = c;
            }
            if (shadowText != null)
            {
                Color sc = new Color(0.05f, 0.05f, 0.08f, alpha * 0.9f);
                shadowText.color = sc;
            }

            if (timer >= duration)
            {
                Destroy(gameObject);
            }
        }
    }
}
