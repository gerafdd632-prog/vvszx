﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using PirateSurvival.Core;
using PirateSurvival.Inventory;
using PirateSurvival.Player;

namespace PirateSurvival.Combat
{
    /// <summary>
    /// Golpe cuerpo a cuerpo en el mundo (fuera del combate táctico): clic izquierdo o [F].
    /// Apunta hacia el ratón (o hacia donde mira el jugador si se usa [F]), gasta energía,
    /// hace el daño del arma equipada (o puños) a la fauna en un arco delante y desgasta el arma.
    /// </summary>
    [RequireComponent(typeof(PlayerStats))]
    public class PlayerMelee : MonoBehaviour
    {
        private const int FistDamage = 4;
        private const float Reach = 1.20f;
        private const float HitRadius = 1.05f;
        private const float StaminaCost = 3f;

        private PlayerStats stats;
        private PlayerController2D controller;
        private PlayerAnimation2D anim;
        private Camera cam;
        private float cooldown;
        private bool inventoryOpen;
        private SpriteRenderer slash;
        private float slashTimer;
        private readonly List<Collider2D> hits = new List<Collider2D>(16);
        private readonly HashSet<Creature> struck = new HashSet<Creature>();
        private ContactFilter2D filter;

        private void Awake()
        {
            stats = GetComponent<PlayerStats>();
            controller = GetComponent<PlayerController2D>();
            anim = GetComponent<PlayerAnimation2D>();
            filter = new ContactFilter2D { useTriggers = true };

            GameObject s = new GameObject("Slash");
            s.transform.SetParent(transform, false);
            slash = s.AddComponent<SpriteRenderer>();
            slash.sprite = SlashSprite();
            slash.sortingOrder = 31500;
            slash.transform.localScale = Vector3.one * 1.35f;
            slash.enabled = false;
        }

        private void OnEnable() { GameEvents.OnInventoryToggle += OnInventoryToggle; }
        private void OnDisable() { GameEvents.OnInventoryToggle -= OnInventoryToggle; }
        private void OnInventoryToggle(bool open) => inventoryOpen = open;

        private void Update()
        {
            if (cooldown > 0f) cooldown -= Time.deltaTime;
            if (slashTimer > 0f)
            {
                slashTimer -= Time.deltaTime;
                slash.color = new Color(1f, 1f, 1f, Mathf.Clamp01(slashTimer / 0.15f));
                if (slashTimer <= 0f) slash.enabled = false;
            }

            if (!GameState.IsPlaying || inventoryOpen || stats.IsDead || stats.IsFainted) return;
            if (!GameInput.IsAttackPressed(out bool fromMouse)) return;
            // Un clic sobre un botón de la interfaz no es un golpe
            if (fromMouse && EventSystem.current != null && EventSystem.current.IsPointerOverGameObject()) return;
            if (cooldown > 0f) return;
            if (stats.CurrentStamina < StaminaCost)
            {
                GameEvents.TriggerNotificationMessage("Estás demasiado cansado para golpear.");
                cooldown = 0.4f;
                return;
            }
            Swing(fromMouse);
        }

        private void Swing(bool aimAtMouse)
        {
            InventoryManager inv = InventoryManager.Instance;
            ItemData weapon = inv != null ? inv.CurrentEquippedTool : null;
            int damage = weapon != null && weapon.combatDamage > 0 ? weapon.combatDamage : FistDamage;
            cooldown = weapon != null ? Mathf.Lerp(0.28f, 0.60f, Mathf.InverseLerp(1f, 3f, weapon.weight)) : 0.25f;
            stats.ModifyStamina(-StaminaCost);

            Vector2 origin = (Vector2)transform.position + SafePositionTracker.FeetOffset * 0.5f;
            Vector2 dir;
            if (aimAtMouse)
            {
                if (cam == null) cam = Camera.main;
                dir = GameInput.GetMouseWorldPosition(cam) - origin;
            }
            else
            {
                dir = controller != null ? controller.FaceDirection : Vector2.down;
            }
            if (dir.sqrMagnitude < 0.0001f) dir = Vector2.down;
            dir.Normalize();

            if (anim != null) anim.TriggerInteractAnimation();
            ShowSlash(dir);

            Vector2 center = origin + dir * Reach;
            hits.Clear();
            struck.Clear();
            Physics2D.OverlapCircle(center, HitRadius, filter, hits);
            bool landed = false;
            bool anyCrit = false;

            foreach (Collider2D c in hits)
            {
                if (c == null) continue;
                Creature creature = c.GetComponentInParent<Creature>();
                if (creature == null || !creature.Alive || !struck.Add(creature)) continue;
                // Crítico: 10% de base o el del arma
                float critChance = weapon != null ? weapon.combatCritChance : 0.12f;
                bool isCrit = Random.value < critChance;
                int dealt = isCrit ? Mathf.RoundToInt(damage * 1.6f) : damage;
                creature.TakeHit(dealt, origin);

                DamagePopup2D.Spawn((Vector2)creature.transform.position + Vector2.up * 0.2f, dealt, isCrit);

                if (isCrit) anyCrit = true;
                landed = true;
            }

            if (landed)
            {
                Camera2D.TriggerShake(anyCrit ? 0.16f : 0.10f, anyCrit ? 0.22f : 0.13f);

                if (AudioManager.Instance != null)
                {
                    if (anyCrit) AudioManager.Instance.PlayCrit();
                    else if (weapon != null && weapon.damageType == CombatDamageType.Slash) AudioManager.Instance.PlaySlash();
                    else AudioManager.Instance.PlayBlunt();
                }

                if (weapon != null && weapon.maxDurability > 0 && inv != null && inv.WearItem(weapon))
                {
                    inv.UnequipTool(); // se ha roto: fuera de la mano
                }
            }
        }

        private void ShowSlash(Vector2 dir)
        {
            slash.transform.localPosition = (Vector3)(dir * Reach) + new Vector3(0f, 0.15f, 0f);
            slash.transform.localRotation = Quaternion.Euler(0f, 0f, Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg);
            slash.enabled = true;
            slashTimer = 0.16f;
        }

        /// <summary>Arco blanco de corte (24x24, apunta a +X).</summary>
        private static Sprite SlashSprite() => RuntimeSpriteCache.Get("fx_slash", () =>
        {
            PixelCanvas c = new PixelCanvas(24, 24);
            for (int y = 0; y < 24; y++)
                for (int x = 0; x < 24; x++)
                {
                    float dx = x + 0.5f - 6f, dy = y + 0.5f - 12f;
                    float r = Mathf.Sqrt(dx * dx + dy * dy);
                    float ang = Mathf.Atan2(dy, dx) * Mathf.Rad2Deg;
                    if (r > 9f && r < 13f && Mathf.Abs(ang) < 70f)
                    {
                        float a = 1f - Mathf.Abs(ang) / 70f;
                        c.Set(x, y, new Color(1f, 1f, 0.9f, 0.35f + a * 0.6f));
                    }
                }
            return c.ToSprite(new Vector2(0.25f, 0.5f), 16f);
        });
    }
}
