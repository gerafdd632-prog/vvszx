﻿using System.Collections.Generic;
using UnityEngine;

namespace PirateSurvival.Combat
{
    public enum StatusType
    {
        Bleeding, Burning, Poisoned, Stunned, Wet, Exhausted, KnockedDown, Confused, Immobilized,
        SeaWeakness, Kairoseki, HakiReinforced, FruitBlocked, ObservationActive
    }

    /// <summary>Definición fija de un estado: nombre, icono (código + color), descripción y reglas de acumulación.</summary>
    public class StatusDefinition
    {
        public StatusType type;
        public string name;
        public string code;        // "icono" de texto que se muestra sobre la unidad
        public Color color;
        public string description;
        public bool stackable;     // si se acumula, sube la intensidad
        public int maxStacks = 1;
    }

    /// <summary>Instancia activa de un estado sobre una unidad.</summary>
    public class StatusEffect
    {
        public StatusType type;
        public int turns;
        public int intensity = 1;
        public StatusDefinition Def => StatusLibrary.Get(type);
    }

    public static class StatusLibrary
    {
        private static readonly Dictionary<StatusType, StatusDefinition> defs = new Dictionary<StatusType, StatusDefinition>();

        static StatusLibrary()
        {
            Add(StatusType.Bleeding, "Sangrado", "SAN", new Color(0.9f, 0.15f, 0.15f), "Pierde 2 PV por intensidad al inicio de cada turno. Sigue tras el combate.", true, 3);
            Add(StatusType.Burning, "Quemadura", "QUE", new Color(1f, 0.5f, 0.1f), "Pierde 4 PV por intensidad cada turno. El agua lo apaga.", true, 2);
            Add(StatusType.Poisoned, "Envenenado", "VEN", new Color(0.5f, 0.85f, 0.2f), "Pierde 2 PV por intensidad cada turno y se cansa. Sigue tras el combate.", true, 3);
            Add(StatusType.Stunned, "Aturdido", "ATU", new Color(1f, 0.9f, 0.3f), "Pierde su próximo turno.", false, 1);
            Add(StatusType.Wet, "Mojado", "MOJ", new Color(0.4f, 0.7f, 1f), "No puede arder. Los usuarios de Logia mojados pueden ser golpeados.", false, 1);
            Add(StatusType.Exhausted, "Exhausto", "EXH", new Color(0.7f, 0.7f, 0.7f), "-1 AP y -15% de daño.", false, 1);
            Add(StatusType.KnockedDown, "Derribado", "DER", new Color(0.8f, 0.6f, 0.4f), "Gasta 2 AP en levantarse y es más fácil de golpear.", false, 1);
            Add(StatusType.Confused, "Confundido", "CON", new Color(0.85f, 0.5f, 1f), "-25% de precisión.", false, 1);
            Add(StatusType.Immobilized, "Inmovilizado", "INM", new Color(0.6f, 0.6f, 0.9f), "No puede moverse (sí atacar).", false, 1);
            Add(StatusType.SeaWeakness, "Debilidad al mar", "MAR", new Color(0.2f, 0.45f, 0.9f), "Usuario de Fruta en el agua: -2 AP y sin poderes.", false, 1);
            Add(StatusType.Kairoseki, "Kairoseki", "KAI", new Color(0.55f, 0.65f, 0.6f), "Usuario de Fruta tocado por Kairoseki: -2 AP, mitad de daño, sin poderes.", false, 1);
            Add(StatusType.HakiReinforced, "Haki reforzado", "HAK", new Color(0.25f, 0.2f, 0.35f), "+40% de daño, +3 de defensa y puede golpear a usuarios de Logia.", false, 1);
            Add(StatusType.FruitBlocked, "Fruta bloqueada", "BLQ", new Color(0.5f, 0.5f, 0.5f), "No puede usar habilidades de Fruta del Diablo.", false, 1);
            Add(StatusType.ObservationActive, "Haki de observación", "OBS", new Color(0.9f, 0.9f, 1f), "+15% de precisión y +25% de esquiva.", false, 1);
        }

        private static void Add(StatusType t, string name, string code, Color c, string desc, bool stack, int max)
        {
            defs[t] = new StatusDefinition { type = t, name = name, code = code, color = c, description = desc, stackable = stack, maxStacks = max };
        }

        public static StatusDefinition Get(StatusType t) => defs[t];
    }
}
