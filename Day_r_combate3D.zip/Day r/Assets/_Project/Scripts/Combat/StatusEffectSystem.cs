﻿using System.Collections.Generic;
using UnityEngine;
using PirateSurvival.Player;

namespace PirateSurvival.Combat
{
    /// <summary>
    /// Reglas de los estados alterados: aplicar/acumular, efectos al inicio del turno, duración y modificadores de combate.
    /// </summary>
    public static class StatusEffectSystem
    {
        /// <summary>Aplica un estado. Devuelve false si no tuvo efecto (p. ej. quemar a alguien mojado).</summary>
        public static bool Apply(BattleUnit u, StatusType type, int turns, int intensity = 1)
        {
            if (!u.Alive) return false;
            if (type == StatusType.Burning && u.Has(StatusType.Wet)) return false;
            if (type == StatusType.Wet) u.statuses.RemoveAll(s => s.type == StatusType.Burning);
            // Kairoseki y el mar solo afectan a usuarios de Fruta
            if ((type == StatusType.Kairoseki || type == StatusType.SeaWeakness) && !u.isFruitUser) return false;

            StatusEffect existing = u.Find(type);
            StatusDefinition def = StatusLibrary.Get(type);
            if (existing != null)
            {
                existing.turns = Mathf.Max(existing.turns, turns);
                if (def.stackable) existing.intensity = Mathf.Min(def.maxStacks, existing.intensity + intensity);
            }
            else
            {
                u.statuses.Add(new StatusEffect { type = type, turns = turns, intensity = Mathf.Min(def.maxStacks, Mathf.Max(1, intensity)) });
            }
            return true;
        }

        public static void Remove(BattleUnit u, StatusType type) => u.statuses.RemoveAll(s => s.type == type);

        /// <summary>Daño de un estado al empezar el turno, con su causa de muerte.</summary>
        public struct StatusDamage
        {
            public int amount;
            public string verb;
            public DeathCause cause;
        }

        /// <summary>Daño por estados al empezar el turno.</summary>
        public static List<StatusDamage> TurnStartDamage(BattleUnit u)
        {
            var list = new List<StatusDamage>();
            foreach (StatusEffect s in u.statuses)
            {
                if (s.type == StatusType.Bleeding) list.Add(new StatusDamage { amount = 2 * s.intensity, verb = "sangra", cause = DeathCause.Bleeding });
                else if (s.type == StatusType.Burning) list.Add(new StatusDamage { amount = 4 * s.intensity, verb = "se quema", cause = DeathCause.Burning });
                else if (s.type == StatusType.Poisoned) list.Add(new StatusDamage { amount = 2 * s.intensity, verb = "sufre el veneno", cause = DeathCause.Poison });
            }
            return list;
        }

        /// <summary>AP efectivos al empezar el turno según los estados.</summary>
        public static int ApAtTurnStart(BattleUnit u, int baseAp)
        {
            if (u.Has(StatusType.Stunned)) return 0;
            int ap = baseAp;
            if (u.Has(StatusType.KnockedDown)) ap -= 2;
            if (u.Has(StatusType.Exhausted)) ap -= 1;
            if (u.Has(StatusType.Kairoseki)) ap -= 2;
            if (u.Has(StatusType.SeaWeakness)) ap -= 2;
            return Mathf.Max(0, ap);
        }

        /// <summary>Al acabar el turno de la unidad: baja duraciones y quita los caducados. Derribado dura solo un turno.</summary>
        public static void TickTurnEnd(BattleUnit u)
        {
            foreach (StatusEffect s in u.statuses) s.turns--;
            u.statuses.RemoveAll(s => s.turns <= 0 || s.type == StatusType.KnockedDown || s.type == StatusType.Stunned);
        }

        public static float DamageMult(BattleUnit u)
        {
            float m = 1f;
            if (u.Has(StatusType.HakiReinforced)) m += 0.4f;
            if (u.Has(StatusType.Kairoseki)) m *= 0.5f;
            if (u.Has(StatusType.Exhausted)) m *= 0.85f;
            return m;
        }

        public static int DefenseBonus(BattleUnit u) => u.Has(StatusType.HakiReinforced) ? 3 : 0;

        public static float AccuracyMod(BattleUnit attacker, BattleUnit target)
        {
            float m = 0f;
            if (attacker.Has(StatusType.Confused)) m -= 0.25f;
            if (attacker.Has(StatusType.ObservationActive)) m += 0.15f;
            if (target != null)
            {
                if (target.Has(StatusType.ObservationActive)) m -= 0.25f;
                if (target.Has(StatusType.KnockedDown)) m += 0.15f;
            }
            return m;
        }

        public static bool CanMove(BattleUnit u) => !u.Has(StatusType.Immobilized) && !u.Has(StatusType.Stunned);

        public static bool CanUseFruit(BattleUnit u) =>
            !u.Has(StatusType.FruitBlocked) && !u.Has(StatusType.Kairoseki) && !u.Has(StatusType.SeaWeakness);

        /// <summary>Texto enriquecido con los códigos de color de los estados activos.</summary>
        public static string Codes(BattleUnit u)
        {
            var sb = new System.Text.StringBuilder();
            foreach (StatusEffect s in u.statuses)
            {
                StatusDefinition d = s.Def;
                sb.Append($"<color=#{ColorUtility.ToHtmlStringRGB(d.color)}>{d.code}{(s.intensity > 1 ? s.intensity.ToString() : "")}</color> ");
            }
            return sb.ToString().TrimEnd();
        }

        public static string Describe(BattleUnit u)
        {
            if (u.statuses.Count == 0) return "Ninguno";
            var parts = new List<string>();
            foreach (StatusEffect s in u.statuses)
                parts.Add($"{s.Def.name}{(s.intensity > 1 ? " x" + s.intensity : "")} ({s.turns}t)");
            return string.Join(", ", parts);
        }
    }
}
