﻿using System.Collections.Generic;
using UnityEngine;

namespace PirateSurvival.Combat
{
    public enum TileType
    {
        Ground,          // '.' se pisa
        Rock,            // 'R' bloquea paso y visión, cobertura sólida
        Cover,           // 'W' restos de barco: bloquea paso, no la visión, cobertura
        Water,           // '~' mar profundo: no se pisa; caer dentro es peligroso (más aún con Fruta)
        Shallow,         // 's' agua poco profunda: cuesta 2 AP, moja; debilita a usuarios de Fruta
        Tree,            // 'T' bloquea paso y disparos
        Barrel,          // 'B' barril: obstáculo bajo destructible
        ExplosiveBarrel, // 'X' barril de pólvora: explota al romperse
        Crate,           // 'C' caja: cobertura destructible
        Fire,            // 'F' fuego: se pisa pero quema
        Mast,            // 'M' mástil: bloquea paso y visión
        Bush             // 'b' arbusto: se pisa (2 AP) y da cobertura
    }

    /// <summary>
    /// Arenas por lugar. Fila 0 = fila superior.
    /// '.' suelo, 'R' roca, 'W' restos, '~' mar, 's' orilla, 'T' árbol, 'B' barril, 'X' pólvora, 'C' caja, 'F' fuego, 'M' mástil, 'b' arbusto.
    /// </summary>
    public static class BattleArenas
    {
        public static readonly string[] Beach =
        {
            ".....R..s~~",
            "...W..C.s~~",
            "..T......s~",
            "....R..X.s~",
            "..B...W.s~~",
            ".R.....C.s~",
            "........s~~",
        };

        public static readonly string[] Forest =
        {
            "T.bT..T.bT.",
            ".b...T...b.",
            "T..R..b..T.",
            "..b.....R..",
            ".T..b.T..bT",
            "...T.....b.",
            "T.b..R.T..T",
        };

        /// <summary>Cubierta de barco: el mar a ambos lados; un empujón desde el borde te tira al agua.</summary>
        public static readonly string[] Ship =
        {
            "~~~~~~~~~~~",
            "~.B..M..X.~",
            "~....C....~",
            "~.X..M..B.~",
            "~...C.....~",
            "~.B......C~",
            "~~~~~~~~~~~",
        };

        /// <summary>Profundidades de la vieja mina del oeste: rocas afiladas y coberturas de estalagmitas.</summary>
        public static readonly string[] Cave =
        {
            "RR..R..R.RR",
            "R...W...R.R",
            "...R...W..R",
            "R..W..R..RR",
            "..R...W...R",
            "R...R...W.R",
            "RR.R..R..RR",
        };
    }

    /// <summary>
    /// Tablero táctico: casillas con coste, objetos destructibles, pathfinding (8 direcciones), línea de visión y cobertura.
    /// </summary>
    public class BattleGrid
    {
        public readonly int Width;
        public readonly int Height;
        private readonly TileType[,] tiles;
        private readonly int[,] objectHp;

        public static readonly Vector2Int[] Directions =
        {
            new Vector2Int(1, 0), new Vector2Int(-1, 0), new Vector2Int(0, 1), new Vector2Int(0, -1),
            new Vector2Int(1, 1), new Vector2Int(1, -1), new Vector2Int(-1, 1), new Vector2Int(-1, -1)
        };

        public BattleGrid(string[] rows)
        {
            Height = rows.Length;
            Width = rows[0].Length;
            tiles = new TileType[Width, Height];
            objectHp = new int[Width, Height];
            for (int y = 0; y < Height; y++)
            {
                string row = rows[Height - 1 - y];
                for (int x = 0; x < Width; x++)
                {
                    TileType t = Parse(x < row.Length ? row[x] : '.');
                    tiles[x, y] = t;
                    objectHp[x, y] = MaxObjectHp(t);
                }
            }
        }

        private static TileType Parse(char c)
        {
            switch (c)
            {
                case 'R': return TileType.Rock;
                case 'W': return TileType.Cover;
                case '~': return TileType.Water;
                case 's': return TileType.Shallow;
                case 'T': return TileType.Tree;
                case 'B': return TileType.Barrel;
                case 'X': return TileType.ExplosiveBarrel;
                case 'C': return TileType.Crate;
                case 'F': return TileType.Fire;
                case 'M': return TileType.Mast;
                case 'b': return TileType.Bush;
                default: return TileType.Ground;
            }
        }

        public static int MaxObjectHp(TileType t)
        {
            switch (t)
            {
                case TileType.Barrel: return 12;
                case TileType.ExplosiveBarrel: return 5;
                case TileType.Crate: return 15;
                default: return 0;
            }
        }

        public bool InBounds(Vector2Int p) => p.x >= 0 && p.y >= 0 && p.x < Width && p.y < Height;
        public TileType Get(Vector2Int p) => tiles[p.x, p.y];
        public void Set(Vector2Int p, TileType t) { tiles[p.x, p.y] = t; objectHp[p.x, p.y] = MaxObjectHp(t); }
        public int ObjectHp(Vector2Int p) => objectHp[p.x, p.y];

        public bool IsWalkable(Vector2Int p)
        {
            if (!InBounds(p)) return false;
            TileType t = tiles[p.x, p.y];
            return t == TileType.Ground || t == TileType.Shallow || t == TileType.Fire || t == TileType.Bush;
        }

        public bool IsPassable(Vector2Int p) => IsWalkable(p);

        public int MoveCost(Vector2Int p)
        {
            TileType t = tiles[p.x, p.y];
            return t == TileType.Shallow || t == TileType.Bush ? 2 : 1;
        }

        public bool IsDeepWater(Vector2Int p) => InBounds(p) && tiles[p.x, p.y] == TileType.Water;
        public bool IsDestructible(Vector2Int p) => InBounds(p) && objectHp[p.x, p.y] > 0;

        public bool BlocksSight(Vector2Int p)
        {
            TileType t = tiles[p.x, p.y];
            return t == TileType.Rock || t == TileType.Tree || t == TileType.Mast;
        }

        /// <summary>Obstáculos bajos: no cortan la visión y ciertas habilidades pasan por encima.</summary>
        public bool IsLowObstacle(Vector2Int p)
        {
            TileType t = tiles[p.x, p.y];
            return t == TileType.Cover || t == TileType.Barrel || t == TileType.ExplosiveBarrel || t == TileType.Crate;
        }

        public bool GivesCover(Vector2Int p) => InBounds(p) && (IsLowObstacle(p) || BlocksSight(p) || tiles[p.x, p.y] == TileType.Bush);

        /// <summary>Daña un objeto. Devuelve true si se destruye (la casilla pasa a suelo; el que llama gestiona explosiones).</summary>
        public bool DamageObject(Vector2Int p, int amount)
        {
            if (!IsDestructible(p)) return false;
            objectHp[p.x, p.y] -= amount;
            if (objectHp[p.x, p.y] > 0) return false;
            Set(p, TileType.Ground);
            return true;
        }

        /// <summary>Distancia en casillas permitiendo diagonales.</summary>
        public static int Distance(Vector2Int a, Vector2Int b) => Mathf.Max(Mathf.Abs(a.x - b.x), Mathf.Abs(a.y - b.y));

        /// <summary>
        /// Casillas alcanzables gastando como mucho maxCost AP (orilla y arbustos cuestan 2). Rellena parents para reconstruir caminos.
        /// </summary>
        public Dictionary<Vector2Int, int> Flood(Vector2Int start, int maxCost, HashSet<Vector2Int> occupied, Dictionary<Vector2Int, Vector2Int> parents)
        {
            var cost = new Dictionary<Vector2Int, int> { [start] = 0 };
            parents?.Clear();
            var open = new List<Vector2Int> { start };
            while (open.Count > 0)
            {
                int best = 0;
                for (int i = 1; i < open.Count; i++)
                    if (cost[open[i]] < cost[open[best]]) best = i;
                Vector2Int cur = open[best];
                open.RemoveAt(best);
                int c = cost[cur];

                foreach (Vector2Int d in Directions)
                {
                    Vector2Int next = cur + d;
                    if (!IsWalkable(next) || occupied.Contains(next)) continue;
                    // Sin atajos en diagonal entre dos obstáculos
                    if (d.x != 0 && d.y != 0 && !IsWalkable(cur + new Vector2Int(d.x, 0)) && !IsWalkable(cur + new Vector2Int(0, d.y))) continue;
                    int nc = c + MoveCost(next);
                    if (nc > maxCost) continue;
                    if (cost.TryGetValue(next, out int old) && old <= nc) continue;
                    cost[next] = nc;
                    if (parents != null) parents[next] = cur;
                    if (!open.Contains(next)) open.Add(next);
                }
            }
            return cost;
        }

        public static List<Vector2Int> BuildPath(Dictionary<Vector2Int, Vector2Int> parents, Vector2Int start, Vector2Int target)
        {
            var path = new List<Vector2Int>();
            Vector2Int cur = target;
            while (cur != start)
            {
                path.Add(cur);
                if (!parents.TryGetValue(cur, out cur)) return new List<Vector2Int>();
            }
            path.Reverse();
            return path;
        }

        /// <summary>Línea de visión (Bresenham): la cortan rocas, árboles y mástiles.</summary>
        public bool HasLineOfSight(Vector2Int a, Vector2Int b)
        {
            int dx = Mathf.Abs(b.x - a.x), dy = -Mathf.Abs(b.y - a.y);
            int sx = a.x < b.x ? 1 : -1, sy = a.y < b.y ? 1 : -1;
            int err = dx + dy;
            Vector2Int p = a;
            while (p != b)
            {
                int e2 = 2 * err;
                if (e2 >= dy) { err += dy; p.x += sx; }
                if (e2 <= dx) { err += dx; p.y += sy; }
                if (p != b && BlocksSight(p)) return false;
            }
            return true;
        }

        /// <summary>El objetivo tiene cobertura si la casilla contigua hacia el atacante es un obstáculo, o si está en un arbusto.</summary>
        public bool HasCover(Vector2Int target, Vector2Int attacker)
        {
            if (tiles[target.x, target.y] == TileType.Bush) return true;
            Vector2Int step = new Vector2Int(System.Math.Sign(attacker.x - target.x), System.Math.Sign(attacker.y - target.y));
            Vector2Int p = target + step;
            return p != attacker && InBounds(p) && GivesCover(p);
        }

        /// <summary>Si a y b están en la misma fila, columna o diagonal, devuelve la dirección unitaria.</summary>
        public static bool StraightDirection(Vector2Int a, Vector2Int b, out Vector2Int dir)
        {
            int dx = b.x - a.x, dy = b.y - a.y;
            dir = new Vector2Int(System.Math.Sign(dx), System.Math.Sign(dy));
            return (dx != 0 || dy != 0) && (dx == 0 || dy == 0 || Mathf.Abs(dx) == Mathf.Abs(dy));
        }

        /// <summary>Casilla libre más cercana (para recolocar a quien cae al mar).</summary>
        public Vector2Int NearestWalkable(Vector2Int from, HashSet<Vector2Int> occupied)
        {
            for (int r = 1; r < Mathf.Max(Width, Height); r++)
            {
                for (int x = from.x - r; x <= from.x + r; x++)
                {
                    for (int y = from.y - r; y <= from.y + r; y++)
                    {
                        var p = new Vector2Int(x, y);
                        if (Distance(p, from) == r && IsWalkable(p) && !occupied.Contains(p)) return p;
                    }
                }
            }
            return from;
        }
    }
}
