﻿using System.Collections.Generic;
using UnityEngine;
using PirateSurvival.Core;
using PirateSurvival.Player;
using PirateSurvival.Combat3D;
using PirateSurvival.Inventory;
using PirateSurvival.Interaction;

namespace PirateSurvival.Combat
{
    public enum EncounterKind
    {
        BeachPirates,   // primer combate: bruto + tirador en la playa
        CaptainShip,    // jefe: Capitán Cuervo en su barco
        CaveSpiders,    // nido de arañas en la cueva
        CaveBats,       // murciélagos voraces en la cueva
        CaveBandits     // saqueadores del tesoro de la cueva
    }

    /// <summary>
    /// Enfrentamiento en el mundo de exploración. Si el jugador entra en su radio de detección, abre el combate táctico.
    /// Cada tipo define arena, enemigos, botín y si se puede huir. Los únicos desaparecen al derrotarlos (PlayerProgress).
    /// </summary>
    public class BattleEncounter : MonoBehaviour
    {
        public struct Loot
        {
            public string itemId;
            public int quantity;
            public float chance;
            public bool onlyIfMissing; // no repetir armas que el jugador ya tiene
        }

        [SerializeField] private string encounterId = "piratas_playa";
        [SerializeField] private EncounterKind kind = EncounterKind.BeachPirates;
        [SerializeField] private float detectionRadius = 2.6f;
        [SerializeField] private GameObject visual;

        private PlayerController2D player;
        private PlayerStats playerStats;
        private PlayerProgress progress;
        private bool armed = true;

        public string EncounterId => encounterId;
        public bool Unique => true;
        public bool CanFlee => kind != EncounterKind.CaptainShip;

        public string[] Arena
        {
            get
            {
                if (kind == EncounterKind.CaptainShip) return BattleArenas.Ship;
                if (kind == EncounterKind.CaveSpiders || kind == EncounterKind.CaveBats || kind == EncounterKind.CaveBandits)
                    return BattleArenas.Cave;
                return BattleArenas.Beach;
            }
        }

        public Vector2Int PlayerStart => kind == EncounterKind.CaptainShip ? new Vector2Int(2, 4) : new Vector2Int(1, 3);

        public string IntroText => kind switch
        {
            EncounterKind.CaptainShip => "¡Has subido al barco del Capitán Cuervo! Cuidado con los bordes: el mar está a ambos lados.",
            EncounterKind.CaveSpiders => "¡Un nido de arañas venenosas te acecha en la penumbra de la cueva!",
            EncounterKind.CaveBats => "¡Una bandada de murciélagos gigantes se abalanza desde el techo de la caverna!",
            EncounterKind.CaveBandits => "¡Los saqueadores de la cueva defienden el cofre del tesoro!",
            _ => "¡Te han descubierto unos piratas!"
        };

        public List<Loot> LootTable
        {
            get
            {
                if (kind == EncounterKind.CaptainShip)
                {
                    return new List<Loot>
                    {
                        new Loot { itemId = "venda", quantity = 2, chance = 1f },
                        new Loot { itemId = "botella_agua", quantity = 2, chance = 1f },
                        new Loot { itemId = "shiokaze", quantity = 1, chance = 1f, onlyIfMissing = true },
                        new Loot { itemId = "lingote_hierro", quantity = 2, chance = 1f }
                    };
                }
                if (kind == EncounterKind.CaveSpiders || kind == EncounterKind.CaveBats)
                {
                    return new List<Loot>
                    {
                        new Loot { itemId = "venda", quantity = 1, chance = 0.8f },
                        new Loot { itemId = "fibra", quantity = 3, chance = 1f },
                        new Loot { itemId = "mineral_hierro", quantity = 2, chance = 0.6f }
                    };
                }
                if (kind == EncounterKind.CaveBandits)
                {
                    return new List<Loot>
                    {
                        new Loot { itemId = "lingote_hierro", quantity = 2, chance = 1f },
                        new Loot { itemId = "venda", quantity = 2, chance = 1f },
                        new Loot { itemId = "botella_agua", quantity = 1, chance = 1f },
                        new Loot { itemId = "katana", quantity = 1, chance = 0.5f, onlyIfMissing = true }
                    };
                }
                return new List<Loot>
                {
                    new Loot { itemId = "sable", quantity = 1, chance = 1f, onlyIfMissing = true },
                    new Loot { itemId = "coco", quantity = 1, chance = 1f },
                    new Loot { itemId = "venda", quantity = 1, chance = 0.6f },
                    new Loot { itemId = "botella_agua", quantity = 1, chance = 0.5f }
                };
            }
        }

        public List<BattleUnit> CreateEnemies()
        {
            if (kind == EncounterKind.CaptainShip)
            {
                return new List<BattleUnit>
                {
                    EnemyLibrary.Captain(new Vector2Int(7, 3)),
                    EnemyLibrary.Swordsman(new Vector2Int(7, 4)),
                    EnemyLibrary.Gunner(new Vector2Int(8, 1))
                };
            }
            if (kind == EncounterKind.CaveSpiders)
            {
                return new List<BattleUnit>
                {
                    EnemyLibrary.CaveSpider(new Vector2Int(7, 3)),
                    EnemyLibrary.CaveSpider(new Vector2Int(8, 2)),
                    EnemyLibrary.CaveBat(new Vector2Int(8, 4))
                };
            }
            if (kind == EncounterKind.CaveBats)
            {
                return new List<BattleUnit>
                {
                    EnemyLibrary.CaveBat(new Vector2Int(7, 4)),
                    EnemyLibrary.CaveBat(new Vector2Int(8, 2)),
                    EnemyLibrary.CaveSpider(new Vector2Int(8, 3))
                };
            }
            if (kind == EncounterKind.CaveBandits)
            {
                return new List<BattleUnit>
                {
                    EnemyLibrary.CaveBandit(new Vector2Int(7, 3)),
                    EnemyLibrary.Gunner(new Vector2Int(8, 1)),
                    EnemyLibrary.CaveSpider(new Vector2Int(8, 4))
                };
            }
            return new List<BattleUnit>
            {
                EnemyLibrary.Bandit(new Vector2Int(8, 4)),
                EnemyLibrary.Gunner(new Vector2Int(8, 1))
            };
        }

        /// <summary>Combate 3D: los mismos rivales que el táctico, uno tras otro, en el escenario que toca.</summary>
        private Combat3DSetup Build3DSetup()
        {
            Combat3DSetup s = new Combat3DSetup
            {
                theme = kind == EncounterKind.CaptainShip ? ArenaTheme.Deck
                      : kind == EncounterKind.BeachPirates ? ArenaTheme.Beach
                      : ArenaTheme.Cave,
                canFlee = CanFlee,
                introText = IntroText,
                worldSource = transform.position,
                grantXp = true
            };
            foreach (BattleUnit u in CreateEnemies()) s.enemies.Add(Combat3DFighter.FromUnit(u));
            // El jefe pelea el último (primero sus hombres)
            s.enemies.Sort((a, b) => a.boss == b.boss ? 0 : a.boss ? 1 : -1);

            s.onVictoryRewards = () =>
            {
                if (progress != null && Unique) progress.MarkDefeated(encounterId);
                List<string> lines = new List<string>();
                foreach (Loot l in LootTable)
                {
                    if (Random.value > l.chance) continue;
                    ItemData item = ItemDatabase.Get(l.itemId);
                    if (item == null || (l.onlyIfMissing && InventoryManager.Instance != null && InventoryManager.Instance.CountItem(item.itemId) > 0)) continue;
                    if (InventoryManager.Instance != null && !InventoryManager.Instance.AddItem(item, l.quantity))
                    {
                        WorldItemFactory.Spawn(item, l.quantity, (Vector2)transform.position + Vector2.down * 0.8f);
                        lines.Add($"{item.itemName} x{l.quantity} (en el suelo: mochila llena)");
                    }
                    else lines.Add($"{item.itemName} x{l.quantity}");
                }
                return lines;
            };
            s.onFinished = outcome =>
            {
                if (outcome == Combat3DOutcome.Won && visual != null) visual.SetActive(false);
            };
            return s;
        }

        public void Configure(string id, EncounterKind encounterKind, GameObject visualRoot)
        {
            encounterId = id;
            kind = encounterKind;
            visual = visualRoot;
        }

        /// <summary>Tras cualquier final (victoria, derrota, huida o carga) no vuelve a saltar hasta que el jugador se aleje.</summary>
        public void Disarm() => armed = false;

        private static readonly System.Collections.Generic.List<BattleEncounter> ActiveEncounters = new System.Collections.Generic.List<BattleEncounter>();
        /// <summary>Encuentros activos en el mundo (para que la historia los bloquee o desbloquee).</summary>
        public static System.Collections.Generic.IReadOnlyList<BattleEncounter> All => ActiveEncounters;
        private void OnEnable() { if (!ActiveEncounters.Contains(this)) ActiveEncounters.Add(this); }
        private void OnDisable() { ActiveEncounters.Remove(this); }

        /// <summary>Bloqueado por la historia: al acercarse solo se muestra 'LockedMessage' y no empieza el combate.</summary>
        public bool Locked { get; set; }
        public string LockedMessage { get; set; } = "";
        private float lockedMessageCooldown;

        private void Update()
        {
            if (player == null)
            {
                player = FindAnyObjectByType<PlayerController2D>();
                if (player == null) return;
                playerStats = player.GetComponent<PlayerStats>();
                progress = player.GetComponent<PlayerProgress>();
            }

            bool defeated = progress != null && progress.HasDefeated(encounterId);
            if (visual != null && visual.activeSelf == defeated) visual.SetActive(!defeated);
            if (defeated || !GameState.IsPlaying || playerStats == null || playerStats.IsDead || playerStats.IsFainted) return;

            float d = Vector2.Distance(player.transform.position, transform.position);
            if (!armed)
            {
                if (d > detectionRadius + 1.5f) armed = true;
                return;
            }

            if (Locked)
            {
                lockedMessageCooldown -= Time.deltaTime;
                if (d <= detectionRadius + 0.5f && lockedMessageCooldown <= 0f && !string.IsNullOrEmpty(LockedMessage))
                {
                    lockedMessageCooldown = 8f;
                    GameEvents.TriggerNotificationMessage(LockedMessage);
                }
                return;
            }

            if (d <= detectionRadius)
            {
                armed = false;
                if (Combat3DManager.Instance != null)
                {
                    // Si ahora no se puede (p. ej. justo tras huir), se vuelve a armar al alejarse, como siempre
                    Combat3DManager.Instance.StartBattle3D(Build3DSetup());
                }
                else if (BattleManager.Instance != null)
                {
                    BattleManager.Instance.StartBattle(this);
                }
            }
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(transform.position, detectionRadius);
        }
    }
}
