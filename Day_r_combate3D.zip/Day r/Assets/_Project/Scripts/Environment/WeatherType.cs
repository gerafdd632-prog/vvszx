﻿namespace PirateSurvival.Environment
{
    /// <summary>
    /// Estados meteorológicos posibles en el juego (Paso 0.1).
    /// </summary>
    public enum WeatherType
    {
        Clear,
        Rain,
        Storm
    }
}
