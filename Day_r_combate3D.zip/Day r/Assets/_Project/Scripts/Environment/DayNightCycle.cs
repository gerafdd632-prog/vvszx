﻿using UnityEngine;
using UnityEngine.UI;
using PirateSurvival.Core;
using PirateSurvival.Player;

namespace PirateSurvival.Environment
{
    /// <summary>
    /// Ciclo Día/Noche sin dependencias de URP ni Light2D (Item F).
    /// Controla un Image Overlay UI a pantalla completa situado bajo el HUD,
    /// con gradiente de color y transparencia generado por código para que NUNCA quede vacío.
    /// </summary>
    public class DayNightCycle : MonoBehaviour
    {
        [Header("Configuración del Tiempo")]
        [Tooltip("Duración de un ciclo de 24 horas en minutos reales")]
        [SerializeField] private float dayDurationInMinutes = 12f;
        [Tooltip("Hora inicial del juego (0 a 24)")]
        [Range(0f, 24f)]
        [SerializeField] private float timeOfDay = 8.0f;

        [Header("Overlay a Pantalla Completa (Item F)")]
        [SerializeField] private Image dayNightOverlay;
        [SerializeField] private Gradient ambientColorGradient;
        [SerializeField] private AnimationCurve darknessCurve;

        [Header("Temperaturas Base de la Isla (°C)")]
        [Tooltip("Temperatura mínima nocturna")]
        [SerializeField] private float minNightTemp = 18f;
        [Tooltip("Temperatura máxima diurna")]
        [SerializeField] private float maxDayTemp = 31f;

        [Header("Referencias")]
        [SerializeField] private PlayerStats playerStats;

        private float timeRate;
        private WeatherSystem weatherSystem;
        private float lastBroadcastHour = -999f;

        public float TimeOfDay => timeOfDay;
        public Image DayNightOverlay => dayNightOverlay;

        private void Awake()
        {
            weatherSystem = GetComponent<WeatherSystem>();
            if (playerStats == null) playerStats = FindFirstObjectByType<PlayerStats>();

            EnsureDefaultGradientsAndCurves();
        }

        private void Start()
        {
            timeRate = 24f / (dayDurationInMinutes * 60f);
            EnsureDefaultGradientsAndCurves();
            UpdateAtmosphere(force: true);
        }

        private void Update()
        {
            UpdateTime();
            UpdateAtmosphere(force: false);
            CalculateAndBroadcastTemperature();
        }

        private void EnsureDefaultGradientsAndCurves()
        {
            // Item F: Crear gradiente por código si está vacío
            if (ambientColorGradient == null || ambientColorGradient.colorKeys.Length == 0)
            {
                ambientColorGradient = new Gradient();
                GradientColorKey[] colors = new GradientColorKey[5];
                colors[0] = new GradientColorKey(new Color(0.02f, 0.04f, 0.12f), 0.0f); // 00:00 Noche profunda
                colors[1] = new GradientColorKey(new Color(1.0f, 0.52f, 0.28f), 0.25f); // 06:00 Amanecer dorado
                colors[2] = new GradientColorKey(new Color(1.0f, 1.0f, 1.0f), 0.5f);   // 12:00 Mediodía claro
                colors[3] = new GradientColorKey(new Color(0.85f, 0.32f, 0.25f), 0.75f); // 18:00 Atardecer rojizo
                colors[4] = new GradientColorKey(new Color(0.02f, 0.04f, 0.12f), 1.0f); // 24:00 Noche profunda

                GradientAlphaKey[] alphas = new GradientAlphaKey[5];
                alphas[0] = new GradientAlphaKey(0.82f, 0.0f);  // Noche oscura
                alphas[1] = new GradientAlphaKey(0.35f, 0.25f); // Amanecer translúcido
                alphas[2] = new GradientAlphaKey(0.0f, 0.5f);   // Mediodía transparente
                alphas[3] = new GradientAlphaKey(0.35f, 0.75f); // Atardecer cálido
                alphas[4] = new GradientAlphaKey(0.82f, 1.0f);  // Noche oscura

                ambientColorGradient.SetKeys(colors, alphas);
            }

            // Curva de oscuridad
            if (darknessCurve == null || darknessCurve.length == 0)
            {
                darknessCurve = new AnimationCurve();
                darknessCurve.AddKey(0.0f, 0.85f);
                darknessCurve.AddKey(0.25f, 0.35f);
                darknessCurve.AddKey(0.5f, 0.0f);
                darknessCurve.AddKey(0.75f, 0.38f);
                darknessCurve.AddKey(1.0f, 0.85f);
            }
        }

        private void UpdateTime()
        {
            timeOfDay += timeRate * Time.deltaTime;
            if (timeOfDay >= 24f) timeOfDay -= 24f;

            if (Mathf.Abs(timeOfDay - lastBroadcastHour) >= 0.016f)
            {
                lastBroadcastHour = timeOfDay;
                GameEvents.TriggerTimeUpdated(timeOfDay);
            }
        }

        private void UpdateAtmosphere(bool force)
        {
            if (dayNightOverlay == null) return;

            float normalizedTime = timeOfDay / 24f;
            Color baseColor = ambientColorGradient.Evaluate(normalizedTime);
            float baseAlpha = darknessCurve.Evaluate(normalizedTime);

            // En tormenta, oscurecer aún más la atmósfera
            if (weatherSystem != null && weatherSystem.CurrentWeather == WeatherType.Storm)
            {
                baseAlpha = Mathf.Min(0.92f, baseAlpha + 0.18f);
            }
            else if (weatherSystem != null && weatherSystem.CurrentWeather == WeatherType.Rain)
            {
                baseAlpha = Mathf.Min(0.88f, baseAlpha + 0.08f);
            }

            baseColor.a = baseAlpha;
            dayNightOverlay.color = baseColor;
        }

        private void CalculateAndBroadcastTemperature()
        {
            float tempFactor = Mathf.Cos((timeOfDay - 14f) * Mathf.PI / 12f);
            float normalizedFactor = (tempFactor + 1f) * 0.5f;

            float islandBaseTemp = Mathf.Lerp(minNightTemp, maxDayTemp, normalizedFactor);

            if (weatherSystem != null)
            {
                islandBaseTemp += weatherSystem.CurrentTemperatureOffset;
            }

            if (playerStats != null)
            {
                playerStats.SetAmbientTemperature(islandBaseTemp);
            }
        }

        public void SetOverlayImage(Image overlay)
        {
            dayNightOverlay = overlay;
            UpdateAtmosphere(force: true);
        }

        public void SetTimeOfDay(float newHour)
        {
            timeOfDay = Mathf.Clamp(newHour, 0f, 24f);
            lastBroadcastHour = timeOfDay;
            UpdateAtmosphere(force: true);
            GameEvents.TriggerTimeUpdated(timeOfDay);
        }

        public void AdvanceTimeHours(float hours)
        {
            float newTime = (timeOfDay + hours) % 24f;
            if (newTime < 0f) newTime += 24f;
            SetTimeOfDay(newTime);
        }
    }
}
