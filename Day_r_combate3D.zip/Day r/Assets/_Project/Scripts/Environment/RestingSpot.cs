﻿using UnityEngine;
using PirateSurvival.Core;
using PirateSurvival.Player;
using PirateSurvival.Interaction;

namespace PirateSurvival.Environment
{
    /// <summary>
    /// Punto de descanso (tienda de campaña, hamaca o cama).
    /// Permite al jugador dormir, saltar la noche peligrosa y restaurar energía a cambio de hambre y sed.
    /// </summary>
    [RequireComponent(typeof(Collider2D))]
    public class RestingSpot : MonoBehaviour, IInteractable
    {
        [SerializeField] private string shelterName = "la Tienda";
        [SerializeField] private float staminaRestored = 80f;
        [SerializeField] private float healthRestored = 20f;
        [SerializeField] private float hoursToAdvance = 6f;

        public void Configure(string name, float hours = 6f)
        {
            shelterName = name;
            hoursToAdvance = hours;
        }

        public bool CanInteract() => true;

        public string GetPromptText() => $"Pulsa [E] para descansar en {shelterName} (Restaura energía y avanza el tiempo)";

        public void Interact(PlayerInteraction2D interactor)
        {
            if (interactor == null) return;
            PlayerStats stats = interactor.GetComponent<PlayerStats>();
            if (stats == null || stats.IsDead || stats.IsFainted) return;

            // No se puede dormir con hambre o sed letales
            if (stats.CurrentHunger < 10f || stats.CurrentThirst < 10f)
            {
                GameEvents.TriggerNotificationMessage("¡Tienes demasiada hambre o sed para poder descansar!");
                return;
            }

            stats.ModifyStamina(staminaRestored);
            stats.Heal(healthRestored);
            stats.SetWetness(0f);
            stats.ModifyTemperature(2f);

            // Coste de pasar horas durmiendo
            stats.ModifyHunger(-12f);
            stats.ModifyThirst(-16f);

            // Avanzar el ciclo día/noche
            DayNightCycle dayNight = FindAnyObjectByType<DayNightCycle>();
            if (dayNight != null)
            {
                // Un avance suave de horas en el tiempo del juego
                dayNight.AdvanceTimeHours(hoursToAdvance);
            }

            if (AudioManager.Instance != null)
            {
                AudioManager.Instance.PlayRest();
            }

            GameEvents.TriggerNotificationMessage($"Has descansado en {shelterName}. ¡Energía renovada!");
        }
    }
}
