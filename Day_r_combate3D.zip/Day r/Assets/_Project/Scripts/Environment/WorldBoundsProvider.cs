﻿using UnityEngine;

namespace PirateSurvival.Environment
{
    /// <summary>
    /// Límites jugables del mundo actual. GameBootstrap los configura para la isla pequeña; el futuro
    /// WorldManager/IslandBounds/OceanManager podrá reconfigurarlos al cambiar de mapa.
    /// Si nadie lo ha configurado, Contains() acepta cualquier posición finita (no bloquea por un tamaño inventado).
    /// </summary>
    public static class WorldBoundsProvider
    {
        private static bool warnedUnconfigured;

        public static bool IsConfigured { get; private set; }
        public static Vector2 MinBounds { get; private set; }
        public static Vector2 MaxBounds { get; private set; }

        public static void Configure(Vector2 min, Vector2 max)
        {
            MinBounds = Vector2.Min(min, max);
            MaxBounds = Vector2.Max(min, max);
            IsConfigured = true;
            warnedUnconfigured = false;
        }

        public static void Clear()
        {
            IsConfigured = false;
        }

        public static bool Contains(Vector2 position)
        {
            if (!IsConfigured)
            {
                WarnOnce();
                return true;
            }
            return position.x >= MinBounds.x && position.x <= MaxBounds.x && position.y >= MinBounds.y && position.y <= MaxBounds.y;
        }

        public static Vector2 Clamp(Vector2 position)
        {
            if (!IsConfigured)
            {
                WarnOnce();
                return position;
            }
            return new Vector2(Mathf.Clamp(position.x, MinBounds.x, MaxBounds.x), Mathf.Clamp(position.y, MinBounds.y, MaxBounds.y));
        }

        private static void WarnOnce()
        {
            if (warnedUnconfigured) return;
            warnedUnconfigured = true;
            Debug.LogWarning("[WorldBoundsProvider] Límites del mundo sin configurar: no se rechazan posiciones por estar fuera del mapa.");
        }
    }
}
