﻿using System.Collections.Generic;
using UnityEngine;

namespace PirateSurvival.Environment
{
    /// <summary>
    /// Volumen de mar (trigger). Solo marca "aquí hay agua profunda"; no hace daño ni gestiona estamina.
    /// El comportamiento del jugador dentro del agua vive en PlayerSwimming. Beber es cosa de WaterSource.
    /// </summary>
    [RequireComponent(typeof(Collider2D))]
    public class SeaZone : MonoBehaviour
    {
        private static readonly List<SeaZone> ActiveZones = new List<SeaZone>();

        [Tooltip("Agua profunda: se nada y, sin fuerzas, uno se ahoga. Una charca NO debe llevar SeaZone.")]
        [SerializeField] private bool deepWater = true;

        private Collider2D zoneCollider;

        public bool DeepWater => deepWater;
        public Collider2D ZoneCollider => zoneCollider;
        public static IReadOnlyList<SeaZone> All => ActiveZones;

        private void Awake()
        {
            zoneCollider = GetComponent<Collider2D>();
            zoneCollider.isTrigger = true;
        }

        private void OnEnable()
        {
            if (!ActiveZones.Contains(this)) ActiveZones.Add(this);
        }

        private void OnDisable()
        {
            ActiveZones.Remove(this);
        }

        /// <summary>¿Este punto del mundo está dentro de agua profunda?</summary>
        public static bool IsDeepWaterAt(Vector2 point)
        {
            for (int i = 0; i < ActiveZones.Count; i++)
            {
                SeaZone z = ActiveZones[i];
                if (z != null && z.deepWater && z.zoneCollider != null && z.zoneCollider.enabled && z.zoneCollider.OverlapPoint(point))
                    return true;
            }
            return false;
        }
    }
}
