﻿namespace PirateSurvival.Environment
{
    /// <summary>Estado acuático del jugador (ver PlayerSwimming).</summary>
    public enum SeaState
    {
        OnLand,
        Swimming,
        ExhaustedSwimming,
        Drowning,
        DevilFruitWeakness
    }
}
