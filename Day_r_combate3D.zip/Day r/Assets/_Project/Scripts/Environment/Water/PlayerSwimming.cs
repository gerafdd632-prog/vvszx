﻿using UnityEngine;
using PirateSurvival.Core;
using PirateSurvival.Player;

namespace PirateSurvival.Environment
{
    /// <summary>
    /// Comportamiento acuático del jugador. Detecta si los pies están dentro de una SeaZone profunda y gestiona:
    /// nadar (gasta estamina, sin regeneración ni sprint), agotamiento, ahogamiento por ticks
    /// y la debilidad de los usuarios de Fruta del Diablo. Salir del agua cancela todo al instante.
    /// </summary>
    [RequireComponent(typeof(PlayerStats))]
    public class PlayerSwimming : MonoBehaviour
    {
        [Header("Detección")]
        [Tooltip("Punto de los pies respecto al pivote (debe coincidir con el collider del jugador)")]
        [SerializeField] private Vector2 feetOffset = new Vector2(0f, -0.2f);

        [Header("Natación normal")]
        [SerializeField] private float swimStaminaDrainPerSecond = 5f;
        [SerializeField] private float swimSpeedMultiplier = 0.6f;
        [Tooltip("Segundos sin estamina antes de empezar a ahogarse")]
        [SerializeField] private float exhaustedGraceSeconds = 3f;

        [Header("Ahogamiento (por ticks, no cada frame)")]
        [SerializeField] private float drownTickInterval = 1f;
        [SerializeField] private float drownDamagePerTick = 5f;

        [Header("Usuario de Fruta del Diablo")]
        [SerializeField] private float fruitStaminaDrainPerSecond = 35f;
        [SerializeField] private float fruitSpeedMultiplier = 0.2f;
        [Tooltip("Segundos de debilidad antes de empezar a hundirse")]
        [SerializeField] private float fruitGraceSeconds = 1.5f;
        [SerializeField] private float fruitDrownDamagePerTick = 4f;
        [Tooltip("Daño extra por cada tick seguido (daño progresivo)")]
        [SerializeField] private float fruitDrownDamageGrowth = 2f;

        private PlayerStats stats;
        private DevilFruitManager fruit;
        private float graceTimer;
        private float tickTimer;
        private int tickCount;

        public SeaState State { get; private set; } = SeaState.OnLand;
        public bool InWater => State != SeaState.OnLand;
        public bool IsSwimming => InWater;
        public bool IsDevilFruitUser => fruit != null && fruit.HasFruit;
        public bool CanSprint => State == SeaState.OnLand;
        /// <summary>En el mar un usuario de Fruta no puede usar sus poderes.</summary>
        public bool FruitPowersBlocked => InWater && IsDevilFruitUser;
        public float SpeedMultiplier => State == SeaState.OnLand ? 1f : (IsDevilFruitUser ? fruitSpeedMultiplier : swimSpeedMultiplier);

        private void Awake()
        {
            stats = GetComponent<PlayerStats>();
            fruit = GetComponent<DevilFruitManager>();
        }

        private void Start()
        {
            if (fruit == null) fruit = GetComponent<DevilFruitManager>();
        }

        private void Update()
        {
            // Pausa, menús, combate y muerte congelan el tiempo: el agua tampoco actúa
            if (stats.IsDead || !GameState.IsPlaying || Time.deltaTime <= 0f) return;

            bool inSea = SeaZone.IsDeepWaterAt((Vector2)transform.position + feetOffset);
            if (!inSea)
            {
                if (State != SeaState.OnLand) ExitWater();
                return;
            }

            if (State == SeaState.OnLand) EnterWater();

            float dt = Time.deltaTime;
            bool cursed = IsDevilFruitUser;
            stats.Soak();
            stats.ModifyStamina(-(cursed ? fruitStaminaDrainPerSecond : swimStaminaDrainPerSecond) * dt);

            // Nadador normal con fuerzas: solo nada
            if (!cursed && stats.CurrentStamina > 0.1f)
            {
                State = SeaState.Swimming;
                graceTimer = 0f;
                tickTimer = 0f;
                tickCount = 0;
                return;
            }

            if (State == SeaState.Swimming)
            {
                State = SeaState.ExhaustedSwimming;
                GameEvents.TriggerNotificationMessage("¡No te quedan fuerzas para nadar! Vuelve a tierra.");
            }

            graceTimer += dt;
            if (graceTimer < (cursed ? fruitGraceSeconds : exhaustedGraceSeconds)) return;

            if (State != SeaState.Drowning)
            {
                State = SeaState.Drowning;
                tickTimer = 0f;
                tickCount = 0;
                GameEvents.TriggerNotificationMessage(cursed ? "¡Te hundes como una piedra! ¡Sal del agua!" : "¡Te estás ahogando!");
            }

            tickTimer += dt;
            if (tickTimer < drownTickInterval) return;
            tickTimer -= drownTickInterval;
            tickCount++;
            float damage = cursed ? fruitDrownDamagePerTick + fruitDrownDamageGrowth * (tickCount - 1) : drownDamagePerTick;
            stats.TakeDamage(damage, cursed ? DeathCause.DevilFruitDrowning : DeathCause.Drowning);
        }

        /// <summary>Vuelve a "en tierra" sin avisos (reaparecer, cargar partida). El siguiente Update re-detecta el agua.</summary>
        public void ResetState()
        {
            State = SeaState.OnLand;
            graceTimer = 0f;
            tickTimer = 0f;
            tickCount = 0;
            stats.SetSwimming(false);
        }

        private void EnterWater()
        {
            bool cursed = IsDevilFruitUser;
            State = cursed ? SeaState.DevilFruitWeakness : SeaState.Swimming;
            graceTimer = 0f;
            tickTimer = 0f;
            tickCount = 0;
            stats.SetSwimming(true);
            GameEvents.TriggerNotificationMessage(cursed
                ? "¡El mar te roba las fuerzas! Como usuario de una Fruta del Diablo no puedes nadar."
                : "Estás nadando: gasta energía. Vuelve a tierra antes de agotarte.");
        }

        private void ExitWater()
        {
            State = SeaState.OnLand;
            graceTimer = 0f;
            tickTimer = 0f;
            tickCount = 0;
            stats.SetSwimming(false);
        }
    }
}
