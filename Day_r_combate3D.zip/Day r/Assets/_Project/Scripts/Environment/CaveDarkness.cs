﻿using UnityEngine;

namespace PirateSurvival.Environment
{
    /// <summary>
    /// Velo oscuro con un hueco de luz en el centro de la cámara (donde está el jugador). Aparece con suavidad al entrar
    /// en una cueva. Va como hijo de la cámara y se escala para cubrir toda la vista con cualquier zoom.
    /// </summary>
    [RequireComponent(typeof(SpriteRenderer))]
    public class CaveDarkness : MonoBehaviour
    {
        [SerializeField] private float fadeSpeed = 1.6f;
        [SerializeField] private float maxAlpha = 0.94f;

        private SpriteRenderer sr;
        private Camera cam;
        private float alpha;

        private void Awake()
        {
            sr = GetComponent<SpriteRenderer>();
            cam = GetComponentInParent<Camera>();
            sr.color = new Color(1f, 1f, 1f, 0f);
            sr.sortingOrder = 32500; // por encima de todo el mundo; la UI va en su propio canvas
            sr.enabled = false;
        }

        private void LateUpdate()
        {
            float target = CaveZone.PlayerInside ? maxAlpha : 0f;
            alpha = Mathf.MoveTowards(alpha, target, fadeSpeed * Time.deltaTime);
            sr.enabled = alpha > 0.001f;
            if (!sr.enabled) return;
            sr.color = new Color(1f, 1f, 1f, alpha);

            if (cam != null && sr.sprite != null)
            {
                float viewH = cam.orthographicSize * 2f;
                float needed = Mathf.Max(viewH * cam.aspect, viewH) * 1.15f;
                transform.localScale = Vector3.one * (needed / sr.sprite.bounds.size.x);
            }
        }
    }
}
