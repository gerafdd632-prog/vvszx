﻿using UnityEngine;
using PirateSurvival.Player;

namespace PirateSurvival.Environment
{
    /// <summary>
    /// Vuelve el tejado o fachada de un edificio semitransparente cuando el jugador camina detrás,
    /// para que nunca quede oculto ni desorientado.
    /// </summary>
    public class RoofFadeTrigger : MonoBehaviour
    {
        private SpriteRenderer targetRenderer;
        private float targetAlpha = 1f;
        private float currentAlpha = 1f;
        private const float FadeSpeed = 6f;

        private void Awake()
        {
            targetRenderer = GetComponentInParent<SpriteRenderer>();
        }

        private void Update()
        {
            if (targetRenderer == null) return;
            if (Mathf.Abs(currentAlpha - targetAlpha) > 0.01f)
            {
                currentAlpha = Mathf.MoveTowards(currentAlpha, targetAlpha, FadeSpeed * Time.deltaTime);
                Color c = targetRenderer.color;
                c.a = currentAlpha;
                targetRenderer.color = c;
            }
        }

        private void OnTriggerEnter2D(Collider2D other)
        {
            if (other.GetComponent<PlayerController2D>() != null)
            {
                targetAlpha = 0.50f;
            }
        }

        private void OnTriggerExit2D(Collider2D other)
        {
            if (other.GetComponent<PlayerController2D>() != null)
            {
                targetAlpha = 1f;
            }
        }
    }
}
