﻿using UnityEngine;
using PirateSurvival.Player;
using PirateSurvival.Interaction;
using PirateSurvival.Core;
using PirateSurvival.Crafting;

namespace PirateSurvival.Environment
{
    /// <summary>
    /// Hoguera (o antorcha): alterna dos sprites de llama, hace parpadear un halo de luz y,
    /// si 'warmthRadius' > 0, calienta y seca al jugador que está cerca (PlayerStats.SetNearFire)
    /// y permite cocinar y descansar con [E].
    /// </summary>
    public class Campfire : MonoBehaviour, IInteractable
    {
        [SerializeField] private SpriteRenderer flame;
        [SerializeField] private Sprite[] flameFrames;
        [SerializeField] private SpriteRenderer glow;
        [SerializeField] private float frameTime = 0.18f;
        [SerializeField] private float warmthRadius = 2.2f;
        [SerializeField] private float warmth = 20f;

        private float timer;
        private int frame;
        private PlayerStats warmedPlayer;
        private float seed;
        private Vector3 glowBaseScale = Vector3.one;

        public void Configure(SpriteRenderer flameRenderer, Sprite[] frames, SpriteRenderer glowRenderer, float radius)
        {
            flame = flameRenderer;
            flameFrames = frames;
            glow = glowRenderer;
            warmthRadius = radius;
            if (glow != null) glowBaseScale = glow.transform.localScale;
        }

        private void Awake()
        {
            seed = Random.value * 10f;
        }

        private void Update()
        {
            timer += Time.deltaTime;
            if (flame != null && flameFrames != null && flameFrames.Length > 0 && timer >= frameTime)
            {
                timer = 0f;
                frame = (frame + 1) % flameFrames.Length;
                flame.sprite = flameFrames[frame];
            }

            if (glow != null)
            {
                float f = 0.85f + Mathf.PerlinNoise(Time.time * 3f, seed) * 0.3f;
                glow.transform.localScale = glowBaseScale * f;
            }

            if (warmthRadius > 0f) UpdateWarmth();
        }

        private void UpdateWarmth()
        {
            if (warmedPlayer == null)
            {
                warmedPlayer = FindAnyObjectByType<PlayerStats>();
                if (warmedPlayer == null) return;
            }
            bool near = Vector2.Distance(warmedPlayer.transform.position, transform.position) <= warmthRadius;
            if (near != isWarming)
            {
                isWarming = near;
                warmedPlayer.SetNearFire(near, warmth);
            }
        }

        private bool isWarming;

        private void OnDisable()
        {
            if (isWarming && warmedPlayer != null) warmedPlayer.SetNearFire(false);
            isWarming = false;
        }

        // ================================================================ IInteractable

        public bool CanInteract() => warmthRadius > 0f;

        public string GetPromptText() => warmthRadius > 0f ? "Pulsa [E] para usar la Hoguera (Cocinar / Descansar)" : string.Empty;

        public void Interact(PlayerInteraction2D interactor)
        {
            if (warmthRadius <= 0f) return;

            if (interactor != null)
            {
                PlayerStats stats = interactor.GetComponent<PlayerStats>();
                if (stats != null)
                {
                    stats.ModifyStamina(35f);
                    stats.SetWetness(0f);
                    stats.ModifyTemperature(1.5f);
                }
            }

            if (AudioManager.Instance != null)
            {
                AudioManager.Instance.PlayRest();
            }

            GameEvents.TriggerNotificationMessage("Te calientas junto al fuego (+Energía). Abriendo cocina...");

            if (PirateSurvival.Inventory.UI.InventoryUI.Instance != null)
            {
                PirateSurvival.Inventory.UI.InventoryUI.Instance.OpenCrafting(RecipeCategory.Cocina);
            }
        }
    }
}
