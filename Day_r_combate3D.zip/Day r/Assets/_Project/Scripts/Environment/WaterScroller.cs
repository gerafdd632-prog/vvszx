﻿using UnityEngine;

namespace PirateSurvival.Environment
{
    /// <summary>
    /// Anima el mar desplazando lentamente un SpriteRenderer en mosaico (drawMode Tiled).
    /// Se mueve en bucle una losa entera, así nunca se ven bordes. Sin coste de físicas ni de texturas.
    /// </summary>
    public class WaterScroller : MonoBehaviour
    {
        [SerializeField] private float tileSize = 2f;
        [SerializeField] private Vector2 speed = new Vector2(0.18f, 0.07f);

        private Vector3 origin;
        private Vector2 offset;

        private void Start()
        {
            origin = transform.position;
        }

        private void Update()
        {
            offset += speed * Time.deltaTime;
            offset.x = Mathf.Repeat(offset.x, tileSize);
            offset.y = Mathf.Repeat(offset.y, tileSize);
            transform.position = origin + (Vector3)offset;
        }
    }
}
