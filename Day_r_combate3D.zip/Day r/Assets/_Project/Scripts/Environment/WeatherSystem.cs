﻿using UnityEngine;
using PirateSurvival.Core;
using PirateSurvival.Player;

namespace PirateSurvival.Environment
{
    /// <summary>
    /// Sistema de clima en 2D sin dependencias de paquetes externos (Item F).
    /// Crea el sistema de partículas 2D de lluvia por código si no existe,
    /// lo mantiene siguiendo a la cámara y modula la humedad corporal y el enfriamiento ambiental.
    /// </summary>
    public class WeatherSystem : MonoBehaviour
    {
        [Header("Estado del Clima")]
        [SerializeField] private WeatherType currentWeather = WeatherType.Clear;
        [SerializeField] private float weatherCheckInterval = 180f;

        [Header("Efectos de Lluvia 2D (Item F)")]
        [SerializeField] private ParticleSystem rainParticles2D;
        [SerializeField] private float clearRainRate = 0f;
        [SerializeField] private float rainEmissionRate = 220f;
        [SerializeField] private float stormEmissionRate = 500f;
        [SerializeField] private float transitionSpeed = 160f;

        [Header("Audio")]
        [SerializeField] private AudioSource rainAudioSource;
        [SerializeField] private float maxAudioVolume = 0.75f;

        [Header("Modificadores Térmicos (°C)")]
        [SerializeField] private float rainTempDrop = -6f;
        [SerializeField] private float stormTempDrop = -11f;

        private float currentTempOffset = 0f;
        private float targetEmission = 0f;
        private float currentEmission = 0f;
        private float targetVolume = 0f;
        private float timer = 0f;

        private PlayerStats playerStats;
        private Camera mainCamera;

        public WeatherType CurrentWeather => currentWeather;
        public float CurrentTemperatureOffset => currentTempOffset;
        public float WeatherTimer => timer;

        private void Awake()
        {
            playerStats = FindFirstObjectByType<PlayerStats>();
            mainCamera = Camera.main;

            EnsureProceduralRainParticles();
        }

        private void Start()
        {
            EnsureProceduralRainParticles();
            ApplyWeather(currentWeather, immediate: true);
            GameEvents.TriggerWeatherChanged(currentWeather.ToString());
        }

        private void EnsureProceduralRainParticles()
        {
            // Item F: Si no hay ParticleSystem asignado, construirlo por código
            if (rainParticles2D == null)
            {
                Transform existingChild = transform.Find("ProceduralRain2D");
                if (existingChild != null)
                {
                    rainParticles2D = existingChild.GetComponent<ParticleSystem>();
                }
                else
                {
                    GameObject rainObj = new GameObject("ProceduralRain2D");
                    rainObj.transform.SetParent(transform, false);

                    rainParticles2D = rainObj.AddComponent<ParticleSystem>();
                    var main = rainParticles2D.main;
                    main.loop = true;
                    main.playOnAwake = false;
                    main.startLifetime = 1.0f;
                    main.startSpeed = 16f;
                    main.startSize = 0.12f;
                    main.startColor = new Color(0.7f, 0.85f, 1f, 0.75f);
                    main.simulationSpace = ParticleSystemSimulationSpace.World;

                    var emission = rainParticles2D.emission;
                    emission.rateOverTime = 0f;

                    var shape = rainParticles2D.shape;
                    shape.shapeType = ParticleSystemShapeType.Box;
                    shape.scale = new Vector3(25f, 1f, 0f);
                    shape.rotation = new Vector3(0f, 0f, 0f);

                    // Orientar partículas hacia abajo y ligeramente a la izquierda
                    var velocity = rainParticles2D.velocityOverLifetime;
                    velocity.enabled = true;
                    velocity.x = -3f;
                    velocity.y = -15f;
                    velocity.z = 0f;

                    // Material por defecto compatible con cualquier render pipeline
                    var renderer = rainObj.GetComponent<ParticleSystemRenderer>();
                    if (renderer != null)
                    {
                        renderer.sortingOrder = 30000;
                        GameObject tempSprite = new GameObject("TempSprite");
                        SpriteRenderer sr = tempSprite.AddComponent<SpriteRenderer>();
                        renderer.sharedMaterial = sr.sharedMaterial;
                        Destroy(tempSprite);
                    }
                }
            }
        }

        private void Update()
        {
            timer += Time.deltaTime;
            if (timer >= weatherCheckInterval)
            {
                timer = 0f;
                ChooseRandomWeather();
            }

            UpdateSmoothTransitions();
            ApplyWetnessToPlayer();
        }

        private void LateUpdate()
        {
            // El emisor de lluvia sigue a la cámara en el plano superior
            if (rainParticles2D != null)
            {
                if (mainCamera == null) mainCamera = Camera.main;
                if (mainCamera != null)
                {
                    Vector3 camPos = mainCamera.transform.position;
                    rainParticles2D.transform.position = new Vector3(camPos.x + 2f, camPos.y + 7.5f, 0f);
                }
            }
        }

        private void ChooseRandomWeather()
        {
            WeatherType nextWeather;
            do
            {
                int roll = Random.Range(0, 100);
                if (roll < 55) nextWeather = WeatherType.Clear;
                else if (roll < 85) nextWeather = WeatherType.Rain;
                else nextWeather = WeatherType.Storm;
            }
            while (nextWeather == currentWeather);

            SetWeather(nextWeather);
        }

        public void SetWeather(WeatherType newWeather)
        {
            currentWeather = newWeather;
            ApplyWeather(newWeather, immediate: false);
            GameEvents.TriggerWeatherChanged(newWeather.ToString());
        }

        private void ApplyWeather(WeatherType weather, bool immediate)
        {
            switch (weather)
            {
                case WeatherType.Clear:
                    targetEmission = clearRainRate;
                    targetVolume = 0f;
                    currentTempOffset = 0f;
                    break;
                case WeatherType.Rain:
                    targetEmission = rainEmissionRate;
                    targetVolume = maxAudioVolume * 0.6f;
                    currentTempOffset = rainTempDrop;
                    break;
                case WeatherType.Storm:
                    targetEmission = stormEmissionRate;
                    targetVolume = maxAudioVolume;
                    currentTempOffset = stormTempDrop;
                    break;
            }

            if (immediate)
            {
                currentEmission = targetEmission;
                SetParticleEmission(currentEmission);

                if (rainAudioSource != null)
                {
                    rainAudioSource.volume = targetVolume;
                    if (targetVolume > 0 && !rainAudioSource.isPlaying) rainAudioSource.Play();
                    else if (targetVolume <= 0) rainAudioSource.Stop();
                }
            }
        }

        private void UpdateSmoothTransitions()
        {
            if (rainParticles2D != null)
            {
                currentEmission = Mathf.MoveTowards(currentEmission, targetEmission, transitionSpeed * Time.deltaTime);
                SetParticleEmission(currentEmission);
            }

            if (rainAudioSource != null)
            {
                rainAudioSource.volume = Mathf.MoveTowards(rainAudioSource.volume, targetVolume, 0.35f * Time.deltaTime);
                if (rainAudioSource.volume > 0.01f && !rainAudioSource.isPlaying)
                {
                    rainAudioSource.Play();
                }
                else if (rainAudioSource.volume <= 0.01f && rainAudioSource.isPlaying)
                {
                    rainAudioSource.Stop();
                }
            }
        }

        private void SetParticleEmission(float rate)
        {
            if (rainParticles2D == null) return;

            var emission = rainParticles2D.emission;
            emission.rateOverTime = rate;

            if (rate > 1f && !rainParticles2D.isPlaying)
            {
                rainParticles2D.Play();
            }
            else if (rate <= 0.1f && rainParticles2D.isPlaying)
            {
                rainParticles2D.Stop();
            }
        }

        private void ApplyWetnessToPlayer()
        {
            if (playerStats == null || currentWeather == WeatherType.Clear) return;

            // Los ritmos de humedad están centralizados en PlayerStats (lluvia, tormenta, mar, secado)
            playerStats.AddRainWetness(currentWeather == WeatherType.Storm, Time.deltaTime);
        }

        public void SetWeatherTimer(float newTimer)
        {
            timer = Mathf.Clamp(newTimer, 0f, weatherCheckInterval);
        }
    }
}
