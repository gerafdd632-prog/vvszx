﻿using UnityEngine;
using PirateSurvival.Player;

namespace PirateSurvival.Environment
{
    /// <summary>
    /// Interior de una cueva (círculo). Dentro, el jugador está a cubierto de la lluvia (SetSheltered)
    /// y CaveDarkness oscurece la pantalla salvo un círculo de luz a su alrededor.
    /// </summary>
    public class CaveZone : MonoBehaviour
    {
        [SerializeField] private float radius = 4.6f;

        private PlayerStats player;
        private bool inside;

        /// <summary>¿El jugador está ahora dentro de alguna cueva?</summary>
        public static bool PlayerInside { get; private set; }

        public void Configure(float zoneRadius) => radius = zoneRadius;

        private void Update()
        {
            if (player == null)
            {
                player = FindAnyObjectByType<PlayerStats>();
                if (player == null) return;
            }
            bool now = Vector2.Distance(player.transform.position, transform.position) <= radius;
            if (now == inside) return;
            inside = now;
            PlayerInside = now;
            player.SetSheltered(now);
        }

        private void OnDisable()
        {
            if (inside && player != null) player.SetSheltered(false);
            inside = false;
            PlayerInside = false;
        }
    }
}
