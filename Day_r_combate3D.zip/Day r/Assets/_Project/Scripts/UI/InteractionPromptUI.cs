﻿using UnityEngine;
using UnityEngine.UI;
using PirateSurvival.Core;

namespace PirateSurvival.UI
{
    /// <summary>
    /// Muestra u oculta en pantalla el cartel de interacción usando Text estándar (Item B).
    /// </summary>
    public class InteractionPromptUI : MonoBehaviour
    {
        [Header("Elementos de UI Estándar")]
        [SerializeField] private GameObject promptRoot;
        [SerializeField] private Text promptText;

        private void OnEnable()
        {
            GameEvents.OnInteractionPromptChanged += SetPrompt;
        }

        private void OnDisable()
        {
            GameEvents.OnInteractionPromptChanged -= SetPrompt;
        }

        private void Start()
        {
            SetPrompt(string.Empty);
        }

        private void SetPrompt(string message)
        {
            if (string.IsNullOrEmpty(message))
            {
                if (promptRoot != null) promptRoot.SetActive(false);
            }
            else
            {
                if (promptRoot != null) promptRoot.SetActive(true);
                if (promptText != null) promptText.text = message;
            }
        }
    }
}
