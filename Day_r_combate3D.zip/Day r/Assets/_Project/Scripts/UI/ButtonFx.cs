﻿using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace PirateSurvival.UI
{
    /// <summary>
    /// Respuesta visual de los botones: crecen un poco al pasar el ratón y se hunden al pulsar.
    /// Usa tiempo real (funciona con el juego en pausa) y respeta los botones desactivados.
    /// </summary>
    public class ButtonFx : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerDownHandler, IPointerUpHandler
    {
        private const float HoverScale = 1.06f;
        private const float PressScale = 0.95f;

        private Vector3 baseScale = Vector3.one;
        private float target = 1f;
        private float current = 1f;
        private bool hovering;
        private Selectable selectable;

        private void Awake()
        {
            baseScale = transform.localScale;
            selectable = GetComponent<Selectable>();
        }

        private bool Interactable => selectable == null || selectable.IsInteractable();

        public void OnPointerEnter(PointerEventData e) { hovering = true; target = Interactable ? HoverScale : 1f; }
        public void OnPointerExit(PointerEventData e) { hovering = false; target = 1f; }
        public void OnPointerDown(PointerEventData e) { if (Interactable) target = PressScale; }
        public void OnPointerUp(PointerEventData e) { target = hovering && Interactable ? HoverScale : 1f; }

        private void OnDisable()
        {
            hovering = false;
            target = current = 1f;
            transform.localScale = baseScale;
        }

        private void Update()
        {
            if (Mathf.Abs(current - target) < 0.001f) return;
            current = Mathf.MoveTowards(current, target, Time.unscaledDeltaTime * 1.2f);
            transform.localScale = baseScale * current;
        }
    }
}
