﻿using UnityEngine;
using UnityEngine.UI;
using PirateSurvival.Core;
using PirateSurvival.SaveSystem;
using PirateSurvival.Player;

namespace PirateSurvival.UI
{
    /// <summary>
    /// Gestiona todos los indicadores del HUD en 2D usando UnityEngine.UI.Text (sin TMP, Item B).
    /// Barras vitales, humedad corporal, temperatura, reloj, clima, pantalla de muerte y ayuda de controles.
    /// </summary>
    public class HUDManager : MonoBehaviour
    {
        [Header("Barras de Estado (Image FillAmount)")]
        [SerializeField] private Image healthBarFill;
        [SerializeField] private Image hungerBarFill;
        [SerializeField] private Image thirstBarFill;
        [SerializeField] private Image staminaBarFill;

        [Header("Valores Numéricos de Estado")]
        [SerializeField] private Text healthValueText;
        [SerializeField] private Text hungerValueText;
        [SerializeField] private Text thirstValueText;
        [SerializeField] private Text staminaValueText;

        [Header("Retrato y Rango")]
        [SerializeField] private Image avatarPortrait;
        [SerializeField] private Text playerTitleText;

        [Header("Alertas de Salud y Estado")]
        [SerializeField] private GameObject bleedAlertBadge;
        [SerializeField] private GameObject poisonAlertBadge;
        [SerializeField] private GameObject tempAlertBadge;
        [SerializeField] private Text tempAlertText;
        [SerializeField] private GameObject wetAlertBadge;
        [SerializeField] private Image lowHealthVignette;

        [Header("Textos de Estado Estándar")]
        [SerializeField] private Text temperatureText;
        [SerializeField] private Image temperatureIcon;
        [SerializeField] private Color coldColor = new Color(0.3f, 0.7f, 1f);
        [SerializeField] private Color normalColor = Color.white;
        [SerializeField] private Color hotColor = new Color(1f, 0.35f, 0.2f);

        [SerializeField] private Text wetnessText;
        [SerializeField] private Image wetnessBarFill;

        [Header("Reloj y Clima")]
        [SerializeField] private Text clockText;
        [SerializeField] private Text weatherText;

        [Header("Pantallas de Estado")]
        [SerializeField] private CanvasGroup faintOverlay;
        [SerializeField] private GameObject deathScreen;
        [SerializeField] private Button respawnButton;
        [SerializeField] private Button loadSaveButton;
        [SerializeField] private Button mainMenuButton;
        [Tooltip("Texto bajo '¡HAS MUERTO!' con la causa de la muerte")]
        [SerializeField] private Text deathCauseText;

        [Header("Avisos y Notificaciones (Paso 0.11)")]
        [SerializeField] private Text notificationText;
        [Tooltip("Objeto que se muestra/oculta (fondo + texto). Si es nulo se usa el propio texto.")]
        [SerializeField] private GameObject notificationRoot;
        private Coroutine notificationCoroutine;

        private float lastCurrentHealth = 100f;
        private float lastMaxHealth = 100f;
        private PlayerWounds cachedWounds;
        private PlayerStats cachedStats;
        private PlayerProgress cachedProgress;

        private void OnEnable()
        {
            GameEvents.OnHealthChanged += UpdateHealth;
            GameEvents.OnHungerChanged += UpdateHunger;
            GameEvents.OnThirstChanged += UpdateThirst;
            GameEvents.OnStaminaChanged += UpdateStamina;
            GameEvents.OnTemperatureChanged += UpdateTemperature;
            GameEvents.OnWetnessChanged += UpdateWetness;
            GameEvents.OnPlayerFaint += HandleFaintOverlay;
            GameEvents.OnPlayerDeath += HandleDeathScreen;
            GameEvents.OnTimeUpdated += UpdateClock;
            GameEvents.OnWeatherChanged += UpdateWeather;
            GameEvents.OnNotificationMessage += ShowNotification;
        }

        private void OnDisable()
        {
            GameEvents.OnHealthChanged -= UpdateHealth;
            GameEvents.OnHungerChanged -= UpdateHunger;
            GameEvents.OnThirstChanged -= UpdateThirst;
            GameEvents.OnStaminaChanged -= UpdateStamina;
            GameEvents.OnTemperatureChanged -= UpdateTemperature;
            GameEvents.OnWetnessChanged -= UpdateWetness;
            GameEvents.OnPlayerFaint -= HandleFaintOverlay;
            GameEvents.OnPlayerDeath -= HandleDeathScreen;
            GameEvents.OnTimeUpdated -= UpdateClock;
            GameEvents.OnWeatherChanged -= UpdateWeather;
            GameEvents.OnNotificationMessage -= ShowNotification;
        }

        private void Start()
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;

            if (faintOverlay != null)
            {
                faintOverlay.alpha = 0f;
                faintOverlay.gameObject.SetActive(false);
            }

            if (deathScreen != null)
            {
                deathScreen.SetActive(false);
            }

            if (respawnButton != null)
            {
                respawnButton.onClick.AddListener(OnRespawnClicked);
            }

            if (loadSaveButton != null)
            {
                loadSaveButton.onClick.AddListener(OnLoadClicked);
            }

            if (mainMenuButton != null)
            {
                mainMenuButton.onClick.AddListener(OnMainMenuClicked);
            }

            if (notificationRoot != null)
            {
                notificationRoot.SetActive(false);
            }
        }

        private void UpdateHealth(float current, float max)
        {
            lastCurrentHealth = current;
            lastMaxHealth = max;
            if (healthBarFill != null) healthBarFill.fillAmount = Mathf.Clamp01(current / Mathf.Max(1f, max));
            if (healthValueText != null) healthValueText.text = $"{Mathf.CeilToInt(current)}/{Mathf.CeilToInt(max)}";
        }

        private void UpdateHunger(float current, float max)
        {
            if (hungerBarFill != null) hungerBarFill.fillAmount = Mathf.Clamp01(current / Mathf.Max(1f, max));
            if (hungerValueText != null) hungerValueText.text = $"{Mathf.CeilToInt(current)}/{Mathf.CeilToInt(max)}";
        }

        private void UpdateThirst(float current, float max)
        {
            if (thirstBarFill != null) thirstBarFill.fillAmount = Mathf.Clamp01(current / Mathf.Max(1f, max));
            if (thirstValueText != null) thirstValueText.text = $"{Mathf.CeilToInt(current)}/{Mathf.CeilToInt(max)}";
        }

        private void UpdateStamina(float current, float max)
        {
            if (staminaBarFill != null) staminaBarFill.fillAmount = Mathf.Clamp01(current / Mathf.Max(1f, max));
            if (staminaValueText != null) staminaValueText.text = $"{Mathf.CeilToInt(current)}/{Mathf.CeilToInt(max)}";
        }

        private void Update()
        {
            if (cachedStats == null)
            {
                cachedStats = FindAnyObjectByType<PlayerStats>();
                if (cachedStats != null)
                {
                    cachedWounds = cachedStats.GetComponent<PlayerWounds>();
                    cachedProgress = cachedStats.GetComponent<PlayerProgress>();
                }
            }

            // Pulso de vida baja (< 25%)
            bool lowHealth = lastMaxHealth > 0f && (lastCurrentHealth / lastMaxHealth) <= 0.25f;
            if (lowHealth && healthBarFill != null)
            {
                float pulse = 0.65f + 0.35f * Mathf.Sin(Time.unscaledTime * 7f);
                healthBarFill.color = Color.Lerp(new Color(0.85f, 0.15f, 0.15f), new Color(1f, 0.4f, 0.4f), pulse);
                if (lowHealthVignette != null)
                {
                    if (!lowHealthVignette.gameObject.activeSelf) lowHealthVignette.gameObject.SetActive(true);
                    lowHealthVignette.color = new Color(0.7f, 0.05f, 0.05f, 0.15f + 0.12f * pulse);
                }
            }
            else
            {
                if (healthBarFill != null) healthBarFill.color = new Color(0.25f, 0.85f, 0.35f);
                if (lowHealthVignette != null && lowHealthVignette.gameObject.activeSelf)
                    lowHealthVignette.gameObject.SetActive(false);
            }

            // Alertas de heridas activas (Sangrado y Veneno)
            if (bleedAlertBadge != null)
            {
                bool bleeding = cachedWounds != null && cachedWounds.IsBleeding;
                if (bleedAlertBadge.activeSelf != bleeding) bleedAlertBadge.SetActive(bleeding);
            }

            if (poisonAlertBadge != null)
            {
                bool poisoned = cachedWounds != null && cachedWounds.IsPoisoned;
                if (poisonAlertBadge.activeSelf != poisoned) poisonAlertBadge.SetActive(poisoned);
            }

            // Alertas de temperatura extrema
            if (tempAlertBadge != null && cachedStats != null)
            {
                float temp = cachedStats.CurrentTemperature;
                bool extremeCold = temp < 34f;
                bool extremeHeat = temp > 39.5f;
                bool hasAlert = extremeCold || extremeHeat;
                if (tempAlertBadge.activeSelf != hasAlert) tempAlertBadge.SetActive(hasAlert);
                if (hasAlert && tempAlertText != null)
                {
                    tempAlertText.text = extremeCold ? "¡HIPOTERMIA!" : "¡INSOLACIÓN!";
                    tempAlertText.color = extremeCold ? new Color(0.4f, 0.85f, 1f) : new Color(1f, 0.45f, 0.2f);
                }
            }

            // Alerta de humedad alta
            if (wetAlertBadge != null && cachedStats != null)
            {
                bool soaked = cachedStats.Wetness > 0.7f;
                if (wetAlertBadge.activeSelf != soaked) wetAlertBadge.SetActive(soaked);
            }

            // Título o rango de pirata con nombre personalizado
            if (playerTitleText != null)
            {
                int b = cachedProgress != null ? cachedProgress.Bounty : 0;
                string rank = b >= 5000000 ? "Capitán Famoso" : (b > 0 ? "Pirata Novato" : "Náufrago");
                playerTitleText.text = $"{CharacterArt.PlayerName} ({rank})";
            }
        }

        /// <summary>Actualiza el retrato del avatar y el nombre del pirata en el HUD.</summary>
        public void RefreshAvatar()
        {
            if (avatarPortrait != null)
            {
                avatarPortrait.sprite = CharacterArt.GetPlayerSprite();
            }
            if (playerTitleText != null)
            {
                int b = cachedProgress != null ? cachedProgress.Bounty : 0;
                string rank = b >= 5000000 ? "Capitán Famoso" : (b > 0 ? "Pirata Novato" : "Náufrago");
                playerTitleText.text = $"{CharacterArt.PlayerName} ({rank})";
            }
        }

        private void UpdateWetness(float currentWetness)
        {
            if (wetnessBarFill != null) wetnessBarFill.fillAmount = Mathf.Clamp01(currentWetness);
            if (wetnessText != null)
            {
                int percentage = Mathf.RoundToInt(currentWetness * 100f);
                wetnessText.text = $"Humedad: {percentage}%";
            }
        }

        private void UpdateTemperature(float currentTemp)
        {
            if (temperatureText != null)
            {
                temperatureText.text = $"{currentTemp:F1}°C";
            }

            if (temperatureIcon != null)
            {
                if (currentTemp < 32f) temperatureIcon.color = coldColor;
                else if (currentTemp > 39f) temperatureIcon.color = hotColor;
                else temperatureIcon.color = normalColor;
            }
        }

        private void UpdateClock(float hour24)
        {
            if (clockText != null)
            {
                int hours = Mathf.FloorToInt(hour24);
                int minutes = Mathf.FloorToInt((hour24 - hours) * 60f);
                clockText.text = $"{hours:00}:{minutes:00}";
            }
        }

        private void UpdateWeather(string weatherName)
        {
            if (weatherText != null)
            {
                weatherText.text = weatherName switch
                {
                    "Clear" => "Soleado",
                    "Rain" => "Lluvia tropical",
                    "Storm" => "Tormenta feroz",
                    _ => weatherName
                };
            }
        }

        private void HandleFaintOverlay(bool isFainted)
        {
            if (faintOverlay != null)
            {
                faintOverlay.gameObject.SetActive(isFainted);
                faintOverlay.alpha = isFainted ? 1f : 0f;
            }
        }

        private void HandleDeathScreen()
        {
            if (deathScreen != null) deathScreen.SetActive(true);
            if (deathCauseText != null)
            {
                PlayerStats stats = FindAnyObjectByType<PlayerStats>();
                deathCauseText.text = DeathCauseText.Describe(stats != null ? stats.LastDeathCause : DeathCause.Unknown);
            }
            // Sin partidas guardadas no hay nada que cargar
            if (loadSaveButton != null)
            {
                bool hasSave = SaveManager.Instance != null && SaveManager.Instance.HasAnySave();
                loadSaveButton.interactable = hasSave;
                Text label = loadSaveButton.GetComponentInChildren<Text>();
                if (label != null) label.color = hasSave ? Color.white : new Color(1f, 1f, 1f, 0.45f);
            }
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }

        /// <summary>La pantalla de muerte está visible (la usa la auditoría técnica).</summary>
        public bool IsDeathScreenVisible => deathScreen != null && deathScreen.activeSelf;

        public void HideDeathScreen()
        {
            if (deathScreen != null) deathScreen.SetActive(false);
        }

        private void OnRespawnClicked()
        {
            if (SaveManager.Instance != null)
            {
                SaveManager.Instance.RespawnPlayer();
            }
        }

        private void OnLoadClicked()
        {
            // Carga la partida más reciente de cualquier ranura
            if (MenuManager.Instance != null)
            {
                MenuManager.Instance.ContinueLatest();
            }
            else if (SaveManager.Instance != null)
            {
                SaveManager.Instance.LoadGame();
            }
        }

        private void OnMainMenuClicked()
        {
            if (MenuManager.Instance != null)
            {
                MenuManager.Instance.ReturnToMainMenu(false);
            }
        }

        public void ShowNotification(string message)
        {
            if (notificationText == null) return;

            if (notificationCoroutine != null)
            {
                StopCoroutine(notificationCoroutine);
            }
            notificationCoroutine = StartCoroutine(NotificationRoutine(message));
        }

        private System.Collections.IEnumerator NotificationRoutine(string message)
        {
            GameObject box = notificationRoot != null ? notificationRoot : notificationText.gameObject;
            box.SetActive(true);
            notificationText.text = message;
            // Tiempo real: el aviso debe desaparecer aunque el juego esté en pausa
            // Mensajes largos (pistas) se quedan más tiempo para poder leerlos
            yield return new WaitForSecondsRealtime(Mathf.Clamp(message.Length * 0.07f, 2.5f, 7f));
            notificationText.text = string.Empty;
            box.SetActive(false);
            notificationCoroutine = null;
        }
    }
}
