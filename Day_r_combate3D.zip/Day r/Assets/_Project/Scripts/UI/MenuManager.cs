﻿using System;
using UnityEngine;
using UnityEngine.UI;
using PirateSurvival.Core;
using PirateSurvival.SaveSystem;
using PirateSurvival.Inventory.UI;
using PirateSurvival.Bootstrap;

namespace PirateSurvival.UI
{
    /// <summary>
    /// Sistema de menús: principal, pausa (ESC), ranuras de guardado/carga, opciones y confirmaciones.
    /// Se construye por código, sobrevive a la reconstrucción del mundo y funciona con Time.timeScale = 0.
    /// </summary>
    public class MenuManager : MonoBehaviour
    {
        public static MenuManager Instance { get; private set; }

        private const string KeyVolume = "opt_volume";
        private const string KeyFullscreen = "opt_fullscreen";
        private const string KeyQuality = "opt_quality";

        private GameObject root, mainPanel, pausePanel, slotsPanel, optionsPanel, confirmPanel, creationPanel;
        private Image backdrop;
        private MenuBackdrop titleScene;
        private Text tipText;
        private Button continueButton;
        private Text slotsTitle, slotsStatus, confirmText, volumeValue;
        private Button fullscreenButton, qualityButton;
        private readonly Text[] slotInfo = new Text[SaveManager.SlotCount];
        private readonly Button[] slotMain = new Button[SaveManager.SlotCount];
        private readonly Button[] slotDelete = new Button[SaveManager.SlotCount];

        private bool slotsForSaving;
        private bool playerDead;
        private Action confirmYes;
        private Button confirmYesButton, confirmNoButton;
        private bool confirmFromGameplay; // diálogo abierto sin menú detrás (p. ej. comer una Fruta)

        public static MenuManager Create()
        {
            if (Instance != null) return Instance;
            GameObject go = new GameObject("MenuSystem");
            DontDestroyOnLoad(go);
            MenuManager m = go.AddComponent<MenuManager>();
            m.Build();
            m.ApplySavedOptions();
            return m;
        }

        private void Awake() { Instance = this; }

        private void OnDestroy()
        {
            // Nunca dejar el juego bloqueado por un modal que ya no existe
            if (confirmPanel != null && confirmPanel.activeSelf) GameInput.ModalBlocked = false;
            confirmYes = null;
            confirmFromGameplay = false;
            if (Instance == this) Instance = null;
        }

        /// <summary>Hay una confirmación abierta (la usa la auditoría técnica).</summary>
        public bool IsConfirmOpen => confirmPanel != null && confirmPanel.activeSelf;

        private void OnEnable()
        {
            Core.GameEvents.OnPlayerDeath += OnDeath;
            Core.GameEvents.OnPlayerRespawn += OnRespawn;
            Core.GameEvents.OnConfirmationRequested += ShowGameplayConfirm;
        }

        private void OnDisable()
        {
            Core.GameEvents.OnPlayerDeath -= OnDeath;
            Core.GameEvents.OnPlayerRespawn -= OnRespawn;
            Core.GameEvents.OnConfirmationRequested -= ShowGameplayConfirm;
        }

        private void OnDeath()
        {
            playerDead = true;
            // Una confirmación de juego abierta se cancela al morir (no se ejecuta)
            if (confirmFromGameplay && IsConfirmOpen) HideConfirm();
        }
        private void OnRespawn() { playerDead = false; }

        // ------------------------------------------------------------ Flujo

        private void Update()
        {
            if (!GameInput.IsCancelPressed()) return;
            // ESC ya usado este frame para cerrar el inventario
            if (Time.frameCount == InventoryUI.CancelConsumedFrame) return;
            // ESC con una conversación abierta la cierra (DialogueUI) sin abrir la pausa
            if (PirateSurvival.Story.DialogueUI.IsOpen || Time.frameCount == PirateSurvival.Story.DialogueUI.CancelConsumedFrame) return;
            // ESC con una confirmación abierta = Cancelar (vuelve exactamente al estado anterior)
            if (IsConfirmOpen)
            {
                HideConfirm();
                return;
            }

            switch (GameState.Current)
            {
                case GameScreen.Dead:
                    break; // la pantalla de muerte tiene sus propios botones
                case GameScreen.Battle:
                case GameScreen.Playing:
                    bool invOpen = InventoryUI.Instance != null && InventoryUI.Instance.IsOpen;
                    if (!playerDead && !invOpen) Pause();
                    break;
                case GameScreen.Paused:
                case GameScreen.MainMenu:
                    Back();
                    break;
            }
        }

        public void ShowMain()
        {
            playerDead = false;
            GameState.Set(GameScreen.MainMenu);
            root.SetActive(true);
            CloseConfirmSilently();
            backdrop.color = UIFactory.Backdrop;
            titleScene.gameObject.SetActive(true);
            tipText.text = "Consejo: " + Tips[UnityEngine.Random.Range(0, Tips.Length)];
            UIFactory.SetButtonEnabled(continueButton, FindLatestSlot() > 0);
            Open(mainPanel);
        }

        public void Pause()
        {
            GameState.Set(GameScreen.Paused);
            root.SetActive(true);
            CloseConfirmSilently();
            backdrop.color = new Color(0.03f, 0.06f, 0.12f, 0.72f);
            titleScene.gameObject.SetActive(false); // en pausa se ve el juego detrás
            Open(pausePanel);
        }

        private void StartNewGame()
        {
            Resume();
            GameEvents.TriggerNotificationMessage("Despiertas en la playa con mucha sed. Busca la charca de agua dulce al noroeste y pulsa [E] para beber.");
        }

        public void Resume()
        {
            CloseConfirmSilently();
            root.SetActive(false);
            titleScene.gameObject.SetActive(false); // que no tape el juego si luego se abre una confirmación
            // Si la pausa se abrió en mitad de un combate, se vuelve al combate
            GameState.Set(GameState.InBattle ? GameScreen.Battle : GameScreen.Playing);
        }

        private void Back()
        {
            if (confirmPanel.activeSelf) { HideConfirm(); return; }
            if (creationPanel != null && creationPanel.activeSelf) { ShowMain(); return; }
            if (GameState.Current == GameScreen.Paused && pausePanel.activeSelf) { Resume(); return; }
            if (GameState.Current == GameScreen.MainMenu && mainPanel.activeSelf) return;
            Open(GameState.Current == GameScreen.MainMenu ? mainPanel : pausePanel);
        }

        private void Open(GameObject panel)
        {
            mainPanel.SetActive(panel == mainPanel);
            pausePanel.SetActive(panel == pausePanel);
            slotsPanel.SetActive(panel == slotsPanel);
            optionsPanel.SetActive(panel == optionsPanel);
            if (creationPanel != null) creationPanel.SetActive(panel == creationPanel);
        }

        private void OpenSlots(bool forSaving)
        {
            slotsForSaving = forSaving;
            slotsStatus.text = string.Empty;
            RefreshSlots();
            Open(slotsPanel);
        }

        public void ReturnToMainMenu(bool askConfirm = true)
        {
            if (askConfirm)
            {
                Confirm("¿Volver al menú principal?\nSe perderá el progreso no guardado.", DoReturnToMain);
            }
            else
            {
                DoReturnToMain();
            }
        }

        private void DoReturnToMain()
        {
            CloseConfirmSilently();
            GameBootstrap.RebuildWorld(ShowMain);
        }

        private void Quit()
        {
#if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
#else
            Application.Quit();
#endif
        }

        // ------------------------------------------------------- Guardado

        private int FindLatestSlot()
        {
            SaveManager sm = SaveManager.Instance;
            if (sm == null) return 0;
            int best = 0;
            string bestDate = string.Empty;
            for (int i = 1; i <= SaveManager.SlotCount; i++)
            {
                SaveSlotInfo info = sm.GetSlotInfo(i);
                // El formato yyyy-MM-dd HH:mm:ss se ordena como texto
                if (info.exists && string.CompareOrdinal(info.saveDate, bestDate) >= 0)
                {
                    best = i;
                    bestDate = info.saveDate;
                }
            }
            return best;
        }

        /// <summary>Carga la partida más reciente y reanuda. Devuelve false si no hay ninguna.</summary>
        public bool ContinueLatest()
        {
            int slot = FindLatestSlot();
            return slot > 0 && LoadSlot(slot);
        }

        private bool LoadSlot(int slot)
        {
            SaveManager sm = SaveManager.Instance;
            if (sm != null && sm.LoadGame(slot))
            {
                sm.SetActiveSlot(slot);
                Resume();
                return true;
            }
            if (slotsStatus != null) slotsStatus.text = "No se pudo cargar la ranura " + slot + ".";
            return false;
        }

        private void SaveSlot(int slot)
        {
            if (GameState.InBattle)
            {
                slotsStatus.text = "No puedes guardar durante un combate.";
                return;
            }
            SaveManager sm = SaveManager.Instance;
            if (sm != null && sm.SaveGame(slot))
            {
                sm.SetActiveSlot(slot);
                slotsStatus.text = "Partida guardada en la ranura " + slot + ".";
            }
            else
            {
                slotsStatus.text = "No se pudo guardar.";
            }
            RefreshSlots();
        }

        private void OnSlotMain(int slot)
        {
            if (!slotsForSaving) { LoadSlot(slot); return; }
            if (SaveManager.Instance.GetSlotInfo(slot).exists)
                Confirm("¿Sobrescribir la ranura " + slot + "?", () => { confirmPanel.SetActive(false); SaveSlot(slot); });
            else
                SaveSlot(slot);
        }

        private void OnSlotDelete(int slot)
        {
            Confirm("¿Borrar la ranura " + slot + "?\nEsta acción no se puede deshacer.", () =>
            {
                confirmPanel.SetActive(false);
                SaveManager.Instance.DeleteSlot(slot);
                slotsStatus.text = "Ranura " + slot + " borrada.";
                RefreshSlots();
            });
        }

        private void RefreshSlots()
        {
            SaveManager sm = SaveManager.Instance;
            slotsTitle.text = slotsForSaving ? "GUARDAR PARTIDA" : "CARGAR PARTIDA";
            for (int i = 0; i < SaveManager.SlotCount; i++)
            {
                int n = i + 1;
                SaveSlotInfo info = sm != null ? sm.GetSlotInfo(n) : default;
                string head = "Ranura " + n + (sm != null && sm.ActiveSlot == n ? "  (activa)" : "");
                if (info.exists)
                {
                    int h = Mathf.FloorToInt(info.timeOfDay);
                    int m = Mathf.FloorToInt((info.timeOfDay - h) * 60f);
                    slotInfo[i].text = $"<b>{head}</b>\n<color=#A6B8D1>{info.saveDate}    Hora {h:00}:{m:00}    Salud {info.health:0}</color>";
                }
                else
                {
                    slotInfo[i].text = $"<b>{head}</b>\n<color=#A6B8D1>Vacía</color>";
                }
                UIFactory.SetButtonLabel(slotMain[i], slotsForSaving ? (info.exists ? "Sobrescribir" : "Guardar") : "Cargar");
                UIFactory.SetButtonEnabled(slotMain[i], slotsForSaving || info.exists);
                UIFactory.SetButtonEnabled(slotDelete[i], info.exists);
            }
        }

        // ------------------------------------------------------ Confirmar

        private void Confirm(string message, Action onYes, string yesLabel = "Sí", string noLabel = "No")
        {
            confirmText.text = message;
            confirmYes = onYes;
            UIFactory.SetButtonLabel(confirmYesButton, yesLabel);
            UIFactory.SetButtonLabel(confirmNoButton, noLabel);
            confirmPanel.SetActive(true);
            confirmPanel.transform.SetAsLastSibling();
            // Modal: bloquea movimiento, interacción, inventario, zoom y guardado/carga rápidos sin tocar GameState ni timeScale
            GameInput.ModalBlocked = true;
        }

        /// <summary>Confirmación pedida desde el juego (GameEvents.RequestConfirmation) sin abrir ningún menú.</summary>
        private void ShowGameplayConfirm(string message, string yesLabel, string noLabel, Action onYes)
        {
            // Solo una confirmación a la vez: una segunda petición se ignora (nunca se ejecutan dos acciones)
            if (IsConfirmOpen)
            {
                Debug.LogWarning("[MenuManager] Ya hay una confirmación abierta: se ignora la nueva petición.");
                return;
            }
            if (playerDead || GameState.Current == GameScreen.Dead) return;
            titleScene.gameObject.SetActive(false);

            // Detener ya al jugador (velocidad residual del Rigidbody2D)
            PirateSurvival.Player.PlayerController2D player = FindFirstObjectByType<PirateSurvival.Player.PlayerController2D>();
            if (player != null) player.StopImmediately();

            if (!root.activeSelf)
            {
                confirmFromGameplay = true;
                root.SetActive(true);
                backdrop.color = Color.clear;
                Open(null);
            }
            Confirm(message, onYes, yesLabel, noLabel);
        }

        private void HideConfirm()
        {
            confirmPanel.SetActive(false);
            confirmYes = null;
            GameInput.ModalBlocked = false;
            if (confirmFromGameplay)
            {
                // El diálogo se abrió sin ningún menú detrás: cerrar también el lienzo de menús
                confirmFromGameplay = false;
                root.SetActive(false);
            }
        }

        /// <summary>Cierra la confirmación sin ejecutar nada (transiciones de menú).</summary>
        private void CloseConfirmSilently()
        {
            confirmPanel.SetActive(false);
            confirmYes = null;
            confirmFromGameplay = false;
            GameInput.ModalBlocked = false;
        }

        private void AcceptConfirm()
        {
            Action action = confirmYes;
            confirmYes = null;
            HideConfirm();
            action?.Invoke();
        }

        // -------------------------------------------------------- Opciones

        private void ApplySavedOptions()
        {
            AudioListener.volume = PlayerPrefs.GetFloat(KeyVolume, 1f);
            if (PlayerPrefs.HasKey(KeyFullscreen))
                Screen.fullScreenMode = PlayerPrefs.GetInt(KeyFullscreen) == 1 ? FullScreenMode.FullScreenWindow : FullScreenMode.Windowed;
            if (PlayerPrefs.HasKey(KeyQuality))
                QualitySettings.SetQualityLevel(Mathf.Clamp(PlayerPrefs.GetInt(KeyQuality), 0, QualitySettings.names.Length - 1));
            RefreshOptionLabels();
        }

        private void RefreshOptionLabels()
        {
            if (volumeValue == null) return;
            volumeValue.text = Mathf.RoundToInt(AudioListener.volume * 100f) + "%";
            UIFactory.SetButtonLabel(fullscreenButton, "Pantalla completa: " + (Screen.fullScreen ? "Sí" : "No"));
            string[] names = QualitySettings.names;
            UIFactory.SetButtonLabel(qualityButton, "Calidad: " + (names.Length > 0 ? names[QualitySettings.GetQualityLevel()] : "-"));
        }

        private void OnVolume(float v)
        {
            AudioListener.volume = v;
            PlayerPrefs.SetFloat(KeyVolume, v);
            RefreshOptionLabels();
        }

        private void ToggleFullscreen()
        {
            bool full = !Screen.fullScreen;
            Screen.fullScreenMode = full ? FullScreenMode.FullScreenWindow : FullScreenMode.Windowed;
            PlayerPrefs.SetInt(KeyFullscreen, full ? 1 : 0);
            // Screen.fullScreen se actualiza al frame siguiente
            UIFactory.SetButtonLabel(fullscreenButton, "Pantalla completa: " + (full ? "Sí" : "No"));
        }

        private void CycleQuality()
        {
            int count = QualitySettings.names.Length;
            if (count == 0) return;
            int next = (QualitySettings.GetQualityLevel() + 1) % count;
            QualitySettings.SetQualityLevel(next);
            PlayerPrefs.SetInt(KeyQuality, next);
            RefreshOptionLabels();
        }

        // ------------------------------------------------------ Construcción

        private void Build()
        {
            root = new GameObject("Canvas_Menus");
            root.transform.SetParent(transform, false);
            Canvas canvas = root.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 100;
            CanvasScaler scaler = root.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;
            root.AddComponent<GraphicRaycaster>();

            backdrop = UIFactory.Box(root.transform, "Backdrop", UIFactory.Backdrop, false);
            UIFactory.Stretch(backdrop.rectTransform);
            titleScene = MenuBackdrop.Create(root.transform); // escena animada del menú principal

            BuildMain();
            BuildPause();
            BuildSlots();
            BuildOptions();
            BuildConfirm();
            BuildCharacterCreator();
            root.SetActive(false);
        }

        private GameObject NewPanel(string name)
        {
            RectTransform rt = UIFactory.NewRect(name, root.transform);
            UIFactory.Stretch(rt);
            rt.gameObject.SetActive(false);
            return rt.gameObject;
        }

        /// <summary>Tarjeta de madera oscura con marco dorado y título; las coordenadas del contenido son relativas a la tarjeta.</summary>
        private RectTransform Card(GameObject panel, Vector2 size, string title)
        {
            PirateTheme.DarkPanel(panel.transform, "Card", out RectTransform card);
            UIFactory.Place(card, new Vector2(0.5f, 0.5f), Vector2.zero, size);
            Text t = PirateTheme.Title(card, title, 46);
            UIFactory.Place(t.rectTransform, new Vector2(0.5f, 1), new Vector2(0, -24), new Vector2(size.x - 40, 60));
            // Filete dorado bajo el título
            Image rule = UIFactory.Box(card, "TitleRule", new Color(0.95f, 0.75f, 0.3f, 0.7f), false);
            rule.raycastTarget = false;
            UIFactory.Place(rule.rectTransform, new Vector2(0.5f, 1), new Vector2(0, -88), new Vector2(Mathf.Min(520f, size.x - 120f), 3f));
            return card;
        }

        private RectTransform Column(Transform parent, Vector2 pos)
        {
            RectTransform rt = UIFactory.NewRect("Column", parent);
            UIFactory.Place(rt, new Vector2(0.5f, 0.5f), pos, new Vector2(420, 100));
            VerticalLayoutGroup v = rt.gameObject.AddComponent<VerticalLayoutGroup>();
            v.spacing = 14f;
            v.childAlignment = TextAnchor.UpperCenter;
            v.childControlWidth = false;
            v.childControlHeight = false;
            v.childForceExpandWidth = false;
            v.childForceExpandHeight = false;
            ContentSizeFitter f = rt.gameObject.AddComponent<ContentSizeFitter>();
            f.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
            // el contenido crece hacia abajo desde la parte superior
            rt.pivot = new Vector2(0.5f, 1f);
            rt.anchoredPosition = pos;
            return rt;
        }

        /// <summary>Botón de tablón; el color de UIFactory tiñe la madera (verde aceptar, rojo peligro...).</summary>
        private Button MenuButton(Transform parent, string label, Color color, UnityEngine.Events.UnityAction onClick)
        {
            return PirateTheme.WoodButton(parent, label, new Vector2(420, 66), Color.Lerp(Color.white, color, 0.45f), onClick, 28);
        }

        private static readonly string[] Tips =
        {
            "El agua salada da más sed. Busca charcas de agua dulce o pozos en la aldea.",
            "Recoge piedras sueltas y fibra en la orilla: con madera harás tus primeras herramientas.",
            "En la hoguera puedes cocinar carne y pescado caliente para recuperar vida y energía.",
            "Descansar en la tienda o hoguera avanza las horas de la noche y restaura tu estamina.",
            "Con [Tab] abres la mochila: inventario, recetas de fabricación, diario y cartel de Se Busca.",
            "Los atajos [1-9] te permiten equipar o consumir objetos directamente desde tu mochila.",
            "Quien come una Fruta del Diablo gana habilidades formidables, pero se ahoga en el mar.",
            "En combate táctico, las coberturas reducen el daño recibido de los tiradores.",
            "Habla con Tetsu en la herrería para aprender a fundir lingotes y forjar espadas legendarias.",
            "Explora la isla a fondo: hay cofres del tesoro enterrados con valiosos Berries."
        };

        private void BuildMain()
        {
            mainPanel = NewPanel("MainMenu");

            // Título con contorno y sombra, y cinta roja con el subtítulo
            Text titleShadow = UIFactory.Label(mainPanel.transform, "PIRATE SURVIVAL", 124, new Color(0f, 0f, 0f, 0.55f), TextAnchor.MiddleCenter, FontStyle.Bold, false);
            UIFactory.Place(titleShadow.rectTransform, new Vector2(0.5f, 1), new Vector2(8, -98), new Vector2(1600, 160));
            Text title = PirateTheme.Title(mainPanel.transform, "PIRATE SURVIVAL", 124);
            UIFactory.Place(title.rectTransform, new Vector2(0.5f, 1), new Vector2(0, -90), new Vector2(1600, 160));
            Image ribbon = UIFactory.Box(mainPanel.transform, "Ribbon", new Color(0.62f, 0.12f, 0.1f, 0.95f), false);
            ribbon.raycastTarget = false;
            UIFactory.Place(ribbon.rectTransform, new Vector2(0.5f, 1), new Vector2(0, -248), new Vector2(760, 54));
            Image ribbonEdge = UIFactory.Box(ribbon.transform, "Edge", new Color(0.95f, 0.75f, 0.3f, 0.9f), false);
            ribbonEdge.raycastTarget = false;
            UIFactory.Stretch(ribbonEdge.rectTransform, 0, 50, 0, 0);
            Text sub = UIFactory.Label(ribbon.transform, "LAS CRÓNICAS DEL EAST BLUE", 30, PirateTheme.Cream, TextAnchor.MiddleCenter, FontStyle.Bold, false);
            Outline subOutline = sub.gameObject.AddComponent<Outline>();
            subOutline.effectColor = new Color(0.2f, 0.04f, 0.02f);

            // Tablón con los botones (a la izquierda, el barco se ve a la derecha)
            RectTransform signContent = PirateTheme.DarkPanel(mainPanel.transform, "Signboard", out RectTransform sign);
            UIFactory.Place(sign, new Vector2(0.5f, 0.5f), new Vector2(-470, -110), new Vector2(520, 520));
            RectTransform col = Column(sign, new Vector2(0, 228));
            continueButton = MenuButton(col, "⚔ Continuar", UIFactory.Green, () => { if (!ContinueLatest()) ShowMain(); });
            MenuButton(col, "⚓ Nueva Partida", UIFactory.Teal, OpenCharacterCreator);
            MenuButton(col, "📜 Cargar Partida", UIFactory.Teal, () => OpenSlots(false));
            MenuButton(col, "⚙ Opciones", UIFactory.Grey, () => { RefreshOptionLabels(); Open(optionsPanel); });
            MenuButton(col, "☠ Salir", UIFactory.Red, () => Confirm("¿Salir del juego?", Quit));

            tipText = UIFactory.Label(mainPanel.transform, "", 24, PirateTheme.Cream, TextAnchor.MiddleCenter, FontStyle.Italic);
            UIFactory.Place(tipText.rectTransform, new Vector2(0.5f, 0), new Vector2(0, 40), new Vector2(1500, 40));

            Text ver = UIFactory.Label(mainPanel.transform, "v0.4 · Edición Definitiva", 18, PirateTheme.Cream, TextAnchor.LowerRight, FontStyle.Normal);
            UIFactory.Place(ver.rectTransform, new Vector2(1, 0), new Vector2(-24, 16), new Vector2(300, 28));
        }

        private void BuildPause()
        {
            pausePanel = NewPanel("PauseMenu");
            RectTransform card = Card(pausePanel, new Vector2(560, 650), "PAUSA");
            RectTransform col = Column(card, new Vector2(0, 225));
            MenuButton(col, "⚔ Reanudar", UIFactory.Green, Resume);
            MenuButton(col, "💾 Guardar Partida", UIFactory.Teal, () => OpenSlots(true));
            MenuButton(col, "📜 Cargar Partida", UIFactory.Teal, () => OpenSlots(false));
            MenuButton(col, "⚙ Opciones", UIFactory.Grey, () => { RefreshOptionLabels(); Open(optionsPanel); });
            MenuButton(col, "⚓ Menú Principal", UIFactory.Grey, () => ReturnToMainMenu(true));
            MenuButton(col, "☠ Salir del Juego", UIFactory.Red, () => Confirm("¿Salir del juego?\nSe perderá el progreso no guardado.", Quit));
        }

        private void BuildSlots()
        {
            slotsPanel = NewPanel("SlotsMenu");
            RectTransform card = Card(slotsPanel, new Vector2(960, 640), "PARTIDAS");
            slotsTitle = card.GetComponentInChildren<Text>(true); // el panel ya está oculto: incluir inactivos

            for (int i = 0; i < SaveManager.SlotCount; i++)
            {
                int n = i + 1;
                Image row = PirateTheme.Inset(card, "Row" + n);
                UIFactory.Place(row.rectTransform, new Vector2(0.5f, 1), new Vector2(0, -105 - i * 125), new Vector2(880, 110));

                Text info = UIFactory.Label(row.transform, "", 26, UIFactory.TextMain, TextAnchor.MiddleLeft, FontStyle.Normal, false);
                UIFactory.Stretch(info.rectTransform, 24, 0, 360, 0);
                slotInfo[i] = info;

                slotMain[i] = PirateTheme.WoodButton(row.transform, "Cargar", new Vector2(220, 64), Color.Lerp(Color.white, UIFactory.Teal, 0.4f), () => OnSlotMain(n), 26);
                UIFactory.Place((RectTransform)slotMain[i].transform, new Vector2(1, 0.5f), new Vector2(-100, 0), new Vector2(220, 64));
                slotDelete[i] = PirateTheme.WoodButton(row.transform, "X", new Vector2(64, 64), Color.Lerp(Color.white, UIFactory.Red, 0.5f), () => OnSlotDelete(n), 28);
                UIFactory.Place((RectTransform)slotDelete[i].transform, new Vector2(1, 0.5f), new Vector2(-20, 0), new Vector2(64, 64));
                // el botón principal queda a la izquierda del de borrar
                ((RectTransform)slotMain[i].transform).anchoredPosition = new Vector2(-104, 0);
            }

            slotsStatus = UIFactory.Label(card, "", 24, UIFactory.Gold, TextAnchor.MiddleCenter, FontStyle.Normal, false);
            UIFactory.Place(slotsStatus.rectTransform, new Vector2(0.5f, 0), new Vector2(0, 92), new Vector2(880, 34));

            Button back = PirateTheme.WoodButton(card, "Volver", new Vector2(260, 60), Back, 26);
            UIFactory.Place((RectTransform)back.transform, new Vector2(0.5f, 0), new Vector2(0, 22), new Vector2(260, 60));
        }

        private void BuildOptions()
        {
            optionsPanel = NewPanel("OptionsMenu");
            RectTransform card = Card(optionsPanel, new Vector2(1160, 640), "OPCIONES");

            Text volLabel = UIFactory.Label(card, "Volumen general", 28, UIFactory.TextMain, TextAnchor.MiddleLeft);
            UIFactory.Place(volLabel.rectTransform, new Vector2(0, 1), new Vector2(50, -120), new Vector2(480, 40));
            Slider vol = UIFactory.MakeSlider(card, new Vector2(400, 40), UIFactory.Teal, 1f, OnVolume);
            UIFactory.Place((RectTransform)vol.transform, new Vector2(0, 1), new Vector2(50, -170), new Vector2(400, 40));
            vol.SetValueWithoutNotify(PlayerPrefs.GetFloat(KeyVolume, 1f));
            volumeValue = UIFactory.Label(card, "100%", 26, UIFactory.Gold, TextAnchor.MiddleLeft, FontStyle.Bold);
            UIFactory.Place(volumeValue.rectTransform, new Vector2(0, 1), new Vector2(470, -170), new Vector2(100, 40));

            fullscreenButton = PirateTheme.WoodButton(card, "Pantalla completa", new Vector2(520, 64), ToggleFullscreen, 26);
            UIFactory.Place((RectTransform)fullscreenButton.transform, new Vector2(0, 1), new Vector2(50, -250), new Vector2(520, 64));
            qualityButton = PirateTheme.WoodButton(card, "Calidad", new Vector2(520, 64), CycleQuality, 26);
            UIFactory.Place((RectTransform)qualityButton.transform, new Vector2(0, 1), new Vector2(50, -334), new Vector2(520, 64));

            // Controles a la derecha: dos columnas con las mismas líneas para que queden alineadas
            Text ctrlTitle = UIFactory.Label(card, "Controles", 30, UIFactory.Gold, TextAnchor.MiddleLeft, FontStyle.Bold);
            UIFactory.Place(ctrlTitle.rectTransform, new Vector2(1, 1), new Vector2(-50, -110), new Vector2(460, 40));
            Text keys = UIFactory.Label(card, "WASD / Flechas\nSHIFT\nE (mantener)\nTAB / I\nShift + clic\nBotón derecho\nRueda\nF5 / F9\nESC", 22, UIFactory.TextMain, TextAnchor.UpperLeft, FontStyle.Bold, false);
            UIFactory.Place(keys.rectTransform, new Vector2(1, 1), new Vector2(-310, -160), new Vector2(190, 330));
            Text acts = UIFactory.Label(card, "Mover\nCorrer\nInteractuar / talar\nInventario\nSoltar objeto\nApuntar al cursor\nZoom\nGuardar / Cargar\nPausa / atrás", 22, UIFactory.Muted, TextAnchor.UpperLeft, FontStyle.Normal, false);
            UIFactory.Place(acts.rectTransform, new Vector2(1, 1), new Vector2(-50, -160), new Vector2(260, 330));
            keys.lineSpacing = acts.lineSpacing = 1.15f;
            
            Button back = PirateTheme.WoodButton(card, "Volver", new Vector2(260, 60), Back, 26);
            UIFactory.Place((RectTransform)back.transform, new Vector2(0.5f, 0), new Vector2(0, 22), new Vector2(260, 60));
        }

        private void BuildConfirm()
        {
            confirmPanel = NewPanel("Confirm");
            Image dim = UIFactory.Box(confirmPanel.transform, "Dim", new Color(0f, 0f, 0f, 0.55f), false);
            UIFactory.Stretch(dim.rectTransform);
            PirateTheme.DarkPanel(confirmPanel.transform, "Card", out RectTransform cardRt);
            UIFactory.Place(cardRt, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(720, 330));
            Transform card = cardRt;
            confirmText = UIFactory.Label(card, "", 32, UIFactory.TextMain);
            UIFactory.Place(confirmText.rectTransform, new Vector2(0.5f, 1), new Vector2(0, -40), new Vector2(620, 130));

            Button yes = PirateTheme.WoodButton(card, "Sí", new Vector2(240, 64), Color.Lerp(Color.white, UIFactory.Green, 0.45f), AcceptConfirm, 28);
            confirmYesButton = yes;
            UIFactory.Place((RectTransform)yes.transform, new Vector2(0.5f, 0), new Vector2(-135, 40), new Vector2(240, 64));
            Button no = PirateTheme.WoodButton(card, "No", new Vector2(240, 64), Color.Lerp(Color.white, UIFactory.Red, 0.45f), HideConfirm, 28);
            confirmNoButton = no;
            UIFactory.Place((RectTransform)no.transform, new Vector2(0.5f, 0), new Vector2(135, 40), new Vector2(240, 64));
            confirmPanel.SetActive(false);
        }

        // ------------------------------------------------ Creación de Personaje
        private InputField charNameInput;
        private Image charPreviewImage;
        private int charSkinIdx = 0;
        private int charHairColIdx = 0;
        private int charHatIdx = 1;
        private int charHatColIdx = 0;
        private int charShirtIdx = 0;
        private int charShirtColIdx = 0;
        private int charPantsIdx = 0;
        private bool charCape = false;
        private bool charSunglasses = false;
        private bool charEyepatch = false;
        private bool charBeard = false;
        private bool charLongHair = false;
        private readonly System.Collections.Generic.List<Action> charRowRefreshes = new System.Collections.Generic.List<Action>();

        public void OpenCharacterCreator()
        {
            if (charNameInput != null) charNameInput.text = CharacterArt.PlayerName;
            RefreshCharacterPreview();
            Open(creationPanel);
        }

        private CharacterLook BuildCurrentLook()
        {
            Color skin = CharacterArt.SkinOptions[Mathf.Clamp(charSkinIdx, 0, CharacterArt.SkinOptions.Length - 1)].color;
            Color hairCol = CharacterArt.HairColorOptions[Mathf.Clamp(charHairColIdx, 0, CharacterArt.HairColorOptions.Length - 1)].color;
            HatStyle hat = CharacterArt.HatOptions[Mathf.Clamp(charHatIdx, 0, CharacterArt.HatOptions.Length - 1)].style;
            Color hatCol = CharacterArt.HatColorOptions[Mathf.Clamp(charHatColIdx, 0, CharacterArt.HatColorOptions.Length - 1)].color;
            ShirtStyle shirt = CharacterArt.ShirtOptions[Mathf.Clamp(charShirtIdx, 0, CharacterArt.ShirtOptions.Length - 1)].style;
            Color shirtCol = CharacterArt.ShirtColorOptions[Mathf.Clamp(charShirtColIdx, 0, CharacterArt.ShirtColorOptions.Length - 1)].color;
            var pantsOpt = CharacterArt.PantsOptions[Mathf.Clamp(charPantsIdx, 0, CharacterArt.PantsOptions.Length - 1)];

            return new CharacterLook
            {
                skin = skin,
                hair = hairCol,
                shirt = shirtCol,
                pants = pantsOpt.color,
                shoes = new Color(0.42f, 0.28f, 0.15f),
                hatColor = hatCol,
                accent = new Color(0.85f, 0.2f, 0.2f),
                hat = hat,
                shirtStyle = shirt,
                shortPants = pantsOpt.isShort,
                cape = charCape,
                sunglasses = charSunglasses,
                eyePatch = charEyepatch,
                beard = charBeard,
                longHair = charLongHair
            };
        }

        private void RefreshCharacterPreview()
        {
            CharacterLook look = BuildCurrentLook();
            if (charPreviewImage != null)
            {
                Sprite spr = CharacterArt.Draw(look);
                charPreviewImage.sprite = spr;
            }
            for (int i = 0; i < charRowRefreshes.Count; i++) charRowRefreshes[i]?.Invoke();
        }

        private void RandomizeCharacter()
        {
            charSkinIdx = UnityEngine.Random.Range(0, CharacterArt.SkinOptions.Length);
            charHairColIdx = UnityEngine.Random.Range(0, CharacterArt.HairColorOptions.Length);
            charHatIdx = UnityEngine.Random.Range(0, CharacterArt.HatOptions.Length);
            charHatColIdx = UnityEngine.Random.Range(0, CharacterArt.HatColorOptions.Length);
            charShirtIdx = UnityEngine.Random.Range(0, CharacterArt.ShirtOptions.Length);
            charShirtColIdx = UnityEngine.Random.Range(0, CharacterArt.ShirtColorOptions.Length);
            charPantsIdx = UnityEngine.Random.Range(0, CharacterArt.PantsOptions.Length);
            charCape = UnityEngine.Random.value > 0.65f;
            charSunglasses = UnityEngine.Random.value > 0.70f;
            charEyepatch = UnityEngine.Random.value > 0.75f;
            charBeard = UnityEngine.Random.value > 0.75f;
            charLongHair = UnityEngine.Random.value > 0.50f;

            string[] names = { "Capitán Brisa", "Barbaroja el Joven", "Sal de Roca", "Kaito Marejada", "Capitana Perla", "Rui Tormenta", "Garra de Gaviota", "Coral el Audaz" };
            if (charNameInput != null) charNameInput.text = names[UnityEngine.Random.Range(0, names.Length)];

            RefreshCharacterPreview();
        }

        private void ConfirmCharacterAndStart()
        {
            string pName = charNameInput != null ? charNameInput.text.Trim() : "Náufrago";
            if (string.IsNullOrEmpty(pName)) pName = "Náufrago";
            CharacterLook look = BuildCurrentLook();
            CharacterArt.ApplyPlayerLook(look, pName);
            StartNewGame();
        }

        private void AddSelectorRow(Transform parent, Vector2 pos, string label, Func<string> getValue, Action onPrev, Action onNext)
        {
            RectTransform row = UIFactory.NewRect("Row_" + label, parent);
            UIFactory.Place(row, new Vector2(0f, 1f), pos, new Vector2(530f, 36f)); // desde el borde izquierdo de la tarjeta

            Text lbl = UIFactory.Label(row, label, 16, UIFactory.Muted, TextAnchor.MiddleLeft);
            UIFactory.Place(lbl.rectTransform, new Vector2(0f, 0.5f), new Vector2(0, 0), new Vector2(170f, 34f));

            Button prevBtn = PirateTheme.WoodButton(row, "<", new Vector2(34f, 30f), () => { onPrev(); RefreshCharacterPreview(); }, 16);
            UIFactory.Place((RectTransform)prevBtn.transform, new Vector2(0f, 0.5f), new Vector2(178f, 0), new Vector2(34f, 30f));

            Text valTxt = UIFactory.Label(row, getValue(), 15, UIFactory.Gold, TextAnchor.MiddleCenter, FontStyle.Bold);
            UIFactory.Place(valTxt.rectTransform, new Vector2(0f, 0.5f), new Vector2(216f, 0), new Vector2(240f, 34f));

            Button nextBtn = PirateTheme.WoodButton(row, ">", new Vector2(34f, 30f), () => { onNext(); RefreshCharacterPreview(); }, 16);
            UIFactory.Place((RectTransform)nextBtn.transform, new Vector2(0f, 0.5f), new Vector2(462f, 0), new Vector2(34f, 30f));

            charRowRefreshes.Add(() => { valTxt.text = getValue(); });
        }

        private void BuildCharacterCreator()
        {
            creationPanel = NewPanel("CharacterCreator");
            RectTransform card = Card(creationPanel, new Vector2(1100, 780), "CREACIÓN DE PERSONAJE");

            Text sub = UIFactory.Label(card, "Personaliza tu aspecto y nombre pirata antes de zarpar", 19, UIFactory.Muted, TextAnchor.MiddleCenter);
            UIFactory.Place(sub.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -94), new Vector2(1000, 30));

            // Columna Izquierda: Retrato en vivo, nombre y aleatorio
            Image previewBox = UIFactory.Box(card, "PreviewBorder", new Color(0.28f, 0.18f, 0.10f, 0.95f));
            UIFactory.Place(previewBox.rectTransform, new Vector2(0f, 1f), new Vector2(80, -134), new Vector2(280, 280));

            Image previewInner = UIFactory.Box(previewBox.transform, "PreviewInner", new Color(0.05f, 0.08f, 0.14f, 1f));
            UIFactory.Stretch(previewInner.rectTransform, 8, 8, 8, 8);

            charPreviewImage = UIFactory.Box(previewInner.transform, "CharAvatar", Color.white, false);
            charPreviewImage.rectTransform.sizeDelta = new Vector2(210, 210);
            UIFactory.Place(charPreviewImage.rectTransform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(210, 210));

            Text nameLbl = UIFactory.Label(card, "Nombre del Pirata:", 18, UIFactory.TextMain, TextAnchor.MiddleLeft, FontStyle.Bold);
            UIFactory.Place(nameLbl.rectTransform, new Vector2(0f, 1f), new Vector2(80, -436), new Vector2(280, 26));

            charNameInput = UIFactory.MakeInputField(card, new Vector2(280, 48), "Tu nombre pirata...", "Náufrago");
            UIFactory.Place(charNameInput.GetComponent<RectTransform>(), new Vector2(0f, 1f), new Vector2(80, -468), new Vector2(280, 48));

            Button randBtn = PirateTheme.WoodButton(card, "Aspecto Aleatorio", new Vector2(280, 46), RandomizeCharacter, 19);
            UIFactory.Place((RectTransform)randBtn.transform, new Vector2(0f, 1f), new Vector2(80, -532), new Vector2(280, 46));

            // Columna Derecha: Selectores de personalización
            charRowRefreshes.Clear();
            float startY = -136f;
            float stepY = 44f;

            AddSelectorRow(card, new Vector2(440, startY), "Tono de Piel",
                () => CharacterArt.SkinOptions[charSkinIdx].name,
                () => { charSkinIdx = (charSkinIdx - 1 + CharacterArt.SkinOptions.Length) % CharacterArt.SkinOptions.Length; },
                () => { charSkinIdx = (charSkinIdx + 1) % CharacterArt.SkinOptions.Length; });

            AddSelectorRow(card, new Vector2(440, startY - stepY * 1), "Color de Pelo",
                () => CharacterArt.HairColorOptions[charHairColIdx].name,
                () => { charHairColIdx = (charHairColIdx - 1 + CharacterArt.HairColorOptions.Length) % CharacterArt.HairColorOptions.Length; },
                () => { charHairColIdx = (charHairColIdx + 1) % CharacterArt.HairColorOptions.Length; });

            AddSelectorRow(card, new Vector2(440, startY - stepY * 2), "Peinado",
                () => charLongHair ? "Melena Larga" : "Pelo Corto",
                () => { charLongHair = !charLongHair; },
                () => { charLongHair = !charLongHair; });

            AddSelectorRow(card, new Vector2(440, startY - stepY * 3), "Sombrero / Tocado",
                () => CharacterArt.HatOptions[charHatIdx].name,
                () => { charHatIdx = (charHatIdx - 1 + CharacterArt.HatOptions.Length) % CharacterArt.HatOptions.Length; },
                () => { charHatIdx = (charHatIdx + 1) % CharacterArt.HatOptions.Length; });

            AddSelectorRow(card, new Vector2(440, startY - stepY * 4), "Color Sombrero",
                () => CharacterArt.HatColorOptions[charHatColIdx].name,
                () => { charHatColIdx = (charHatColIdx - 1 + CharacterArt.HatColorOptions.Length) % CharacterArt.HatColorOptions.Length; },
                () => { charHatColIdx = (charHatColIdx + 1) % CharacterArt.HatColorOptions.Length; });

            AddSelectorRow(card, new Vector2(440, startY - stepY * 5), "Atuendo / Camisa",
                () => CharacterArt.ShirtOptions[charShirtIdx].name,
                () => { charShirtIdx = (charShirtIdx - 1 + CharacterArt.ShirtOptions.Length) % CharacterArt.ShirtOptions.Length; },
                () => { charShirtIdx = (charShirtIdx + 1) % CharacterArt.ShirtOptions.Length; });

            AddSelectorRow(card, new Vector2(440, startY - stepY * 6), "Color Atuendo",
                () => CharacterArt.ShirtColorOptions[charShirtColIdx].name,
                () => { charShirtColIdx = (charShirtColIdx - 1 + CharacterArt.ShirtColorOptions.Length) % CharacterArt.ShirtColorOptions.Length; },
                () => { charShirtColIdx = (charShirtColIdx + 1) % CharacterArt.ShirtColorOptions.Length; });

            AddSelectorRow(card, new Vector2(440, startY - stepY * 7), "Pantalones",
                () => CharacterArt.PantsOptions[charPantsIdx].name,
                () => { charPantsIdx = (charPantsIdx - 1 + CharacterArt.PantsOptions.Length) % CharacterArt.PantsOptions.Length; },
                () => { charPantsIdx = (charPantsIdx + 1) % CharacterArt.PantsOptions.Length; });

            AddSelectorRow(card, new Vector2(440, startY - stepY * 8), "Capa de Capitán",
                () => charCape ? "Sí (Sobre hombros)" : "No",
                () => { charCape = !charCape; },
                () => { charCape = !charCape; });

            AddSelectorRow(card, new Vector2(440, startY - stepY * 9), "Gafas de Sol",
                () => charSunglasses ? "Sí (Modernas)" : "No",
                () => { charSunglasses = !charSunglasses; },
                () => { charSunglasses = !charSunglasses; });

            AddSelectorRow(card, new Vector2(440, startY - stepY * 10), "Parche Pirata",
                () => charEyepatch ? "Sí" : "No",
                () => { charEyepatch = !charEyepatch; },
                () => { charEyepatch = !charEyepatch; });

            AddSelectorRow(card, new Vector2(440, startY - stepY * 11), "Barba",
                () => charBeard ? "Sí" : "No",
                () => { charBeard = !charBeard; },
                () => { charBeard = !charBeard; });

            // Botones inferiores de confirmación y regreso
            Button backBtn = PirateTheme.WoodButton(card, "Volver", new Vector2(240, 58), ShowMain, 24);
            UIFactory.Place((RectTransform)backBtn.transform, new Vector2(0f, 0f), new Vector2(80, 28), new Vector2(240, 58));

            Button startBtn = PirateTheme.WoodButton(card, "¡ZARPAR A LA AVENTURA!", new Vector2(420, 58), Color.Lerp(Color.white, UIFactory.Green, 0.45f), ConfirmCharacterAndStart, 26);
            UIFactory.Place((RectTransform)startBtn.transform, new Vector2(1f, 0f), new Vector2(-80, 28), new Vector2(420, 58));
        }
    }
}
