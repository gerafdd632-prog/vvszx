﻿using UnityEngine;
using PirateSurvival.Core;

namespace PirateSurvival.UI
{
    /// <summary>
    /// Indicador visual flotante en 2D que se sitúa sobre el interactuable más cercano.
    /// Bug A2.I.4 resuelto: Crea un hijo visual por código y activa/desactiva ese hijo, NUNCA su propio GameObject.
    /// </summary>
    public class InteractableTargetIndicator : MonoBehaviour
    {
        [Header("Configuración Visual")]
        [Tooltip("Transform del icono o flecha indicadora (hijo visual)")]
        [SerializeField] private Transform visualChild;
        [Tooltip("Desplazamiento vertical sobre el objeto objetivo")]
        [SerializeField] private float verticalOffset = 0.9f;

        private GameObject currentTarget;

        private void Awake()
        {
            EnsureVisualChild();
        }

        private void OnEnable()
        {
            GameEvents.OnTargetInteractableChanged += HandleTargetChanged;
        }

        private void OnDisable()
        {
            GameEvents.OnTargetInteractableChanged -= HandleTargetChanged;
        }

        private void Start()
        {
            EnsureVisualChild();
            if (visualChild != null)
            {
                visualChild.gameObject.SetActive(false);
            }
        }

        private void EnsureVisualChild()
        {
            if (visualChild == null)
            {
                // Buscar hijo existente o crearlo por código
                if (transform.childCount > 0)
                {
                    visualChild = transform.GetChild(0);
                }
                else
                {
                    GameObject child = new GameObject("VisualIndicator");
                    child.transform.SetParent(transform, false);
                    SpriteRenderer sr = child.AddComponent<SpriteRenderer>();
                    sr.sortingOrder = 999;
                    sr.color = new Color(1f, 0.9f, 0.2f, 0.9f); // Amarillo dorado brillante

                    // Sprite procedural de flecha (cacheado: no se regenera al reconstruir el mundo)
                    sr.sprite = RuntimeSpriteCache.Get("target_arrow", CreateArrowSprite);

                    visualChild = child.transform;
                }
            }
        }

        private static Sprite CreateArrowSprite()
        {
            Texture2D tex = new Texture2D(16, 16, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Point;
            for (int y = 0; y < 16; y++)
            {
                for (int x = 0; x < 16; x++)
                {
                    // Punto 7: Triángulo que apunta hacia abajo con el vértice en y = 0
                    int widthAtY = y;
                    bool inside = (x >= (8 - widthAtY / 2) && x <= (8 + widthAtY / 2));
                    tex.SetPixel(x, y, inside ? Color.white : Color.clear);
                }
            }
            tex.Apply();
            return Sprite.Create(tex, new Rect(0, 0, 16, 16), new Vector2(0.5f, 0f), 16f);
        }

        private void LateUpdate()
        {
            if (currentTarget != null && visualChild != null)
            {
                // Pequeño bamboleo flotante vertical
                float bob = Mathf.Sin(Time.time * 6f) * 0.08f;
                visualChild.position = currentTarget.transform.position + new Vector3(0f, verticalOffset + bob, 0f);
            }
        }

        private void HandleTargetChanged(GameObject newTarget)
        {
            currentTarget = newTarget;
            EnsureVisualChild();

            if (visualChild != null)
            {
                visualChild.gameObject.SetActive(currentTarget != null);
                if (currentTarget != null)
                {
                    visualChild.position = currentTarget.transform.position + new Vector3(0f, verticalOffset, 0f);
                }
            }
        }
    }
}
