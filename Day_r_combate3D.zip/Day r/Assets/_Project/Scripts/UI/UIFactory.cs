﻿using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using PirateSurvival.Core;

namespace PirateSurvival.UI
{
    /// <summary>
    /// Constructor de UI por código (sin prefabs ni montaje manual): paleta, sprites redondeados,
    /// textos, botones y sliders con un estilo único para HUD, inventario y menús.
    /// </summary>
    public static class UIFactory
    {
        public static readonly Color Backdrop = new Color(0.03f, 0.06f, 0.12f, 0.90f);
        public static readonly Color Panel = new Color(0.08f, 0.13f, 0.22f, 0.96f);
        public static readonly Color PanelLight = new Color(0.14f, 0.21f, 0.34f, 1f);
        public static readonly Color HudPanel = new Color(0.04f, 0.08f, 0.15f, 0.68f);
        public static readonly Color Gold = new Color(1f, 0.82f, 0.28f);
        public static readonly Color Teal = new Color(0.16f, 0.50f, 0.72f);
        public static readonly Color Green = new Color(0.20f, 0.60f, 0.33f);
        public static readonly Color Red = new Color(0.75f, 0.20f, 0.20f);
        public static readonly Color Grey = new Color(0.30f, 0.36f, 0.46f);
        public static readonly Color TextMain = new Color(0.95f, 0.96f, 1f);
        public static readonly Color Muted = new Color(0.65f, 0.72f, 0.82f);

        private static Font font;
        private static Sprite whiteSprite;
        private static Sprite roundedSprite;

        public static Font Font
        {
            get
            {
                if (font == null)
                {
                    font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
                    if (font == null) font = Resources.GetBuiltinResource<Font>("Arial.ttf");
                }
                return font;
            }
        }

        /// <summary>Sprite blanco liso. Necesario para Image.Type.Filled (sin sprite, fillAmount se ignora).</summary>
        public static Sprite White
        {
            get
            {
                if (whiteSprite == null)
                {
                    Texture2D t = new Texture2D(4, 4, TextureFormat.RGBA32, false);
                    for (int y = 0; y < 4; y++)
                        for (int x = 0; x < 4; x++)
                            t.SetPixel(x, y, Color.white);
                    t.Apply();
                    whiteSprite = Sprite.Create(t, new Rect(0, 0, 4, 4), new Vector2(0.5f, 0.5f), 100f);
                }
                return whiteSprite;
            }
        }

        /// <summary>Rectángulo con esquinas redondeadas y antialiasing, listo para Image.Type.Sliced.</summary>
        public static Sprite Rounded
        {
            get
            {
                if (roundedSprite == null)
                {
                    const int S = 32;
                    const float R = 10f;
                    Texture2D t = new Texture2D(S, S, TextureFormat.RGBA32, false);
                    t.filterMode = FilterMode.Bilinear;
                    t.wrapMode = TextureWrapMode.Clamp;
                    for (int y = 0; y < S; y++)
                    {
                        for (int x = 0; x < S; x++)
                        {
                            float px = x + 0.5f - S / 2f;
                            float py = y + 0.5f - S / 2f;
                            float dx = Mathf.Max(Mathf.Abs(px) - (S / 2f - R), 0f);
                            float dy = Mathf.Max(Mathf.Abs(py) - (S / 2f - R), 0f);
                            float d = Mathf.Sqrt(dx * dx + dy * dy);
                            t.SetPixel(x, y, new Color(1f, 1f, 1f, Mathf.Clamp01(R - d + 0.5f)));
                        }
                    }
                    t.Apply();
                    roundedSprite = Sprite.Create(t, new Rect(0, 0, S, S), new Vector2(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect, new Vector4(12, 12, 12, 12));
                }
                return roundedSprite;
            }
        }

        public static RectTransform NewRect(string name, Transform parent)
        {
            GameObject go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            return (RectTransform)go.transform;
        }

        public static void Stretch(RectTransform r, float left = 0f, float bottom = 0f, float right = 0f, float top = 0f)
        {
            r.anchorMin = Vector2.zero;
            r.anchorMax = Vector2.one;
            r.offsetMin = new Vector2(left, bottom);
            r.offsetMax = new Vector2(-right, -top);
        }

        /// <summary>Ancla y pivote en el mismo punto (0..1), posición y tamaño absolutos.</summary>
        public static void Place(RectTransform r, Vector2 anchor, Vector2 pos, Vector2 size)
        {
            r.anchorMin = anchor;
            r.anchorMax = anchor;
            r.pivot = anchor;
            r.anchoredPosition = pos;
            r.sizeDelta = size;
        }

        public static Image Box(Transform parent, string name, Color color, bool rounded = true)
        {
            RectTransform rt = NewRect(name, parent);
            Image img = rt.gameObject.AddComponent<Image>();
            img.sprite = rounded ? Rounded : White;
            img.type = rounded ? Image.Type.Sliced : Image.Type.Simple;
            img.color = color;
            return img;
        }

        public static Text Label(Transform parent, string text, int size, Color color,
            TextAnchor align = TextAnchor.MiddleCenter, FontStyle style = FontStyle.Normal, bool shadow = true)
        {
            RectTransform rt = NewRect("Text", parent);
            Stretch(rt);
            Text t = rt.gameObject.AddComponent<Text>();
            t.font = Font;
            t.fontSize = size;
            t.fontStyle = style;
            t.text = text;
            t.color = color;
            t.alignment = align;
            t.raycastTarget = false;
            t.horizontalOverflow = HorizontalWrapMode.Wrap;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            if (shadow)
            {
                Shadow sh = rt.gameObject.AddComponent<Shadow>();
                sh.effectColor = new Color(0f, 0f, 0f, 0.65f);
                sh.effectDistance = new Vector2(1.5f, -1.5f);
            }
            return t;
        }

        public static Text Label(Transform parent, string name, string text, int size, FontStyle style, Color color)
        {
            RectTransform rt = NewRect(name, parent);
            Stretch(rt);
            Text t = rt.gameObject.AddComponent<Text>();
            t.font = Font;
            t.fontSize = size;
            t.fontStyle = style;
            t.text = text;
            t.color = color;
            t.alignment = TextAnchor.MiddleCenter;
            t.raycastTarget = false;
            t.horizontalOverflow = HorizontalWrapMode.Wrap;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            Shadow sh = rt.gameObject.AddComponent<Shadow>();
            sh.effectColor = new Color(0f, 0f, 0f, 0.65f);
            sh.effectDistance = new Vector2(1.5f, -1.5f);
            return t;
        }

        public static Button Button(Transform parent, string name, string label, Vector2 size, UnityAction onClick, Color color, int fontSize = 20)
        {
            RectTransform rt = NewRect(name, parent);
            rt.sizeDelta = size;
            Image img = rt.gameObject.AddComponent<Image>();
            img.sprite = Rounded;
            img.type = Image.Type.Sliced;
            img.color = color;
            Button btn = rt.gameObject.AddComponent<Button>();
            btn.targetGraphic = img;

            ColorBlock cb = btn.colors;
            cb.normalColor = color;
            cb.highlightedColor = Color.Lerp(color, Color.white, 0.28f);
            cb.pressedColor = Color.Lerp(color, Color.black, 0.3f);
            cb.selectedColor = color;
            cb.disabledColor = new Color(color.r * 0.45f, color.g * 0.45f, color.b * 0.45f, 0.65f);
            cb.fadeDuration = 0.08f;
            btn.colors = cb;

            Text t = Label(rt, label, fontSize, TextMain, TextAnchor.MiddleCenter, FontStyle.Bold);
            t.name = "Label";
            if (onClick != null)
            {
                btn.onClick.AddListener(() =>
                {
                    if (AudioManager.Instance != null) AudioManager.Instance.PlayUiClick();
                    onClick();
                });
            }
            return btn;
        }

        public static Button MakeButton(Transform parent, string label, Vector2 size, Color color, UnityAction onClick, int fontSize = 28)
        {
            RectTransform rt = NewRect("Btn_" + label, parent);
            rt.sizeDelta = size;
            Image img = rt.gameObject.AddComponent<Image>();
            img.sprite = Rounded;
            img.type = Image.Type.Sliced;
            Button btn = rt.gameObject.AddComponent<Button>();
            btn.targetGraphic = img;

            ColorBlock cb = btn.colors;
            cb.normalColor = color;
            cb.highlightedColor = Color.Lerp(color, Color.white, 0.28f);
            cb.pressedColor = Color.Lerp(color, Color.black, 0.3f);
            cb.selectedColor = color;
            cb.disabledColor = new Color(color.r * 0.45f, color.g * 0.45f, color.b * 0.45f, 0.65f);
            cb.fadeDuration = 0.08f;
            btn.colors = cb;

            Text t = Label(rt, label, fontSize, TextMain, TextAnchor.MiddleCenter, FontStyle.Bold);
            t.name = "Label";
            if (onClick != null)
            {
                btn.onClick.AddListener(() =>
                {
                    if (AudioManager.Instance != null) AudioManager.Instance.PlayUiClick();
                    onClick();
                });
            }
            return btn;
        }

        public static void SetButtonLabel(Button btn, string label)
        {
            Text t = btn.GetComponentInChildren<Text>(true);
            if (t != null) t.text = label;
        }

        public static void SetButtonEnabled(Button btn, bool enabled)
        {
            btn.interactable = enabled;
            Text t = btn.GetComponentInChildren<Text>(true);
            if (t != null) t.color = enabled ? TextMain : Muted;
        }

        public static Slider MakeSlider(Transform parent, Vector2 size, Color fillColor, float value, UnityAction<float> onChange)
        {
            RectTransform rt = NewRect("Slider", parent);
            rt.sizeDelta = size;

            Image bg = Box(rt, "Background", new Color(0.03f, 0.05f, 0.10f, 1f));
            bg.rectTransform.anchorMin = new Vector2(0f, 0.5f);
            bg.rectTransform.anchorMax = new Vector2(1f, 0.5f);
            bg.rectTransform.offsetMin = new Vector2(0f, -8f);
            bg.rectTransform.offsetMax = new Vector2(0f, 8f);

            RectTransform fillArea = NewRect("Fill Area", rt);
            fillArea.anchorMin = new Vector2(0f, 0.5f);
            fillArea.anchorMax = new Vector2(1f, 0.5f);
            fillArea.offsetMin = new Vector2(12f, -8f);
            fillArea.offsetMax = new Vector2(-12f, 8f);
            Image fill = Box(fillArea, "Fill", fillColor);
            Stretch(fill.rectTransform);

            RectTransform handleArea = NewRect("Handle Slide Area", rt);
            handleArea.anchorMin = Vector2.zero;
            handleArea.anchorMax = Vector2.one;
            handleArea.offsetMin = new Vector2(12f, 0f);
            handleArea.offsetMax = new Vector2(-12f, 0f);
            Image handle = Box(handleArea, "Handle", Gold);
            handle.rectTransform.sizeDelta = new Vector2(26f, 0f);

            Slider s = rt.gameObject.AddComponent<Slider>();
            s.fillRect = fill.rectTransform;
            s.handleRect = handle.rectTransform;
            s.targetGraphic = handle;
            s.direction = Slider.Direction.LeftToRight;
            s.minValue = 0f;
            s.maxValue = 1f;
            s.SetValueWithoutNotify(value);
            if (onChange != null) s.onValueChanged.AddListener(onChange);
            return s;
        }

        public static InputField MakeInputField(Transform parent, Vector2 size, string placeholderText, string defaultText)
        {
            RectTransform rt = NewRect("InputField", parent);
            rt.sizeDelta = size;
            Image bg = Box(rt, "Background", new Color(0.04f, 0.07f, 0.14f, 0.95f));
            Stretch(bg.rectTransform);

            InputField input = rt.gameObject.AddComponent<InputField>();

            Text placeholder = Label(rt, placeholderText, 20, new Color(0.5f, 0.58f, 0.7f, 0.65f), TextAnchor.MiddleLeft);
            Stretch(placeholder.rectTransform, 14, 4, 14, 4);

            Text textComp = Label(rt, defaultText, 22, TextMain, TextAnchor.MiddleLeft, FontStyle.Bold);
            Stretch(textComp.rectTransform, 14, 4, 14, 4);

            input.textComponent = textComp;
            input.placeholder = placeholder;
            input.text = defaultText;
            input.characterLimit = 22;
            input.targetGraphic = bg;
            return input;
        }
    }
}
