﻿using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using PirateSurvival.Core;

namespace PirateSurvival.UI
{
    /// <summary>
    /// Estética pirata para las ventanas grandes (mochila, fabricación, diario, diálogos):
    /// pergamino envejecido, marcos de madera con remaches dorados, botones de tablón y casillas oscuras.
    /// Todo se dibuja por código en pixel art (1 píxel de textura = 4 px de pantalla a 1080p).
    /// </summary>
    public static class PirateTheme
    {
        public static readonly Color Ink = new Color(0.22f, 0.13f, 0.07f);
        public static readonly Color InkSoft = new Color(0.38f, 0.26f, 0.15f);
        public static readonly Color GoldText = new Color(1f, 0.84f, 0.35f);
        public static readonly Color Cream = new Color(1f, 0.95f, 0.82f);
        public static readonly Color Good = new Color(0.16f, 0.5f, 0.18f);
        public static readonly Color Bad = new Color(0.72f, 0.14f, 0.1f);
        public static readonly Color SlotSelected = new Color(1f, 0.85f, 0.35f);

        private const float PixelScale = 25f; // ppu: 100 / 25 = 4 px de pantalla por píxel

        private static readonly Color Paper = new Color(0.91f, 0.82f, 0.62f);
        private static readonly Color Wood = new Color(0.45f, 0.28f, 0.15f);
        private static readonly Color WoodDark = new Color(0.27f, 0.16f, 0.08f);
        private static readonly Color WoodLight = new Color(0.62f, 0.41f, 0.22f);
        private static readonly Color Gold = new Color(0.95f, 0.75f, 0.25f);

        // ------------------------------------------------------------------ Sprites

        /// <summary>Pergamino que se repite sin costuras (64x64).</summary>
        public static Sprite Parchment() => RuntimeSpriteCache.Get("ui_parchment", () =>
        {
            const int S = 64;
            PixelCanvas c = new PixelCanvas(S, S);
            for (int y = 0; y < S; y++)
                for (int x = 0; x < S; x++)
                {
                    float n = TileNoise(x, y, S, 8, 1) * 0.6f + TileNoise(x, y, S, 16, 2) * 0.4f;
                    float k = (n - 0.5f) * 0.10f;
                    Color col = k > 0 ? Color.Lerp(Paper, new Color(0.98f, 0.94f, 0.84f), k * 1.2f) : Color.Lerp(Paper, new Color(0.82f, 0.72f, 0.52f), -k * 1.2f);
                    c.Set(x, y, col);
                }
            Sprite s = c.ToSprite(new Vector2(0.5f, 0.5f), PixelScale);
            s.texture.wrapMode = TextureWrapMode.Repeat;
            return s;
        });

        /// <summary>Marco de madera con remaches dorados (centro transparente, para Image Sliced sin relleno).</summary>
        public static Sprite WoodFrame() => RuntimeSpriteCache.Get("ui_woodframe", () =>
        {
            const int S = 24, B = 7;
            PixelCanvas c = new PixelCanvas(S, S);
            for (int y = 0; y < S; y++)
                for (int x = 0; x < S; x++)
                {
                    bool border = x < B || y < B || x >= S - B || y >= S - B;
                    if (!border) continue;
                    bool horizontal = y < B || y >= S - B;
                    int along = horizontal ? x : y;
                    int across = horizontal ? (y < B ? y : S - 1 - y) : (x < B ? x : S - 1 - x);
                    Color col = Wood;
                    if (across == 0) col = WoodDark;
                    else if (across == 1) col = WoodLight;
                    else if (across == B - 1) col = WoodDark;
                    else if ((along + across * 3) % 7 == 0) col = Color.Lerp(Wood, WoodDark, 0.5f);
                    c.Set(x, y, col);
                }
            // Remaches dorados en las esquinas
            foreach (int cx in new[] { 3, S - 4 })
                foreach (int cy in new[] { 3, S - 4 })
                {
                    c.Rect(cx - 1, cy - 1, 2, 2, Gold);
                    c.Set(cx - 1, cy, Color.Lerp(Gold, Color.white, 0.5f));
                }
            Texture2D tex = c.ToTexture();
            return Sprite.Create(tex, new Rect(0, 0, S, S), new Vector2(0.5f, 0.5f), PixelScale, 0, SpriteMeshType.FullRect, new Vector4(B, B, B, B));
        });

        /// <summary>Tablón de madera para botones.</summary>
        public static Sprite Plank() => RuntimeSpriteCache.Get("ui_plank", () =>
        {
            const int W = 24, H = 12, B = 4;
            PixelCanvas c = new PixelCanvas(W, H);
            c.Rect(0, 0, W, H, Wood);
            c.Rect(0, 0, W, 1, WoodDark); c.Rect(0, H - 1, W, 1, WoodDark);
            c.Rect(0, 0, 1, H, WoodDark); c.Rect(W - 1, 0, 1, H, WoodDark);
            c.Rect(1, H - 2, W - 2, 1, WoodLight);
            c.Rect(1, 1, W - 2, 1, Color.Lerp(Wood, WoodDark, 0.5f));
            c.Rect(5, 5, 6, 1, Color.Lerp(Wood, WoodDark, 0.35f));
            c.Rect(14, 7, 5, 1, Color.Lerp(Wood, WoodDark, 0.35f));
            c.Set(2, 2, Gold); c.Set(W - 3, 2, Gold); c.Set(2, H - 3, Gold); c.Set(W - 3, H - 3, Gold);
            Texture2D tex = c.ToTexture();
            return Sprite.Create(tex, new Rect(0, 0, W, H), new Vector2(0.5f, 0.5f), PixelScale, 0, SpriteMeshType.FullRect, new Vector4(B, B, B, B));
        });

        /// <summary>Casilla oscura hundida (huecos de la mochila, iconos).</summary>
        public static Sprite SlotFrame() => RuntimeSpriteCache.Get("ui_slot", () =>
        {
            const int S = 12, B = 3;
            PixelCanvas c = new PixelCanvas(S, S);
            c.Rect(0, 0, S, S, new Color(0.3f, 0.2f, 0.12f));
            c.Rect(1, 1, S - 2, S - 2, new Color(0.42f, 0.3f, 0.18f));
            c.Rect(2, 2, S - 4, S - 4, new Color(0.55f, 0.42f, 0.27f));
            c.Rect(1, S - 2, S - 2, 1, new Color(0.22f, 0.14f, 0.08f)); // sombra interior arriba
            Texture2D tex = c.ToTexture();
            return Sprite.Create(tex, new Rect(0, 0, S, S), new Vector2(0.5f, 0.5f), PixelScale, 0, SpriteMeshType.FullRect, new Vector4(B, B, B, B));
        });

        /// <summary>Tablones de madera oscura (bitácora del capitán) que se repiten sin costuras (64x64).</summary>
        public static Sprite DarkWood() => RuntimeSpriteCache.Get("ui_darkwood", () =>
        {
            const int S = 64;
            PixelCanvas c = new PixelCanvas(S, S);
            Color baseWood = new Color(0.2f, 0.12f, 0.07f);
            for (int y = 0; y < S; y++)
            {
                int plank = y / 16;
                for (int x = 0; x < S; x++)
                {
                    float grain = TileNoise(x, (y * 4) % S, S, 16, 3 + plank) * 0.6f + TileNoise(x, y, S, 8, 9) * 0.4f;
                    Color col = Color.Lerp(baseWood, new Color(0.3f, 0.19f, 0.1f), grain);
                    if (y % 16 == 0) col = new Color(0.1f, 0.06f, 0.03f);          // junta entre tablones
                    else if (y % 16 == 1) col = Color.Lerp(col, Color.white, 0.06f);
                    int seam = (plank * 23) % S;                                   // juntas verticales escalonadas
                    if (x == seam) col = new Color(0.12f, 0.07f, 0.04f);
                    if ((x == seam + 2 || x == seam - 3) && y % 16 == 8) col = new Color(0.55f, 0.45f, 0.3f); // clavos
                    c.Set(x, y, col);
                }
            }
            Sprite sp = c.ToSprite(new Vector2(0.5f, 0.5f), PixelScale);
            sp.texture.wrapMode = TextureWrapMode.Repeat;
            return sp;
        });

        // ------------------------------------------------------------------ Piezas

        /// <summary>
        /// Panel de madera oscura con marco y remaches dorados (menús, confirmaciones). El texto claro se lee bien encima.
        /// Devuelve el contenedor interior (con margen).
        /// </summary>
        public static RectTransform DarkPanel(Transform parent, string name, out RectTransform root)
        {
            root = UIFactory.NewRect(name, parent);
            Image shadow = UIFactory.Box(root, "Shadow", new Color(0f, 0f, 0f, 0.5f), false);
            UIFactory.Stretch(shadow.rectTransform, 12, -16, -16, 12);
            shadow.raycastTarget = false;

            Image wood = UIFactory.Box(root, "Wood", Color.white, false);
            wood.sprite = DarkWood();
            wood.type = Image.Type.Tiled;
            UIFactory.Stretch(wood.rectTransform, 12, 12, 12, 12);

            Image frame = UIFactory.Box(root, "Frame", Color.white, false);
            frame.sprite = WoodFrame();
            frame.type = Image.Type.Sliced;
            frame.fillCenter = false;
            frame.raycastTarget = false;
            UIFactory.Stretch(frame.rectTransform);

            RectTransform content = UIFactory.NewRect("Content", root);
            UIFactory.Stretch(content, 34, 34, 34, 34);
            return content;
        }

        /// <summary>Panel de pergamino con marco de madera. Devuelve el contenedor interior (con margen).</summary>
        public static RectTransform Panel(Transform parent, string name, out RectTransform root)
        {
            root = UIFactory.NewRect(name, parent);
            Image shadow = UIFactory.Box(root, "Shadow", new Color(0f, 0f, 0f, 0.45f), false);
            UIFactory.Stretch(shadow.rectTransform, 10, -14, -14, 10);
            shadow.raycastTarget = false;

            Image paper = UIFactory.Box(root, "Paper", Color.white, false);
            paper.sprite = Parchment();
            paper.type = Image.Type.Tiled;
            UIFactory.Stretch(paper.rectTransform, 12, 12, 12, 12);

            Image frame = UIFactory.Box(root, "Frame", Color.white, false);
            frame.sprite = WoodFrame();
            frame.type = Image.Type.Sliced;
            frame.fillCenter = false;
            frame.raycastTarget = false;
            UIFactory.Stretch(frame.rectTransform);

            RectTransform content = UIFactory.NewRect("Content", root);
            UIFactory.Stretch(content, 34, 34, 34, 34);
            return content;
        }

        /// <summary>Recuadro hundido (para listas e iconos) dentro de un panel.</summary>
        public static Image Inset(Transform parent, string name)
        {
            Image img = UIFactory.Box(parent, name, Color.white, false);
            img.sprite = SlotFrame();
            img.type = Image.Type.Sliced;
            return img;
        }

        public static Text Title(Transform parent, string text, int size)
        {
            Text t = UIFactory.Label(parent, text, size, GoldText, TextAnchor.MiddleCenter, FontStyle.Bold, false);
            Outline o = t.gameObject.AddComponent<Outline>();
            o.effectColor = new Color(0.2f, 0.1f, 0.04f, 1f);
            o.effectDistance = new Vector2(3f, -3f);
            return t;
        }

        public static Text InkText(Transform parent, string text, int size, TextAnchor align = TextAnchor.UpperLeft, FontStyle style = FontStyle.Normal)
        {
            return UIFactory.Label(parent, text, size, Ink, align, style, false);
        }

        /// <summary>Tablón teñido (verde = aceptar, rojo = peligro...). 'tint' blanco = madera normal.</summary>
        public static Button WoodButton(Transform parent, string label, Vector2 size, Color tint, UnityAction onClick, int fontSize = 24)
        {
            Button b = WoodButton(parent, label, size, onClick, fontSize);
            ((Image)b.targetGraphic).color = tint;
            return b;
        }

        public static Button WoodButton(Transform parent, string label, Vector2 size, UnityAction onClick, int fontSize = 24)
        {
            RectTransform rt = UIFactory.NewRect("Btn_" + label, parent);
            rt.sizeDelta = size;
            Image img = rt.gameObject.AddComponent<Image>();
            img.sprite = Plank();
            img.type = Image.Type.Sliced;
            Button b = rt.gameObject.AddComponent<Button>();
            ColorBlock cb = b.colors;
            cb.normalColor = Color.white;
            cb.highlightedColor = new Color(1.15f, 1.08f, 0.95f);
            cb.pressedColor = new Color(0.8f, 0.75f, 0.7f);
            cb.disabledColor = new Color(0.55f, 0.55f, 0.55f, 0.8f);
            cb.colorMultiplier = 1.2f;
            b.colors = cb;
            b.targetGraphic = img;
            if (onClick != null)
            {
                b.onClick.AddListener(() =>
                {
                    if (AudioManager.Instance != null) AudioManager.Instance.PlayUiClick();
                    onClick();
                });
            }
            rt.gameObject.AddComponent<ButtonFx>();
            Text t = UIFactory.Label(rt, label, fontSize, Cream, TextAnchor.MiddleCenter, FontStyle.Bold, false);
            Outline o = t.gameObject.AddComponent<Outline>();
            o.effectColor = new Color(0.15f, 0.08f, 0.03f, 1f);
            o.effectDistance = new Vector2(2f, -2f);
            return b;
        }

        /// <summary>Ruido de valor que se repite cada 'size' píxeles (para texturas en mosaico sin costuras).</summary>
        private static float TileNoise(int x, int y, int size, int cell, int seed)
        {
            int cells = Mathf.Max(1, size / cell);
            float fx = (float)x / cell, fy = (float)y / cell;
            int x0 = Mathf.FloorToInt(fx), y0 = Mathf.FloorToInt(fy);
            float tx = fx - x0, ty = fy - y0;
            tx = tx * tx * (3f - 2f * tx); ty = ty * ty * (3f - 2f * ty);
            float a = PixelCanvas.Hash(((x0 % cells) + cells) % cells, ((y0 % cells) + cells) % cells, seed);
            float b = PixelCanvas.Hash(((x0 + 1) % cells + cells) % cells, ((y0 % cells) + cells) % cells, seed);
            float c = PixelCanvas.Hash(((x0 % cells) + cells) % cells, ((y0 + 1) % cells + cells) % cells, seed);
            float d = PixelCanvas.Hash(((x0 + 1) % cells + cells) % cells, ((y0 + 1) % cells + cells) % cells, seed);
            return Mathf.Lerp(Mathf.Lerp(a, b, tx), Mathf.Lerp(c, d, tx), ty);
        }
    }
}
