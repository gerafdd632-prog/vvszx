﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using PirateSurvival.Core;
using PirateSurvival.Player;
using PirateSurvival.Inventory;
using PirateSurvival.Environment;
using PirateSurvival.Bootstrap;

namespace PirateSurvival.UI
{
    /// <summary>
    /// Menú de Administrador y Depuración abierto con [F2].
    /// Permite obtener cualquier objeto del juego, activar Modo Dios,
    /// teletransportarse a cualquier zona del mapa, modificar el clima y la hora.
    /// </summary>
    public class AdminPanelUI : MonoBehaviour
    {
        public static AdminPanelUI Instance { get; private set; }

        private enum AdminTab { Items, Cheats, Teleport, World }

        private bool isOpen = false;
        private bool isGodMode = false;
        private bool isSpeedBoost = false;
        private int selectedQty = 1;
        private ItemType? selectedTypeFilter = null;
        private AdminTab currentTab = AdminTab.Items;

        private GameObject windowRoot;
        private RectTransform contentContainer;
        private Text godModeBtnText;
        private Text speedBtnText;

        public bool IsOpen => isOpen;

        public static AdminPanelUI Create(Transform canvas)
        {
            GameObject go = new GameObject("AdminPanelUI");
            go.transform.SetParent(canvas, false);
            AdminPanelUI ui = go.AddComponent<AdminPanelUI>();
            return ui;
        }

        private void Awake()
        {
            Instance = this;
            BuildUI();
            SetOpen(false);
        }

        private void Update()
        {
            if (GameInput.IsF2Pressed())
            {
                Toggle();
            }

            if (isGodMode)
            {
                ApplyGodModeEffects();
            }
        }

        public void Toggle()
        {
            SetOpen(!isOpen);
        }

        public void SetOpen(bool open)
        {
            isOpen = open;
            if (windowRoot != null)
            {
                windowRoot.SetActive(isOpen);
            }

            if (isOpen)
            {
                RefreshCurrentTab();
                if (AudioManager.Instance != null) AudioManager.Instance.PlayUiClick();
            }
        }

        private void ApplyGodModeEffects()
        {
            PlayerStats stats = FindAnyObjectByType<PlayerStats>();
            if (stats != null)
            {
                stats.Heal(100f);
                stats.ModifyHunger(100f);
                stats.ModifyThirst(100f);
                stats.ModifyStamina(100f);
                stats.SetWetness(0f);
            }
        }

        // ================================================================ CONSTRUCCIÓN UI

        private void BuildUI()
        {
            // Panel Principal
            windowRoot = new GameObject("AdminWindow");
            windowRoot.transform.SetParent(transform, false);
            RectTransform winRect = windowRoot.AddComponent<RectTransform>();
            winRect.sizeDelta = new Vector2(860f, 580f);
            winRect.anchorMin = winRect.anchorMax = new Vector2(0.5f, 0.5f);
            winRect.pivot = new Vector2(0.5f, 0.5f);

            Image winBg = UIFactory.Box(winRect, "WinBg", new Color(0.04f, 0.07f, 0.12f, 0.98f), true);
            UIFactory.Stretch(winBg.rectTransform);

            // Cabecera
            Image header = UIFactory.Box(winRect, "Header", new Color(0.08f, 0.14f, 0.24f, 1f), true);
            header.rectTransform.anchorMin = new Vector2(0f, 1f);
            header.rectTransform.anchorMax = new Vector2(1f, 1f);
            header.rectTransform.pivot = new Vector2(0.5f, 1f);
            header.rectTransform.sizeDelta = new Vector2(0f, 50f);

            Text title = UIFactory.Label(header.transform, "Title", "⚡ MODO ADMINISTRADOR (F2) — PIRATE SURVIVAL ⚡", 18, FontStyle.Bold, UIFactory.Gold);
            title.alignment = TextAnchor.MiddleCenter;
            UIFactory.Stretch(title.rectTransform);

            Button closeBtn = UIFactory.Button(header.transform, "CloseBtn", "✕", new Vector2(36f, 36f), () => SetOpen(false), UIFactory.Red);
            closeBtn.image.rectTransform.anchorMin = closeBtn.image.rectTransform.anchorMax = new Vector2(1f, 0.5f);
            closeBtn.image.rectTransform.pivot = new Vector2(1f, 0.5f);
            closeBtn.image.rectTransform.anchoredPosition = new Vector2(-10f, 0f);

            // Barra de Pestañas
            Transform tabBar = UIFactory.NewRect("TabBar", winRect);
            RectTransform tabRect = (RectTransform)tabBar;
            tabRect.anchorMin = new Vector2(0f, 1f);
            tabRect.anchorMax = new Vector2(1f, 1f);
            tabRect.pivot = new Vector2(0.5f, 1f);
            tabRect.anchoredPosition = new Vector2(0f, -54f);
            tabRect.sizeDelta = new Vector2(-20f, 38f);

            CreateTabBtn(tabBar, "🎒 Objetos", AdminTab.Items, 0);
            CreateTabBtn(tabBar, "🛡️ Trucos & Modo Dios", AdminTab.Cheats, 1);
            CreateTabBtn(tabBar, "📍 Teletransporte", AdminTab.Teleport, 2);
            CreateTabBtn(tabBar, "☀️ Clima y Tiempo", AdminTab.World, 3);

            // Contenedor de contenido
            GameObject contentObj = new GameObject("ContentContainer");
            contentObj.transform.SetParent(winRect, false);
            contentContainer = contentObj.AddComponent<RectTransform>();
            contentContainer.anchorMin = new Vector2(0f, 0f);
            contentContainer.anchorMax = new Vector2(1f, 1f);
            contentContainer.pivot = new Vector2(0.5f, 0.5f);
            contentContainer.offsetMin = new Vector2(12f, 12f);
            contentContainer.offsetMax = new Vector2(-12f, -100f);
        }

        private void CreateTabBtn(Transform parent, string title, AdminTab tab, int index)
        {
            float width = 195f;
            float xPos = index * (width + 8f) + (width * 0.5f) - 400f;
            Button btn = UIFactory.Button(parent, "Tab_" + tab, title, new Vector2(width, 36f), () =>
            {
                currentTab = tab;
                RefreshCurrentTab();
            }, UIFactory.PanelLight);
            btn.image.rectTransform.anchoredPosition = new Vector2(xPos, 0f);
        }

        private void RefreshCurrentTab()
        {
            if (contentContainer == null) return;
            for (int i = contentContainer.childCount - 1; i >= 0; i--)
            {
                Destroy(contentContainer.GetChild(i).gameObject);
            }

            switch (currentTab)
            {
                case AdminTab.Items: BuildItemsTab(); break;
                case AdminTab.Cheats: BuildCheatsTab(); break;
                case AdminTab.Teleport: BuildTeleportTab(); break;
                case AdminTab.World: BuildWorldTab(); break;
            }
        }

        // ================================================================ PESTAÑA: OBJETOS

        private void BuildItemsTab()
        {
            // Barra superior de filtros y cantidad
            Transform filterRow = UIFactory.NewRect("FilterRow", contentContainer);
            RectTransform frRect = (RectTransform)filterRow;
            frRect.anchorMin = new Vector2(0f, 1f);
            frRect.anchorMax = new Vector2(1f, 1f);
            frRect.pivot = new Vector2(0.5f, 1f);
            frRect.sizeDelta = new Vector2(0f, 36f);

            // Botones de filtro
            CreateFilterBtn(filterRow, "Todos", null, -300f);
            CreateFilterBtn(filterRow, "Armas/Herram.", ItemType.Weapon, -210f);
            CreateFilterBtn(filterRow, "Comida", ItemType.Food, -110f);
            CreateFilterBtn(filterRow, "Medicina", ItemType.Medicine, -20f);
            CreateFilterBtn(filterRow, "Materiales", ItemType.Material, 70f);

            // Selector de Cantidad
            Text qtyLabel = UIFactory.Label(filterRow, "QtyLabel", "Cantidad:", 13, FontStyle.Bold, UIFactory.Gold);
            qtyLabel.rectTransform.anchoredPosition = new Vector2(190f, 0f);
            CreateQtyBtn(filterRow, "x1", 1, 245f);
            CreateQtyBtn(filterRow, "x5", 5, 290f);
            CreateQtyBtn(filterRow, "x20", 20, 335f);
            CreateQtyBtn(filterRow, "x50", 50, 380f);

            // ScrollView de Objetos
            GameObject scrollObj = new GameObject("ScrollView");
            scrollObj.transform.SetParent(contentContainer, false);
            RectTransform sRect = scrollObj.AddComponent<RectTransform>();
            sRect.anchorMin = new Vector2(0f, 0f);
            sRect.anchorMax = new Vector2(1f, 1f);
            sRect.offsetMin = new Vector2(0f, 0f);
            sRect.offsetMax = new Vector2(0f, -42f);

            ScrollRect scroll = scrollObj.AddComponent<ScrollRect>();
            scroll.horizontal = false;
            scroll.vertical = true;
            scroll.scrollSensitivity = 25f;

            GameObject viewPort = new GameObject("Viewport");
            viewPort.transform.SetParent(scrollObj.transform, false);
            RectTransform vpRect = viewPort.AddComponent<RectTransform>();
            UIFactory.Stretch(vpRect);
            viewPort.AddComponent<Mask>().showMaskGraphic = false;
            Image vpImage = viewPort.AddComponent<Image>();
            vpImage.color = Color.white;

            GameObject gridObj = new GameObject("Grid");
            gridObj.transform.SetParent(viewPort.transform, false);
            RectTransform gridRect = gridObj.AddComponent<RectTransform>();
            gridRect.anchorMin = new Vector2(0f, 1f);
            gridRect.anchorMax = new Vector2(1f, 1f);
            gridRect.pivot = new Vector2(0.5f, 1f);
            gridRect.sizeDelta = new Vector2(0f, 800f);

            GridLayoutGroup grid = gridObj.AddComponent<GridLayoutGroup>();
            grid.cellSize = new Vector2(265f, 52f);
            grid.spacing = new Vector2(8f, 8f);
            grid.padding = new RectOffset(6, 6, 6, 6);

            ContentSizeFitter fitter = gridObj.AddComponent<ContentSizeFitter>();
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            scroll.content = gridRect;
            scroll.viewport = vpRect;

            // Listado de objetos registrados
            var allItems = GameBootstrap.GetItemDatabase();
            if (allItems != null)
            {
                foreach (var pair in allItems)
                {
                    ItemData item = pair.Value;
                    if (item == null) continue;

                    if (selectedTypeFilter.HasValue)
                    {
                        if (selectedTypeFilter == ItemType.Weapon && (item.itemType != ItemType.Weapon && item.itemType != ItemType.Tool)) continue;
                        if (selectedTypeFilter != ItemType.Weapon && item.itemType != selectedTypeFilter.Value) continue;
                    }

                    CreateItemCard(gridObj.transform, item);
                }
            }
        }

        private void CreateFilterBtn(Transform parent, string label, ItemType? type, float x)
        {
            bool isCurrent = selectedTypeFilter == type;
            Button b = UIFactory.Button(parent, "Filt_" + label, label, new Vector2(85f, 28f), () =>
            {
                selectedTypeFilter = type;
                RefreshCurrentTab();
            }, isCurrent ? UIFactory.Teal : UIFactory.Grey);
            b.image.rectTransform.anchoredPosition = new Vector2(x, 0f);
        }

        private void CreateQtyBtn(Transform parent, string label, int qty, float x)
        {
            bool isCurrent = selectedQty == qty;
            Button b = UIFactory.Button(parent, "Qty_" + label, label, new Vector2(40f, 28f), () =>
            {
                selectedQty = qty;
                RefreshCurrentTab();
            }, isCurrent ? UIFactory.Gold : UIFactory.Grey);
            b.image.rectTransform.anchoredPosition = new Vector2(x, 0f);
        }

        private void CreateItemCard(Transform parent, ItemData item)
        {
            Image card = UIFactory.Box(parent, "Card_" + item.itemId, new Color(0.12f, 0.18f, 0.28f, 0.95f), true);

            // Icono
            if (item.icon != null)
            {
                Image icon = UIFactory.Box(card.transform, "Icon", Color.white, false);
                icon.sprite = item.icon;
                icon.rectTransform.anchorMin = icon.rectTransform.anchorMax = new Vector2(0f, 0.5f);
                icon.rectTransform.pivot = new Vector2(0f, 0.5f);
                icon.rectTransform.anchoredPosition = new Vector2(6f, 0f);
                icon.rectTransform.sizeDelta = new Vector2(40f, 40f);
            }

            // Nombre
            Text nameTxt = UIFactory.Label(card.transform, "Name", item.itemName, 12, FontStyle.Bold, Color.white);
            nameTxt.rectTransform.anchorMin = new Vector2(0f, 0.5f);
            nameTxt.rectTransform.anchorMax = new Vector2(1f, 0.5f);
            nameTxt.rectTransform.pivot = new Vector2(0f, 0.5f);
            nameTxt.rectTransform.anchoredPosition = new Vector2(52f, 0f);
            nameTxt.rectTransform.sizeDelta = new Vector2(-120f, 36f);
            nameTxt.alignment = TextAnchor.MiddleLeft;

            // Botón Obtener
            Button giveBtn = UIFactory.Button(card.transform, "GiveBtn", $"+{selectedQty}", new Vector2(58f, 34f), () =>
            {
                if (InventoryManager.Instance != null)
                {
                    InventoryManager.Instance.AddItem(item, selectedQty);
                    GameEvents.TriggerNotificationMessage($"Admin: +{selectedQty} {item.itemName}");
                    if (AudioManager.Instance != null) AudioManager.Instance.PlayCraftSuccess();
                }
            }, UIFactory.Green);
            giveBtn.image.rectTransform.anchorMin = giveBtn.image.rectTransform.anchorMax = new Vector2(1f, 0.5f);
            giveBtn.image.rectTransform.pivot = new Vector2(1f, 0.5f);
            giveBtn.image.rectTransform.anchoredPosition = new Vector2(-6f, 0f);
        }

        // ================================================================ PESTAÑA: TRUCOS Y CHEATS

        private void BuildCheatsTab()
        {
            Transform cheatsRoot = UIFactory.NewRect("CheatsRoot", contentContainer);
            RectTransform cr = (RectTransform)cheatsRoot;
            UIFactory.Stretch(cr);

            // Modo Dios Toggle
            string godText = isGodMode ? "🛡️ MODO DIOS: [ ACTIVADO ]" : "🛡️ MODO DIOS: [ DESACTIVADO ]";
            Color godColor = isGodMode ? UIFactory.Green : UIFactory.Grey;
            Button godBtn = UIFactory.Button(cheatsRoot, "GodModeBtn", godText, new Vector2(380f, 50f), () =>
            {
                isGodMode = !isGodMode;
                GameEvents.TriggerNotificationMessage(isGodMode ? "¡Modo Dios Activado! (Inmortal)" : "Modo Dios Desactivado.");
                RefreshCurrentTab();
            }, godColor);
            godBtn.image.rectTransform.anchoredPosition = new Vector2(-200f, 150f);

            // Super Velocidad Toggle
            string spdText = isSpeedBoost ? "⚡ VELOCIDAD X2.5: [ ACTIVADA ]" : "⚡ VELOCIDAD X2.5: [ DESACTIVADA ]";
            Color spdColor = isSpeedBoost ? UIFactory.Teal : UIFactory.Grey;
            Button spdBtn = UIFactory.Button(cheatsRoot, "SpeedBtn", spdText, new Vector2(380f, 50f), () =>
            {
                isSpeedBoost = !isSpeedBoost;
                ApplySpeedBoost(isSpeedBoost);
                RefreshCurrentTab();
            }, spdColor);
            spdBtn.image.rectTransform.anchoredPosition = new Vector2(200f, 150f);

            // Restaurar Todo al 100%
            Button healBtn = UIFactory.Button(cheatsRoot, "HealAllBtn", "💖 Restaurar Salud, Hambre y Sed al 100%", new Vector2(380f, 48f), () =>
            {
                PlayerStats stats = FindAnyObjectByType<PlayerStats>();
                if (stats != null)
                {
                    stats.Heal(100f);
                    stats.ModifyHunger(100f);
                    stats.ModifyThirst(100f);
                    stats.ModifyStamina(100f);
                    stats.SetWetness(0f);
                    stats.ModifyTemperature(0f);
                    GameEvents.TriggerNotificationMessage("¡Cuerpo completamente revitalizado al 100%!");
                }
            }, UIFactory.Teal);
            healBtn.image.rectTransform.anchoredPosition = new Vector2(-200f, 70f);

            // +10,000 Berries
            Button moneyBtn = UIFactory.Button(cheatsRoot, "MoneyBtn", "💰 Añadir +10.000 Berries de Fortuna", new Vector2(380f, 48f), () =>
            {
                PlayerProgress prog = FindAnyObjectByType<PlayerProgress>();
                if (prog != null)
                {
                    prog.AddPlayerBounty(10000);
                    GameEvents.TriggerNotificationMessage("¡Añadidos +10.000 Berries a tu bolsa!");
                }
            }, UIFactory.Gold);
            moneyBtn.image.rectTransform.anchoredPosition = new Vector2(200f, 70f);

            // Kit Pirata Legendario
            Button kitBtn = UIFactory.Button(cheatsRoot, "KitBtn", "🎁 Otorgar Kit Pirata de Élite Completo", new Vector2(420f, 52f), () =>
            {
                GiveElitePirateKit();
            }, UIFactory.Green);
            kitBtn.image.rectTransform.anchoredPosition = new Vector2(0f, -15f);

            // Explicación
            Text info = UIFactory.Label(cheatsRoot, "InfoText",
                "• Modo Dios: No recibes daño de ningún tipo, no tienes hambre, sed ni hipotermia/insolación.\n" +
                "• Velocidad x2.5: Te permite recorrer y explorar toda la isla rápidamente sin cansancio.",
                13, FontStyle.Italic, UIFactory.Muted);
            info.rectTransform.anchoredPosition = new Vector2(0f, -120f);
            info.alignment = TextAnchor.MiddleCenter;
        }

        private void ApplySpeedBoost(bool boost)
        {
            PlayerController2D pc = FindAnyObjectByType<PlayerController2D>();
            if (pc != null)
            {
                float baseWalk = boost ? 10f : 4f;
                float baseSprint = boost ? 16f : 6.8f;
                GameBootstrap.InjectField(pc, "walkSpeed", baseWalk);
                GameBootstrap.InjectField(pc, "sprintSpeed", baseSprint);
                GameEvents.TriggerNotificationMessage(boost ? "¡Super velocidad activada!" : "Velocidad normal restaurada.");
            }
        }

        private void GiveElitePirateKit()
        {
            var db = GameBootstrap.GetItemDatabase();
            if (db == null || InventoryManager.Instance == null) return;

            string[] kit = { "itemShiokaze", "itemTrabuco", "itemBalasPlomo", "itemBotiquin", "itemRonPirata", "itemCarneAsada", "itemSombreroPaja", "itemChalecoCuero" };
            int[] qtys = { 1, 1, 30, 3, 4, 5, 1, 1 };

            for (int i = 0; i < kit.Length; i++)
            {
                if (db.ContainsKey(kit[i]))
                {
                    InventoryManager.Instance.AddItem(db[kit[i]], qtys[i]);
                }
            }
            GameEvents.TriggerNotificationMessage("¡Has recibido el Kit Pirata de Élite!");
            if (AudioManager.Instance != null) AudioManager.Instance.PlayTreasureOpen();
        }

        // ================================================================ PESTAÑA: TELETRANSPORTE

        private void BuildTeleportTab()
        {
            Transform tpRoot = UIFactory.NewRect("TpRoot", contentContainer);
            RectTransform tr = (RectTransform)tpRoot;
            UIFactory.Stretch(tr);

            CreateTeleportBtn(tpRoot, "🏖️ Playa del Naufragio (Inicio)", IslandLayout.Spawn, -200f, 130f);
            CreateTeleportBtn(tpRoot, "🏘️ Aldea Coral (Plaza Central)", IslandLayout.Village, 200f, 130f);
            CreateTeleportBtn(tpRoot, "⚓ Muelle & Barco de Cuervo", new Vector2(17.3f, 25f), -200f, 65f);
            CreateTeleportBtn(tpRoot, "🦇 Guarida de Contrabandistas (Mina)", new Vector2(-16f, 12f), 200f, 65f);
            CreateTeleportBtn(tpRoot, "🗼 Colina del Faro (Cima)", new Vector2(-1f, 21f), -200f, 0f);
            CreateTeleportBtn(tpRoot, "🏴‍☠️ Campamento Pirata (Sureste)", new Vector2(20f, -14f), 200f, 0f);
            CreateTeleportBtn(tpRoot, "💧 Charca de Agua Dulce", IslandLayout.Pond, -200f, -65f);
            CreateTeleportBtn(tpRoot, "🌿 Bosque Oeste Profundo", new Vector2(-12f, -15f), 200f, -65f);
            CreateTeleportBtn(tpRoot, "🌋 Isla 2: Playa Ceniza (Desembarco)", Island2Layout.Dock, -200f, -130f);
            CreateTeleportBtn(tpRoot, "🌋 Isla 2: Cráter de Obsidiana", Island2Layout.Crater, 200f, -130f);
        }

        private void CreateTeleportBtn(Transform parent, string label, Vector2 targetPos, float x, float y)
        {
            Button btn = UIFactory.Button(parent, "TP_" + label, label, new Vector2(370f, 44f), () =>
            {
                PlayerController2D pc = FindAnyObjectByType<PlayerController2D>();
                if (pc != null)
                {
                    pc.transform.position = targetPos;

                    if (targetPos.x > 150f)
                    {
                        WorldBoundsProvider.Configure(Island2Layout.WorldMin, Island2Layout.WorldMax);
                    }
                    else
                    {
                        WorldBoundsProvider.Configure(
                            new Vector2(-IslandLayout.WorldHalfSize, -IslandLayout.WorldHalfSize),
                            new Vector2(IslandLayout.WorldHalfSize, IslandLayout.WorldHalfSize)
                        );
                    }

                    Camera2D cam = FindAnyObjectByType<Camera2D>();
                    if (cam != null)
                    {
                        cam.transform.position = new Vector3(targetPos.x, targetPos.y, cam.transform.position.z);
                    }

                    GameEvents.TriggerNotificationMessage($"Teletransportado a: {label}");
                    if (AudioManager.Instance != null) AudioManager.Instance.PlayUiClick();
                    SetOpen(false);
                }
            }, UIFactory.PanelLight);
            btn.image.rectTransform.anchoredPosition = new Vector2(x, y);
        }

        // ================================================================ PESTAÑA: CLIMA Y TIEMPO

        private void BuildWorldTab()
        {
            Transform worldRoot = UIFactory.NewRect("WorldRoot", contentContainer);
            RectTransform wr = (RectTransform)worldRoot;
            UIFactory.Stretch(wr);

            // Hora del Día
            Text timeTitle = UIFactory.Label(worldRoot, "TimeTitle", "⏰ Control de la Hora del Día", 16, FontStyle.Bold, UIFactory.Gold);
            timeTitle.rectTransform.anchoredPosition = new Vector2(0f, 140f);

            CreateTimeBtn(worldRoot, "🌅 06:00 (Amanecer)", 6f, -300f, 90f);
            CreateTimeBtn(worldRoot, "☀️ 12:00 (Mediodía)", 12f, -100f, 90f);
            CreateTimeBtn(worldRoot, "🌇 18:00 (Atardecer)", 18f, 100f, 90f);
            CreateTimeBtn(worldRoot, "🌙 00:00 (Medianoche)", 0f, 300f, 90f);

            // Clima
            Text weatherTitle = UIFactory.Label(worldRoot, "WeatherTitle", "🌧️ Control del Clima y la Atmósfera", 16, FontStyle.Bold, UIFactory.Gold);
            weatherTitle.rectTransform.anchoredPosition = new Vector2(0f, 10f);

            CreateWeatherBtn(worldRoot, "☀️ Despejado y Soleado", WeatherType.Clear, -200f, -45f);
            CreateWeatherBtn(worldRoot, "🌧️ Lluvia Tropical", WeatherType.Rain, 0f, -45f);
            CreateWeatherBtn(worldRoot, "⛈️ Gran Tormenta Marina", WeatherType.Storm, 200f, -45f);

            Text hint = UIFactory.Label(worldRoot, "Hint", "Cambia la hora y el clima al instante para probar los ciclos térmicos, iluminación y eventos.", 12, FontStyle.Italic, UIFactory.Muted);
            hint.rectTransform.anchoredPosition = new Vector2(0f, -120f);
        }

        private void CreateTimeBtn(Transform parent, string label, float hour, float x, float y)
        {
            Button btn = UIFactory.Button(parent, "Time_" + hour, label, new Vector2(175f, 42f), () =>
            {
                DayNightCycle dn = FindAnyObjectByType<DayNightCycle>();
                if (dn != null)
                {
                    dn.SetTimeOfDay(hour);
                    GameEvents.TriggerNotificationMessage($"Hora cambiada a: {label}");
                }
            }, UIFactory.PanelLight);
            btn.image.rectTransform.anchoredPosition = new Vector2(x, y);
        }

        private void CreateWeatherBtn(Transform parent, string label, WeatherType wType, float x, float y)
        {
            Button btn = UIFactory.Button(parent, "Weather_" + wType, label, new Vector2(185f, 42f), () =>
            {
                WeatherSystem ws = FindAnyObjectByType<WeatherSystem>();
                if (ws != null)
                {
                    ws.SetWeather(wType);
                    GameEvents.TriggerNotificationMessage($"Clima cambiado a: {label}");
                }
            }, UIFactory.Teal);
            btn.image.rectTransform.anchoredPosition = new Vector2(x, y);
        }
    }
}
