﻿using UnityEngine;
using UnityEngine.UI;
using PirateSurvival.Core;
using PirateSurvival.Bootstrap;

namespace PirateSurvival.UI
{
    /// <summary>
    /// Escena animada del menú principal: cielo de atardecer, sol, nubes, isla lejana, mar con olas
    /// en dos capas, el barco pirata meciéndose y gaviotas. Todo en UI y con tiempo real (el juego está en pausa).
    /// </summary>
    public class MenuBackdrop : MonoBehaviour
    {
        private RawImage seaFar, seaNear;
        private RectTransform ship, sun;
        private RectTransform[] clouds;
        private RectTransform[] gulls;
        private float[] cloudSpeed;
        private float t;

        public static MenuBackdrop Create(Transform parent)
        {
            RectTransform rt = UIFactory.NewRect("TitleScene", parent);
            UIFactory.Stretch(rt);
            MenuBackdrop b = rt.gameObject.AddComponent<MenuBackdrop>();
            b.Build(rt);
            return b;
        }

        private void Build(RectTransform root)
        {
            // Cielo
            Image sky = UIFactory.Box(root, "Sky", Color.white, false);
            sky.sprite = SkyGradient();
            sky.raycastTarget = false;
            UIFactory.Stretch(sky.rectTransform);

            // Sol con halo
            Image sunImg = UIFactory.Box(root, "Sun", new Color(1f, 0.85f, 0.5f, 1f), false);
            sunImg.sprite = SoftCircle();
            sunImg.raycastTarget = false;
            sun = sunImg.rectTransform;
            UIFactory.Place(sun, new Vector2(0.72f, 0.46f), Vector2.zero, new Vector2(520f, 520f));
            sun.pivot = new Vector2(0.5f, 0.5f); // escalar el halo desde su centro
            Image sunCore = UIFactory.Box(sun, "Core", new Color(1f, 0.93f, 0.7f), false);
            sunCore.sprite = SoftCircle();
            sunCore.raycastTarget = false;
            UIFactory.Place(sunCore.rectTransform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(170f, 170f));

            // Nubes
            clouds = new RectTransform[4];
            cloudSpeed = new float[clouds.Length];
            for (int i = 0; i < clouds.Length; i++)
            {
                Image c = UIFactory.Box(root, "Cloud" + i, new Color(1f, 0.92f, 0.88f, 0.85f - i * 0.12f), false);
                c.sprite = Cloud(i % 2);
                c.raycastTarget = false;
                c.preserveAspect = true;
                clouds[i] = c.rectTransform;
                float w = 380f - i * 50f;
                UIFactory.Place(clouds[i], new Vector2(0f, 1f), new Vector2(i * 520f + 80f, -80f - i * 70f), new Vector2(w, w * 0.38f));
                cloudSpeed[i] = 14f + i * 6f;
            }

            // Isla lejana en el horizonte
            Image island = UIFactory.Box(root, "FarIsland", new Color(0.16f, 0.22f, 0.3f, 1f), false);
            island.sprite = IslandSilhouette();
            island.raycastTarget = false;
            UIFactory.Place(island.rectTransform, new Vector2(0.18f, 0.36f), Vector2.zero, new Vector2(620f, 150f));
            island.rectTransform.pivot = new Vector2(0.5f, 0f);

            // Mar lejano (horizonte hacia abajo)
            seaFar = WaterLayer(root, "SeaFar", new Color(0.55f, 0.62f, 0.85f), 0f, 0.37f, 6f);

            // Barco pirata
            Image shipImg = UIFactory.Box(root, "Ship", Color.white, false);
            shipImg.sprite = GameSprites.Get("w_ship", WorldArt.Ship);
            shipImg.preserveAspect = true;
            shipImg.raycastTarget = false;
            ship = shipImg.rectTransform;
            UIFactory.Place(ship, new Vector2(0.68f, 0.24f), Vector2.zero, new Vector2(560f, 486f));
            ship.pivot = new Vector2(0.5f, 0.08f);

            // Mar cercano (tapa el casco del barco por abajo)
            seaNear = WaterLayer(root, "SeaNear", new Color(0.8f, 0.85f, 1f), 0f, 0.24f, 3.2f);

            // Gaviotas
            gulls = new RectTransform[3];
            for (int i = 0; i < gulls.Length; i++)
            {
                Text g = UIFactory.Label(root, "v", 30 - i * 6, new Color(0.15f, 0.12f, 0.15f, 0.85f), TextAnchor.MiddleCenter, FontStyle.Bold, false);
                gulls[i] = g.rectTransform;
                UIFactory.Place(gulls[i], new Vector2(0.55f + i * 0.08f, 0.78f - i * 0.05f), Vector2.zero, new Vector2(40f, 30f));
            }

            // Viñeta para centrar la mirada en los botones
            Image vignette = UIFactory.Box(root, "Vignette", Color.white, false);
            vignette.sprite = Vignette();
            vignette.raycastTarget = false;
            UIFactory.Stretch(vignette.rectTransform);
        }

        private static RawImage WaterLayer(RectTransform root, string name, Color tint, float yMin, float yMax, float tilesAcross)
        {
            RectTransform rt = UIFactory.NewRect(name, root);
            rt.anchorMin = new Vector2(0f, yMin);
            rt.anchorMax = new Vector2(1f, yMax);
            rt.offsetMin = rt.offsetMax = Vector2.zero;
            RawImage img = rt.gameObject.AddComponent<RawImage>();
            img.texture = WorldArt.WaterTile().texture; // textura en Repeat: el uvRect se desplaza sin costuras
            img.color = tint;
            img.raycastTarget = false;
            img.uvRect = new Rect(0f, 0f, tilesAcross, tilesAcross * 0.35f);
            return img;
        }

        private void Update()
        {
            float dt = Time.unscaledDeltaTime;
            t += dt;

            Rect r = seaFar.uvRect; r.x += dt * 0.02f; seaFar.uvRect = r;
            r = seaNear.uvRect; r.x -= dt * 0.06f; r.y = Mathf.Sin(t * 0.8f) * 0.04f; seaNear.uvRect = r;

            // El barco se mece y cabecea
            ship.localRotation = Quaternion.Euler(0f, 0f, Mathf.Sin(t * 0.9f) * 2.2f);
            ship.anchoredPosition = new Vector2(Mathf.Sin(t * 0.15f) * 40f, Mathf.Sin(t * 1.3f) * 7f);

            sun.localScale = Vector3.one * (1f + Mathf.Sin(t * 0.6f) * 0.03f);

            float width = ((RectTransform)transform).rect.width + 500f;
            for (int i = 0; i < clouds.Length; i++)
            {
                Vector2 p = clouds[i].anchoredPosition;
                p.x += cloudSpeed[i] * dt;
                if (p.x > width) p.x = -420f;
                clouds[i].anchoredPosition = p;
            }

            for (int i = 0; i < gulls.Length; i++)
            {
                float k = t * (0.9f + i * 0.2f) + i * 2f;
                gulls[i].anchoredPosition = new Vector2(Mathf.Sin(k * 0.3f) * 160f, Mathf.Sin(k) * 14f);
                gulls[i].localScale = new Vector3(1f, 0.6f + Mathf.Abs(Mathf.Sin(k * 3f)) * 0.5f, 1f); // aleteo
            }
        }

        // ------------------------------------------------------------------ Texturas

        private static Sprite SkyGradient() => RuntimeSpriteCache.Get("ui_sky", () =>
        {
            Texture2D tex = new Texture2D(1, 128, TextureFormat.RGBA32, false);
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.filterMode = FilterMode.Bilinear;
            Color top = new Color(0.12f, 0.16f, 0.38f), mid = new Color(0.85f, 0.45f, 0.42f), horizon = new Color(1f, 0.78f, 0.45f);
            for (int y = 0; y < 128; y++)
            {
                float k = y / 127f;
                Color c = k > 0.55f ? Color.Lerp(mid, top, (k - 0.55f) / 0.45f) : Color.Lerp(horizon, mid, k / 0.55f);
                tex.SetPixel(0, y, c);
            }
            tex.Apply();
            return Sprite.Create(tex, new Rect(0, 0, 1, 128), new Vector2(0.5f, 0.5f), 100f);
        });

        private static Sprite SoftCircle() => RuntimeSpriteCache.Get("ui_softcircle", () =>
        {
            const int S = 64;
            Texture2D tex = new Texture2D(S, S, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Bilinear;
            for (int y = 0; y < S; y++)
                for (int x = 0; x < S; x++)
                {
                    float dx = (x + 0.5f) / S * 2f - 1f, dy = (y + 0.5f) / S * 2f - 1f;
                    float a = Mathf.Clamp01(1f - Mathf.Sqrt(dx * dx + dy * dy));
                    tex.SetPixel(x, y, new Color(1f, 1f, 1f, a * a));
                }
            tex.Apply();
            return Sprite.Create(tex, new Rect(0, 0, S, S), new Vector2(0.5f, 0.5f), 100f);
        });

        private static Sprite Cloud(int variant) => RuntimeSpriteCache.Get("ui_cloud_" + variant, () =>
        {
            PixelCanvas c = new PixelCanvas(64, 24);
            Color w = Color.white, shade = new Color(0.86f, 0.84f, 0.92f);
            if (variant == 0)
            {
                c.Ellipse(20, 9, 14, 7, shade); c.Ellipse(36, 12, 16, 10, shade); c.Ellipse(50, 8, 11, 6, shade);
                c.Ellipse(20, 11, 13, 6, w); c.Ellipse(36, 14, 15, 9, w); c.Ellipse(50, 10, 10, 5, w);
            }
            else
            {
                c.Ellipse(26, 9, 20, 6, shade); c.Ellipse(40, 12, 12, 8, shade);
                c.Ellipse(26, 11, 19, 5, w); c.Ellipse(40, 14, 11, 7, w);
            }
            return c.ToSprite(new Vector2(0.5f, 0.5f), 16f);
        });

        private static Sprite IslandSilhouette() => RuntimeSpriteCache.Get("ui_far_island", () =>
        {
            PixelCanvas c = new PixelCanvas(96, 24);
            for (int x = 0; x < 96; x++)
            {
                float h = 6f + Mathf.Sin(x / 96f * Mathf.PI) * 10f + Mathf.Sin(x * 0.35f) * 1.2f;
                c.Rect(x, 0, 1, Mathf.RoundToInt(h), Color.white);
            }
            // Palmeras
            foreach (int px in new[] { 30, 58, 70 })
            {
                c.Line(px, 12, px + 2, 21, Color.white);
                c.Line(px + 2, 21, px - 4, 18, Color.white); c.Line(px + 2, 21, px + 8, 19, Color.white);
                c.Line(px + 2, 21, px - 2, 23, Color.white); c.Line(px + 2, 21, px + 6, 23, Color.white);
            }
            // Faro
            c.Rect(80, 6, 3, 12, Color.white); c.Rect(79, 18, 5, 2, Color.white);
            return c.ToSprite(new Vector2(0.5f, 0f), 16f);
        });

        private static Sprite Vignette() => RuntimeSpriteCache.Get("ui_vignette", () =>
        {
            const int S = 64;
            Texture2D tex = new Texture2D(S, S, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Bilinear;
            tex.wrapMode = TextureWrapMode.Clamp;
            for (int y = 0; y < S; y++)
                for (int x = 0; x < S; x++)
                {
                    float dx = (x + 0.5f) / S * 2f - 1f, dy = (y + 0.5f) / S * 2f - 1f;
                    float d = Mathf.Sqrt(dx * dx * 0.8f + dy * dy);
                    float a = Mathf.SmoothStep(0f, 0.75f, Mathf.InverseLerp(0.55f, 1.35f, d));
                    tex.SetPixel(x, y, new Color(0.02f, 0.02f, 0.06f, a));
                }
            tex.Apply();
            return Sprite.Create(tex, new Rect(0, 0, S, S), new Vector2(0.5f, 0.5f), 100f);
        });
    }
}
