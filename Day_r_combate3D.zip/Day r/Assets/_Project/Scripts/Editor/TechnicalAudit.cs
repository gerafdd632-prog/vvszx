﻿using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEditor;
using PirateSurvival.Player;
using PirateSurvival.Interaction;
using PirateSurvival.Inventory;
using PirateSurvival.Environment;
using PirateSurvival.SaveSystem;
using PirateSurvival.Combat;
using PirateSurvival.Core;
using PirateSurvival.UI;

namespace PirateSurvival.EditorTools
{
    /// <summary>
    /// Auditoría técnica ampliada (complementa "Validar escena").
    /// Como el mundo se construye en tiempo de ejecución, la mayoría de comprobaciones son útiles en Play Mode.
    /// </summary>
    public static class TechnicalAudit
    {
        private static int errors;
        private static int warnings;

        [MenuItem("Pirate Survival/Auditoría técnica")]
        public static void Run()
        {
            errors = 0;
            warnings = 0;
            Debug.Log("================ AUDITORÍA TÉCNICA (PIRATE SURVIVAL) ================");
            if (!Application.isPlaying)
                Warn("Fuera de Play Mode el mundo aún no existe (lo crea GameBootstrap). Ejecuta la auditoría con el juego en marcha para comprobarlo todo.");

            CheckSingletons();
            CheckPlayer();
            CheckResources();
            CheckItems();
            CheckEncounters();
            CheckInventory();
            CheckWater();
            CheckSpawnAndCamera();
            CheckWorldBounds();
            CheckStates();
            CheckImportantPickups();
            CheckScriptLocations();

            Debug.Log($"================ AUDITORÍA: {errors} errores | {warnings} advertencias ================");
            EditorUtility.DisplayDialog("Auditoría técnica",
                $"Completada con {errors} errores y {warnings} advertencias.\nRevisa la consola.", "Aceptar");
        }

        private static void Error(string msg, Object ctx = null) { errors++; Debug.LogError("[Auditoría] " + msg, ctx); }
        private static void Warn(string msg, Object ctx = null) { warnings++; Debug.LogWarning("[Auditoría] " + msg, ctx); }

        private static void CheckSingletons()
        {
            CountUnique<InventoryManager>("InventoryManager");
            CountUnique<SaveManager>("SaveManager");
            CountUnique<BattleManager>("BattleManager");
        }

        private static void CountUnique<T>(string label) where T : Object
        {
            int n = Object.FindObjectsByType<T>(FindObjectsSortMode.None).Length;
            if (n > 1) Error($"{label} duplicado ({n} instancias).");
            else if (n == 0 && Application.isPlaying) Warn($"No hay {label} en la escena.");
        }

        private static void CheckPlayer()
        {
            PlayerController2D player = Object.FindFirstObjectByType<PlayerController2D>();
            if (player == null)
            {
                if (Application.isPlaying) Error("No hay jugador (PlayerController2D).");
                return;
            }
            if (player.GetComponent<PlayerStats>() == null) Error("El jugador no tiene PlayerStats.", player);
            if (player.GetComponent<DevilFruitManager>() == null) Error("El jugador no tiene DevilFruitManager.", player);
            if (player.GetComponent<HakiManager>() == null) Error("El jugador no tiene HakiManager.", player);
            if (player.GetComponent<PlayerSwimming>() == null) Error("El jugador no tiene PlayerSwimming (natación/ahogamiento).", player);
            if (player.GetComponent<SafePositionTracker>() == null) Warn("El jugador no tiene SafePositionTracker.", player);
        }

        private static void CheckResources()
        {
            var ids = new HashSet<string>();
            foreach (HarvestableResource res in Object.FindObjectsByType<HarvestableResource>(FindObjectsSortMode.None))
            {
                if (string.IsNullOrEmpty(res.ResourceId)) Error($"Recurso '{res.name}' sin resourceId.", res);
                else if (!ids.Add(res.ResourceId)) Error($"resourceId duplicado: '{res.ResourceId}'.", res);

                SerializedObject so = new SerializedObject(res);
                SerializedProperty drop = so.FindProperty("dropItem");
                if (drop != null && drop.objectReferenceValue == null) Warn($"Recurso '{res.name}' sin objeto de botín (dropItem).", res);
            }
        }

        private static void CheckItems()
        {
            SaveManager save = Object.FindFirstObjectByType<SaveManager>();
            if (save == null) return;
            var ids = new HashSet<string>();
            foreach (ItemData item in save.ItemDatabase)
            {
                if (item == null) { Error("Referencia nula en itemDatabase."); continue; }
                if (string.IsNullOrEmpty(item.itemId)) Error($"'{item.name}' sin itemId.", item);
                else if (!ids.Add(item.itemId)) Error($"itemId duplicado: '{item.itemId}'.", item);

                bool equipable = item.itemType == ItemType.Tool || item.itemType == ItemType.Weapon;
                if (equipable && item.maxStackSize > 1) Error($"'{item.itemId}' es herramienta/arma y se apila ({item.maxStackSize}).", item);
                if (item.combatDamage > 0 && item.maxStackSize > 1) Error($"'{item.itemId}' es un arma de combate con maxStackSize > 1.", item);
                if (item.maxDurability > 0 && item.maxStackSize > 1) Warn($"'{item.itemId}' tiene durabilidad y se apila: la durabilidad es por casilla.", item);
                if (item.itemType == ItemType.DevilFruit && string.IsNullOrEmpty(item.devilFruitId)) Error($"Fruta '{item.itemId}' sin devilFruitId.", item);
            }
        }

        private static void CheckEncounters()
        {
            var ids = new HashSet<string>();
            foreach (BattleEncounter enc in Object.FindObjectsByType<BattleEncounter>(FindObjectsSortMode.None))
            {
                if (string.IsNullOrEmpty(enc.EncounterId)) Error($"Encuentro '{enc.name}' sin ID.", enc);
                else if (!ids.Add(enc.EncounterId)) Error($"ID de encuentro duplicado: '{enc.EncounterId}'.", enc);
            }
        }

        private static void CheckInventory()
        {
            InventoryManager inv = Object.FindFirstObjectByType<InventoryManager>();
            if (inv == null) return;
            for (int i = 0; i < inv.Slots.Count; i++)
            {
                InventorySlot s = inv.Slots[i];
                if (s.IsEmpty) continue;
                if (s.Quantity > s.ItemData.maxStackSize) Error($"Casilla {i}: {s.ItemData.itemId} x{s.Quantity} supera su máximo ({s.ItemData.maxStackSize}).");
                if (s.ItemData.maxDurability > 0 && (s.Durability <= 0 || s.Durability > s.ItemData.maxDurability))
                    Error($"Casilla {i}: durabilidad {s.Durability} fuera de 1..{s.ItemData.maxDurability}.");
            }
            if (inv.EquippedSlotIndex >= 0)
            {
                if (inv.EquippedSlotIndex >= inv.Slots.Count || inv.Slots[inv.EquippedSlotIndex].ItemData != inv.CurrentEquippedTool)
                    Error("El arma equipada no coincide con su casilla.");
            }
        }

        private static void CheckWater()
        {
            SeaZone[] zones = Object.FindObjectsByType<SeaZone>(FindObjectsSortMode.None);
            if (Application.isPlaying && zones.Length == 0) Warn("No hay ninguna SeaZone: el mar no tendrá natación ni ahogamiento.");
            foreach (SeaZone z in zones)
            {
                Collider2D c = z.GetComponent<Collider2D>();
                if (c == null || !c.isTrigger) Error($"SeaZone '{z.name}' necesita un Collider2D trigger.", z);
                // El océano solo marca agua profunda: beber va en puntos pequeños de la orilla
                if (z.GetComponent<WaterSource>() != null) Error($"'{z.name}' (SeaZone/OceanBorder) usa WaterSource directamente: muévela a puntos de orilla pequeños.", z);
                if (z.GetComponent<IInteractable>() != null) Warn($"SeaZone '{z.name}' también es IInteractable: competirá con los objetos cercanos.", z);
            }
            foreach (WaterSource ws in Object.FindObjectsByType<WaterSource>(FindObjectsSortMode.None))
            {
                Collider2D c = ws.GetComponent<Collider2D>();
                if (c != null && (c.bounds.extents.x > 3f || c.bounds.extents.y > 3f))
                    Error($"WaterSource '{ws.name}' tiene un collider enorme ({c.bounds.size}): solo debe cubrir un punto para beber.", ws);
                if (ws.Type == WaterType.FreshWater && ws.GetComponent<SeaZone>() != null)
                    Error($"Agua dulce '{ws.name}' marcada como mar profundo (SeaZone).", ws);
            }
        }

        private static void CheckSpawnAndCamera()
        {
            Camera2D cam = Object.FindFirstObjectByType<Camera2D>();
            if (cam != null && cam.Target == null) Error("Camera2D sin objetivo.", cam);

            SaveManager save = Object.FindFirstObjectByType<SaveManager>();
            if (save == null || !Application.isPlaying) return;
            if (save.DefaultSpawnPoint == null)
            {
                Error("SaveManager sin defaultSpawnPoint.", save);
                return;
            }
            PlayerController2D player = Object.FindFirstObjectByType<PlayerController2D>();
            Rigidbody2D rb = player != null ? player.GetComponent<Rigidbody2D>() : null;
            if (!SafePositionTracker.IsValidLandPosition(save.DefaultSpawnPoint.position, rb))
            {
                bool recoverable = SafePositionTracker.TryFindNearestSafePosition(save.DefaultSpawnPoint.position, rb, 6f, 0.5f, out Vector2 near);
                Error($"El punto de aparición {save.DefaultSpawnPoint.position} está en el mar, fuera de límites o dentro de un collider. " +
                      (recoverable ? $"Se usaría {near}." : "No hay posición segura cerca."), save);
            }

            SerializedObject so = new SerializedObject(save);
            foreach (string field in new[] { "playerController", "playerStats", "inventoryManager", "dayNightCycle", "weatherSystem", "hudManager" })
            {
                SerializedProperty p = so.FindProperty(field);
                if (p != null && p.objectReferenceValue == null) Warn($"SaveManager.{field} sin asignar (se buscará en tiempo de ejecución).", save);
            }
        }

        private static void CheckWorldBounds()
        {
            if (Application.isPlaying && !WorldBoundsProvider.IsConfigured)
                Warn("WorldBoundsProvider sin configurar en Play Mode: las posiciones no se limitan al mapa.");
        }

        private static void CheckStates()
        {
            if (!Application.isPlaying) return;
            PlayerStats stats = Object.FindFirstObjectByType<PlayerStats>();
            HUDManager hud = Object.FindFirstObjectByType<HUDManager>();
            if (stats != null && stats.IsDead && GameState.Current != GameScreen.Dead)
                Error($"El jugador está muerto pero GameState es {GameState.Current} (debería ser Dead).");
            if (stats != null && !stats.IsDead && GameState.Current == GameScreen.Dead)
                Error("GameState es Dead pero el jugador está vivo.");
            if (hud != null && stats != null && hud.IsDeathScreenVisible != stats.IsDead)
                Error($"Pantalla de muerte visible = {hud.IsDeathScreenVisible} pero jugador muerto = {stats.IsDead}.");

            MenuManager menu = MenuManager.Instance;
            if (menu != null && menu.IsConfirmOpen && !GameInput.ModalBlocked)
                Error("Hay una confirmación abierta pero el juego no está bloqueado (GameInput.ModalBlocked = false).");
            if ((menu == null || !menu.IsConfirmOpen) && GameInput.ModalBlocked)
                Error("GameInput.ModalBlocked está activo sin ninguna confirmación abierta: el jugador quedaría bloqueado.");
        }

        private static void CheckImportantPickups()
        {
            if (!Application.isPlaying) return;
            foreach (WorldItemPickup p in Object.FindObjectsByType<WorldItemPickup>(FindObjectsSortMode.None))
            {
                if (!p.IsPersistent) continue;
                if (SeaZone.IsDeepWaterAt(p.transform.position) || !WorldBoundsProvider.Contains(p.transform.position))
                    Error($"Objeto importante '{p.ItemData.itemId}' en una posición inválida {p.transform.position} (mar o fuera del mapa).", p);
            }
        }

        private static void CheckScriptLocations()
        {
            if (AssetDatabase.IsValidFolder("Assets/Scripts"))
                Warn("Existe 'Assets/Scripts': el proyecto usa 'Assets/_Project/Scripts'. No dupliques la estructura.");

            foreach (string guid in AssetDatabase.FindAssets("t:MonoScript", new[] { "Assets/_Project/Scripts" }))
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                if (path.Replace('\\', '/').Contains("/Editor/")) continue;
                string text = File.ReadAllText(path);
                if (text.Contains("using UnityEditor;"))
                    Error($"'{path}' usa UnityEditor fuera de una carpeta Editor: fallará al compilar la build.");
            }
        }
    }
}
