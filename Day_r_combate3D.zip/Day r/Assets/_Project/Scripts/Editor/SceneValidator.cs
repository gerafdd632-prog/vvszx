﻿using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using PirateSurvival.Player;
using PirateSurvival.Interaction;
using PirateSurvival.Inventory;
using PirateSurvival.Inventory.UI;
using PirateSurvival.Environment;
using PirateSurvival.SaveSystem;
using PirateSurvival.UI;

namespace PirateSurvival.EditorTools
{
    /// <summary>
    /// Herramienta de validación automatizada de escena para Unity 6 (A3 / FASE A2).
    /// Detecta inconsistencias de capas, duplicados de IDs, overlays y problemas
    /// de arquitectura que causan fallos silenciosos en tiempo de ejecución.
    /// Nota: Si la escena está vacía, GameBootstrap construirá el entorno completo al dar Play.
    /// </summary>
    public static class SceneValidator
    {
        [MenuItem("Pirate Survival/Validar escena")]
        public static void ValidateCurrentScene()
        {
            int errorCount = 0;
            int warningCount = 0;

            Debug.Log("================ INICIO DE VALIDACIÓN DE ESCENA (PIRATE SURVIVAL 2D) ================");

            // 1. Validar Cámara 2D
            Camera2D cam = Object.FindFirstObjectByType<Camera2D>();
            if (cam == null)
            {
                Debug.LogWarning("[Validador] No se encontró 'Camera2D' en la escena (GameBootstrap la generará si la escena está vacía).");
                warningCount++;
            }
            else if (cam.Target == null)
            {
                Debug.LogError("[Validador] 'Camera2D' tiene el campo 'Target' sin asignar.", cam);
                errorCount++;
            }

            // 2. Validar PlayerController2D y PlayerStats
            PlayerController2D player = Object.FindFirstObjectByType<PlayerController2D>();
            if (player == null)
            {
                Debug.LogWarning("[Validador] No se encontró 'PlayerController2D' en la escena (GameBootstrap lo generará si la escena está vacía).");
                warningCount++;
            }
            else
            {
                Rigidbody2D rb = player.GetComponent<Rigidbody2D>();
                if (rb == null)
                {
                    Debug.LogError("[Validador] El jugador carece de componente Rigidbody2D.", player);
                    errorCount++;
                }
                else if (rb.gravityScale != 0f)
                {
                    Debug.LogWarning($"[Validador] El Rigidbody2D del jugador tiene gravityScale = {rb.gravityScale}. Para top-down debe ser 0.", player);
                    warningCount++;
                }

                PlayerStats stats = player.GetComponent<PlayerStats>();
                if (stats == null)
                {
                    Debug.LogError("[Validador] El jugador carece de 'PlayerStats'.", player);
                    errorCount++;
                }
            }

            // 3. Validar PlayerInteraction2D y solapamiento de capas
            PlayerInteraction2D interaction = Object.FindFirstObjectByType<PlayerInteraction2D>();
            if (interaction != null)
            {
                SerializedObject so = new SerializedObject(interaction);
                SerializedProperty interactableLayers = so.FindProperty("interactableLayers");
                SerializedProperty obstacleLayers = so.FindProperty("obstacleLayers");

                if (interactableLayers.intValue == 0)
                {
                    Debug.LogWarning("[Validador] 'PlayerInteraction2D.interactableLayers' está vacía (Nothing). Se usará fallback automático ~Player.", interaction);
                    warningCount++;
                }
                else if ((interactableLayers.intValue & obstacleLayers.intValue) != 0)
                {
                    Debug.LogWarning("[Validador] 'interactableLayers' y 'obstacleLayers' comparten capas. Los interactuables podrían auto-bloquear su línea de visión Linecast.", interaction);
                    warningCount++;
                }
            }

            // 4. Validar DayNightCycle y Overlay
            DayNightCycle dayNight = Object.FindFirstObjectByType<DayNightCycle>();
            if (dayNight != null)
            {
                if (dayNight.DayNightOverlay == null)
                {
                    Debug.LogWarning("[Validador] 'DayNightCycle' no tiene asignado 'dayNightOverlay'. Si se usa GameBootstrap se asignará automáticamente.", dayNight);
                    warningCount++;
                }
            }

            // 5. Validar duplicados de resourceId en HarvestableResource
            HarvestableResource[] resources = Object.FindObjectsByType<HarvestableResource>(FindObjectsSortMode.None);
            HashSet<string> resourceIds = new HashSet<string>();

            foreach (var res in resources)
            {
                if (string.IsNullOrEmpty(res.ResourceId))
                {
                    Debug.LogError($"[Validador] El recurso '{res.gameObject.name}' tiene 'resourceId' vacío.", res);
                    errorCount++;
                }
                else if (resourceIds.Contains(res.ResourceId))
                {
                    Debug.LogError($"[Validador] 'resourceId' duplicado detectado: '{res.ResourceId}' en '{res.gameObject.name}'. Usa 'Pirate Survival/Reparar IDs de Recursos'.", res);
                    errorCount++;
                }
                else
                {
                    resourceIds.Add(res.ResourceId);
                }

                Collider2D col = res.GetComponent<Collider2D>();
                if (col == null)
                {
                    Debug.LogError($"[Validador] El recurso '{res.gameObject.name}' no tiene Collider2D.", res);
                    errorCount++;
                }
            }

            // 6. Validar SaveManager e itemDatabase
            SaveManager saveMgr = Object.FindFirstObjectByType<SaveManager>();
            if (saveMgr != null)
            {
                HashSet<string> itemIds = new HashSet<string>();
                foreach (var item in saveMgr.ItemDatabase)
                {
                    if (item == null)
                    {
                        Debug.LogError("[Validador] Elemento nulo (Missing) encontrado en 'SaveManager.itemDatabase'.", saveMgr);
                        errorCount++;
                        continue;
                    }

                    if (string.IsNullOrEmpty(item.itemId))
                    {
                        Debug.LogError($"[Validador] El objeto '{item.name}' en itemDatabase tiene itemId vacío.", item);
                        errorCount++;
                    }
                    else if (itemIds.Contains(item.itemId))
                    {
                        Debug.LogError($"[Validador] itemId duplicado en itemDatabase: '{item.itemId}' en '{item.name}'.", item);
                        errorCount++;
                    }
                    else
                    {
                        itemIds.Add(item.itemId);
                    }
                }
            }

            // 7. (La mochila se construye sola por código: no hay paneles que validar)

            // 8. Validar HUDManager
            HUDManager hud = Object.FindFirstObjectByType<HUDManager>();
            if (hud == null && player != null)
            {
                Debug.LogWarning("[Validador] Hay jugador en la escena pero no se encontró 'HUDManager'.");
                warningCount++;
            }

            // Resumen final
            Debug.Log($"================ RESUMEN: {errorCount} Errores | {warningCount} Advertencias ================");
            if (errorCount == 0 && warningCount == 0)
            {
                EditorUtility.DisplayDialog("Validación de Escena", "¡Excelente! La escena no tiene errores ni advertencias.\n(Recuerda que si la escena está vacía, GameBootstrap construirá el juego al dar Play).", "Aceptar");
            }
            else
            {
                EditorUtility.DisplayDialog("Validación de Escena", $"Validación completada con {errorCount} errores y {warningCount} advertencias. Revisa la consola de Unity.", "Entendido");
            }
        }

        /// <summary>
        /// Punto 15: Repara y garantiza IDs únicos deterministas para todos los recursos de la escena sin depender de coordenadas de posición.
        /// </summary>
        [MenuItem("Pirate Survival/Reparar IDs de Recursos")]
        public static void RepairResourceIds()
        {
            HarvestableResource[] resources = Object.FindObjectsByType<HarvestableResource>(FindObjectsSortMode.None);
            HashSet<string> usedIds = new HashSet<string>();
            int fixedCount = 0;

            foreach (var res in resources)
            {
                SerializedObject so = new SerializedObject(res);
                SerializedProperty idProp = so.FindProperty("resourceId");
                string currentId = idProp.stringValue;

                if (string.IsNullOrEmpty(currentId) || usedIds.Contains(currentId))
                {
                    string baseName = res.gameObject.name.Replace(" ", "_").ToLower();
                    int counter = 1;
                    string newId = $"{baseName}_{counter}";
                    while (usedIds.Contains(newId))
                    {
                        counter++;
                        newId = $"{baseName}_{counter}";
                    }

                    idProp.stringValue = newId;
                    so.ApplyModifiedProperties();
                    EditorUtility.SetDirty(res);
                    usedIds.Add(newId);
                    fixedCount++;
                    Debug.Log($"[Validador] Reparado resourceId para '{res.gameObject.name}' -> '{newId}'.", res);
                }
                else
                {
                    usedIds.Add(currentId);
                }
            }

            if (!Application.isPlaying)
            {
                UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(UnityEditor.SceneManagement.EditorSceneManager.GetActiveScene());
            }

            EditorUtility.DisplayDialog("Reparación de Recursos", $"Proceso completado. Se han verificado {resources.Length} recursos y reparado {fixedCount} IDs únicos.", "Aceptar");
        }
    }
}
