﻿using UnityEditor;
using UnityEngine;

namespace PirateSurvival.EditorTools
{
    /// <summary>
    /// Ajustes de importación de pixel art para todo lo que esté en una carpeta Resources/Sprites:
    /// Sprite, filtro Point, sin compresión, sin mipmaps, 16 píxeles por unidad.
    /// (Los .meta incluidos ya lo traen; esto solo cubre imágenes nuevas o .meta perdidos.)
    /// El pivote no se toca: cada .meta trae el suyo.
    /// </summary>
    public class PixelArtImporter : AssetPostprocessor
    {
        private void OnPreprocessTexture()
        {
            string path = assetPath.Replace('\\', '/');
            if (!path.Contains("/Resources/Sprites/")) return;

            TextureImporter importer = (TextureImporter)assetImporter;
            importer.textureType = TextureImporterType.Sprite;
            importer.spriteImportMode = SpriteImportMode.Single;
            importer.spritePixelsPerUnit = 16f;
            importer.filterMode = FilterMode.Point;
            importer.mipmapEnabled = false;
            importer.textureCompression = TextureImporterCompression.Uncompressed;
            importer.npotScale = TextureImporterNPOTScale.None;
            importer.alphaIsTransparency = true;
            importer.wrapMode = TextureWrapMode.Clamp;
        }
    }
}
