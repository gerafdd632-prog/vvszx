﻿using System.Collections.Generic;
using UnityEngine;
using PirateSurvival.Core;
using PirateSurvival.Inventory;

namespace PirateSurvival.Bootstrap
{
    /// <summary>Materiales de fabricación, espadas, armas de fuego, cocina y medicina (catálogo ampliado).</summary>
    public static partial class GameBootstrap
    {
        private static void AddCraftingItems(Dictionary<string, ItemData> dict)
        {
            // ================================================================ MATERIALES BÁSICOS Y ALQUIMIA
            dict["itemFibra"] = Material("fibra", "Fibra de Palma", "Hebras resistentes de los arbustos. Se trenzan para hacer cuerda y tela.", 0.1f, 30, new Color(0.55f, 0.72f, 0.3f));
            dict["itemMineral"] = Material("mineral_hierro", "Mineral de Hierro", "Roca con vetas de hierro de la vieja mina del oeste. En la forja se funde en lingotes.", 1.0f, 20, new Color(0.55f, 0.35f, 0.3f));
            dict["itemLingote"] = Material("lingote_hierro", "Lingote de Hierro", "Hierro fundido listo para forjar armas.", 0.8f, 20, new Color(0.7f, 0.72f, 0.78f));
            dict["itemLingoteAcero"] = Material("lingote_acero", "Lingote de Acero", "Hierro enriquecido con carbón para hojas afiladas de gran tenacidad.", 0.9f, 20, new Color(0.85f, 0.88f, 0.95f));
            dict["itemCarbon"] = Material("carbon", "Carbón Vegetal", "Carbón obtenido quemando madera. Sirve de combustible y para fabricar pólvora.", 0.4f, 25, new Color(0.2f, 0.2f, 0.22f));
            dict["itemAzufre"] = Material("azufre", "Azufre Volcánico", "Mineral amarillo extraído de las profundidades de la cueva. Esencial para la pólvora.", 0.4f, 20, new Color(0.92f, 0.85f, 0.25f));
            dict["itemPolvora"] = Material("polvora", "Pólvora Negra", "Mezcla detonante de carbón y azufre para armas de fuego y cañones.", 0.3f, 30, new Color(0.3f, 0.3f, 0.32f));
            dict["itemCuerda"] = Material("cuerda", "Cuerda", "Cuerda trenzada con fibra de palma. Imprescindible en cualquier barco.", 0.2f, 20, new Color(0.8f, 0.68f, 0.45f));
            dict["itemTela"] = Material("tela", "Tela de Vela", "Lona gruesa. Sirve para vendas, empuñaduras y velas.", 0.3f, 20, new Color(0.92f, 0.9f, 0.82f));
            dict["itemCuero"] = Material("cuero", "Cuero Curtido", "Piel flexible y resistente para confeccionar chalecos, vainas y armaduras.", 0.5f, 20, new Color(0.65f, 0.42f, 0.25f));
            dict["itemClavo"] = Material("clavo_hierro", "Clavos de Hierro", "Clavos forjados a mano para ensamblar herramientas, barriles y barcos.", 0.05f, 50, new Color(0.6f, 0.6f, 0.65f));
            dict["itemHierbas"] = Material("hierbas", "Hierbas Medicinales", "Hojas de plantas silvestres con propiedades cicatrizantes y desintoxicantes.", 0.1f, 30, new Color(0.35f, 0.75f, 0.35f));
            dict["itemBotellaVacia"] = Material("botella_vacia", "Botella Vacía", "Recipiente de cristal para rellenar con agua de manantial o infusiones.", 0.2f, 10, new Color(0.45f, 0.7f, 0.85f));
            
            ItemData perla = Material("perla_marina", "Perla Marina", "Gema brillante hallada en los arrecifes. Vale muchos Berries para los comerciantes.", 0.1f, 10, new Color(0.95f, 0.95f, 1.0f));
            perla.neverDespawn = true;
            dict["itemPerlaMarina"] = perla;

            ItemData kairo = Material("kairoseki", "Kairoseki", "Piedra marina: emite la misma energía que el mar. Los usuarios de Frutas del Diablo pierden su fuerza al tocarla.", 1.5f, 10, new Color(0.45f, 0.55f, 0.62f));
            kairo.neverDespawn = true;
            dict["itemKairoseki"] = kairo;

            // ================================================================ HERRAMIENTAS
            ItemData picoMadera = ScriptableObject.CreateInstance<ItemData>();
            picoMadera.itemId = "pico_madera";
            picoMadera.itemName = "Pico de Madera";
            picoMadera.description = "Un palo con punta endurecida al fuego. Pica piedra despacio y se rompe pronto, pero sirve para empezar.";
            picoMadera.itemType = ItemType.Tool;
            picoMadera.toolType = ToolType.Pickaxe;
            picoMadera.resourceDamage = 8f;
            picoMadera.weight = 1.2f;
            picoMadera.maxStackSize = 1;
            picoMadera.maxDurability = 30;
            picoMadera.combatDamage = 5;
            picoMadera.combatApCost = 2;
            picoMadera.combatAccuracy = 0.8f;
            picoMadera.combatDamageType = CombatDamageType.Pierce;
            picoMadera.icon = ItemArt.Get("pico_madera");
            picoMadera.equippedPrefab = CreateToolEquippedPrefab("PicoMadera", picoMadera.icon);
            dict["itemPicoMadera"] = picoMadera;

            ItemData pala = ScriptableObject.CreateInstance<ItemData>();
            pala.itemId = "pala_pirata";
            pala.itemName = "Pala de Explorador";
            pala.description = "Herramienta robusta ideal para desenterrar cofres ocultos y cavar en la arena.";
            pala.itemType = ItemType.Tool;
            pala.toolType = ToolType.None;
            pala.resourceDamage = 10f;
            pala.weight = 1.8f;
            pala.maxStackSize = 1;
            pala.maxDurability = 60;
            pala.combatDamage = 9;
            pala.combatApCost = 2;
            pala.combatAccuracy = 0.85f;
            pala.combatDamageType = CombatDamageType.Blunt;
            pala.icon = ItemArt.Get("pala_pirata");
            pala.equippedPrefab = CreateToolEquippedPrefab("Pala", pala.icon);
            dict["itemPalaPirata"] = pala;

            ItemData antorcha = ScriptableObject.CreateInstance<ItemData>();
            antorcha.itemId = "antorcha_mano";
            antorcha.itemName = "Antorcha Portátil";
            antorcha.description = "Palo embadurnado de carbón encendido. Ilumina la oscuridad y aleja el frío nocturno.";
            antorcha.itemType = ItemType.Tool;
            antorcha.toolType = ToolType.None;
            antorcha.weight = 0.7f;
            antorcha.maxStackSize = 1;
            antorcha.maxDurability = 80;
            antorcha.combatDamage = 7;
            antorcha.combatApCost = 2;
            antorcha.combatAccuracy = 0.85f;
            antorcha.combatDamageType = CombatDamageType.Fire;
            antorcha.icon = ItemArt.Get("antorcha_mano");
            antorcha.equippedPrefab = CreateToolEquippedPrefab("Antorcha", antorcha.icon);
            dict["itemAntorchaMano"] = antorcha;

            ItemData cana = ScriptableObject.CreateInstance<ItemData>();
            cana.itemId = "cana_pescar";
            cana.itemName = "Caña de Pescar Rústica";
            cana.description = "Caña flexible con sedal y anzuelo de clavo. Permite pescar peces en la orilla del mar.";
            cana.itemType = ItemType.Tool;
            cana.toolType = ToolType.None;
            cana.weight = 1.0f;
            cana.maxStackSize = 1;
            cana.maxDurability = 45;
            cana.icon = ItemArt.Get("cana_pescar");
            cana.equippedPrefab = CreateToolEquippedPrefab("CanaPescar", cana.icon);
            dict["itemCanaPescar"] = cana;

            // ================================================================ FAUNA Y COCINA
            dict["itemCarneCruda"] = Meat("carne_cruda", "Carne Cruda", "Carne de jabalí. Quita el hambre, pero cruda sienta mal (resta un poco de vida).", 14f, -3f, new Color(0.8f, 0.3f, 0.3f));
            dict["itemCarneCangrejo"] = Meat("carne_cangrejo", "Carne de Cangrejo", "Carne blanca y salada. Se puede comer cruda sin problema.", 9f, 2f, new Color(0.95f, 0.55f, 0.45f));
            
            dict["itemCarneAsada"] = CookedFood("carne_asada", "Carne de Jabalí Asada", "Carne tierna y jugosa asada al fuego. Sacia enormemente y recupera salud.", 48f, 15f, 20f, new Color(0.58f, 0.28f, 0.15f));
            dict["itemPescadoAsado"] = CookedFood("pescado_asado", "Pescado a la Brasa", "Pescado blanco recién dorado a las brasas. Ligero, nutritivo y revitalizante.", 36f, 10f, 15f, new Color(0.85f, 0.58f, 0.35f));
            
            ItemData sopa = ScriptableObject.CreateInstance<ItemData>();
            sopa.itemId = "sopa_marisco";
            sopa.itemName = "Guiso Marinero";
            sopa.description = "Caldo humeante de coco y marisco. Quita el hambre, hidrata y reconforta de la hipotermia.";
            sopa.itemType = ItemType.Food;
            sopa.hungerRestore = 50f;
            sopa.thirstRestore = 35f;
            sopa.healthRestore = 22f;
            sopa.temperatureChange = 2.0f;
            sopa.weight = 0.6f;
            sopa.maxStackSize = 5;
            sopa.icon = ItemArt.Get("sopa_marisco");
            dict["itemSopaMarisco"] = sopa;

            ItemData infusion = ScriptableObject.CreateInstance<ItemData>();
            infusion.itemId = "infusion_herbal";
            infusion.itemName = "Infusión Revitalizante";
            infusion.description = "Té caliente de hierbas medicinales. Alivia el cansancio, calma la sed y reconforta el cuerpo.";
            infusion.itemType = ItemType.Drink;
            infusion.thirstRestore = 35f;
            infusion.healthRestore = 15f;
            infusion.staminaRestore = 25f;
            infusion.temperatureChange = 1.2f;
            infusion.weight = 0.5f;
            infusion.maxStackSize = 5;
            infusion.icon = ItemArt.Get("infusion_herbal");
            dict["itemInfusion"] = infusion;

            ItemData ron = ScriptableObject.CreateInstance<ItemData>();
            ron.itemId = "ron_pirata";
            ron.itemName = "Botella de Ron Pirata";
            ron.description = "Ron añejo fuerte del East Blue. Da un subidón de energía inmediato y calienta la sangre.";
            ron.itemType = ItemType.Drink;
            ron.thirstRestore = 15f;
            ron.healthRestore = 6f;
            ron.staminaRestore = 45f;
            ron.temperatureChange = 2.5f;
            ron.weight = 0.6f;
            ron.maxStackSize = 5;
            ron.icon = ItemArt.Get("ron_pirata");
            dict["itemRonPirata"] = ron;

            // ================================================================ MEDICINA
            ItemData unguento = ScriptableObject.CreateInstance<ItemData>();
            unguento.itemId = "unguento";
            unguento.itemName = "Ungüento Calmante";
            unguento.description = "Bálsamo herbal que alivia quemaduras y neutraliza toxinas leves en la piel.";
            unguento.itemType = ItemType.Medicine;
            unguento.healthRestore = 15f;
            unguento.curesPoison = true;
            unguento.weight = 0.2f;
            unguento.maxStackSize = 10;
            unguento.icon = ItemArt.Get("unguento");
            dict["itemUnguento"] = unguento;

            ItemData antidoto = ScriptableObject.CreateInstance<ItemData>();
            antidoto.itemId = "antidoto";
            antidoto.itemName = "Antídoto Herbal";
            antidoto.description = "Poción amarga que purga por completo el veneno de mordeduras de araña o toxinas.";
            antidoto.itemType = ItemType.Medicine;
            antidoto.healthRestore = 10f;
            antidoto.curesPoison = true;
            antidoto.weight = 0.3f;
            antidoto.maxStackSize = 5;
            antidoto.icon = ItemArt.Get("antidoto");
            dict["itemAntidoto"] = antidoto;

            ItemData botiquin = ScriptableObject.CreateInstance<ItemData>();
            botiquin.itemId = "botiquin";
            botiquin.itemName = "Botiquín de Emergencia";
            botiquin.description = "Estuche médico completo con vendas, bálsamos y desinfectante. Corta hemorragias y cura 40 de salud.";
            botiquin.itemType = ItemType.Medicine;
            botiquin.healthRestore = 40f;
            botiquin.curesBleeding = true;
            botiquin.curesPoison = true;
            botiquin.weight = 0.8f;
            botiquin.maxStackSize = 3;
            botiquin.icon = ItemArt.Get("botiquin");
            dict["itemBotiquin"] = botiquin;

            // ================================================================ ARMAS CUERPO A CUERPO
            dict["itemEspadaMadera"] = Sword("espada_madera", "Espada de Madera", "Un bokken tallado a mano. Mejor que los puños... por poco.",
                1.0f, 7, 2, 0.9f, 0.05f, CombatDamageType.Blunt, 30, 4f);
            dict["itemDagaAbordaje"] = Sword("daga_abordaje", "Daga de Abordaje", "Hoja corta y rapidísima. Cuesta solo 1 AP y tiene gran probabilidad de golpe crítico.",
                0.7f, 9, 1, 0.94f, 0.25f, CombatDamageType.Pierce, 55, 6f);
            dict["itemEspadaMarina"] = Sword("espada_marina", "Espada Oficial de la Marina", "Espada recta reglamentaria del Gobierno Mundial. Bien balanceada y letal.",
                1.5f, 15, 2, 0.93f, 0.15f, CombatDamageType.Slash, 85, 10f);
            dict["itemKatana"] = Sword("katana", "Katana de Acero", "Hoja curva de acero templado forjada por Tetsu. Rápida y precisa.",
                1.4f, 16, 2, 0.94f, 0.20f, CombatDamageType.Slash, 95, 10f);
            dict["itemNodachi"] = Sword("nodachi", "Nodachi", "Espada larguísima y pesada. Cada golpe parte escudos, pero cansa.",
                3.0f, 21, 3, 0.82f, 0.16f, CombatDamageType.Slash, 110, 14f);
            dict["itemMazaHierro"] = Sword("maza_hierro", "Maza con Remaches", "Maza de roble tachonada de clavos de hierro. Machaca corazas y conmociona al objetivo.",
                2.5f, 17, 3, 0.84f, 0.18f, CombatDamageType.Blunt, 80, 12f);
            
            ItemData lanza = Sword("lanza_madera", "Lanza de Caza", "Lanza con punta de hierro templado. Permite atacar a 2 casillas de distancia en combate táctico.",
                1.8f, 12, 2, 0.90f, 0.12f, CombatDamageType.Pierce, 65, 8f);
            lanza.combatMaxRange = 2;
            dict["itemLanzaMadera"] = lanza;

            ItemData daga = Sword("daga_kairoseki", "Daga de Kairoseki", "Filo de piedra marina. Anula los poderes de los usuarios de Frutas del Diablo.",
                0.8f, 10, 2, 0.9f, 0.1f, CombatDamageType.Pierce, 70, 5f);
            daga.kairoseki = true;
            dict["itemDagaKairoseki"] = daga;

            ItemData shiokaze = Sword("shiokaze", "Shiokaze (Meito)", "Espada legendaria del Capitán Cuervo, «Brisa marina». Su hoja nunca se mella.",
                1.5f, 20, 2, 0.96f, 0.28f, CombatDamageType.Slash, 0, 12f);
            shiokaze.neverDespawn = true;
            dict["itemShiokaze"] = shiokaze;

            // ================================================================ ARMAS A DISTANCIA Y MUNICIÓN
            dict["itemBalinesPiedra"] = AmmoItem("balines_piedra", "Balines de Piedra", "Guijarros redondos seleccionados para disparar con tirachinas.", 0.04f, 50, new Color(0.6f, 0.6f, 0.65f));
            dict["itemBalasPlomo"] = AmmoItem("balas_plomo", "Balas de Plomo con Pólvora", "Proyectiles pesados con carga de pólvora para pistolas y trabucos.", 0.08f, 40, new Color(0.35f, 0.35f, 0.4f));

            ItemData tirachinas = RangedWeapon("tirachinas", "Tirachinas de Madera", "Horquilla de madera con gomas de resina. Dispara proyectiles de piedra a media distancia.",
                0.6f, 8, 2, 1, 3, 0.88f, 0.15f, CombatDamageType.Blunt, 50, "balines_piedra");
            dict["itemTirachinas"] = tirachinas;

            ItemData pistola = RangedWeapon("pistola_chispa", "Pistola de Chispa", "Arma de fuego clásica de pirata. Gran penetración a distancia a costa de consumir pólvora y balas.",
                1.6f, 18, 3, 2, 4, 0.85f, 0.22f, CombatDamageType.Pierce, 70, "balas_plomo");
            dict["itemPistolaChispa"] = pistola;

            ItemData trabuco = RangedWeapon("trabuco", "Trabuco de Abordaje", "Cañón ancho que dispara metralla demoledora. Devastador a corta y media distancia.",
                2.8f, 25, 3, 1, 3, 0.78f, 0.25f, CombatDamageType.Explosion, 60, "balas_plomo");
            dict["itemTrabuco"] = trabuco;

            // ================================================================ ARMADURAS Y EQUIPO
            dict["itemSombreroPaja"] = EquipmentItem("sombrero_paja", "Sombrero de Paja", "El legendario sombrero de paja tejido. Protege del sol abrasador y eleva la moral del marinero.", 0.3f, new Color(0.95f, 0.85f, 0.35f));
            dict["itemChalecoCuero"] = EquipmentItem("chaleco_cuero", "Chaleco de Cuero", "Chaleco protector confeccionado con cuero grueso. Amortigua impactos y tajos.", 1.6f, new Color(0.55f, 0.35f, 0.2f));
            dict["itemCapaJusticia"] = EquipmentItem("capa_justicia", "Capa de la Justicia", "Capa ceremonial arrebatada a un alto rango de la Marina. Impone respeto y abriga en noches gélidas.", 1.2f, new Color(0.95f, 0.95f, 0.95f));
        }

        private static ItemData Meat(string id, string name, string description, float hunger, float health, Color color)
        {
            ItemData item = ScriptableObject.CreateInstance<ItemData>();
            item.itemId = id;
            item.itemName = name;
            item.description = description;
            item.itemType = ItemType.Food;
            item.hungerRestore = hunger;
            item.healthRestore = health;
            item.weight = 0.4f;
            item.maxStackSize = 10;
            item.icon = ItemArt.Get(id);
            return item;
        }

        private static ItemData CookedFood(string id, string name, string description, float hunger, float health, float stamina, Color color)
        {
            ItemData item = ScriptableObject.CreateInstance<ItemData>();
            item.itemId = id;
            item.itemName = name;
            item.description = description;
            item.itemType = ItemType.Food;
            item.hungerRestore = hunger;
            item.healthRestore = health;
            item.staminaRestore = stamina;
            item.weight = 0.4f;
            item.maxStackSize = 10;
            item.icon = ItemArt.Get(id);
            return item;
        }

        private static ItemData Material(string id, string name, string description, float weight, int stack, Color color)
        {
            ItemData item = ScriptableObject.CreateInstance<ItemData>();
            item.itemId = id;
            item.itemName = name;
            item.description = description;
            item.itemType = ItemType.Material;
            item.weight = weight;
            item.maxStackSize = stack;
            item.icon = ItemArt.Get(id);
            return item;
        }

        private static ItemData AmmoItem(string id, string name, string description, float weight, int stack, Color color)
        {
            ItemData item = ScriptableObject.CreateInstance<ItemData>();
            item.itemId = id;
            item.itemName = name;
            item.description = description;
            item.itemType = ItemType.Material;
            item.weight = weight;
            item.maxStackSize = stack;
            item.icon = ItemArt.Get(id);
            return item;
        }

        private static ItemData EquipmentItem(string id, string name, string description, float weight, Color color)
        {
            ItemData item = ScriptableObject.CreateInstance<ItemData>();
            item.itemId = id;
            item.itemName = name;
            item.description = description;
            item.itemType = ItemType.Tool;
            item.toolType = ToolType.None;
            item.weight = weight;
            item.maxStackSize = 1;
            item.maxDurability = 100;
            item.icon = ItemArt.Get(id);
            return item;
        }

        private static ItemData Sword(string id, string name, string description, float weight, int damage, int apCost,
            float accuracy, float crit, CombatDamageType type, int durability, float resourceDamage)
        {
            ItemData item = ScriptableObject.CreateInstance<ItemData>();
            item.itemId = id;
            item.itemName = name;
            item.description = description;
            item.itemType = ItemType.Weapon;
            item.toolType = ToolType.Cutlass;
            item.weight = weight;
            item.maxStackSize = 1;
            item.resourceDamage = resourceDamage;
            item.combatDamage = damage;
            item.combatApCost = apCost;
            item.combatAccuracy = accuracy;
            item.combatCritChance = crit;
            item.combatDamageType = type;
            item.maxDurability = durability;
            item.icon = ItemArt.Get(id);
            item.equippedPrefab = CreateToolEquippedPrefab(name, item.icon);
            return item;
        }

        private static ItemData RangedWeapon(string id, string name, string description, float weight, int damage, int apCost,
            int minRange, int maxRange, float accuracy, float crit, CombatDamageType type, int durability, string ammoId)
        {
            ItemData item = ScriptableObject.CreateInstance<ItemData>();
            item.itemId = id;
            item.itemName = name;
            item.description = description;
            item.itemType = ItemType.Weapon;
            item.toolType = ToolType.Cutlass;
            item.weight = weight;
            item.maxStackSize = 1;
            item.resourceDamage = 4f;
            item.combatDamage = damage;
            item.combatApCost = apCost;
            item.combatMinRange = minRange;
            item.combatMaxRange = maxRange;
            item.combatAccuracy = accuracy;
            item.combatCritChance = crit;
            item.combatDamageType = type;
            item.maxDurability = durability;
            item.ammoItemId = ammoId;
            item.icon = ItemArt.Get(id);
            item.equippedPrefab = CreateToolEquippedPrefab(name, item.icon);
            return item;
        }
    }
}
