﻿using System.Collections.Generic;
using UnityEngine;
using PirateSurvival.Core;
using PirateSurvival.Player;
using PirateSurvival.Inventory;
using PirateSurvival.Interaction;
using PirateSurvival.Environment;
using PirateSurvival.Combat;
using PirateSurvival.Crafting;
using PirateSurvival.Story;

namespace PirateSurvival.Bootstrap
{
    /// <summary>
    /// Construye la isla inicial: suelo, mar animado, costa (SeaZone), playa del naufragio, charca, Aldea Coral,
    /// vieja mina del oeste, bosque, muelle con el barco del Capitán Cuervo, aldeanos, recursos, objetos y combates.
    /// El plano está en IslandLayout y la colocación de objetos en IslandPlacements.
    /// </summary>
    internal static class IslandBuilder
    {
        // Capas de dibujo (el resto de objetos se ordena por Y con YSorter)
        private const int OrderWater = -6000;
        private const int OrderGround = -5000;
        private const int OrderGroundDecor = -4400;
        private const int OrderPier = -4300;

        private static int treeCount, palmCount, rockCount, oreCount, bushCount, stoneCount, driftwoodCount, herbCount, coalCount, sulfurCount, chestCount;

        public static void Build(Dictionary<string, ItemData> itemDb)
        {
            treeCount = palmCount = rockCount = oreCount = bushCount = stoneCount = driftwoodCount = herbCount = coalCount = sulfurCount = chestCount = 0;
            GameObject root = GameBootstrap.NewRoot("Island");

            CreateGround(root);
            CreateSea(root);
            CreateBounds(root);
            CreatePond(root);
            CreatePier(root);
            CreateCave(root);

            Transform scenery = Child(root.transform, "Scenery");

            // Recopilar posiciones de edificios y NPCs para limpiar vegetación que cause bugs de colisión o bloqueo
            HashSet<string> buildingKinds = new HashSet<string>
            {
                "house", "townhall", "tavern", "lighthouse", "drydock", "forge", "workbench", "well", "stall", "fountain", "tent", "defense_cannon"
            };
            List<Vector2> buildingPositions = new List<Vector2>();
            foreach (IslandPlacements.Item it in IslandPlacements.Scenery)
            {
                if (buildingKinds.Contains(it.kind)) buildingPositions.Add(it.pos);
            }

            Vector2[] npcPositions = new Vector2[]
            {
                IslandPlacements.NpcAbuela, IslandPlacements.NpcAlcaldesa, IslandPlacements.NpcHerrero,
                IslandPlacements.NpcCarpintero, IslandPlacements.NpcTabernera, IslandPlacements.NpcMercader,
                IslandPlacements.NpcNino, IslandPlacements.NpcPescador, IslandPlacements.NpcMarine,
                IslandPlacements.NpcBoticario, IslandPlacements.NpcKenshi, IslandPlacements.NpcSogeking,
                IslandPlacements.NpcTimon
            };

            foreach (IslandPlacements.Item item in IslandPlacements.Scenery)
            {
                bool isObstacle = item.kind == "tree" || item.kind == "pine" || item.kind == "treeround" ||
                                  item.kind == "autumn" || item.kind == "palm" || item.kind == "boulder" || item.kind == "rock";

                if (isObstacle)
                {
                    // Evitar que árboles o rocas se generen dentro o pegados a casas y edificios
                    bool nearBuilding = false;
                    for (int b = 0; b < buildingPositions.Count; b++)
                    {
                        if (Vector2.Distance(item.pos, buildingPositions[b]) < 3.4f) { nearBuilding = true; break; }
                    }
                    if (nearBuilding) continue;

                    // Evitar obstáculos encima de NPCs
                    bool nearNpc = false;
                    for (int n = 0; n < npcPositions.Length; n++)
                    {
                        if (Vector2.Distance(item.pos, npcPositions[n]) < 2.0f) { nearNpc = true; break; }
                    }
                    if (nearNpc) continue;

                    // Dejar los caminos limpios para correr sin atascarse
                    if (IslandLayout.DistanceToPaths(item.pos) < 1.35f) continue;

                    // Mantener la plaza del pueblo despejada de árboles salvajes
                    if (Vector2.Distance(item.pos, IslandLayout.Village) < 8.2f) continue;
                }

                CreateScenery(scenery, item, itemDb);
            }

            CreateVillagers(root);

            // Combates (mismos ids de siempre: los guardados siguen valiendo)
            GameBootstrap.CreateEncounter(root, "piratas_playa", EncounterKind.BeachPirates, IslandPlacements.EncPiratas);
            GameBootstrap.CreateEncounter(root, "capitan_cuervo", EncounterKind.CaptainShip, IslandPlacements.EncCapitan);
            GameBootstrap.CreateEncounter(root, "cueva_aranas", EncounterKind.CaveSpiders, IslandPlacements.EncCuevaAranas);
            GameBootstrap.CreateEncounter(root, "cueva_murcielagos", EncounterKind.CaveBats, IslandPlacements.EncCuevaMurcielagos);
            GameBootstrap.CreateEncounter(root, "cueva_bandidos", EncounterKind.CaveBandits, IslandPlacements.EncCuevaBandidos);

            // Objetos en el suelo
            WorldItemFactory.Spawn(itemDb["itemPico"], 1, IslandPlacements.ItemPico);
            WorldItemFactory.Spawn(itemDb["itemCoco"], 3, IslandPlacements.ItemCoco);
            WorldItemFactory.Spawn(itemDb["itemVenda"], 1, IslandPlacements.ItemVenda);
            WorldItemFactory.Spawn(itemDb["itemBotella"], 1, IslandPlacements.ItemBotella);
            WorldItemFactory.Spawn(itemDb["itemFruta"], 1, IslandPlacements.ItemFruta);
        }

        // ------------------------------------------------------------------ Suelo y agua

        private static void CreateGround(GameObject root)
        {
            GameObject ground = new GameObject("IslandGround");
            ground.transform.SetParent(root.transform, false);
            SpriteRenderer sr = ground.AddComponent<SpriteRenderer>();
            sr.sprite = GameSprites.Get("ground_island", BuildFallbackGround);
            sr.sortingOrder = OrderGround;

            GameObject water = new GameObject("Sea");
            water.transform.SetParent(root.transform, false);
            SpriteRenderer wsr = water.AddComponent<SpriteRenderer>();
            wsr.sprite = WorldArt.WaterTile();
            wsr.drawMode = SpriteDrawMode.Tiled;
            wsr.size = new Vector2(IslandLayout.GroundHalfSize * 2.6f, IslandLayout.GroundHalfSize * 2.6f);
            wsr.sortingOrder = OrderWater;
            water.AddComponent<WaterScroller>();
        }

        /// <summary>Suelo dibujado por código si falta Resources/Sprites/ground_island.png (8 px por unidad).</summary>
        private static Sprite BuildFallbackGround()
        {
            const int ppu = 8;
            float min = -IslandLayout.GroundHalfSize;
            int size = Mathf.RoundToInt(IslandLayout.GroundHalfSize * 2f) * ppu;
            Color32[] px = new Color32[size * size];
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    Vector2 p = new Vector2(min + (x + 0.5f) / ppu, min + (y + 0.5f) / ppu);
                    IslandLayout.Terrain t = IslandLayout.Sample(p, out float shore);
                    float n = PixelCanvas.Hash(x, y, 3) * 0.08f - 0.04f;
                    Color c;
                    switch (t)
                    {
                        case IslandLayout.Terrain.DeepWater: c = Color.clear; break;
                        case IslandLayout.Terrain.Shallow:
                            float k = Mathf.Clamp01(shore / IslandLayout.ShallowWidth);
                            c = shore < 0.2f ? new Color(0.95f, 0.98f, 1f) : Color.Lerp(new Color(0.3f, 0.7f, 0.8f), new Color(0.11f, 0.38f, 0.62f), k);
                            c.a = Mathf.Clamp01(1f - (k - 0.55f) / 0.45f);
                            break;
                        case IslandLayout.Terrain.WetSand: c = new Color(0.8f, 0.66f, 0.45f); break;
                        case IslandLayout.Terrain.Sand: c = new Color(0.92f, 0.78f, 0.52f); break;
                        case IslandLayout.Terrain.Path: c = new Color(0.82f, 0.58f, 0.36f); break;
                        case IslandLayout.Terrain.Plaza: c = new Color(0.62f, 0.66f, 0.6f); break;
                        case IslandLayout.Terrain.Rock: c = new Color(0.5f, 0.53f, 0.6f); break;
                        case IslandLayout.Terrain.CaveFloor: c = new Color(0.36f, 0.2f, 0.18f); break;
                        case IslandLayout.Terrain.Pond: c = new Color(0.25f, 0.58f, 0.82f); break;
                        case IslandLayout.Terrain.Plateau: c = new Color(0.42f, 0.74f, 0.32f); break;
                        default: c = new Color(0.36f, 0.66f, 0.3f); break;
                    }
                    if (c.a > 0f) { c.r += n; c.g += n; c.b += n; }
                    px[y * size + x] = c;
                }
            }
            Texture2D tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Point;
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.SetPixels32(px);
            tex.Apply(false, false);
            return Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), ppu, 0, SpriteMeshType.FullRect);
        }

        /// <summary>
        /// Todo el mar es SeaZone profunda (un anillo con la forma de la costa como agujero, muelle incluido como tierra).
        /// Beber agua de mar se hace en puntos pequeños de la orilla, no en todo el mar.
        /// </summary>
        private static void CreateSea(GameObject root)
        {
            GameObject sea = new GameObject("OceanBorder");
            sea.transform.SetParent(root.transform, false);
            PolygonCollider2D col = sea.AddComponent<PolygonCollider2D>();
            col.isTrigger = true;
            col.pathCount = 2;
            float o = IslandLayout.GroundHalfSize + 9f;
            col.SetPath(0, new[] { new Vector2(-o, -o), new Vector2(-o, o), new Vector2(o, o), new Vector2(o, -o) });
            col.SetPath(1, IslandLayout.BuildSeaHole(144));
            sea.AddComponent<SeaZone>();

            float[] drinkAngles = { 20f, 100f, 165f, 200f, 232f, 300f, 330f };
            foreach (float a in drinkAngles)
            {
                float rad = a * Mathf.Deg2Rad;
                Vector2 pos = new Vector2(Mathf.Cos(rad), Mathf.Sin(rad)) * (IslandLayout.ShoreRadius(rad) + 0.55f);
                GameObject point = new GameObject($"SaltWaterDrinkPoint_{a:0}");
                point.transform.SetParent(sea.transform, false);
                point.transform.position = pos;
                CircleCollider2D pc = point.AddComponent<CircleCollider2D>();
                pc.radius = 0.7f;
                pc.isTrigger = true; // no bloquea; sin SeaZone propio: no activa natación
                WaterSource water = point.AddComponent<WaterSource>();
                GameBootstrap.InjectField(water, "waterType", WaterType.SaltWater);
            }
        }

        private static void CreateBounds(GameObject root)
        {
            GameObject bounds = new GameObject("OuterWorldBounds");
            bounds.transform.SetParent(root.transform, false);
            // Muros invisibles justo fuera de los límites del mundo (WorldBoundsProvider)
            float w = IslandLayout.WorldHalfSize + 2f, len = w * 2f + 8f;
            Wall(bounds, "Bound_North", new Vector2(0f, w), new Vector2(len, 4f));
            Wall(bounds, "Bound_South", new Vector2(0f, -w), new Vector2(len, 4f));
            Wall(bounds, "Bound_East", new Vector2(w, 0f), new Vector2(4f, len));
            Wall(bounds, "Bound_West", new Vector2(-w, 0f), new Vector2(4f, len));
        }

        private static void Wall(GameObject parent, string name, Vector2 pos, Vector2 size)
        {
            GameObject wall = new GameObject(name);
            wall.transform.SetParent(parent.transform, false);
            wall.transform.localPosition = pos;
            BoxCollider2D col = wall.AddComponent<BoxCollider2D>();
            col.size = size;
        }

        private static void CreatePond(GameObject root)
        {
            // La charca va dibujada en el suelo; aquí solo el trigger para beber (no es SeaZone: no se nada en ella)
            GameObject pond = new GameObject("FreshWaterPond");
            pond.transform.SetParent(root.transform, false);
            pond.transform.position = IslandLayout.Pond;
            CapsuleCollider2D col = pond.AddComponent<CapsuleCollider2D>();
            col.direction = CapsuleDirection2D.Horizontal;
            col.size = new Vector2(IslandLayout.PondRx * 2f, IslandLayout.PondRy * 2f);
            col.isTrigger = true;
            WaterSource water = pond.AddComponent<WaterSource>();
            GameBootstrap.InjectField(water, "waterType", WaterType.FreshWater);
        }

        private static void CreatePier(GameObject root)
        {
            GameObject pier = new GameObject("Pier");
            pier.transform.SetParent(root.transform, false);
            float startY = IslandLayout.PierStartY;
            float length = IslandLayout.PierEndY - startY;
            float cx = (IslandLayout.PierMinX + IslandLayout.PierMaxX) * 0.5f;
            pier.transform.position = new Vector3(cx, startY + length * 0.5f, 0f);
            SpriteRenderer sr = pier.AddComponent<SpriteRenderer>();
            sr.sprite = GameSprites.Get("w_pier", WorldArt.PierPlank);
            sr.drawMode = SpriteDrawMode.Tiled;
            sr.size = new Vector2(IslandLayout.PierMaxX - IslandLayout.PierMinX, length);
            sr.sortingOrder = OrderPier;

            // Barandillas invisibles: el muelle es tierra, pero no se puede saltar al agua desde los lados
            float wallLen = length - 1.5f;
            foreach (float x in new[] { IslandLayout.PierMinX - 0.1f, IslandLayout.PierMaxX + 0.1f })
            {
                GameObject side = new GameObject("PierRail");
                side.transform.SetParent(pier.transform, false);
                side.transform.position = new Vector3(x, startY + 1.5f + wallLen * 0.5f, 0f);
                BoxCollider2D bc = side.AddComponent<BoxCollider2D>();
                bc.size = new Vector2(0.2f, wallLen);
            }
            GameObject end = new GameObject("PierEnd");
            end.transform.SetParent(pier.transform, false);
            end.transform.position = new Vector3(cx, IslandLayout.PierEndY + 0.1f, 0f);
            end.AddComponent<BoxCollider2D>().size = new Vector2(IslandLayout.PierMaxX - IslandLayout.PierMinX + 0.4f, 0.2f);

            for (float y = startY + 2f; y <= IslandLayout.PierEndY; y += 2.5f)
            {
                foreach (float x in new[] { IslandLayout.PierMinX - 0.05f, IslandLayout.PierMaxX + 0.05f })
                {
                    SpriteOnly(pier.transform, "Post", GameSprites.Get("w_pier_post", WorldArt.PierPost), new Vector2(x, y - 0.4f), true);
                }
            }

            // Bote amarrado en el muelle para zarpar a Isla Volcán Negro
            GameObject travelBoat = Solid(pier.transform, "BoteTravesiaVolcan", GameSprites.Get("w_rowboat", WorldArt.Rowboat), new Vector2(cx + 1.2f, IslandLayout.PierEndY - 2.5f), new Vector2(1.8f, 0.6f));
            CircleCollider2D travelTrig = travelBoat.AddComponent<CircleCollider2D>();
            travelTrig.radius = 1.6f;
            travelTrig.isTrigger = true;
            IslandTravelTrigger travelComp = travelBoat.AddComponent<IslandTravelTrigger>();
            travelComp.Setup(true, "Pulsa [E] para Zarpar rumbo a Isla Volcán Negro");
        }

        // ------------------------------------------------------------------ Cueva

        private static void CreateCave(GameObject root)
        {
            // Guarida de Contrabandistas: vieja mina oscura con una sola entrada
            GameObject cave = RockRing(root, "GuaridaContrabandistas", IslandLayout.Cave, IslandLayout.CaveInner, IslandLayout.CaveOuter,
                IslandLayout.CaveEntranceAngle, IslandLayout.CaveEntranceHalfWidth);
            cave.AddComponent<CaveZone>().Configure(IslandLayout.CaveInner + 0.2f);

            // Colina del Faro: acantilado alrededor de la meseta, se sube por la rampa
            RockRing(root, "ColinaDelFaro", IslandLayout.Hill, IslandLayout.HillInner, IslandLayout.HillOuter,
                IslandLayout.HillRampAngle, IslandLayout.HillRampHalfWidth);
        }

        /// <summary>Pared de roca en forma de "C" (arco exterior + arco interior) abierta por 'gapAngle'.</summary>
        private static GameObject RockRing(GameObject root, string name, Vector2 center, float innerRadius, float outerRadius, float gapAngle, float gapHalfWidth)
        {
            GameObject ring = new GameObject(name);
            ring.transform.SetParent(root.transform, false);
            ring.transform.position = center;

            PolygonCollider2D wall = ring.AddComponent<PolygonCollider2D>();
            const int steps = 40;
            float gapStart = gapAngle + gapHalfWidth;
            float sweep = 360f - gapHalfWidth * 2f;
            float outer = outerRadius - 0.5f, inner = innerRadius + 0.35f;
            Vector2[] pts = new Vector2[(steps + 1) * 2];
            for (int i = 0; i <= steps; i++)
            {
                float a = (gapStart + sweep * i / steps) * Mathf.Deg2Rad;
                pts[i] = new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * outer;
                float b = (gapStart + sweep * (steps - i) / steps) * Mathf.Deg2Rad;
                pts[steps + 1 + i] = new Vector2(Mathf.Cos(b), Mathf.Sin(b)) * inner;
            }
            wall.SetPath(0, pts);
            return ring;
        }

        // ------------------------------------------------------------------ Objetos

        private static void CreateScenery(Transform parent, IslandPlacements.Item item, Dictionary<string, ItemData> itemDb)
        {
            Vector2 p = item.pos;
            switch (item.kind)
            {
                case "palm":
                    Harvestable(parent, "Palmera", GameSprites.Get("w_palm", WorldArt.Palm), p, $"palmera_island_{palmCount++}",
                        ResourceType.Tree, "Palmera Tropical", ToolType.Axe, 3f, itemDb["itemMadera"], 0.20f, 50f, 2, 4);
                    break;
                case "tree":
                case "pine":
                case "treeround":
                case "autumn":
                    Harvestable(parent, "Arbol", TreeSprite(item.kind, item.variant), p, $"arbol_island_{treeCount++}",
                        ResourceType.Tree, "Árbol", ToolType.Axe, 3f, itemDb["itemMadera"], 0.18f, 35f, 1, 3);
                    break;
                case "rock":
                    Harvestable(parent, "Roca", GameSprites.Get("w_rock", () => WorldArt.Rock(false)), p, $"roca_island_{rockCount++}",
                        ResourceType.Rock, "Veta de Roca", ToolType.Pickaxe, 0f, itemDb["itemPiedra"], 0.36f, 50f, 2, 4);
                    break;
                case "ore":
                {
                    // Vetas de hierro: mineral siempre y, a veces, Kairoseki
                    GameObject vein = Harvestable(parent, "VetaCueva", GameSprites.Get("w_rock_ore", () => WorldArt.Rock(true)), p, $"veta_cueva_{oreCount++}",
                        ResourceType.Rock, "Veta de Hierro", ToolType.Pickaxe, 0f, itemDb["itemMineral"], 0.36f, 70f, 2, 3);
                    HarvestableResource res = vein.GetComponent<HarvestableResource>();
                    GameBootstrap.InjectField(res, "bonusDropItem", itemDb["itemKairoseki"]);
                    GameBootstrap.InjectField(res, "bonusDropChance", 0.2f);
                    GameBootstrap.InjectField(res, "respawnTimeMinutes", 3f);
                    break;
                }
                case "bush":
                {
                    // Arbustos: fibra con las manos (la base de cuerda, tela y vendas)
                    GameObject bush = Harvestable(parent, "Arbusto", GameSprites.Get("w_bush", () => WorldArt.Bush(false)), p, $"arbusto_island_{bushCount++}",
                        ResourceType.Bush, "Arbusto", ToolType.None, 10f, itemDb["itemFibra"], 0.2f, 10f, 2, 3);
                    GameBootstrap.InjectField(bush.GetComponent<HarvestableResource>(), "respawnTimeMinutes", 2.5f);
                    break;
                }
                case "forge":
                    Station(parent, "Forja", GameSprites.Get("w_forge", WorldArt.Crate), p, new Vector2(2.0f, 0.6f), StationType.Forge);
                    break;
                case "workbench":
                    Station(parent, "MesaDeTrabajo", GameSprites.Get("w_workbench", WorldArt.Crate), p, new Vector2(1.6f, 0.4f), StationType.Workbench);
                    break;
                case "marineflag":
                    Solid(parent, "BanderaMarina", GameSprites.Get("w_marineflag", WorldArt.Lantern), p, new Vector2(0.25f, 0.2f));
                    break;
                case "cannon":
                    Solid(parent, "Canon", GameSprites.Get("w_cannon", WorldArt.Barrel), p, new Vector2(1.2f, 0.4f));
                    break;
                case "mushroom":
                    SpriteOnly(parent, "Setas", GameSprites.Get("w_mushroom", () => WorldArt.Bush(true)), p, true);
                    break;
                case "sprout":
                    Flat(parent, "Brote", GameSprites.Get("w_sprout", WorldArt.GrassTuft), p);
                    break;
                case "shell":
                    Flat(parent, "Concha", GameSprites.Get("w_shell_" + item.variant, () => WorldArt.Shell(item.variant)), p);
                    break;
                case "driftwood":
                {
                    GameObject dw = Harvestable(parent, "Madera a la deriva", GameSprites.Get("w_driftwood", WorldArt.Driftwood), p, $"driftwood_{driftwoodCount++}",
                        ResourceType.Bush, "Madera a la deriva", ToolType.None, 10f, itemDb["itemMadera"], 0.25f, 8f, 1, 2);
                    GameBootstrap.InjectField(dw.GetComponent<HarvestableResource>(), "respawnTimeMinutes", 3f);
                    break;
                }
                case "herb":
                {
                    GameObject herb = Harvestable(parent, "Hierbas Medicinales", GameSprites.Get("w_sprout", WorldArt.GrassTuft), p, $"herb_{herbCount++}",
                        ResourceType.Bush, "Hierbas Medicinales", ToolType.None, 10f, itemDb["itemHierbas"], 0.25f, 6f, 1, 3);
                    GameBootstrap.InjectField(herb.GetComponent<HarvestableResource>(), "respawnTimeMinutes", 3f);
                    break;
                }
                case "ore_coal":
                {
                    GameObject coalVein = Harvestable(parent, "Veta de Carbón", GameSprites.Get("w_rock_ore", () => WorldArt.Rock(true)), p, $"veta_carbon_{coalCount++}",
                        ResourceType.Rock, "Veta de Carbón", ToolType.Pickaxe, 0f, itemDb["itemCarbon"], 0.45f, 60f, 2, 4);
                    HarvestableResource res = coalVein.GetComponent<HarvestableResource>();
                    GameBootstrap.InjectField(res, "bonusDropItem", itemDb["itemPiedra"]);
                    GameBootstrap.InjectField(res, "bonusDropChance", 0.5f);
                    GameBootstrap.InjectField(res, "respawnTimeMinutes", 4f);
                    break;
                }
                case "ore_sulfur":
                {
                    GameObject sulfurVein = Harvestable(parent, "Veta de Azufre", GameSprites.Get("w_rock_ore", () => WorldArt.Rock(true)), p, $"veta_azufre_{sulfurCount++}",
                        ResourceType.Rock, "Veta de Azufre", ToolType.Pickaxe, 0f, itemDb["itemAzufre"], 0.45f, 65f, 2, 3);
                    HarvestableResource res = sulfurVein.GetComponent<HarvestableResource>();
                    GameBootstrap.InjectField(res, "bonusDropItem", itemDb["itemPiedra"]);
                    GameBootstrap.InjectField(res, "bonusDropChance", 0.4f);
                    GameBootstrap.InjectField(res, "respawnTimeMinutes", 4f);
                    break;
                }
                case "flowers":
                    Flat(parent, "Flores", GameSprites.Get("w_flowers_" + item.variant, () => WorldArt.Flowers(item.variant)), p);
                    break;
                case "starfish":
                    Flat(parent, "Estrella de Mar", GameSprites.Get("w_starfish", WorldArt.Starfish), p);
                    break;
                case "anchor":
                    Solid(parent, "Ancla Antigua", GameSprites.Get("w_anchor", WorldArt.Anchor), p, new Vector2(1.1f, 0.45f));
                    break;
                case "fishrack":
                    Solid(parent, "Secadero de Pescado", GameSprites.Get("w_fishrack", WorldArt.FishRack), p, new Vector2(1.7f, 0.45f));
                    break;
                case "banner":
                    Solid(parent, "Estandarte", GameSprites.Get("w_banner_" + item.variant, () => WorldArt.Banner(item.variant)), p, new Vector2(0.35f, 0.2f));
                    break;
                case "crystal":
                {
                    GameObject cry = SpriteOnly(parent, "Cristal de Cueva", GameSprites.Get("w_crystal_" + item.variant, () => WorldArt.Crystal(item.variant)), p, true);
                    Glow(cry.transform, new Vector2(0f, 0.4f), 1.3f);
                    break;
                }
                case "boulder":
                    SpriteOnly(parent, "Pedrusco", GameSprites.Get("w_boulder_" + item.variant, () => WorldArt.Boulder(item.variant)), p, true);
                    break;
                case "stalagmite":
                    Solid(parent, "Estalagmita", GameSprites.Get("w_stalagmite", WorldArt.Stalagmite), p, new Vector2(0.4f, 0.25f));
                    break;
                case "house":
                {
                    Sprite s = item.variant == 4
                        ? GameSprites.Get("w_hut_0", () => WorldArt.House(0))
                        : GameSprites.Get("w_house_" + item.variant, () => WorldArt.House(item.variant % 4));
                    float w = s.bounds.size.x;
                    GameObject hGo = Solid(parent, "Casa", s, p, new Vector2(w - 0.5f, 1.0f));

                    // Trigger para hacer translúcido el tejado cuando el jugador camina detrás
                    GameObject roofTrig = new GameObject("RoofTrigger");
                    roofTrig.transform.SetParent(hGo.transform, false);
                    roofTrig.transform.localPosition = new Vector3(0f, 1.8f, 0f);
                    BoxCollider2D rCol = roofTrig.AddComponent<BoxCollider2D>();
                    rCol.size = new Vector2(w, 2.2f);
                    rCol.isTrigger = true;
                    roofTrig.AddComponent<RoofFadeTrigger>();
                    break;
                }
                case "stall":
                    Solid(parent, "Puesto", GameSprites.Get("w_stall", WorldArt.Stall), p, new Vector2(2.6f, 0.7f));
                    break;
                case "well":
                    CreateWell(parent, p);
                    break;
                case "fence":
                {
                    string key = item.variant == 0 ? "w_fence_l" : (item.variant == 2 ? "w_fence_r" : "w_fence");
                    Solid(parent, "Valla", GameSprites.Get(key, WorldArt.Fence), p, new Vector2(1f, 0.3f));
                    break;
                }
                case "lantern":
                {
                    GameObject go = Solid(parent, "Farol", GameSprites.Get("w_lantern", WorldArt.Lantern), p, new Vector2(0.25f, 0.2f));
                    Glow(go.transform, new Vector2(0f, 1.6f), 1.6f);
                    break;
                }
                case "barrel":
                    Solid(parent, "Barril", GameSprites.Get("w_barrel", WorldArt.Barrel), p, new Vector2(0.7f, 0.4f));
                    break;
                case "crate":
                    Solid(parent, "Caja", GameSprites.Get("w_crate", WorldArt.Crate), p, new Vector2(0.85f, 0.45f));
                    break;
                case "sack":
                    Solid(parent, "Saco", GameSprites.Get("w_sack", WorldArt.Crate), p, new Vector2(0.6f, 0.3f));
                    break;
                case "bucket":
                    Solid(parent, "Cubo", GameSprites.Get("w_bucket", WorldArt.Barrel), p, new Vector2(0.5f, 0.3f));
                    break;
                case "beehive":
                    Solid(parent, "Colmena", GameSprites.Get("w_beehive", WorldArt.Barrel), p, new Vector2(0.6f, 0.3f));
                    break;
                case "chest":
                {
                    GameObject chestObj = Solid(parent, "Cofre", GameSprites.Get("w_chest", WorldArt.Chest), p, new Vector2(0.9f, 0.4f));
                    TreasureChest chest = chestObj.AddComponent<TreasureChest>();
                    string cId = $"chest_{item.variant}_{Mathf.RoundToInt(p.x)}_{Mathf.RoundToInt(p.y)}";
                    int berries = 300 + (item.variant * 350);
                    List<string> lootItems = new List<string>();
                    List<int> lootQtys = new List<int>();

                    if (item.variant == 0) // Cofre costero / explorador
                    {
                        lootItems.Add("venda"); lootQtys.Add(2);
                        lootItems.Add("clavo_hierro"); lootQtys.Add(4);
                        lootItems.Add("botella_vacia"); lootQtys.Add(1);
                        lootItems.Add("madera"); lootQtys.Add(3);
                    }
                    else if (item.variant == 1) // Cofre pirata
                    {
                        lootItems.Add("ron_pirata"); lootQtys.Add(2);
                        lootItems.Add("polvora"); lootQtys.Add(4);
                        lootItems.Add("balas_plomo"); lootQtys.Add(6);
                        berries = 800;
                    }
                    else if (item.variant == 2) // Gran tesoro de la cueva
                    {
                        lootItems.Add("pistola_chispa"); lootQtys.Add(1);
                        lootItems.Add("balas_plomo"); lootQtys.Add(10);
                        lootItems.Add("botiquin"); lootQtys.Add(1);
                        lootItems.Add("perla_marina"); lootQtys.Add(2);
                        berries = 2500;
                    }
                    else // Alijo del faro / militar
                    {
                        lootItems.Add("lingote_acero"); lootQtys.Add(2);
                        lootItems.Add("cuero"); lootQtys.Add(3);
                        lootItems.Add("infusion_herbal"); lootQtys.Add(2);
                        lootItems.Add("antidoto"); lootQtys.Add(1);
                        berries = 1200;
                    }

                    chest.Configure(cId, berries, lootItems.ToArray(), lootQtys.ToArray());
                    break;
                }
                case "tent":
                {
                    GameObject tentObj = Solid(parent, "Tienda", GameSprites.Get("w_tent", WorldArt.Tent), p, new Vector2(2.1f, 0.8f));
                    RestingSpot spot = tentObj.AddComponent<RestingSpot>();
                    spot.Configure("la Tienda de Campaña", 6f);
                    break;
                }
                case "wreck":
                    Solid(parent, "Naufragio", GameSprites.Get("w_wreck", WorldArt.Wreck), p, new Vector2(3.4f, 0.7f));
                    break;
                case "rowboat":
                    Solid(parent, "Bote", GameSprites.Get("w_rowboat", WorldArt.Rowboat), p, new Vector2(1.8f, 0.5f));
                    break;
                case "ship":
                    // Fondeado en agua profunda: se rodea nadando, no se atraviesa
                    Solid(parent, "BarcoCuervo", GameSprites.Get("w_ship", WorldArt.Ship), p, new Vector2(6.6f, 1.6f));
                    break;
                case "campfire":
                    CreateFire(parent, p, true);
                    break;
                case "torch":
                    CreateFire(parent, p, false);
                    break;
                case "sign":
                    CreateSign(parent, p, item.variant);
                    break;
                // Fauna con combate en tiempo real (clic / F): vida, ataque, botín y reaparición
                case "spider": CreateCreature(parent, p, CreatureKind.Spider, null, GameSprites.Get("c_spider", WorldArt.Spider)); break;
                case "bat": CreateCreature(parent, p, CreatureKind.Bat, null, GameSprites.Get("c_bat", WorldArt.Bat)); break;
                case "crab": CreateCreature(parent, p, CreatureKind.Crab, itemDb["itemCarneCangrejo"], GameSprites.Get("c_crab", () => WorldArt.Bush(false))); break;
                case "boar": break;
                case "rat": CreateCreature(parent, p, CreatureKind.Rat, itemDb["itemCarneCruda"], GameSprites.Get("c_rat", () => WorldArt.Bush(false))); break;
                case "stones":
                {
                    // Piedras sueltas: piedra con las manos (rompe el círculo "sin pico no hay piedra, sin piedra no hay pico")
                    GameObject stones = Harvestable(parent, "PiedrasSueltas", GameSprites.Get("w_stones", () => WorldArt.Rock(false)), p, $"piedras_sueltas_{stoneCount++}",
                        ResourceType.Bush, "Piedras sueltas", ToolType.None, 10f, itemDb["itemPiedra"], 0.15f, 10f, 1, 2);
                    GameBootstrap.InjectField(stones.GetComponent<HarvestableResource>(), "respawnTimeMinutes", 2f);
                    break;
                }
                case "tavern":
                    Solid(parent, "GranTaberna", GameSprites.Get("w_tavern", WorldArt.Tavern), p, new Vector2(4.0f, 1.2f));
                    break;
                case "townhall":
                    Solid(parent, "Ayuntamiento", GameSprites.Get("w_townhall", WorldArt.TownHall), p, new Vector2(4.5f, 1.4f));
                    break;
                case "lighthouse":
                    Solid(parent, "GranFaro", GameSprites.Get("w_lighthouse", WorldArt.Lighthouse), p, new Vector2(2.2f, 1.0f));
                    Glow(parent, p + new Vector2(0f, 3.8f), 4.5f);
                    break;
                case "fountain":
                    Solid(parent, "FuentePlaza", GameSprites.Get("w_fountain", WorldArt.Fountain), p, new Vector2(2.2f, 1.0f));
                    break;
                case "drydock":
                    Solid(parent, "Astillero", GameSprites.Get("w_drydock", WorldArt.Drydock), p, new Vector2(3.2f, 1.0f));
                    break;
                case "defense_cannon":
                    Solid(parent, "CanonDefensa", GameSprites.Get("w_cannon_defense", WorldArt.CannonDefense), p, new Vector2(1.6f, 0.6f));
                    break;
                case "easter_barrel":
                    CreateEasterEgg(parent, p, "barrel");
                    break;
                case "easter_wanted":
                    CreateEasterEgg(parent, p, "wanted");
                    break;
                case "easter_sword":
                    CreateEasterEgg(parent, p, "sword");
                    break;
                case "easter_bottle":
                    CreateEasterEgg(parent, p, "bottle");
                    break;
                case "easter_poneglyph":
                    CreateEasterEgg(parent, p, "poneglyph");
                    break;
                default:
                    Debug.LogWarning($"[IslandBuilder] Tipo de objeto desconocido: {item.kind}");
                    break;
            }
        }

        private static Sprite TreeSprite(string kind, int variant)
        {
            switch (kind)
            {
                case "pine": return GameSprites.Get(variant == 0 ? "w_pine" : "w_pine_dark", () => WorldArt.Pine(variant != 0));
                case "treeround": return GameSprites.Get("w_tree_round", WorldArt.TreeRound);
                case "autumn": return GameSprites.Get("w_autumn_" + variant, () => WorldArt.AutumnTree(variant));
                default: return GameSprites.Get("w_tree", WorldArt.Tree);
            }
        }

        private static GameObject Harvestable(Transform parent, string name, Sprite sprite, Vector2 pos, string id, ResourceType type,
            string displayName, ToolType tool, float unarmedDamage, ItemData drop, float colliderRadius, float health, int minDrop, int maxDrop)
        {
            GameObject go = SpriteOnly(parent, name, sprite, pos, true);
            CircleCollider2D col = go.AddComponent<CircleCollider2D>();
            col.radius = colliderRadius;
            col.offset = new Vector2(0f, colliderRadius * 0.6f);

            HarvestableResource res = go.AddComponent<HarvestableResource>();
            res.SetResourceId(id);
            GameBootstrap.InjectField(res, "resourceType", type);
            GameBootstrap.InjectField(res, "resourceName", displayName);
            GameBootstrap.InjectField(res, "requiredTool", tool);
            GameBootstrap.InjectField(res, "unarmedDamage", unarmedDamage);
            GameBootstrap.InjectField(res, "dropItem", drop);
            GameBootstrap.InjectField(res, "maxHealth", health);
            GameBootstrap.InjectField(res, "currentHealth", health); // Awake ya copió la vida por defecto
            GameBootstrap.InjectField(res, "minDropAmount", minDrop);
            GameBootstrap.InjectField(res, "maxDropAmount", maxDrop);
            return go;
        }

        private static void Station(Transform parent, string name, Sprite sprite, Vector2 pos, Vector2 baseSize, StationType type)
        {
            GameObject go = Solid(parent, name, sprite, pos, baseSize);
            go.AddComponent<CraftingStation>().Configure(type, 2.6f);
        }

        private static void CreateWell(Transform parent, Vector2 pos)
        {
            GameObject go = Solid(parent, "Pozo", GameSprites.Get("w_well", WorldArt.Well), pos, new Vector2(0.9f, 0.5f));
            // El agua va en un hijo con trigger propio: el pozo sigue siendo sólido aunque WaterSource marque su collider como trigger
            GameObject spot = new GameObject("AguaDelPozo");
            spot.transform.SetParent(go.transform, false);
            CircleCollider2D trigger = spot.AddComponent<CircleCollider2D>();
            trigger.radius = 0.7f;
            trigger.offset = new Vector2(0f, 0.3f);
            trigger.isTrigger = true;
            WaterSource water = spot.AddComponent<WaterSource>();
            GameBootstrap.InjectField(water, "waterType", WaterType.FreshWater);
            GameBootstrap.InjectField(water, "thirstRecovery", 30f);
        }

        private static void CreateFire(Transform parent, Vector2 pos, bool campfire)
        {
            GameObject go = campfire
                ? Solid(parent, "Hoguera", GameSprites.Get("w_campfire", WorldArt.CampfireBase), pos, new Vector2(0.9f, 0.4f))
                : SpriteOnly(parent, "Antorcha", GameSprites.Get("w_torch", WorldArt.Torch), pos, true);

            Sprite[] frames = { GameSprites.Get("w_flame_0", () => WorldArt.Flame(0)), GameSprites.Get("w_flame_1", () => WorldArt.Flame(1)) };
            GameObject flame = new GameObject("Llama");
            flame.transform.SetParent(go.transform, false);
            flame.transform.localPosition = campfire ? new Vector3(0f, 0.15f, 0f) : new Vector3(0f, 0.68f, 0f);
            if (!campfire) flame.transform.localScale = Vector3.one * 0.6f;
            SpriteRenderer fsr = flame.AddComponent<SpriteRenderer>();
            fsr.sprite = frames[0];

            SpriteRenderer glow = Glow(go.transform, campfire ? new Vector2(0f, 0.4f) : new Vector2(0f, 0.85f), campfire ? 3.2f : 2.2f);
            go.AddComponent<Campfire>().Configure(fsr, frames, glow, campfire ? 2.2f : 0f);
            if (campfire)
            {
                go.AddComponent<CraftingStation>().Configure(StationType.Campfire, 2.6f);
            }

            // La llama siempre por delante de su base
            YSorter sorter = go.GetComponent<YSorter>();
            if (sorter != null) sorter.SyncChildRenderers = true;
        }

        private static SpriteRenderer Glow(Transform parent, Vector2 offset, float size)
        {
            GameObject g = new GameObject("Halo");
            g.transform.SetParent(parent, false);
            g.transform.localPosition = offset;
            SpriteRenderer sr = g.AddComponent<SpriteRenderer>();
            sr.sprite = WorldArt.Glow();
            sr.drawMode = SpriteDrawMode.Simple;
            g.transform.localScale = Vector3.one * (size / 2f);
            sr.sortingOrder = 32000; // halo encima del suelo y los objetos cercanos
            return sr;
        }

        private static void CreateCreature(Transform parent, Vector2 pos, CreatureKind kind, ItemData drop, Sprite sprite)
        {
            GameObject go = new GameObject(kind.ToString());
            go.transform.SetParent(parent, false);
            go.transform.position = pos;
            GameObject visual = new GameObject("Visual");
            visual.transform.SetParent(go.transform, false);
            SpriteRenderer sr = visual.AddComponent<SpriteRenderer>();
            sr.sprite = sprite;
            YSorter sorter = visual.AddComponent<YSorter>();
            sorter.TargetRenderer = sr;
            CircleCollider2D col = go.AddComponent<CircleCollider2D>();
            col.radius = 0.3f;
            go.AddComponent<Rigidbody2D>().gravityScale = 0f;
            go.AddComponent<Creature>().Configure(kind, drop);
        }

        private static void CreateSign(Transform parent, Vector2 pos, int variant)
        {
            GameObject go = Solid(parent, "Cartel", GameSprites.Get("w_sign", WorldArt.Sign), pos, new Vector2(0.6f, 0.3f));
            string[] text;
            switch (variant)
            {
                case 0: text = new[] { "PUERTO DE ALDEA CORAL. Pozo de agua dulce en la plaza.", "Al norte, el muelle. Al sureste, la playa de los piratas. Al noroeste, la Colina del Faro." }; break;
                case 1: text = new[] { "VIEJA MINA. ¡Prohibido el paso! — firmado: nadie.", "Las vetas de hierro se pican con un pico. Al fondo dicen que acampan contrabandistas." }; break;
                case 2: text = new[] { "COLINA DEL FARO. Sube por la rampa.", "Desde arriba se ve toda Isla Coral." }; break;
                default: text = new[] { "PLAYA DEL NAUFRAGIO.", "Piedras sueltas por la arena: cógelas con [E]. Con madera y cuerda harás un pico." }; break;
            }
            go.AddComponent<VillagerNpc>().Configure("Cartel", text, true, null);
        }

        private static void CreateEasterEgg(Transform parent, Vector2 pos, string kind)
        {
            switch (kind)
            {
                case "barrel":
                {
                    GameObject go = Solid(parent, "BarrilLuffy", GameSprites.Get("w_easter_barrel", WorldArt.EasterBarrel), pos, new Vector2(0.9f, 0.5f));
                    TreasureChest chest = go.AddComponent<TreasureChest>();
                    chest.Configure("easter_barrel_luffy", 500, new[] { "carne_asada", "sombrero_paja", "ron_pirata" }, new[] { 3, 1, 1 });
                    break;
                }
                case "wanted":
                {
                    GameObject go = Solid(parent, "CartelRecompensa", GameSprites.Get("w_wanted_poster", WorldArt.WantedPoster), pos, new Vector2(0.8f, 0.3f));
                    string[] text = new[]
                    {
                        "¡CARTEL DE RECOMPENSA DE LA MARINA!",
                        "DEAD OR ALIVE: Rui \"Puño de Ancla\" Tormenta — 30.000.000 Berries.",
                        "En una esquina alguien ha garabateado: '¡Algún día seré el Rey de los Piratas!'"
                    };
                    go.AddComponent<VillagerNpc>().Configure("Cartel de Se Busca", text, true, null);
                    break;
                }
                case "sword":
                {
                    GameObject go = Solid(parent, "MonumentoEspada", GameSprites.Get("w_sword_monument", WorldArt.SwordMonument), pos, new Vector2(1.0f, 0.4f));
                    string[] text = new[]
                    {
                        "Una elegante katana blanca de empuñadura impoluta descansa clavada en la roca ante el mar infinito.",
                        "Grabado en el pedestal: 'Una promesa hecha a un alma eterna. Mi nombre resonará hasta los cielos...'"
                    };
                    go.AddComponent<VillagerNpc>().Configure("Monumento del Espadachín", text, true, null);
                    break;
                }
                case "bottle":
                {
                    GameObject go = SpriteOnly(parent, "MensajeBotella", GameSprites.Get("w_message_bottle", WorldArt.MessageBottle), pos, true);
                    CircleCollider2D col = go.AddComponent<CircleCollider2D>();
                    col.radius = 0.5f;
                    string[] text = new[]
                    {
                        "Descorchas la botella y desenrollas un pergamino firmado con una 'D':",
                        "'¿Mi tesoro? Si lo queréis, os lo daré... ¡Buscadlo! ¡Dejé todo lo que poseo en ese lugar!' — Gol D. Roger"
                    };
                    go.AddComponent<VillagerNpc>().Configure("Mensaje en una Botella", text, true, null);
                    break;
                }
                case "poneglyph":
                {
                    GameObject go = Solid(parent, "Poneglyph", GameSprites.Get("w_poneglyph", WorldArt.Poneglyph), pos, new Vector2(2.0f, 0.8f));
                    Glow(go.transform, new Vector2(0f, 1.2f), 2.2f);
                    string[] text = new[]
                    {
                        "Un gigantesco monolito de piedra indestructible cubierto de extraños glifos ancestrales tallados.",
                        "Emana una energía imponente. Las leyendas del mar lo llaman 'Poneglyph': guardián de los secretos del Siglo Vacío."
                    };
                    go.AddComponent<VillagerNpc>().Configure("Monolito Ancestral (Poneglyph)", text, true, null);
                    break;
                }
            }
        }

        // ------------------------------------------------------------------ Aldeanos

        private static void CreateVillagers(GameObject root)
        {
            Transform parent = Child(root.transform, "Aldeanos");
            Villager(parent, "Abuela Marea", "c_villager_3", IslandPlacements.NpcAbuela, "abuela");
            Villager(parent, "Alcaldesa Coral", "c_villager_2", IslandPlacements.NpcAlcaldesa, "alcaldesa");
            Villager(parent, "Tetsu el herrero", "c_herrero", IslandPlacements.NpcHerrero, "herrero");
            Villager(parent, "Maese Tablón", "c_carpintero", IslandPlacements.NpcCarpintero, "carpintero");
            Villager(parent, "Lola la tabernera", "c_tabernera", IslandPlacements.NpcTabernera, "tabernera");
            Villager(parent, "Ramón el mercader", "c_villager_1", IslandPlacements.NpcMercader, "mercader");
            Villager(parent, "Tico", "c_villager_0", IslandPlacements.NpcNino, "nino");
            Villager(parent, "Bruno el pescador", "c_villager_4", IslandPlacements.NpcPescador, "pescador");
            Villager(parent, "Cabo Rocco", "c_marine", IslandPlacements.NpcMarine, "marine");
            Villager(parent, "Doctor Tonic", "c_boticario", IslandPlacements.NpcBoticario, "boticario");
            Villager(parent, "Kenshi el Extraviado", "c_kenshi", IslandPlacements.NpcKenshi, "kenshi");
            Villager(parent, "Tirador Misterioso", "c_sogeking", IslandPlacements.NpcSogeking, "sogeking");
            Villager(parent, "Viejo Timón", "c_timon", IslandPlacements.NpcTimon, "timon");
        }

        private static void Villager(Transform parent, string npcName, string spriteKey, Vector2 pos, string dialogueId)
        {
            GameObject go = new GameObject(npcName);
            go.transform.SetParent(parent, false);
            go.transform.position = pos;
            GameObject visual = new GameObject("Visual");
            visual.transform.SetParent(go.transform, false);
            SpriteRenderer sr = visual.AddComponent<SpriteRenderer>();
            sr.sprite = RuntimeSpriteCache.Get("op_" + spriteKey, () => CharacterArt.Draw(VillagerLook(spriteKey)));
            YSorter sorter = visual.AddComponent<YSorter>();
            sorter.TargetRenderer = sr;
            sorter.IsStatic = true;
            CircleCollider2D col = go.AddComponent<CircleCollider2D>();
            col.radius = 0.3f;
            col.offset = new Vector2(0f, -0.1f); // los pies quedan 0.2 por debajo del pivote, como el jugador
            VillagerNpc npc = go.AddComponent<VillagerNpc>();
            npc.Configure(npcName, new[] { "..." }, false, visual.transform);
            npc.SetDialogue(NpcDialogues.For(dialogueId));

            GameObject shadow = new GameObject("DropShadow");
            shadow.transform.SetParent(go.transform, false);
            shadow.transform.localPosition = new Vector3(0f, -0.2f, 0f);
            SpriteRenderer ssr = shadow.AddComponent<SpriteRenderer>();
            ssr.sprite = WorldArt.DropShadow();
            ssr.sortingOrder = -4400;
        }

        private static CharacterLook VillagerLook(string key)
        {
            switch (key)
            {
                case "c_herrero":
                    // Tetsu el herrero: Wano moderno / rudo artesano con gafas y fajín
                    return new CharacterLook
                    {
                        skin = CharacterArt.SkinTan,
                        hair = new Color(0.15f, 0.12f, 0.1f),
                        shirt = new Color(0.2f, 0.22f, 0.26f),
                        pants = new Color(0.85f, 0.25f, 0.2f),
                        shoes = new Color(0.15f, 0.12f, 0.1f),
                        hatColor = new Color(0.9f, 0.2f, 0.2f),
                        accent = new Color(0.95f, 0.8f, 0.25f),
                        hat = HatStyle.Goggles,
                        shirtStyle = ShirtStyle.OpenVest,
                        held = HeldItem.Hammer,
                        beard = true
                    };

                case "c_tabernera":
                    // Lola la tabernera: Pirata chic moderna (estilo Nami/Shakky en color spreads)
                    return new CharacterLook
                    {
                        skin = CharacterArt.SkinLight,
                        hair = new Color(0.95f, 0.5f, 0.15f),
                        shirt = new Color(0.18f, 0.55f, 0.72f),
                        pants = new Color(0.95f, 0.95f, 0.95f),
                        shoes = new Color(0.8f, 0.3f, 0.3f),
                        hatColor = Color.clear,
                        accent = new Color(1f, 0.82f, 0.25f),
                        hat = HatStyle.None,
                        shirtStyle = ShirtStyle.ModernJacket,
                        shortPants = true,
                        sunglasses = true,
                        longHair = true
                    };

                case "c_villager_2":
                    // Alcaldesa Coral: Capitana/Alcaldesa con abrigo de seda y charreteras
                    return new CharacterLook
                    {
                        skin = CharacterArt.SkinLight,
                        hair = new Color(0.55f, 0.15f, 0.25f),
                        shirt = new Color(0.12f, 0.18f, 0.28f),
                        pants = new Color(0.12f, 0.18f, 0.28f),
                        shoes = new Color(0.85f, 0.75f, 0.3f),
                        hatColor = new Color(0.95f, 0.95f, 0.95f),
                        accent = new Color(1f, 0.82f, 0.28f),
                        hat = HatStyle.None,
                        shirtStyle = ShirtStyle.Coat,
                        cape = true,
                        longHair = true
                    };

                case "c_carpintero":
                    // Maese Tablón: Estilo Galley-La moderno (como Franky / Paulie)
                    return new CharacterLook
                    {
                        skin = CharacterArt.SkinTan,
                        hair = new Color(0.2f, 0.6f, 0.75f),
                        shirt = new Color(0.92f, 0.45f, 0.15f),
                        pants = new Color(0.3f, 0.32f, 0.38f),
                        shoes = new Color(0.2f, 0.2f, 0.2f),
                        hatColor = new Color(0.95f, 0.8f, 0.3f),
                        accent = new Color(1f, 0.9f, 0.4f),
                        hat = HatStyle.Goggles,
                        shirtStyle = ShirtStyle.Hawaiian,
                        shortPants = true,
                        beard = true
                    };

                case "c_villager_4":
                    // Bruno el pescador: Bucanero moderno con arpón y gafas de sol
                    return new CharacterLook
                    {
                        skin = CharacterArt.SkinTan,
                        hair = new Color(0.2f, 0.18f, 0.15f),
                        shirt = new Color(0.15f, 0.35f, 0.45f),
                        pants = new Color(0.22f, 0.25f, 0.3f),
                        shoes = new Color(0.25f, 0.18f, 0.12f),
                        hatColor = new Color(0.18f, 0.2f, 0.25f),
                        accent = new Color(0.3f, 0.8f, 1f),
                        hat = HatStyle.Bandana,
                        shirtStyle = ShirtStyle.OpenVest,
                        held = HeldItem.FishingRod,
                        shortPants = true,
                        sunglasses = true,
                        beard = true
                    };

                case "c_marine":
                    // Cabo Rocco: Oficial de la Marina con capa de Justicia ("Seigi")
                    return new CharacterLook
                    {
                        skin = CharacterArt.SkinTan,
                        hair = new Color(0.25f, 0.2f, 0.15f),
                        shirt = new Color(0.15f, 0.25f, 0.48f),
                        pants = new Color(0.92f, 0.92f, 0.95f),
                        shoes = new Color(0.1f, 0.1f, 0.15f),
                        hatColor = Color.white,
                        accent = new Color(0.15f, 0.25f, 0.48f),
                        hat = HatStyle.MarineCap,
                        shirtStyle = ShirtStyle.Plain,
                        held = HeldItem.Sword,
                        cape = true
                    };

                case "c_villager_1":
                    // Ramón el mercader: Contrabandista moderno con fedora y pluma
                    return new CharacterLook
                    {
                        skin = CharacterArt.SkinLight,
                        hair = new Color(0.45f, 0.3f, 0.15f),
                        shirt = new Color(0.6f, 0.22f, 0.45f),
                        pants = new Color(0.25f, 0.22f, 0.2f),
                        shoes = new Color(0.3f, 0.2f, 0.15f),
                        hatColor = new Color(0.35f, 0.22f, 0.35f),
                        accent = new Color(1f, 0.82f, 0.25f),
                        hat = HatStyle.Fedora,
                        shirtStyle = ShirtStyle.Striped,
                        held = HeldItem.Basket
                    };

                case "c_villager_0":
                    // Tico (niño): grumete del puerto con gorra de lana y camiseta de rayas
                    return new CharacterLook
                    {
                        skin = CharacterArt.SkinTan,
                        hair = new Color(0.55f, 0.32f, 0.15f),
                        shirt = new Color(0.25f, 0.45f, 0.75f),
                        pants = new Color(0.55f, 0.45f, 0.3f),
                        shoes = new Color(0.45f, 0.3f, 0.15f),
                        hatColor = new Color(0.85f, 0.55f, 0.2f),
                        accent = new Color(0.95f, 0.95f, 0.9f),
                        hat = HatStyle.Headscarf,
                        shirtStyle = ShirtStyle.Striped,
                        shortPants = true
                    };

                case "c_boticario":
                    // Doctor Tonic: Boticario con bata aguamarina, anteojos y bolso
                    return new CharacterLook
                    {
                        skin = CharacterArt.SkinLight,
                        hair = new Color(0.35f, 0.25f, 0.2f),
                        shirt = new Color(0.2f, 0.6f, 0.5f),
                        pants = new Color(0.25f, 0.3f, 0.35f),
                        shoes = new Color(0.2f, 0.15f, 0.1f),
                        hatColor = new Color(0.9f, 0.85f, 0.7f),
                        accent = new Color(0.1f, 0.8f, 0.4f),
                        hat = HatStyle.None,
                        shirtStyle = ShirtStyle.Coat,
                        held = HeldItem.Basket
                    };

                case "c_kenshi":
                    // Kenshi el Extraviado (Zoro Easter Egg): Pelo verde, cicatriz, haramaki y espada
                    return new CharacterLook
                    {
                        skin = CharacterArt.SkinTan,
                        hair = new Color(0.2f, 0.75f, 0.3f),
                        shirt = new Color(0.12f, 0.35f, 0.2f),
                        pants = new Color(0.15f, 0.2f, 0.18f),
                        shoes = new Color(0.12f, 0.1f, 0.08f),
                        hatColor = Color.clear,
                        accent = new Color(0.3f, 0.8f, 0.35f),
                        hat = HatStyle.None,
                        shirtStyle = ShirtStyle.OpenVest,
                        held = HeldItem.Sword,
                        eyePatch = true
                    };

                case "c_sogeking":
                    // Tirador Misterioso (Usopp Easter Egg): Pelo rizado, bandana y gafas tácticas
                    return new CharacterLook
                    {
                        skin = CharacterArt.SkinDark,
                        hair = new Color(0.12f, 0.1f, 0.1f),
                        shirt = new Color(0.75f, 0.55f, 0.25f),
                        pants = new Color(0.7f, 0.5f, 0.2f),
                        shoes = new Color(0.2f, 0.15f, 0.1f),
                        hatColor = new Color(0.95f, 0.85f, 0.3f),
                        accent = new Color(0.2f, 0.6f, 0.9f),
                        hat = HatStyle.Goggles,
                        shirtStyle = ShirtStyle.Striped,
                        held = HeldItem.Pistol,
                        shortPants = true
                    };

                case "c_timon":
                    // Viejo Timón (Guardián del Faro): Barba blanca canosa, gorra marinera y abrigo
                    return new CharacterLook
                    {
                        skin = CharacterArt.SkinTan,
                        hair = new Color(0.9f, 0.92f, 0.95f),
                        shirt = new Color(0.1f, 0.15f, 0.3f),
                        pants = new Color(0.15f, 0.18f, 0.28f),
                        shoes = new Color(0.1f, 0.1f, 0.1f),
                        hatColor = Color.white,
                        accent = new Color(0.95f, 0.8f, 0.25f),
                        hat = HatStyle.MarineCap,
                        shirtStyle = ShirtStyle.Coat,
                        held = HeldItem.FishingRod,
                        beard = true
                    };

                case "c_villager_3":
                default:
                    // Abuela Marea: Sabia navegante con foulard aguamarina y capa
                    return new CharacterLook
                    {
                        skin = CharacterArt.SkinLight,
                        hair = new Color(0.88f, 0.88f, 0.9f),
                        shirt = new Color(0.25f, 0.55f, 0.52f),
                        pants = new Color(0.2f, 0.3f, 0.35f),
                        shoes = new Color(0.35f, 0.25f, 0.15f),
                        hatColor = new Color(0.2f, 0.65f, 0.6f),
                        accent = new Color(1f, 0.85f, 0.4f),
                        hat = HatStyle.Headscarf,
                        shirtStyle = ShirtStyle.Dress,
                        cape = true,
                        longHair = true
                    };
            }
        }

        // ------------------------------------------------------------------ Utilidades

        private static Transform Child(Transform parent, string name)
        {
            GameObject go = new GameObject(name);
            go.transform.SetParent(parent, false);
            return go.transform;
        }

        /// <summary>Sprite con orden por Y (o fijo si sortByY = false).</summary>
        private static GameObject SpriteOnly(Transform parent, string name, Sprite sprite, Vector2 pos, bool staticSort)
        {
            GameObject go = new GameObject(name);
            go.transform.SetParent(parent, false);
            go.transform.position = pos;
            SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = sprite;
            YSorter sorter = go.AddComponent<YSorter>();
            sorter.TargetRenderer = sr;
            sorter.IsStatic = staticSort;
            return go;
        }

        /// <summary>Sprite plano pegado al suelo (conchas, brotes): siempre por debajo de personajes y objetos.</summary>
        private static void Flat(Transform parent, string name, Sprite sprite, Vector2 pos)
        {
            GameObject go = new GameObject(name);
            go.transform.SetParent(parent, false);
            go.transform.position = pos;
            SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = sprite;
            sr.sortingOrder = OrderGroundDecor;
        }

        /// <summary>Objeto sólido: collider de caja en la base (los pies), centrado horizontalmente.</summary>
        private static GameObject Solid(Transform parent, string name, Sprite sprite, Vector2 pos, Vector2 baseSize)
        {
            GameObject go = SpriteOnly(parent, name, sprite, pos, true);
            BoxCollider2D col = go.AddComponent<BoxCollider2D>();
            col.size = baseSize;
            col.offset = new Vector2(0f, baseSize.y * 0.5f);
            return go;
        }
    }
}
