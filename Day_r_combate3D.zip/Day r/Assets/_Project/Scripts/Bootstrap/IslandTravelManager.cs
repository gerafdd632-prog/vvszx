﻿using UnityEngine;
using PirateSurvival.Core;
using PirateSurvival.Player;
using PirateSurvival.Environment;

namespace PirateSurvival.Bootstrap
{
    /// <summary>
    /// Gestiona las travesías marinas entre Isla 1 (Isla Coral) e Isla 2 (Isla Volcán Negro).
    /// Reconfigura WorldBoundsProvider, reposiciona al jugador y emite los efectos de viaje.
    /// </summary>
    public static class IslandTravelManager
    {
        public static bool IsOnIsland2 { get; private set; }

        public static void TravelToIsland2(PlayerController2D player = null)
        {
            if (player == null) player = Object.FindFirstObjectByType<PlayerController2D>();
            if (player == null) return;

            IsOnIsland2 = true;
            WorldBoundsProvider.Configure(Island2Layout.WorldMin, Island2Layout.WorldMax);

            Vector2 destination = Island2Layout.Dock + new Vector2(1.8f, 0.8f);
            player.transform.position = destination;

            // Centrar cámara en el destino de inmediato
            Camera2D cam = Object.FindFirstObjectByType<Camera2D>();
            if (cam != null)
            {
                cam.transform.position = new Vector3(destination.x, destination.y, cam.transform.position.z);
            }

            if (AudioManager.Instance != null) AudioManager.Instance.PlayLevelUp();
            GameEvents.TriggerNotificationMessage("¡Levando anclas! El barco cruza aguas humeantes... ¡Has llegado a Isla Volcán Negro!");
            Debug.Log("[IslandTravel] Viaje completado a Isla Volcán Negro (Isla 2). Posición: " + destination);
        }

        public static void TravelToIsland1(PlayerController2D player = null)
        {
            if (player == null) player = Object.FindFirstObjectByType<PlayerController2D>();
            if (player == null) return;

            IsOnIsland2 = false;
            WorldBoundsProvider.Configure(
                new Vector2(-IslandLayout.WorldHalfSize, -IslandLayout.WorldHalfSize),
                new Vector2(IslandLayout.WorldHalfSize, IslandLayout.WorldHalfSize)
            );

            Vector2 destination = new Vector2(17.3f, 25.0f); // Muelle de Aldea Coral
            player.transform.position = destination;

            Camera2D cam = Object.FindFirstObjectByType<Camera2D>();
            if (cam != null)
            {
                cam.transform.position = new Vector3(destination.x, destination.y, cam.transform.position.z);
            }

            if (AudioManager.Instance != null) AudioManager.Instance.PlayUiClick();
            GameEvents.TriggerNotificationMessage("¡Rumbo de vuelta fijado! Amarras el barco en el muelle de Isla Coral.");
            Debug.Log("[IslandTravel] Viaje completado a Isla Coral (Isla 1). Posición: " + destination);
        }
    }
}
