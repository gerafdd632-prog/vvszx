﻿using System.Collections.Generic;
using UnityEngine;

namespace PirateSurvival.Bootstrap
{
    /// <summary>
    /// Plano de la Isla 1 (Isla Coral): costa, zonas y caminos. Es la única fuente de verdad del mapa:
    /// el suelo dibujado, el mar (SeaZone), las paredes de roca y la colocación de objetos salen de aquí.
    /// (La herramienta Tools/island_designer usa estas mismas constantes.)
    ///
    /// Zonas:
    ///  - Playa del Naufragio (sur): donde despiertas.
    ///  - Pueblo Portuario / Aldea Coral (este) con el muelle y el barco de Cuervo al noreste.
    ///  - Bosque Espeso (oeste y suroeste), con la charca de agua dulce.
    ///  - Colina del Faro (norte): meseta rodeada de acantilados con una rampa al sureste.
    ///  - Guarida de Contrabandistas (oeste): vieja mina en la roca con una sola entrada.
    /// </summary>
    internal static class IslandLayout
    {
        public enum Terrain { DeepWater, Shallow, WetSand, Sand, Grass, Path, Plaza, Rock, CaveFloor, Pond, Plateau }

        // Límites del mundo (WorldBoundsProvider) y del suelo dibujado
        public const float WorldHalfSize = 44f;
        public const float GroundHalfSize = 46f;

        // Zonas
        public static readonly Vector2 Spawn = new Vector2(0f, -29f);
        public static readonly Vector2 Pond = new Vector2(-9f, -21f);
        public const float PondRx = 2.8f, PondRy = 1.9f;
        public static readonly Vector2 Village = new Vector2(14f, 4f);
        public const float PlazaRadius = 7.0f;

        // Guarida de Contrabandistas (anillo de roca con entrada)
        public static readonly Vector2 Cave = new Vector2(-18f, 12f);
        public const float CaveInner = 5.8f, CaveOuter = 8.5f;
        public const float CaveEntranceAngle = -45f, CaveEntranceHalfWidth = 24f;

        // Colina del Faro (meseta con acantilado y rampa)
        public static readonly Vector2 Hill = new Vector2(-1f, 20f);
        public const float HillInner = 5.0f, HillOuter = 6.6f;
        public const float HillRampAngle = -60f, HillRampHalfWidth = 18f;

        // Muelle recto hacia el norte (franja x en [PierMinX, PierMaxX], desde la playa hasta PierEndY)
        public const float PierMinX = 16.6f, PierMaxX = 18.0f, PierStartY = 23.5f, PierEndY = 33f;

        /// <summary>Distancia (más allá de la costa) a la que empieza el agua profunda donde se nada.</summary>
        public const float DeepWaterMargin = 1.0f;
        /// <summary>Ancho de la franja de agua poco profunda que se dibuja.</summary>
        public const float ShallowWidth = 2.4f;

        /// <summary>Caminos de tierra (polilíneas).</summary>
        public static readonly Vector2[][] Paths =
        {
            // Playa del Naufragio -> Pueblo Portuario
            new[] { new Vector2(0f, -27.5f), new Vector2(2f, -20f), new Vector2(6f, -10f), new Vector2(11.5f, 0.8f), Village },
            // -> charca
            new[] { new Vector2(2f, -20f), new Vector2(-5.6f, -20.6f) },
            // -> Bosque Espeso -> Guarida de Contrabandistas
            new[] { new Vector2(6f, -10f), new Vector2(-4f, -6f), new Vector2(-9f, -1f), new Vector2(-12f, 4f), new Vector2(-13.2f, 6.6f), new Vector2(-15f, 8.9f) },
            // Pueblo -> muelle
            new[] { Village, new Vector2(16.3f, 8.5f), new Vector2(18.4f, 13.5f), new Vector2(17.6f, 20f), new Vector2(17.3f, 24f) },
            // Pueblo -> playa de los piratas (sureste)
            new[] { Village, new Vector2(16.5f, -4f), new Vector2(17.6f, -12.5f) },
            // Pueblo -> Colina del Faro (rampa)
            new[] { Village, new Vector2(8f, 9f), new Vector2(3.5f, 12.4f), new Vector2(1.9f, 15f), new Vector2(0.5f, 17.6f) },
        };

        /// <summary>Radio de la costa según el ángulo (radianes). Entre ~25 y ~36 unidades.</summary>
        public static float ShoreRadius(float angle)
        {
            return 30.5f + 2.9f * Mathf.Sin(3f * angle + 0.8f) + 1.9f * Mathf.Sin(5f * angle + 2.1f) + 1.0f * Mathf.Sin(8f * angle + 0.3f);
        }

        public static float ShoreRadiusAt(Vector2 p) => ShoreRadius(Mathf.Atan2(p.y, p.x));

        public static bool IsOnPier(Vector2 p)
        {
            return p.x >= PierMinX && p.x <= PierMaxX && p.y > PierStartY - 2f && p.y <= PierEndY;
        }

        public static float DistanceToPaths(Vector2 p)
        {
            float best = float.MaxValue;
            for (int i = 0; i < Paths.Length; i++)
            {
                Vector2[] path = Paths[i];
                for (int j = 0; j < path.Length - 1; j++)
                {
                    float d = DistanceToSegment(p, path[j], path[j + 1]);
                    if (d < best) best = d;
                }
            }
            return best;
        }

        private static float DistanceToSegment(Vector2 p, Vector2 a, Vector2 b)
        {
            Vector2 ab = b - a;
            float t = Mathf.Clamp01(Vector2.Dot(p - a, ab) / Mathf.Max(0.0001f, ab.sqrMagnitude));
            return Vector2.Distance(p, a + ab * t);
        }

        /// <summary>¿El punto está en la abertura (entrada/rampa) de un anillo de roca?</summary>
        public static bool InGap(Vector2 p, Vector2 center, float gapAngle, float gapHalfWidth)
        {
            Vector2 d = p - center;
            float ang = Mathf.Atan2(d.y, d.x) * Mathf.Rad2Deg;
            return Mathf.Abs(Mathf.DeltaAngle(ang, gapAngle)) < gapHalfWidth;
        }

        /// <summary>
        /// Tipo de terreno en un punto. 'shoreOffset' = distancia con signo a la costa (positivo = mar).
        /// </summary>
        public static Terrain Sample(Vector2 p, out float shoreOffset)
        {
            float d = p.magnitude;
            float r = ShoreRadiusAt(p) + (Mathf.PerlinNoise(p.x * 0.35f + 40f, p.y * 0.35f + 40f) - 0.5f) * 0.6f;
            shoreOffset = d - r;
            if (shoreOffset > ShallowWidth) return Terrain.DeepWater;
            if (shoreOffset > 0f) return Terrain.Shallow;

            Vector2 pc = p - Pond;
            float pondK = (pc.x * pc.x) / (PondRx * PondRx) + (pc.y * pc.y) / (PondRy * PondRy);
            if (pondK < 1f) return Terrain.Pond;
            if (pondK < 1.35f) return Terrain.WetSand;

            float rockNoise = (Mathf.PerlinNoise(p.x * 0.6f + 7f, p.y * 0.6f + 3f) - 0.5f) * 0.9f;
            float dc = Vector2.Distance(p, Cave);
            if (dc < CaveInner) return Terrain.CaveFloor;
            if (dc < CaveOuter + rockNoise) return InGap(p, Cave, CaveEntranceAngle, CaveEntranceHalfWidth) ? Terrain.CaveFloor : Terrain.Rock;

            float dh = Vector2.Distance(p, Hill);
            if (dh < HillInner) return DistanceToPaths(p) < 0.7f ? Terrain.Path : Terrain.Plateau;
            if (dh < HillOuter + rockNoise * 0.5f) return InGap(p, Hill, HillRampAngle, HillRampHalfWidth) ? Terrain.Path : Terrain.Rock;

            if (shoreOffset > -0.7f) return Terrain.WetSand;
            float sandEdge = -3.0f + (Mathf.PerlinNoise(p.x * 0.25f, p.y * 0.25f) - 0.5f) * 1.6f;
            if (shoreOffset > sandEdge) return Terrain.Sand;

            if (Vector2.Distance(p, Village) < PlazaRadius) return Terrain.Plaza;
            float pathNoise = (Mathf.PerlinNoise(p.x * 0.8f + 11f, p.y * 0.8f) - 0.5f) * 0.35f;
            if (DistanceToPaths(p) < 0.8f + pathNoise) return Terrain.Path;
            return Terrain.Grass;
        }

        /// <summary>
        /// Contorno del agujero del mar (la tierra): costa + margen, con el muelle incluido como tierra
        /// para poder caminar por él sin nadar.
        /// </summary>
        public static Vector2[] BuildSeaHole(int points)
        {
            List<Vector2> ring = new List<Vector2>(points + 4);
            for (int i = 0; i < points; i++)
            {
                float a = i * Mathf.PI * 2f / points;
                ring.Add(new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * (ShoreRadius(a) + DeepWaterMargin));
            }

            // Sustituir los puntos del primer cuadrante que caen en la franja del muelle por su rectángulo
            int first = -1, last = -1;
            for (int i = 0; i < ring.Count; i++)
            {
                Vector2 v = ring[i];
                if (v.y > 0f && v.x > 0f && v.x <= PierMaxX && v.x >= PierMinX)
                {
                    if (first < 0) first = i;
                    last = i;
                }
            }
            if (first <= 0 || last >= ring.Count - 1) return ring.ToArray();

            Vector2 before = ring[first - 1], after = ring[last + 1];
            float yA = Mathf.Lerp(before.y, ring[first].y, Mathf.InverseLerp(before.x, ring[first].x, PierMaxX));
            float yB = Mathf.Lerp(ring[last].y, after.y, Mathf.InverseLerp(ring[last].x, after.x, PierMinX));
            ring.RemoveRange(first, last - first + 1);
            ring.InsertRange(first, new[]
            {
                new Vector2(PierMaxX, yA), new Vector2(PierMaxX, PierEndY),
                new Vector2(PierMinX, PierEndY), new Vector2(PierMinX, yB)
            });
            return ring.ToArray();
        }
    }
}
