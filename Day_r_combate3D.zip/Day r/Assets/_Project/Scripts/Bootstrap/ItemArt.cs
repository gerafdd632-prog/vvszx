﻿using System;
using UnityEngine;
using PirateSurvival.Core;

namespace PirateSurvival.Bootstrap
{
    /// <summary>
    /// Generador de iconos pixel art de alta calidad para todos los objetos del juego.
    /// Sustituye los círculos y rectángulos simples por ilustraciones auténticas de temática One Piece y pirata.
    /// </summary>
    public static class ItemArt
    {
        private const float PPU = 16f;
        private static readonly Color Ink = new Color(0.10f, 0.08f, 0.07f);
        private static readonly Color Gold = new Color(0.96f, 0.80f, 0.24f);
        private static readonly Color GoldDark = new Color(0.68f, 0.50f, 0.12f);
        private static readonly Color Steel = new Color(0.88f, 0.92f, 0.96f);
        private static readonly Color SteelDark = new Color(0.42f, 0.48f, 0.58f);
        private static readonly Color Wood = new Color(0.58f, 0.38f, 0.20f);
        private static readonly Color WoodDark = new Color(0.36f, 0.22f, 0.10f);
        private static readonly Color WoodLight = new Color(0.76f, 0.55f, 0.32f);

        public static Sprite Get(string itemId)
        {
            string cleanId = itemId.StartsWith("item_") ? itemId.Substring(5) : itemId;
            return RuntimeSpriteCache.Get("art_item_" + cleanId, () => DrawItem(cleanId));
        }

        private static Sprite DrawItem(string id)
        {
            PixelCanvas c = new PixelCanvas(24, 24);

            switch (id)
            {
                // ============================================================ MATERIALES BÁSICOS
                case "madera":
                    // Tronco de madera con anillos y corteza
                    c.ShadedEllipse(12, 12, 9, 6, Wood, 0.2f, 0.35f);
                    c.Ellipse(18, 12, 3, 5, WoodLight);
                    c.Circle(18, 12, 1.2f, WoodDark);
                    c.Line(5, 14, 15, 14, WoodDark);
                    c.Line(6, 10, 16, 10, WoodDark);
                    break;

                case "piedra":
                    // Roca facetada tallada
                    c.ShadedEllipse(12, 11, 8, 6.5f, new Color(0.55f, 0.56f, 0.60f), 0.3f, 0.4f);
                    c.Line(7, 13, 13, 16, Color.white);
                    c.Line(13, 16, 17, 12, new Color(0.4f, 0.42f, 0.46f));
                    c.Line(12, 11, 16, 7, new Color(0.32f, 0.34f, 0.38f));
                    break;

                case "coco":
                    // Coco partido con leche y cáscara
                    c.ShadedEllipse(12, 12, 7.5f, 7.5f, new Color(0.45f, 0.30f, 0.15f), 0.2f, 0.4f);
                    c.Circle(14, 13, 4.5f, Color.white);
                    c.Circle(14, 13, 2.5f, new Color(0.85f, 0.95f, 1f));
                    break;

                case "fibra":
                    // Manojo de fibras vegetales de palma
                    c.Line(5, 5, 19, 19, new Color(0.45f, 0.72f, 0.28f), 2);
                    c.Line(8, 4, 20, 16, new Color(0.35f, 0.62f, 0.22f), 2);
                    c.Line(4, 8, 16, 20, new Color(0.55f, 0.82f, 0.35f), 2);
                    c.Rect(10, 10, 4, 4, new Color(0.75f, 0.60f, 0.35f)); // atadura
                    break;

                case "mineral_hierro":
                    // Roca oscura con vetas metálicas brillantes
                    c.ShadedEllipse(12, 11, 8, 6, new Color(0.38f, 0.36f, 0.35f), 0.2f, 0.4f);
                    c.Line(7, 10, 11, 14, new Color(0.85f, 0.45f, 0.25f), 2);
                    c.Line(12, 13, 17, 9, new Color(0.95f, 0.65f, 0.35f), 2);
                    c.Set(10, 13, Color.white); c.Set(14, 11, Color.white);
                    break;

                case "lingote_hierro":
                    // Lingote biselado de hierro
                    c.Rect(5, 7, 14, 9, SteelDark);
                    c.Rect(6, 8, 12, 7, Steel);
                    c.Line(6, 14, 17, 14, Color.white);
                    c.Line(6, 8, 6, 14, Color.white);
                    break;

                case "lingote_acero":
                    // Lingote pulido de acero con destello azulado
                    Color steelBlue = new Color(0.75f, 0.85f, 0.98f);
                    c.Rect(5, 7, 14, 9, new Color(0.35f, 0.45f, 0.62f));
                    c.Rect(6, 8, 12, 7, steelBlue);
                    c.Line(6, 14, 17, 14, Color.white);
                    c.Line(10, 9, 13, 14, Color.white); // reflejo diagonal
                    break;

                case "carbon":
                    // Carbón con chispas incandescentes
                    c.ShadedEllipse(12, 11, 7.5f, 6.5f, new Color(0.20f, 0.20f, 0.22f), 0.25f, 0.5f);
                    c.Set(10, 12, new Color(1f, 0.35f, 0.1f));
                    c.Set(14, 9, new Color(1f, 0.65f, 0.15f));
                    c.Set(11, 8, new Color(0.9f, 0.2f, 0.1f));
                    break;

                case "azufre":
                    // Cristales amarillos de azufre volcánico
                    Color sulfur = new Color(0.95f, 0.88f, 0.20f);
                    c.Line(7, 6, 12, 18, sulfur, 3);
                    c.Line(12, 18, 17, 7, sulfur, 2);
                    c.Line(5, 7, 14, 12, Color.Lerp(sulfur, Color.white, 0.4f), 2);
                    c.Line(11, 6, 18, 15, Color.Lerp(sulfur, Color.black, 0.25f), 2);
                    break;

                case "polvora":
                    // Saquito de pólvora negra con cordel
                    c.ShadedEllipse(12, 10, 7, 6, new Color(0.35f, 0.32f, 0.30f), 0.2f, 0.4f);
                    c.Rect(10, 15, 4, 3, new Color(0.25f, 0.20f, 0.18f));
                    c.Rect(9, 14, 6, 1, Gold);
                    c.Circle(17, 7, 1.2f, Color.black); c.Circle(19, 9, 1.0f, Color.black);
                    break;

                case "cuerda":
                    // Rollo circular de cuerda de cáñamo
                    Color rope = new Color(0.82f, 0.70f, 0.45f);
                    c.Circle(12, 12, 7.5f, rope);
                    c.Circle(12, 12, 4.0f, Color.clear);
                    c.Circle(12, 12, 4.0f, new Color(0f, 0f, 0f, 0.25f));
                    for (int i = 0; i < 8; i++)
                    {
                        float a = i * Mathf.PI / 4f;
                        c.Set(Mathf.RoundToInt(12 + Mathf.Cos(a) * 6f), Mathf.RoundToInt(12 + Mathf.Sin(a) * 6f), WoodDark);
                    }
                    break;

                case "tela":
                    // Rollo de lona de vela blanca
                    c.ShadedEllipse(12, 12, 8, 5, new Color(0.92f, 0.90f, 0.84f), 0.2f, 0.25f);
                    c.Circle(18, 12, 3f, new Color(0.80f, 0.78f, 0.72f));
                    c.Circle(18, 12, 1.2f, WoodDark);
                    c.Line(6, 13, 16, 13, new Color(0.75f, 0.72f, 0.65f));
                    break;

                case "cuero":
                    // Piel curtida marrón con costuras
                    Color leather = new Color(0.65f, 0.42f, 0.22f);
                    c.Rect(6, 6, 12, 12, leather);
                    c.Set(6, 6, Color.clear); c.Set(17, 6, Color.clear);
                    c.Set(6, 17, Color.clear); c.Set(17, 17, Color.clear);
                    c.Line(7, 16, 16, 16, Color.Lerp(leather, Color.white, 0.3f));
                    c.Set(9, 8, Gold); c.Set(14, 14, Gold);
                    break;

                case "clavo_hierro":
                    // Clavos de hierro forjado
                    c.Line(6, 6, 17, 17, Steel, 2);
                    c.Line(15, 17, 18, 14, SteelDark, 2);
                    c.Line(8, 16, 16, 8, SteelDark, 1);
                    break;

                case "hierbas":
                    // Ramillete de hojas medicinales y flor roja
                    c.ShadedEllipse(10, 11, 4, 6, new Color(0.35f, 0.75f, 0.30f));
                    c.ShadedEllipse(14, 13, 5, 4, new Color(0.28f, 0.65f, 0.25f));
                    c.Circle(12, 16, 2.5f, new Color(0.95f, 0.25f, 0.35f));
                    c.Set(12, 16, Gold);
                    break;

                case "botella_vacia":
                    // Frasco de cristal transparente
                    Color glass = new Color(0.55f, 0.80f, 0.92f, 0.85f);
                    c.Rect(7, 4, 10, 12, glass);
                    c.Rect(9, 16, 6, 4, glass);
                    c.Rect(9, 19, 6, 2, WoodDark); // corcho
                    c.Line(8, 5, 8, 15, Color.white); // reflejo
                    break;

                case "botella":
                    // Botella de agua fresca purificada
                    c.Rect(7, 4, 10, 12, new Color(0.30f, 0.65f, 0.95f));
                    c.Rect(7, 10, 10, 6, new Color(0.65f, 0.85f, 1f));
                    c.Rect(9, 16, 6, 4, new Color(0.55f, 0.80f, 0.92f));
                    c.Rect(9, 19, 6, 2, WoodDark);
                    c.Line(8, 5, 8, 14, Color.white);
                    break;

                case "perla_marina":
                    // Perla luminosa con brillo irisado
                    c.Circle(12, 12, 7.5f, new Color(0.95f, 0.95f, 1f));
                    c.Circle(10, 14, 3.0f, Color.white);
                    c.Circle(14, 9, 2.0f, new Color(0.80f, 0.85f, 0.95f));
                    c.Set(9, 15, Color.white);
                    break;

                case "kairoseki":
                    // Prisma de piedra marina con destellos de energía
                    Color kairo = new Color(0.35f, 0.55f, 0.72f);
                    c.Rect(7, 5, 10, 14, kairo);
                    c.Line(7, 18, 16, 18, Color.white);
                    c.Line(7, 5, 7, 18, Color.white);
                    c.Set(11, 12, new Color(0.6f, 0.9f, 1f));
                    c.Set(13, 8, new Color(0.6f, 0.9f, 1f));
                    break;

                // ============================================================ HERRAMIENTAS
                case "pico_madera":
                case "pico":
                    // Pico de minero con mango de madera y punta afilada
                    c.Line(5, 5, 17, 17, Wood, 2);
                    Color pHead = id.Contains("madera") ? WoodDark : Steel;
                    c.Line(9, 18, 18, 9, pHead, 2);
                    c.Line(8, 19, 11, 16, pHead, 2);
                    c.Line(16, 11, 19, 8, pHead, 2);
                    c.Set(18, 18, Gold);
                    break;

                case "hacha":
                    // Hacha de abordaje con hoja ancha
                    c.Line(5, 5, 18, 18, Wood, 2);
                    c.Rect(13, 13, 6, 6, Steel);
                    c.Line(12, 19, 19, 12, Color.white, 2);
                    c.Set(15, 15, SteelDark);
                    break;

                case "pala_pirata":
                case "pala":
                    // Pala de explorador
                    c.Line(6, 6, 16, 16, Wood, 2);
                    c.ShadedEllipse(7, 7, 4, 4, Steel);
                    c.Rect(16, 16, 4, 2, WoodDark);
                    break;

                case "antorcha_mano":
                case "antorcha":
                    // Antorcha viva con llama ardiente
                    c.Line(6, 6, 14, 14, WoodDark, 3);
                    c.Circle(16, 16, 4f, new Color(1f, 0.45f, 0.1f));
                    c.Circle(17, 17, 2.2f, new Color(1f, 0.9f, 0.2f));
                    c.Set(18, 19, Color.white);
                    break;

                case "cana_pescar":
                    // Caña de pescar con sedal y anzuelo
                    c.Line(4, 5, 19, 18, Wood, 2);
                    c.Line(19, 18, 20, 10, Color.white, 1);
                    c.Line(20, 10, 18, 8, Steel, 1);
                    c.Line(18, 8, 19, 7, Steel, 1);
                    c.Circle(8, 9, 2f, Gold); // carrete
                    break;

                // ============================================================ COMIDA Y BEBIDA
                case "carne_cruda":
                    // Chuleta de carne fresca
                    c.ShadedEllipse(12, 12, 7, 5, new Color(0.85f, 0.25f, 0.28f));
                    c.Line(9, 13, 14, 13, Color.white, 1);
                    c.Circle(16, 14, 1.8f, Color.white); // hueso
                    break;

                case "carne_cangrejo":
                    // Pinza de cangrejo roja
                    c.ShadedEllipse(12, 12, 7, 5, new Color(0.92f, 0.28f, 0.22f));
                    c.Line(15, 14, 19, 16, new Color(0.92f, 0.28f, 0.22f), 2);
                    c.Line(15, 10, 18, 8, new Color(0.92f, 0.28f, 0.22f), 2);
                    c.Circle(9, 11, 2.5f, Color.white);
                    break;

                case "carne_asada":
                    // Jamón asado legendario con hueso (Luffy style)
                    c.Line(4, 6, 20, 18, new Color(0.95f, 0.92f, 0.85f), 3); // hueso
                    c.Circle(4, 6, 2.5f, Color.white);
                    c.Circle(20, 18, 2.5f, Color.white);
                    c.ShadedEllipse(12, 12, 7, 6, new Color(0.68f, 0.32f, 0.16f), 0.25f, 0.4f);
                    c.Line(10, 14, 14, 10, new Color(0.92f, 0.65f, 0.25f), 1); // marcas tostadas
                    c.Line(12, 15, 15, 12, new Color(0.40f, 0.18f, 0.08f), 1);
                    break;

                case "pescado_asado":
                    // Pescado a la brasa
                    c.ShadedEllipse(12, 12, 8, 4, new Color(0.82f, 0.58f, 0.32f));
                    c.Line(4, 12, 7, 15, new Color(0.70f, 0.45f, 0.20f), 2); // cola
                    c.Line(4, 12, 7, 9, new Color(0.70f, 0.45f, 0.20f), 2);
                    c.Line(10, 13, 12, 10, new Color(0.45f, 0.25f, 0.10f)); // brasa
                    c.Line(13, 13, 15, 10, new Color(0.45f, 0.25f, 0.10f));
                    c.Set(16, 13, Ink); // ojo
                    break;

                case "sopa_marisco":
                    // Guiso de marisco en cuenco
                    c.ShadedEllipse(12, 9, 8, 4.5f, WoodDark);
                    c.ShadedEllipse(12, 11, 7, 3.5f, new Color(0.95f, 0.55f, 0.22f));
                    c.Circle(15, 13, 2.5f, new Color(0.95f, 0.25f, 0.25f)); // pinza
                    c.Set(10, 15, Color.white); c.Set(12, 17, Color.white); // vapor
                    break;

                case "infusion_herbal":
                case "infusion":
                    // Taza humeante de té herbal
                    c.Rect(7, 5, 10, 10, new Color(0.72f, 0.55f, 0.40f));
                    c.ShadedEllipse(12, 13, 5, 2.5f, new Color(0.35f, 0.75f, 0.35f));
                    c.Line(17, 7, 19, 10, new Color(0.72f, 0.55f, 0.40f), 2); // asa
                    c.Set(11, 16, Color.white); c.Set(13, 18, Color.white);
                    break;

                case "ron_pirata":
                    // Botella de ron pirata con calavera
                    c.Rect(7, 4, 10, 12, new Color(0.32f, 0.18f, 0.10f));
                    c.Rect(9, 15, 6, 4, new Color(0.32f, 0.18f, 0.10f));
                    c.Rect(9, 18, 6, 2, WoodDark);
                    c.Rect(8, 7, 8, 6, new Color(0.92f, 0.85f, 0.65f)); // etiqueta
                    c.Circle(12, 10, 1.5f, Ink); // calavera
                    break;

                // ============================================================ MEDICINA
                case "venda":
                    // Rollo de vendas limpias
                    c.Circle(12, 12, 7.5f, new Color(0.92f, 0.92f, 0.90f));
                    c.Circle(12, 12, 3.5f, new Color(0.75f, 0.75f, 0.72f));
                    c.Set(12, 12, new Color(0.85f, 0.2f, 0.2f)); // cruz roja
                    break;

                case "unguento":
                    // Tarro de pomada calmante
                    c.Rect(6, 6, 12, 10, new Color(0.85f, 0.85f, 0.88f));
                    c.Rect(5, 14, 14, 3, Gold);
                    c.Rect(8, 8, 8, 6, new Color(0.30f, 0.75f, 0.45f));
                    break;

                case "antidoto":
                    // Matraz de antídoto verde
                    c.Line(7, 5, 17, 5, new Color(0.3f, 0.85f, 0.6f), 2);
                    c.Line(10, 14, 14, 14, new Color(0.3f, 0.85f, 0.6f), 2);
                    c.ShadedEllipse(12, 8, 6, 4, new Color(0.20f, 0.90f, 0.50f));
                    c.Rect(10, 13, 4, 4, new Color(0.6f, 0.9f, 0.8f));
                    c.Rect(10, 17, 4, 2, WoodDark);
                    break;

                case "botiquin":
                    // Maletín médico de emergencia
                    c.Rect(5, 5, 14, 11, new Color(0.85f, 0.20f, 0.20f));
                    c.Rect(9, 16, 6, 2, WoodDark); // asa
                    c.Rect(10, 8, 4, 5, Color.white); // cruz
                    c.Rect(9, 9, 6, 3, Color.white);
                    break;

                // ============================================================ MUNICIÓN Y ARMAS A DISTANCIA
                case "balines_piedra":
                    c.Circle(9, 9, 3.0f, new Color(0.6f, 0.6f, 0.65f));
                    c.Circle(15, 9, 3.0f, new Color(0.5f, 0.5f, 0.55f));
                    c.Circle(12, 14, 3.2f, new Color(0.7f, 0.7f, 0.75f));
                    break;

                case "balas_plomo":
                    c.Circle(8, 8, 3.5f, new Color(0.35f, 0.35f, 0.40f));
                    c.Circle(16, 9, 3.5f, new Color(0.30f, 0.30f, 0.35f));
                    c.Circle(12, 15, 4.0f, new Color(0.40f, 0.40f, 0.45f));
                    c.Set(10, 16, Color.white);
                    break;

                case "tirachinas":
                    c.Line(12, 4, 12, 11, Wood, 3);
                    c.Line(12, 11, 7, 18, Wood, 2);
                    c.Line(12, 11, 17, 18, Wood, 2);
                    c.Line(7, 18, 17, 18, new Color(0.85f, 0.25f, 0.25f), 1);
                    break;

                case "pistola_chispa":
                    // Pistola de chispa pirata
                    c.Line(6, 6, 12, 11, WoodDark, 3); // culata
                    c.Rect(10, 11, 10, 4, Steel); // cañón
                    c.Rect(18, 10, 2, 6, Gold); // boca cañón
                    c.Set(11, 14, SteelDark); // gatillo
                    break;

                case "trabuco":
                    // Trabuco naval con boca acampanada
                    c.Line(5, 5, 11, 10, WoodDark, 4);
                    c.Line(10, 10, 17, 14, Steel, 3);
                    c.Line(16, 12, 19, 16, Gold, 4); // campana
                    break;

                // ============================================================ ESPADAS Y ARMAS
                case "espada_madera":
                    c.Line(5, 5, 18, 18, Wood, 2);
                    c.Line(7, 9, 9, 7, WoodDark, 2);
                    break;

                case "daga_abordaje":
                case "daga":
                case "daga_kairoseki":
                    Color dBlade = id.Contains("kairoseki") ? new Color(0.35f, 0.65f, 0.95f) : Steel;
                    c.Line(5, 5, 8, 8, WoodDark, 2); // empuñadura
                    c.Line(7, 9, 9, 7, Gold, 3); // guarda
                    c.Line(9, 9, 18, 18, dBlade, 2); // filo
                    c.Set(18, 18, Color.white);
                    break;

                case "espada_marina":
                    c.Line(5, 5, 8, 8, new Color(0.15f, 0.25f, 0.5f), 2);
                    c.Circle(8, 8, 3.5f, Gold); // cazoleta
                    c.Line(9, 9, 19, 19, Steel, 2);
                    c.Set(19, 19, Color.white);
                    break;

                case "katana":
                case "katana_acero":
                    // Katana con filo curvo y hamon
                    c.Line(4, 4, 8, 8, new Color(0.2f, 0.2f, 0.2f), 2);
                    c.Circle(8, 8, 2.5f, Gold); // tsuba
                    c.Line(9, 9, 18, 17, Steel, 2);
                    c.Line(10, 10, 19, 18, Color.white, 1);
                    break;

                case "shiokaze":
                    // Katana legendaria Meito "Shiokaze"
                    c.Line(4, 4, 8, 8, Color.white, 2); // tsuka blanco
                    c.Circle(8, 8, 3.0f, Gold);
                    c.Line(9, 9, 19, 18, new Color(0.85f, 0.95f, 1f), 2);
                    c.Line(10, 10, 20, 19, Color.white, 1); // brillo divino
                    c.Set(20, 20, Gold);
                    break;

                case "nodachi":
                    c.Line(3, 3, 8, 8, new Color(0.85f, 0.2f, 0.2f), 2);
                    c.Circle(8, 8, 2.5f, Gold);
                    c.Line(9, 9, 21, 21, Steel, 2);
                    break;

                case "maza_hierro":
                case "maza":
                    c.Line(5, 5, 14, 14, Wood, 3);
                    c.Circle(16, 16, 4.5f, SteelDark);
                    c.Set(14, 18, Steel); c.Set(18, 14, Steel); c.Set(17, 17, Steel);
                    break;

                case "lanza_madera":
                case "lanza":
                    c.Line(4, 4, 17, 17, Wood, 2);
                    c.Line(17, 17, 20, 20, Steel, 3);
                    c.Set(20, 20, Color.white);
                    break;

                // ============================================================ ARMADURAS Y ROPA
                case "sombrero_paja":
                    // El sombrero de paja de Luffy
                    Color straw = new Color(0.96f, 0.82f, 0.32f);
                    Color ribbon = new Color(0.85f, 0.15f, 0.15f);
                    c.ShadedEllipse(12, 10, 9, 4.0f, straw, 0.25f, 0.35f); // ala ancha
                    c.ShadedEllipse(12, 14, 5.5f, 4.5f, straw, 0.25f, 0.35f); // cúpula
                    c.Rect(7, 11, 10, 2, ribbon); // cinta roja
                    break;

                case "chaleco_cuero":
                    // Chaleco pirata
                    Color vLeather = new Color(0.62f, 0.38f, 0.20f);
                    c.Rect(7, 6, 10, 12, vLeather);
                    c.Line(12, 11, 12, 18, Color.clear, 2); // abierto en el centro
                    c.Set(10, 9, Gold); c.Set(14, 9, Gold); // botones
                    break;

                case "capa_marina":
                    // Capa de la Marina con charreteras
                    c.Rect(6, 5, 12, 13, Color.white);
                    c.Line(6, 16, 17, 16, new Color(0.15f, 0.25f, 0.5f), 2);
                    c.Circle(7, 17, 2f, Gold); c.Circle(17, 17, 2f, Gold); // charreteras
                    break;

                case "fruta":
                    // Fruta del Diablo mística
                    Color fruit = new Color(0.65f, 0.25f, 0.75f);
                    c.Circle(12, 11, 7f, fruit);
                    c.Line(12, 17, 14, 20, new Color(0.2f, 0.7f, 0.3f), 2); // tallo en espiral
                    c.Set(15, 20, new Color(0.2f, 0.7f, 0.3f));
                    c.Set(9, 12, Color.white); c.Set(13, 8, Color.white); // espirales
                    break;

                default:
                    // Objeto genérico estilizado como cofre/medallón
                    c.Circle(12, 12, 7f, Gold);
                    c.Circle(12, 12, 5f, GoldDark);
                    c.Set(12, 12, Color.white);
                    break;
            }

            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 0.5f), PPU);
        }
    }
}
