﻿using System;
using System.Collections;
using System.Reflection;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem.UI;
#endif

using PirateSurvival.Core;
using PirateSurvival.Player;
using PirateSurvival.Inventory;
using PirateSurvival.Inventory.UI;
using PirateSurvival.Interaction;
using PirateSurvival.Environment;
using PirateSurvival.SaveSystem;
using PirateSurvival.UI;
using PirateSurvival.Combat;

namespace PirateSurvival.Bootstrap
{
    /// <summary>
    /// Arranque autónomo de escena para Unity 6.
    /// Si la escena no tiene un jugador, construye todo el mundo en tiempo de ejecución (isla, jugador, cámara,
    /// recursos, guardado, ciclo día/noche, clima, HUD, inventario) y muestra el menú principal.
    /// ¡CERO MONTAJE MANUAL EN EL EDITOR!
    /// </summary>
    public static partial class GameBootstrap
    {
        // Objetos raíz del mundo: se destruyen al volver al menú principal
        private static readonly List<GameObject> worldRoots = new List<GameObject>();

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        public static void InitializeGameWorld()
        {
            // Si ya existe un jugador en la escena, no sobreescribir nada
            if (UnityEngine.Object.FindFirstObjectByType<PlayerController2D>() != null)
            {
                Debug.Log("[GameBootstrap] Escena existente detectada con jugador. Omitiendo construcción automática.");
                GameState.Set(GameScreen.Playing); // por si quedó bloqueado de una sesión anterior
                return;
            }

            worldRoots.Clear();
            BuildWorld();
            MenuManager.Create().ShowMain();
        }

        /// <summary>Crea un GameObject raíz que se destruirá al reconstruir el mundo.</summary>
        internal static GameObject NewRoot(string name)
        {
            GameObject go = new GameObject(name);
            worldRoots.Add(go);
            return go;
        }

        /// <summary>Destruye el mundo actual y construye uno nuevo (partida limpia). Requiere MenuManager (ejecuta la corrutina).</summary>
        public static void RebuildWorld(Action onBuilt)
        {
            MenuManager.Instance.StartCoroutine(RebuildRoutine(onBuilt));
        }

        private static IEnumerator RebuildRoutine(Action onBuilt)
        {
            WorldItemPickup[] drops = UnityEngine.Object.FindObjectsByType<WorldItemPickup>(FindObjectsSortMode.None);
            for (int i = 0; i < drops.Length; i++) UnityEngine.Object.Destroy(drops[i].gameObject);
            for (int i = 0; i < worldRoots.Count; i++)
            {
                if (worldRoots[i] != null) UnityEngine.Object.Destroy(worldRoots[i]);
            }
            worldRoots.Clear();

            // Destroy es diferido: esperar un frame para que los singletons (InventoryManager, SaveManager...) se liberen
            yield return null;

            BuildWorld();
            onBuilt?.Invoke();
        }

        private static void BuildWorld()
        {
            Debug.Log("[GameBootstrap] Construyendo el mundo 2D de Pirate Survival...");

            // Límites de la Isla 1 (IslandLayout). El futuro World/ los reconfigurará por isla.
            WorldBoundsProvider.Configure(new Vector2(-IslandLayout.WorldHalfSize, -IslandLayout.WorldHalfSize), new Vector2(IslandLayout.WorldHalfSize, IslandLayout.WorldHalfSize));

            // 1. ScriptableObjects de objetos
            var itemDb = GetItemDatabase();

            // 2. Cámara 2D
            GameObject camObj = CreateCamera2D();
            Camera2D cam2D = camObj.GetComponent<Camera2D>();

            // 3. Jugador 2D
            GameObject playerObj = CreatePlayer2D(out PlayerStats playerStats, out InventoryManager invMgr, out PlayerController2D playerCtrl);
            cam2D.SetTarget(playerObj.transform);

            // 4. Isla: Playa del Naufragio, Pueblo Portuario, Bosque Espeso, Colina del Faro, Guarida de Contrabandistas
            IslandBuilder.Build(itemDb);
            Island2Builder.Build(itemDb);
            playerObj.transform.position = IslandPlacements.Spawn;
            CreateCaveDarkness(camObj.transform);

            // 5. Entorno y guardado
            GameObject envMgrObj = NewRoot("EnvironmentManager");
            DayNightCycle dayNight = envMgrObj.AddComponent<DayNightCycle>();
            WeatherSystem weather = envMgrObj.AddComponent<WeatherSystem>();

            GameObject saveMgrObj = NewRoot("SaveManager");
            SaveManager saveMgr = saveMgrObj.AddComponent<SaveManager>();
            InjectField(saveMgr, "itemDatabase", new List<ItemData>(itemDb.Values));
            InjectField(saveMgr, "playerController", playerCtrl);
            InjectField(saveMgr, "playerStats", playerStats);
            InjectField(saveMgr, "inventoryManager", invMgr);
            InjectField(saveMgr, "dayNightCycle", dayNight);
            InjectField(saveMgr, "weatherSystem", weather);

            GameObject spawnPointObj = NewRoot("PlayerSpawnPoint");
            spawnPointObj.transform.position = IslandPlacements.Spawn;
            InjectField(saveMgr, "defaultSpawnPoint", spawnPointObj.transform);

            // Modo historia (objetivos, flags guardados, bloqueo del jefe)
            NewRoot("StoryManager").AddComponent<PirateSurvival.Story.StoryManager>();

            // Combate táctico (la lógica vive en Combat/, aquí solo se inicializa)
            NewRoot("BattleSystem").AddComponent<BattleManager>();
            NewRoot("Combat3DSystem").AddComponent<PirateSurvival.Combat3D.Combat3DManager>();

            // Flecha sobre el interactuable más cercano
            NewRoot("InteractableTargetIndicator").AddComponent<InteractableTargetIndicator>();

            // 6. HUD, inventario, pantalla de muerte
            GameUIBuilder.Build(playerStats, invMgr, dayNight, saveMgr);

            // 7. EventSystem
            CreateEventSystem();

            // Náufrago: empieza sediento para que lo primero sea buscar agua dulce (al cargar partida se sobrescribe)
            playerStats.ModifyThirst(-45f);

            // Items iniciales
            invMgr.AddItem(itemDb["itemCoco"], 2);
            invMgr.AddItem(itemDb["itemHacha"], 1);
        }

        internal static void InjectField(object target, string fieldName, object value)
        {
            if (target == null) return;
            Type t = target.GetType();
            FieldInfo fi = null;

            while (t != null && fi == null)
            {
                fi = t.GetField(fieldName, BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
                t = t.BaseType;
            }

            if (fi != null)
            {
                fi.SetValue(target, value);
            }
            else
            {
                Debug.LogWarning($"[GameBootstrap] Campo '{fieldName}' no encontrado en {target.GetType().Name}.");
            }
        }

        // Base de datos de objetos y plantillas de herramientas: se crean UNA vez y se reutilizan al reconstruir el mundo
        private static Dictionary<string, ItemData> itemDbCache;
        private static GameObject templatesRoot;

        public static Dictionary<string, ItemData> GetItemDatabase()
        {
            bool valid = itemDbCache != null && templatesRoot != null;
            if (valid)
            {
                foreach (ItemData item in itemDbCache.Values)
                {
                    if (item == null) { valid = false; break; }
                }
            }
            if (valid)
            {
                ItemDatabase.Register(itemDbCache.Values);
                return itemDbCache;
            }

            if (templatesRoot == null)
            {
                templatesRoot = new GameObject("RuntimeTemplates");
                templatesRoot.SetActive(false);
                UnityEngine.Object.DontDestroyOnLoad(templatesRoot);
            }
            itemDbCache = CreateScriptableObjects();
            ItemDatabase.Register(itemDbCache.Values);
            return itemDbCache;
        }

        private static Dictionary<string, ItemData> CreateScriptableObjects()
        {
            var dict = new Dictionary<string, ItemData>();

            // Madera
            ItemData madera = ScriptableObject.CreateInstance<ItemData>();
            madera.itemId = "madera";
            madera.itemName = "Madera";
            madera.description = "Tronco resistente talado de una palmera tropical.";
            madera.itemType = ItemType.Material;
            madera.weight = 0.8f;
            madera.maxStackSize = 25;
            madera.icon = ItemArt.Get("madera");
            dict["itemMadera"] = madera;

            // Piedra
            ItemData piedra = ScriptableObject.CreateInstance<ItemData>();
            piedra.itemId = "piedra";
            piedra.itemName = "Piedra";
            piedra.description = "Fragmento de roca sólida para fabricar herramientas y refugios.";
            piedra.itemType = ItemType.Material;
            piedra.weight = 1.2f;
            piedra.maxStackSize = 20;
            piedra.icon = ItemArt.Get("piedra");
            dict["itemPiedra"] = piedra;

            // Coco
            ItemData coco = ScriptableObject.CreateInstance<ItemData>();
            coco.itemId = "coco";
            coco.itemName = "Coco Dulce";
            coco.description = "Fruta tropical fresca que sacia el hambre y la sed.";
            coco.itemType = ItemType.Food;
            coco.healthRestore = 6f;
            coco.hungerRestore = 22f;
            coco.thirstRestore = 18f;
            coco.weight = 0.5f;
            coco.maxStackSize = 10;
            coco.icon = ItemArt.Get("coco");
            dict["itemCoco"] = coco;

            // Hacha (Punto 9: sprite y prefab equipado procedural)
            ItemData hacha = ScriptableObject.CreateInstance<ItemData>();
            hacha.itemId = "hacha";
            hacha.itemName = "Hacha de Abordaje";
            hacha.description = "Herramienta afilada ideal para talar árboles con rapidez.";
            hacha.itemType = ItemType.Tool;
            hacha.toolType = ToolType.Axe;
            hacha.resourceDamage = 16f;
            hacha.weight = 2.0f;
            hacha.maxStackSize = 1;
            hacha.icon = GameSprites.Get("item_hacha", CreateAxeSprite);
            hacha.equippedPrefab = CreateToolEquippedPrefab("Hacha", hacha.icon);
            // Pesada: mucho daño, cara en AP y poco precisa
            hacha.combatDamage = 14;
            hacha.combatApCost = 3;
            hacha.combatAccuracy = 0.75f;
            hacha.combatCritChance = 0.1f;
            hacha.combatDamageType = CombatDamageType.Slash;
            hacha.maxDurability = 80;
            dict["itemHacha"] = hacha;

            // Pico (Punto 9: sprite y prefab equipado procedural)
            ItemData pico = ScriptableObject.CreateInstance<ItemData>();
            pico.itemId = "pico";
            pico.itemName = "Pico Minero";
            pico.description = "Herramienta puntiaguda obligatoria para picar vetas de roca.";
            pico.itemType = ItemType.Tool;
            pico.toolType = ToolType.Pickaxe;
            pico.resourceDamage = 15f;
            pico.weight = 2.4f;
            pico.maxStackSize = 1;
            pico.icon = GameSprites.Get("item_pico", CreatePickaxeSprite);
            pico.equippedPrefab = CreateToolEquippedPrefab("Pico", pico.icon);
            pico.combatDamage = 12;
            pico.combatApCost = 3;
            pico.combatAccuracy = 0.7f;
            pico.combatCritChance = 0.15f;
            pico.combatDamageType = CombatDamageType.Pierce;
            pico.maxDurability = 80;
            dict["itemPico"] = pico;

            // Sable (Punto 9: sprite y prefab equipado procedural)
            ItemData sable = ScriptableObject.CreateInstance<ItemData>();
            sable.itemId = "sable";
            sable.itemName = "Sable Pirata (Cutlass)";
            sable.description = "Hoja curvada de pirata forjada para el combate cuerpo a cuerpo.";
            sable.itemType = ItemType.Weapon;
            sable.toolType = ToolType.Cutlass;
            sable.resourceDamage = 8f;
            sable.weight = 1.6f;
            sable.maxStackSize = 1;
            sable.icon = GameSprites.Get("item_sable", CreateCutlassSprite);
            sable.equippedPrefab = CreateToolEquippedPrefab("Sable", sable.icon);
            // Arma de verdad: daño medio, barata y precisa
            sable.combatDamage = 12;
            sable.combatApCost = 2;
            sable.combatAccuracy = 0.9f;
            sable.combatCritChance = 0.12f;
            sable.combatDamageType = CombatDamageType.Slash;
            sable.maxDurability = 60;
            dict["itemSable"] = sable;

            // Botella de Agua
            ItemData botella = ScriptableObject.CreateInstance<ItemData>();
            botella.itemId = "botella_agua";
            botella.itemName = "Botella de Agua Dulce";
            botella.description = "Agua fresca de manantial embotellada.";
            botella.itemType = ItemType.Drink;
            botella.thirstRestore = 35f;
            botella.temperatureChange = -0.5f;
            botella.weight = 0.6f;
            botella.maxStackSize = 5;
            botella.icon = ItemArt.Get("botella");
            dict["itemBotella"] = botella;

            // Venda: cura sangrado (también el que sigue tras un combate)
            ItemData venda = ScriptableObject.CreateInstance<ItemData>();
            venda.itemId = "venda";
            venda.itemName = "Venda";
            venda.description = "Tela limpia para cortar hemorragias. Cura el sangrado y 10 de vida.";
            venda.itemType = ItemType.Medicine;
            venda.healthRestore = 10f;
            venda.curesBleeding = true;
            venda.weight = 0.1f;
            venda.maxStackSize = 10;
            venda.icon = ItemArt.Get("venda");
            dict["itemVenda"] = venda;

            // Fruta del Diablo inicial
            ItemData fruta = ScriptableObject.CreateInstance<ItemData>();
            fruta.itemId = "fruta_elastica";
            fruta.itemName = "Fruta Elástica";
            fruta.description = "Una fruta extraña con espirales. Dicen que da un poder enorme... a cambio del mar.";
            fruta.itemType = ItemType.DevilFruit;
            fruta.devilFruitId = DevilFruitManager.Elastic;
            fruta.neverDespawn = true; // objeto único: nunca desaparece del suelo
            fruta.weight = 0.4f;
            fruta.maxStackSize = 1;
            fruta.icon = ItemArt.Get("fruta");
            dict["itemFruta"] = fruta;

            AddCraftingItems(dict);
            return dict;
        }

        private static GameObject CreateCamera2D()
        {
            // Limpiar cualquier cámara o AudioListener previo de la escena para evitar duplicados
            Camera[] oldCams = UnityEngine.Object.FindObjectsByType<Camera>(FindObjectsSortMode.None);
            for (int i = 0; i < oldCams.Length; i++)
            {
                if (oldCams[i] != null && !worldRoots.Contains(oldCams[i].gameObject))
                {
                    UnityEngine.Object.Destroy(oldCams[i].gameObject);
                }
            }
            AudioListener[] oldListeners = UnityEngine.Object.FindObjectsByType<AudioListener>(FindObjectsSortMode.None);
            for (int i = 0; i < oldListeners.Length; i++)
            {
                if (oldListeners[i] != null && !worldRoots.Contains(oldListeners[i].gameObject))
                {
                    UnityEngine.Object.Destroy(oldListeners[i]);
                }
            }

            GameObject camObj = NewRoot("Main Camera");
            camObj.tag = "MainCamera";
            Camera cam = camObj.AddComponent<Camera>();
            cam.orthographic = true;
            cam.orthographicSize = 6.0f;
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.12f, 0.35f, 0.55f); // Color del mar
            camObj.transform.position = new Vector3(0f, 0f, -10f);

            camObj.AddComponent<AudioListener>();
            Camera2D cam2D = camObj.AddComponent<Camera2D>();
            InjectField(cam2D, "smoothTime", 0.12f);
            InjectField(cam2D, "defaultOrthoSize", 6.0f);
            InjectField(cam2D, "minOrthoSize", 3.5f);
            InjectField(cam2D, "maxOrthoSize", 10.0f);

            return camObj;
        }

        private static GameObject CreatePlayer2D(out PlayerStats stats, out InventoryManager inv, out PlayerController2D ctrl)
        {
            GameObject player = NewRoot("Player");
            player.transform.position = Vector3.zero;

            // Objeto hijo 'Visual' para el sprite y animaciones sin rotar el Rigidbody2D
            GameObject visualObj = new GameObject("Visual");
            visualObj.transform.SetParent(player.transform, false);
            SpriteRenderer sr = visualObj.AddComponent<SpriteRenderer>();
            sr.sprite = CharacterArt.GetPlayerSprite();
            sr.sortingOrder = 0;

            // Rigidbody2D en el GameObject raíz
            Rigidbody2D rb = player.AddComponent<Rigidbody2D>();
            rb.gravityScale = 0f;
            rb.constraints = RigidbodyConstraints2D.FreezeRotation;
            rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;

            // CircleCollider2D en los pies en el GameObject raíz
            // Pies redondos y sin fricción: el jugador resbala por paredes y esquinas en vez de engancharse
            CircleCollider2D col = player.AddComponent<CircleCollider2D>();
            col.radius = 0.28f;
            col.offset = new Vector2(0f, -0.2f);
            PhysicsMaterial2D slippery = new PhysicsMaterial2D("PlayerNoFriction") { friction = 0f, bounciness = 0f };
            col.sharedMaterial = slippery;
            rb.sharedMaterial = slippery;

            // Componentes del jugador (DevilFruitManager y PlayerSwimming antes del controlador, que los lee en Awake)
            player.AddComponent<DevilFruitManager>();
            player.AddComponent<PlayerSwimming>();
            ctrl = player.AddComponent<PlayerController2D>();
            stats = player.GetComponent<PlayerStats>();
            if (stats == null)
            {
                stats = player.AddComponent<PlayerStats>();
            }

            PlayerAnimation2D anim = player.AddComponent<PlayerAnimation2D>();
            InjectField(anim, "visualTransform", visualObj.transform);

            // YSorter en el hijo 'Visual' donde reside el SpriteRenderer visible
            YSorter sorter = visualObj.AddComponent<YSorter>();
            sorter.TargetRenderer = sr;
            sorter.SyncChildRenderers = true; // la herramienta equipada queda delante/detrás con el jugador

            PlayerInteraction2D interaction = player.AddComponent<PlayerInteraction2D>();
            inv = player.AddComponent<InventoryManager>();
            player.AddComponent<PlayerProgress>();
            player.AddComponent<SafePositionTracker>();
            player.AddComponent<HakiManager>();
            player.AddComponent<AbilityController>();
            player.AddComponent<PlayerWounds>();
            player.AddComponent<CrewManager>();
            player.AddComponent<PlayerMelee>(); // golpes en el mundo contra la fauna (clic / F)

            // Configurar punto de soltado
            GameObject dropPoint = new GameObject("DropPoint");
            dropPoint.transform.SetParent(player.transform);
            dropPoint.transform.localPosition = new Vector3(0f, -0.6f, 0f);
            InjectField(inv, "dropPoint", dropPoint.transform);

            // Configurar punto de mano para herramientas (Punto 9)
            GameObject toolSocket = new GameObject("ToolSocket");
            toolSocket.transform.SetParent(visualObj.transform); // Hijo de Visual para balanceo armónico
            toolSocket.transform.localPosition = new Vector3(0.35f, 0f, 0f);
            InjectField(inv, "toolSocket", toolSocket.transform);
            InjectField(anim, "toolSocket", toolSocket.transform);

            return player;
        }

        internal static void CreateEncounter(GameObject parent, string id, EncounterKind kind, Vector2 pos)
        {
            GameObject enc = new GameObject("Encuentro_" + id);
            enc.transform.SetParent(parent.transform, false);
            enc.transform.position = new Vector3(pos.x, pos.y, 0f);

            GameObject visual = new GameObject("Visual");
            visual.transform.SetParent(enc.transform, false);
            foreach (BattleUnit u in CreateEncounterPreview(kind))
                AddEncounterSprite(visual.transform, u.sprite, new Vector2((u.pos.x - 8) * 0.55f, (u.pos.y - 2.5f) * 0.3f));

            BattleEncounter encounter = enc.AddComponent<BattleEncounter>();
            encounter.Configure(id, kind, visual);
        }

        /// <summary>Los mismos enemigos del combate, para dibujarlos en el mapa.</summary>
        private static List<BattleUnit> CreateEncounterPreview(EncounterKind kind)
        {
            switch (kind)
            {
                case EncounterKind.CaptainShip:
                    return new List<BattleUnit> { EnemyLibrary.Captain(new Vector2Int(8, 3)), EnemyLibrary.Swordsman(new Vector2Int(7, 4)), EnemyLibrary.Gunner(new Vector2Int(9, 1)) };
                case EncounterKind.CaveSpiders:
                    return new List<BattleUnit> { EnemyLibrary.CaveSpider(new Vector2Int(8, 3)), EnemyLibrary.CaveSpider(new Vector2Int(9, 2)) };
                case EncounterKind.CaveBats:
                    return new List<BattleUnit> { EnemyLibrary.CaveBat(new Vector2Int(8, 3)), EnemyLibrary.CaveBat(new Vector2Int(9, 2)) };
                case EncounterKind.CaveBandits:
                    return new List<BattleUnit> { EnemyLibrary.CaveBandit(new Vector2Int(8, 3)), EnemyLibrary.Gunner(new Vector2Int(9, 2)) };
                default:
                    return new List<BattleUnit> { EnemyLibrary.Bandit(new Vector2Int(7, 3)), EnemyLibrary.Gunner(new Vector2Int(9, 2)) };
            }
        }

        private static void AddEncounterSprite(Transform parent, Sprite sprite, Vector2 offset)
        {
            GameObject go = new GameObject("Pirata");
            go.transform.SetParent(parent, false);
            go.transform.localPosition = offset;
            SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = sprite;
            sr.flipX = true; // miran hacia el interior de la isla
            YSorter sorter = go.AddComponent<YSorter>();
            sorter.IsStatic = true;
        }

        private static void CreateEventSystem()
        {
            if (UnityEngine.Object.FindFirstObjectByType<EventSystem>() == null)
            {
                GameObject esObj = NewRoot("EventSystem");
                esObj.AddComponent<EventSystem>();

#if ENABLE_INPUT_SYSTEM
                // Acciones predeterminadas para permitir clics y arrastres de UI
                var uiModule = esObj.AddComponent<InputSystemUIInputModule>();
                uiModule.AssignDefaultActions();
#else
                esObj.AddComponent<StandaloneInputModule>();
#endif
            }
        }

        /// <summary>Velo de oscuridad de las cuevas, pegado a la cámara.</summary>
        private static void CreateCaveDarkness(Transform cameraTransform)
        {
            GameObject dark = new GameObject("CaveDarkness");
            dark.transform.SetParent(cameraTransform, false);
            dark.transform.localPosition = new Vector3(0f, 0f, 9f);
            SpriteRenderer sr = dark.AddComponent<SpriteRenderer>();
            sr.sprite = WorldArt.DarknessMask();
            dark.AddComponent<CaveDarkness>();
        }

        private static GameObject CreateToolEquippedPrefab(string toolName, Sprite toolSprite)
        {
            GameObject toolObj = new GameObject($"Equipped_{toolName}_Template");
            toolObj.transform.SetParent(templatesRoot.transform, false);
            SpriteRenderer sr = toolObj.AddComponent<SpriteRenderer>();
            sr.sprite = toolSprite;
            sr.sortingOrder = 5;
            toolObj.SetActive(false);
            return toolObj;
        }

        #region Generación Procedural de Sprites (Pixel Art)

        private static Sprite CreateItemIcon(Color baseColor, string shape)
        {
            Texture2D tex = NewClearTexture(16, 16);

            Color dark = new Color(baseColor.r * 0.5f, baseColor.g * 0.5f, baseColor.b * 0.5f, 1f);
            Color light = Color.Lerp(baseColor, Color.white, 0.4f);

            switch (shape)
            {
                case "log":
                    DrawBox(tex, 1, 4, 14, 8, dark);
                    DrawBox(tex, 2, 5, 12, 6, baseColor);
                    DrawBox(tex, 12, 5, 2, 6, light);
                    break;
                case "bottle":
                    DrawBox(tex, 4, 1, 8, 10, dark);
                    DrawBox(tex, 5, 2, 6, 8, baseColor);
                    DrawBox(tex, 5, 8, 2, 2, light);
                    DrawBox(tex, 6, 11, 4, 3, dark);
                    DrawBox(tex, 6, 14, 4, 1, new Color(0.9f, 0.75f, 0.3f));
                    break;
                default: // circle
                    DrawCircle(tex, 8, 8, 7, dark);
                    DrawCircle(tex, 8, 8, 6, baseColor);
                    DrawCircle(tex, 6, 10, 2, light);
                    break;
            }

            tex.Apply();
            return Sprite.Create(tex, new Rect(0, 0, 16, 16), new Vector2(0.5f, 0.5f), 16f);
        }

        internal static Sprite CreateTemperatureSprite()
        {
            Texture2D tex = NewClearTexture(16, 20);

            Color white = Color.white;
            DrawCircle(tex, 8, 5, 4, white);
            DrawBox(tex, 7, 8, 3, 9, white);
            DrawCircle(tex, 8, 17, 2, white);

            tex.Apply();
            return Sprite.Create(tex, new Rect(0, 0, 16, 20), new Vector2(0.5f, 0.5f), 16f);
        }

        private static Sprite CreateAxeSprite()
        {
            Texture2D tex = NewClearTexture(24, 24);

            Color handle = new Color(0.55f, 0.35f, 0.15f);
            Color metal = new Color(0.75f, 0.8f, 0.85f);
            Color edge = new Color(0.95f, 0.95f, 1f);

            for (int i = 0; i < 16; i++)
            {
                tex.SetPixel(6 + i / 2, 2 + i, handle);
                tex.SetPixel(7 + i / 2, 2 + i, handle);
            }

            DrawBox(tex, 13, 14, 6, 6, metal);
            DrawBox(tex, 19, 13, 2, 8, edge);

            tex.Apply();
            return Sprite.Create(tex, new Rect(0, 0, 24, 24), new Vector2(0.35f, 0.25f), 24f);
        }

        private static Sprite CreatePickaxeSprite()
        {
            Texture2D tex = NewClearTexture(24, 24);

            Color handle = new Color(0.55f, 0.35f, 0.15f);
            Color iron = new Color(0.45f, 0.5f, 0.55f);
            Color tip = new Color(0.75f, 0.8f, 0.85f);

            for (int i = 0; i < 16; i++)
            {
                tex.SetPixel(6 + i / 2, 2 + i, handle);
                tex.SetPixel(7 + i / 2, 2 + i, handle);
            }

            DrawBox(tex, 10, 16, 7, 4, iron);
            tex.SetPixel(8, 14, tip);
            tex.SetPixel(9, 15, iron);
            tex.SetPixel(17, 18, iron);
            tex.SetPixel(18, 19, tip);

            tex.Apply();
            return Sprite.Create(tex, new Rect(0, 0, 24, 24), new Vector2(0.35f, 0.25f), 24f);
        }

        private static Sprite CreateCutlassSprite()
        {
            Texture2D tex = NewClearTexture(24, 24);

            Color gold = new Color(0.95f, 0.8f, 0.2f);
            Color steel = new Color(0.85f, 0.9f, 0.95f);
            Color highlight = Color.white;

            DrawBox(tex, 4, 3, 3, 3, gold);
            DrawBox(tex, 6, 6, 4, 2, gold);

            for (int i = 0; i < 12; i++)
            {
                tex.SetPixel(8 + i, 8 + i, steel);
                tex.SetPixel(8 + i, 9 + i, steel);
                tex.SetPixel(7 + i, 9 + i, highlight);
            }
            tex.SetPixel(20, 21, highlight);
            tex.SetPixel(21, 20, steel);

            tex.Apply();
            return Sprite.Create(tex, new Rect(0, 0, 24, 24), new Vector2(0.3f, 0.25f), 24f);
        }

        /// <summary>Textura transparente con filtro de píxel (base de todos los sprites procedurales).</summary>
        private static Texture2D NewClearTexture(int width, int height)
        {
            Texture2D tex = new Texture2D(width, height, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Point;
            Color32[] pixels = new Color32[width * height]; // por defecto (0,0,0,0) = transparente
            tex.SetPixels32(pixels);
            return tex;
        }

        private static void DrawBox(Texture2D tex, int startX, int startY, int width, int height, Color col)
        {
            for (int y = startY; y < startY + height; y++)
            {
                for (int x = startX; x < startX + width; x++)
                {
                    if (x >= 0 && x < tex.width && y >= 0 && y < tex.height)
                    {
                        tex.SetPixel(x, y, col);
                    }
                }
            }
        }

        private static void DrawCircle(Texture2D tex, int cx, int cy, int r, Color col)
        {
            for (int y = cy - r; y <= cy + r; y++)
            {
                for (int x = cx - r; x <= cx + r; x++)
                {
                    if (x >= 0 && x < tex.width && y >= 0 && y < tex.height)
                    {
                        if ((x - cx) * (x - cx) + (y - cy) * (y - cy) <= r * r)
                        {
                            tex.SetPixel(x, y, col);
                        }
                    }
                }
            }
        }

        #endregion
    }
}
