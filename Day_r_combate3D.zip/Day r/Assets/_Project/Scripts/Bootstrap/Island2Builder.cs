﻿using System.Collections.Generic;
using UnityEngine;
using PirateSurvival.Core;
using PirateSurvival.Player;
using PirateSurvival.Inventory;
using PirateSurvival.Interaction;
using PirateSurvival.Environment;
using PirateSurvival.Crafting;
using PirateSurvival.Combat;

namespace PirateSurvival.Bootstrap
{
    /// <summary>
    /// Construye los cimientos de la Isla 2 (Isla Volcán Negro):
    /// Suelo volcánico oscuro, mar hirviente, playa de desembarco con bote para regresar,
    /// campamento de expedición abandonado, recursos volcánicos (vetas de obsidiana, azufre, carbón)
    /// y cartel con advertencias del Nuevo Mundo.
    /// </summary>
    internal static class Island2Builder
    {
        private const int OrderWater = -6000;
        private const int OrderGround = -5000;

        public static void Build(Dictionary<string, ItemData> itemDb)
        {
            GameObject root = GameBootstrap.NewRoot("Island2");

            CreateGround(root);
            CreateSea(root);
            CreateBounds(root);
            CreateDockAndTravel(root);
            CreateExpeditionCamp(root.transform, itemDb);
            CreateVolcanicResources(root.transform, itemDb);
            CreateHazardsAndEncounters(root);

            Debug.Log("[Island2Builder] Isla 2 (Isla Volcán Negro) construida y lista para la aventura.");
        }

        // ================================================================ SUELO Y MAR VOLCÁNICO

        private static void CreateGround(GameObject root)
        {
            GameObject ground = new GameObject("Island2Ground");
            ground.transform.SetParent(root.transform, false);
            ground.transform.position = Island2Layout.Center;

            SpriteRenderer sr = ground.AddComponent<SpriteRenderer>();
            sr.sprite = GameSprites.Get("ground_island2", BuildVolcanoGround);
            sr.sortingOrder = OrderGround;
        }

        private static Sprite BuildVolcanoGround()
        {
            const int ppu = 8;
            int size = Mathf.RoundToInt(Island2Layout.GroundHalfSize * 2f) * ppu;
            Color32[] px = new Color32[size * size];

            float minX = Island2Layout.Center.x - Island2Layout.GroundHalfSize;
            float minY = Island2Layout.Center.y - Island2Layout.GroundHalfSize;

            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    Vector2 worldPos = new Vector2(minX + (x + 0.5f) / ppu, minY + (y + 0.5f) / ppu);
                    Island2Layout.Terrain t = Island2Layout.Sample(worldPos);
                    float n = PixelCanvas.Hash(x, y, 7) * 0.08f - 0.04f;

                    Color c;
                    switch (t)
                    {
                        case Island2Layout.Terrain.DeepWater:
                            c = Color.clear;
                            break;
                        case Island2Layout.Terrain.ShallowWater:
                            c = new Color(0.18f, 0.25f, 0.32f, 0.75f);
                            break;
                        case Island2Layout.Terrain.AshSand:
                            c = new Color(0.24f, 0.22f, 0.26f);
                            break;
                        case Island2Layout.Terrain.Basalt:
                            c = new Color(0.16f, 0.15f, 0.18f);
                            break;
                        case Island2Layout.Terrain.SulfurField:
                            c = new Color(0.68f, 0.65f, 0.18f);
                            break;
                        case Island2Layout.Terrain.ObsidianRock:
                            c = new Color(0.10f, 0.09f, 0.12f);
                            break;
                        case Island2Layout.Terrain.LavaCrust:
                            c = new Color(0.55f, 0.18f, 0.10f);
                            break;
                        case Island2Layout.Terrain.CraterInterior:
                            c = new Color(0.13f, 0.08f, 0.08f);
                            break;
                        default:
                            c = new Color(0.22f, 0.20f, 0.24f);
                            break;
                    }

                    if (c.a > 0f)
                    {
                        c.r = Mathf.Clamp01(c.r + n);
                        c.g = Mathf.Clamp01(c.g + n);
                        c.b = Mathf.Clamp01(c.b + n);
                    }
                    px[y * size + x] = c;
                }
            }

            Texture2D tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Point;
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.SetPixels32(px);
            tex.Apply(false, false);
            return Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), ppu, 0, SpriteMeshType.FullRect);
        }

        private static void CreateSea(GameObject root)
        {
            GameObject water = new GameObject("Island2Sea");
            water.transform.SetParent(root.transform, false);
            water.transform.position = Island2Layout.Center;

            SpriteRenderer wsr = water.AddComponent<SpriteRenderer>();
            wsr.sprite = WorldArt.WaterTile();
            wsr.drawMode = SpriteDrawMode.Tiled;
            wsr.size = new Vector2(Island2Layout.GroundHalfSize * 2.5f, Island2Layout.GroundHalfSize * 2.5f);
            wsr.sortingOrder = OrderWater;
            wsr.color = new Color(0.75f, 0.85f, 0.9f, 1f); // agua volcánica más densa
            water.AddComponent<WaterScroller>();
        }

        private static void CreateBounds(GameObject root)
        {
            GameObject bounds = new GameObject("Island2Bounds");
            bounds.transform.SetParent(root.transform, false);

            Vector2 center = (Island2Layout.WorldMin + Island2Layout.WorldMax) * 0.5f;
            Vector2 size = Island2Layout.WorldMax - Island2Layout.WorldMin;

            Wall(bounds, "Bound2_North", new Vector2(center.x, Island2Layout.WorldMax.y + 1f), new Vector2(size.x + 4f, 2f));
            Wall(bounds, "Bound2_South", new Vector2(center.x, Island2Layout.WorldMin.y - 1f), new Vector2(size.x + 4f, 2f));
            Wall(bounds, "Bound2_East", new Vector2(Island2Layout.WorldMax.x + 1f, center.y), new Vector2(2f, size.y + 4f));
            Wall(bounds, "Bound2_West", new Vector2(Island2Layout.WorldMin.x - 1f, center.y), new Vector2(2f, size.y + 4f));
        }

        private static void Wall(GameObject parent, string name, Vector2 pos, Vector2 size)
        {
            GameObject wall = new GameObject(name);
            wall.transform.SetParent(parent.transform, false);
            wall.transform.position = pos;
            BoxCollider2D col = wall.AddComponent<BoxCollider2D>();
            col.size = size;
        }

        // ================================================================ DESEMBARCO Y REGRESO

        private static void CreateDockAndTravel(GameObject root)
        {
            Transform dockTr = new GameObject("DockAndTravel").transform;
            dockTr.SetParent(root.transform, false);

            // Bote de desembarco (interactuable para regresar a Isla Coral)
            Vector2 boatPos = Island2Layout.Dock;
            GameObject boat = Solid(dockTr, "BoteRegreso", GameSprites.Get("w_rowboat", WorldArt.Rowboat), boatPos, new Vector2(2.0f, 0.8f));
            CircleCollider2D trig = boat.AddComponent<CircleCollider2D>();
            trig.radius = 1.4f;
            trig.isTrigger = true;
            IslandTravelTrigger travel = boat.AddComponent<IslandTravelTrigger>();
            travel.Setup(false, "Pulsa [E] para Regresar a Isla Coral");

            // Estela o cartel de bienvenida en la orilla
            Vector2 signPos = boatPos + new Vector2(3.5f, 1.2f);
            CreateWelcomeSign(dockTr, signPos);
        }

        private static void CreateWelcomeSign(Transform parent, Vector2 pos)
        {
            GameObject sign = Solid(parent, "CartelVolcan", GameSprites.Get("w_sign_volcan", WorldArt.Sign), pos, new Vector2(0.6f, 0.3f));
            CircleCollider2D col = sign.AddComponent<CircleCollider2D>();
            col.radius = 1.4f;
            col.isTrigger = true;
            sign.AddComponent<VolcanoSignInteractable>();
        }

        private class VolcanoSignInteractable : MonoBehaviour, IInteractable
        {
            public string GetPromptText() => "Pulsa [E] para Leer la Advertencia";
            public void Interact(PlayerInteraction2D interactor)
            {
                if (AudioManager.Instance != null) AudioManager.Instance.PlayUiClick();
                GameEvents.TriggerNotificationMessage("«ISLA VOLCÁN NEGRO · GRAND LINE»\nCeniza ardiente bajo tus botas. El volcán ruge en la lejanía. Solo los piratas con temple de acero sobreviven aquí.");
            }
            public bool CanInteract() => true;
        }

        // ================================================================ CAMPAMENTO DE EXPEDICIÓN

        private static void CreateExpeditionCamp(Transform parent, Dictionary<string, ItemData> itemDb)
        {
            Vector2 cp = Island2Layout.Camp;
            Transform camp = new GameObject("ExpeditionCamp").transform;
            camp.SetParent(parent, false);

            // Hoguera encendida
            GameObject fire = Solid(camp, "HogueraCampamento", GameSprites.Get("w_campfire_lit", () => WorldArt.Campfire(true)), cp, new Vector2(0.8f, 0.4f));
            Campfire cComp = fire.AddComponent<Campfire>();
            GameBootstrap.InjectField(cComp, "isLit", true);
            CircleCollider2D fireTrig = fire.AddComponent<CircleCollider2D>();
            fireTrig.radius = 1.6f;
            fireTrig.isTrigger = true;

            // Tienda de expedición (para descansar)
            GameObject tent = Solid(camp, "TiendaExpedicion", GameSprites.Get("w_tent", WorldArt.Tent), cp + new Vector2(-3.0f, 1.5f), new Vector2(2.1f, 0.8f));
            RestingSpot spot = tent.AddComponent<RestingSpot>();
            spot.Configure("el Refugio de Ceniza", 6f);

            // Mesa de forja o yunque de viaje
            Station(camp, "YunqueExpedicion", GameSprites.Get("w_forge", WorldArt.Crate), cp + new Vector2(2.5f, 0.8f), new Vector2(1.8f, 0.6f), StationType.Forge);

            // Cofre de suministros de expedición
            Vector2 chestPos = cp + new Vector2(-1.5f, -1.8f);
            GameObject chestObj = Solid(camp, "CofreExpedicion", GameSprites.Get("w_chest", WorldArt.Chest), chestPos, new Vector2(0.9f, 0.4f));
            TreasureChest chest = chestObj.AddComponent<TreasureChest>();
            List<string> loot = new List<string> { "carne_asada", "pocion_salud", "carbon", "azufre", "balas_plomo" };
            List<int> qtys = new List<int> { 3, 2, 6, 4, 15 };
            chest.Configure("chest_island2_camp", 650, loot, qtys);
        }

        // ================================================================ RECURSOS VOLCÁNICOS

        private static void CreateVolcanicResources(Transform parent, Dictionary<string, ItemData> itemDb)
        {
            Transform resRoot = new GameObject("VolcanicResources").transform;
            resRoot.SetParent(parent, false);

            // Depósitos de Azufre Volcánico
            Vector2[] sulfurSpots =
            {
                Island2Layout.SulfurFields + new Vector2(-1.5f, 0.5f),
                Island2Layout.SulfurFields + new Vector2(2.0f, -1.2f),
                Island2Layout.SulfurFields + new Vector2(-0.8f, -2.4f)
            };
            for (int i = 0; i < sulfurSpots.Length; i++)
            {
                Harvestable(resRoot, "VetaAzufreVolcan", GameSprites.Get("w_rock_ore", () => WorldArt.Rock(true)), sulfurSpots[i],
                    $"sulfur_i2_{i}", ResourceType.Rock, "Azufre Volcánico", ToolType.Pickaxe, 0f, itemDb["itemAzufre"], 0.45f, 65f, 2, 4);
            }

            // Vetas de Carbón de Magma
            Vector2[] coalSpots =
            {
                Island2Layout.ObsidianRidge + new Vector2(-2.0f, 1.0f),
                Island2Layout.ObsidianRidge + new Vector2(1.8f, -0.6f)
            };
            for (int i = 0; i < coalSpots.Length; i++)
            {
                Harvestable(resRoot, "VetaCarbonVolcan", GameSprites.Get("w_rock_ore", () => WorldArt.Rock(true)), coalSpots[i],
                    $"coal_i2_{i}", ResourceType.Rock, "Carbón Fósil", ToolType.Pickaxe, 0f, itemDb["itemCarbon"], 0.45f, 60f, 2, 4);
            }

            // Vetas de Obsidiana y Mineral de Hierro con bonus de Kairoseki
            Vector2[] oreSpots =
            {
                Island2Layout.ObsidianRidge + new Vector2(0f, 2.0f),
                Island2Layout.Crater + new Vector2(-2.5f, -1.5f),
                Island2Layout.Crater + new Vector2(2.0f, 1.2f)
            };
            for (int i = 0; i < oreSpots.Length; i++)
            {
                GameObject vein = Harvestable(resRoot, "VetaObsidiana", GameSprites.Get("w_rock_ore", () => WorldArt.Rock(true)), oreSpots[i],
                    $"ore_i2_{i}", ResourceType.Rock, "Veta de Obsidiana y Hierro", ToolType.Pickaxe, 0f, itemDb["itemMineral"], 0.45f, 75f, 2, 4);
                HarvestableResource hr = vein.GetComponent<HarvestableResource>();
                GameBootstrap.InjectField(hr, "bonusDropItem", itemDb["itemKairoseki"]);
                GameBootstrap.InjectField(hr, "bonusDropChance", 0.35f);
                GameBootstrap.InjectField(hr, "respawnTimeMinutes", 3f);
            }

            // Rocas de basalto sueltas en la playa
            Vector2[] stoneSpots =
            {
                Island2Layout.Dock + new Vector2(4f, -2f),
                Island2Layout.Dock + new Vector2(6f, 3f),
                Island2Layout.Camp + new Vector2(3f, -4f)
            };
            for (int i = 0; i < stoneSpots.Length; i++)
            {
                Harvestable(resRoot, "BasaltoSuelto", GameSprites.Get("w_stones", () => WorldArt.Rock(false)), stoneSpots[i],
                    $"basalto_i2_{i}", ResourceType.Bush, "Basalto Volcánico", ToolType.None, 10f, itemDb["itemPiedra"], 0.15f, 10f, 1, 3);
            }
        }

        // ================================================================ PELIGROS Y COMBATES

        private static void CreateHazardsAndEncounters(GameObject root)
        {
            // Primer encuentro hostil de Isla 2: Vanguardia de la Banda de Ceniza
            Vector2 encPos = new Vector2(252.0f, -8.0f);
            GameBootstrap.CreateEncounter(root, "vanguardia_ceniza", EncounterKind.BeachPirates, encPos);
        }

        // ================================================================ UTILIDADES

        private static GameObject Solid(Transform parent, string name, Sprite sprite, Vector2 pos, Vector2 colSize)
        {
            GameObject go = new GameObject(name);
            go.transform.SetParent(parent, false);
            go.transform.position = pos;

            SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = sprite;
            sr.sortingOrder = 0;
            go.AddComponent<YSorter>();

            BoxCollider2D bc = go.AddComponent<BoxCollider2D>();
            bc.size = colSize;
            return go;
        }

        private static GameObject Harvestable(Transform parent, string name, Sprite sprite, Vector2 pos, string resId,
            ResourceType type, string displayName, ToolType reqTool, float gatherTime, ItemData dropItem,
            float dropChance, float health, int minDrop, int maxDrop)
        {
            GameObject go = new GameObject(name);
            go.transform.SetParent(parent, false);
            go.transform.position = pos;

            SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = sprite;
            sr.sortingOrder = 0;
            go.AddComponent<YSorter>();

            CircleCollider2D col = go.AddComponent<CircleCollider2D>();
            col.radius = 0.5f;

            HarvestableResource hr = go.AddComponent<HarvestableResource>();
            GameBootstrap.InjectField(hr, "resourceId", resId);
            GameBootstrap.InjectField(hr, "resourceType", type);
            GameBootstrap.InjectField(hr, "resourceDisplayName", displayName);
            GameBootstrap.InjectField(hr, "requiredTool", reqTool);
            GameBootstrap.InjectField(hr, "gatherTime", gatherTime);
            GameBootstrap.InjectField(hr, "dropItem", dropItem);
            GameBootstrap.InjectField(hr, "dropChance", dropChance);
            GameBootstrap.InjectField(hr, "maxHealth", health);
            GameBootstrap.InjectField(hr, "currentHealth", health);
            GameBootstrap.InjectField(hr, "minDropCount", minDrop);
            GameBootstrap.InjectField(hr, "maxDropCount", maxDrop);
            return go;
        }

        private static GameObject Station(Transform parent, string name, Sprite sprite, Vector2 pos, Vector2 colSize, StationType type)
        {
            GameObject go = Solid(parent, name, sprite, pos, colSize);
            CircleCollider2D trig = go.AddComponent<CircleCollider2D>();
            trig.radius = 1.8f;
            trig.isTrigger = true;
            CraftingStation cs = go.AddComponent<CraftingStation>();
            GameBootstrap.InjectField(cs, "stationType", type);
            return go;
        }
    }
}
