﻿using UnityEngine;
using UnityEngine.UI;
using PirateSurvival.Core;
using PirateSurvival.Player;
using PirateSurvival.Inventory;
using PirateSurvival.Inventory.UI;
using PirateSurvival.Environment;
using PirateSurvival.SaveSystem;
using PirateSurvival.UI;
using PirateSurvival.Story;

namespace PirateSurvival.Bootstrap
{
    /// <summary>
    /// Construye por código el canvas de juego: HUD, cartel de interacción, desmayo, inventario con tooltip y pantalla de muerte.
    /// (Los menús principal/pausa/opciones viven en MenuManager.)
    /// </summary>
    public static class GameUIBuilder
    {
        private static void Inject(object target, string field, object value) => GameBootstrap.InjectField(target, field, value);

        public static void Build(PlayerStats playerStats, InventoryManager invMgr, DayNightCycle dayNight, SaveManager saveMgr)
        {
            GameObject canvasObj = GameBootstrap.NewRoot("Canvas_GameUI");
            Canvas canvas = canvasObj.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 0;
            CanvasScaler scaler = canvasObj.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;
            canvasObj.AddComponent<GraphicRaycaster>();

            // Overlay día/noche (bajo todo el HUD)
            Image overlay = UIFactory.Box(canvasObj.transform, "DayNightOverlayImage", new Color(0, 0, 0, 0), false);
            UIFactory.Stretch(overlay.rectTransform);
            overlay.raycastTarget = false;
            dayNight.SetOverlayImage(overlay);

            HUDManager hud = BuildHud(canvasObj.transform);
            Inject(saveMgr, "hudManager", hud);

            BuildPrompt(canvasObj.transform);
            BuildFaintOverlay(canvasObj.transform, hud);
            BuildInventory(canvasObj, invMgr);
            AdminPanelUI.Create(canvasObj.transform);
            QuestTrackerUI.Create(hud.transform);
            DialogueUI.Create(GameBootstrap.NewRoot("UI_Dialogue").transform);
            BuildDeathScreen(canvasObj.transform, hud);
        }

        // ---------------------------------------------------------------- HUD

        private static HUDManager BuildHud(Transform canvas)
        {
            RectTransform hudRoot = UIFactory.NewRect("HUDRoot", canvas);
            UIFactory.Stretch(hudRoot);
            HUDManager hud = hudRoot.gameObject.AddComponent<HUDManager>();

            // Viñeta de peligro por vida baja (parpadeo rojo)
            Image lowHp = UIFactory.Box(hudRoot, "LowHealthVignette", new Color(0.8f, 0.05f, 0.05f, 0f), false);
            UIFactory.Stretch(lowHp.rectTransform);
            lowHp.raycastTarget = false;
            lowHp.gameObject.SetActive(false);
            Inject(hud, "lowHealthVignette", lowHp);

            // Panel de estadísticas náutico-táctico (arriba-izquierda)
            Image stats = UIFactory.Box(hudRoot, "StatsPanel", new Color(0.05f, 0.08f, 0.14f, 0.92f));
            UIFactory.Place(stats.rectTransform, new Vector2(0, 1), new Vector2(20, -20), new Vector2(430, 230));

            // Marco náutico de ojo de buey / porthole con remaches dorados para el avatar
            Image avBorder = UIFactory.Box(stats.transform, "AvatarBorder", new Color(0.85f, 0.68f, 0.25f, 0.95f));
            UIFactory.Place(avBorder.rectTransform, new Vector2(0, 1), new Vector2(14, -14), new Vector2(72, 72));
            Image avInner = UIFactory.Box(avBorder.transform, "AvatarInner", new Color(0.12f, 0.16f, 0.24f, 1f));
            UIFactory.Stretch(avInner.rectTransform, 3, 3, 3, 3);
            Image av = UIFactory.Box(avInner.transform, "Avatar", Color.white, false);
            av.sprite = GameSprites.Get("c_player", () => CharacterArt.Draw(CharacterArt.Castaway()));
            UIFactory.Stretch(av.rectTransform, 2, 2, 2, 2);
            Inject(hud, "avatarPortrait", av);

            // Cinta dorada de rango y nombre bajo el avatar
            Image titleRibbon = UIFactory.Box(stats.transform, "TitleRibbon", new Color(0.08f, 0.12f, 0.20f, 0.95f));
            UIFactory.Place(titleRibbon.rectTransform, new Vector2(0, 1), new Vector2(10, -90), new Vector2(80, 24));
            Text titleTxt = UIFactory.Label(titleRibbon.transform, CharacterArt.PlayerName, 12, UIFactory.Gold, TextAnchor.MiddleCenter, FontStyle.Bold);
            UIFactory.Stretch(titleTxt.rectTransform, 2, 2, 2, 2);
            Inject(hud, "playerTitleText", titleTxt);

            // Barras de estado tácticas con iconos y cajas de cifras independientes
            Text hVal, huVal, thVal, stVal;
            Inject(hud, "healthBarFill", StatBar(stats.transform, 98, -14, 318, 24, "", new Color(0.85f, 0.18f, 0.18f), "Salud", new Color(0.25f, 0.88f, 0.38f), out hVal));
            Inject(hud, "healthValueText", hVal);

            Inject(hud, "hungerBarFill", StatBar(stats.transform, 98, -42, 318, 24, "", new Color(0.92f, 0.52f, 0.12f), "Hambre", new Color(1.0f, 0.62f, 0.15f), out huVal));
            Inject(hud, "hungerValueText", huVal);

            Inject(hud, "thirstBarFill", StatBar(stats.transform, 98, -70, 318, 24, "", new Color(0.18f, 0.55f, 0.92f), "Sed", new Color(0.25f, 0.78f, 1.0f), out thVal));
            Inject(hud, "thirstValueText", thVal);

            Inject(hud, "staminaBarFill", StatBar(stats.transform, 98, -98, 318, 24, "", new Color(0.95f, 0.80f, 0.15f), "Energía", new Color(1.0f, 0.92f, 0.28f), out stVal));
            Inject(hud, "staminaValueText", stVal);

            // Fila de temperatura y humedad en contenedor estilizado
            Image envBox = UIFactory.Box(stats.transform, "EnvModule", new Color(0.03f, 0.05f, 0.10f, 0.8f));
            UIFactory.Place(envBox.rectTransform, new Vector2(0, 1), new Vector2(14, -132), new Vector2(402, 30));

            RectTransform iconRt = UIFactory.NewRect("TemperatureIcon", envBox.transform);
            UIFactory.Place(iconRt, new Vector2(0, 0.5f), new Vector2(10, 0), new Vector2(18, 22));
            Image tempIcon = iconRt.gameObject.AddComponent<Image>();
            tempIcon.sprite = RuntimeSpriteCache.Get("temperature", GameBootstrap.CreateTemperatureSprite);
            Inject(hud, "temperatureIcon", tempIcon);

            Text tempTxt = UIFactory.Label(envBox.transform, "36.6°C", 18, UIFactory.TextMain, TextAnchor.MiddleLeft, FontStyle.Bold);
            UIFactory.Place(tempTxt.rectTransform, new Vector2(0, 0.5f), new Vector2(34, 0), new Vector2(75, 24));
            Inject(hud, "temperatureText", tempTxt);

            Text wetTxt = UIFactory.Label(envBox.transform, "Humedad: 0%", 16, new Color(0.45f, 0.82f, 1f), TextAnchor.MiddleLeft, FontStyle.Bold);
            UIFactory.Place(wetTxt.rectTransform, new Vector2(0, 0.5f), new Vector2(140, 0), new Vector2(250, 24));
            Inject(hud, "wetnessText", wetTxt);

            // Fila de insignias de alertas activas
            GameObject bleedBadge = AlertBadge(stats.transform, 14, -174, 96, 26, "SANGRADO", new Color(0.75f, 0.15f, 0.12f, 0.95f), Color.white);
            Inject(hud, "bleedAlertBadge", bleedBadge);

            GameObject poisonBadge = AlertBadge(stats.transform, 116, -174, 96, 26, "VENENO", new Color(0.55f, 0.15f, 0.75f, 0.95f), Color.white);
            Inject(hud, "poisonAlertBadge", poisonBadge);

            GameObject tempBadge = AlertBadge(stats.transform, 218, -174, 102, 26, "HIPOTERMIA", new Color(0.15f, 0.45f, 0.85f, 0.95f), Color.white);
            Inject(hud, "tempAlertBadge", tempBadge);
            Inject(hud, "tempAlertText", tempBadge.GetComponentInChildren<Text>(true)); // la insignia empieza oculta

            GameObject wetBadge = AlertBadge(stats.transform, 326, -174, 90, 26, "EMPAPADO", new Color(0.15f, 0.65f, 0.75f, 0.95f), Color.white);
            Inject(hud, "wetAlertBadge", wetBadge);

            // Reloj y clima (arriba-centro)
            Image clockBox = UIFactory.Box(hudRoot, "ClockPanel", UIFactory.HudPanel);
            UIFactory.Place(clockBox.rectTransform, new Vector2(0.5f, 1), new Vector2(0, -20), new Vector2(240, 88));
            Text clock = UIFactory.Label(clockBox.transform, "08:00", 42, UIFactory.Gold, TextAnchor.MiddleCenter, FontStyle.Bold);
            UIFactory.Place(clock.rectTransform, new Vector2(0.5f, 1), new Vector2(0, -6), new Vector2(230, 50));
            Inject(hud, "clockText", clock);
            Text weather = UIFactory.Label(clockBox.transform, "Soleado", 21, UIFactory.TextMain);
            UIFactory.Place(weather.rectTransform, new Vector2(0.5f, 1), new Vector2(0, -56), new Vector2(230, 28));
            Inject(hud, "weatherText", weather);

            // Aviso temporal (toast)
            Image toast = UIFactory.Box(hudRoot, "NotificationToast", new Color(0.10f, 0.05f, 0.08f, 0.85f));
            UIFactory.Place(toast.rectTransform, new Vector2(0.5f, 1), new Vector2(0, -122), new Vector2(720, 52));
            Text toastTxt = UIFactory.Label(toast.transform, "", 25, new Color(1f, 0.85f, 0.4f), TextAnchor.MiddleCenter, FontStyle.Bold);
            UIFactory.Stretch(toastTxt.rectTransform, 12, 4, 12, 4);
            Inject(hud, "notificationText", toastTxt);
            Inject(hud, "notificationRoot", toast.gameObject);
            toast.gameObject.SetActive(false);

            // Ayuda de controles (abajo-izquierda)
            Image help = UIFactory.Box(hudRoot, "ControlsHelp", UIFactory.HudPanel);
            UIFactory.Place(help.rectTransform, new Vector2(0, 0), new Vector2(20, 20), new Vector2(600, 66));
            Text helpTxt = UIFactory.Label(help.transform, "WASD mover | SHIFT correr | E interactuar | TAB inventario | ESC pausa\nF5 guardado rápido | F9 carga rápida", 17, UIFactory.Muted, TextAnchor.MiddleLeft, FontStyle.Normal, false);
            UIFactory.Stretch(helpTxt.rectTransform, 14, 4, 10, 4);

            return hud;
        }

        private static Image StatBar(Transform parent, float x, float y, float w, float h, string iconSymbol, Color iconBgColor, string label, Color color, out Text valueTxt)
        {
            // Carcasa exterior metálica
            Image casing = UIFactory.Box(parent, "Casing_" + label, new Color(0.03f, 0.05f, 0.10f, 0.95f));
            UIFactory.Place(casing.rectTransform, new Vector2(0, 1), new Vector2(x, y), new Vector2(w, h));

            // Insignia con icono a la izquierda
            Image iconBadge = UIFactory.Box(casing.transform, "IconBadge", iconBgColor);
            UIFactory.Place(iconBadge.rectTransform, new Vector2(0, 0.5f), new Vector2(2, 0), new Vector2(h - 4, h - 4));
            Text iconTxt = UIFactory.Label(iconBadge.transform, iconSymbol, 13, Color.white, TextAnchor.MiddleCenter, FontStyle.Bold);
            UIFactory.Stretch(iconTxt.rectTransform);

            // Zanja interior de la barra
            Image trench = UIFactory.Box(casing.transform, "Trench", new Color(0.01f, 0.02f, 0.04f, 0.9f));
            UIFactory.Place(trench.rectTransform, new Vector2(0, 0.5f), new Vector2(h + 2, 0), new Vector2(w - h - 86, h - 4));

            // Relleno de color
            Image fill = UIFactory.Box(trench.transform, "Fill", color, false);
            fill.sprite = UIFactory.White;
            fill.type = Image.Type.Filled;
            fill.fillMethod = Image.FillMethod.Horizontal;
            fill.fillAmount = 1f;
            UIFactory.Stretch(fill.rectTransform, 1, 1, 1, 1);

            // Etiqueta del nombre de la estadística sobre la barra
            Text lbl = UIFactory.Label(trench.transform, label, 12, new Color(1f, 1f, 1f, 0.95f), TextAnchor.MiddleLeft, FontStyle.Bold);
            UIFactory.Place(lbl.rectTransform, new Vector2(0, 0.5f), new Vector2(6, 0), new Vector2(80, h - 4));

            // Caja pastilla táctica para la cifra numérica (derecha)
            Image numPill = UIFactory.Box(casing.transform, "NumPill", new Color(0.06f, 0.09f, 0.16f, 1f));
            UIFactory.Place(numPill.rectTransform, new Vector2(1, 0.5f), new Vector2(-2, 0), new Vector2(80, h - 4));

            valueTxt = UIFactory.Label(numPill.transform, "100/100", 12, UIFactory.TextMain, TextAnchor.MiddleCenter, FontStyle.Bold);
            UIFactory.Stretch(valueTxt.rectTransform);

            return fill;
        }

        private static GameObject AlertBadge(Transform parent, float x, float y, float w, float h, string text, Color bgColor, Color textColor)
        {
            Image badge = UIFactory.Box(parent, "Badge_" + text, bgColor);
            UIFactory.Place(badge.rectTransform, new Vector2(0, 1), new Vector2(x, y), new Vector2(w, h));
            Text lbl = UIFactory.Label(badge.transform, text, 12, textColor, TextAnchor.MiddleCenter, FontStyle.Bold);
            UIFactory.Stretch(lbl.rectTransform, 2, 2, 2, 2);
            badge.gameObject.SetActive(false);
            return badge.gameObject;
        }

        // ------------------------------------------------- Prompt y desmayo

        private static void BuildPrompt(Transform canvas)
        {
            // El script va en un contenedor aparte: si estuviera en el mismo objeto que se oculta, se desactivaría a sí mismo.
            RectTransform ctrl = UIFactory.NewRect("InteractionPrompt", canvas);
            UIFactory.Stretch(ctrl);
            InteractionPromptUI promptUI = ctrl.gameObject.AddComponent<InteractionPromptUI>();

            Image box = UIFactory.Box(ctrl, "PromptBox", new Color(0.04f, 0.08f, 0.15f, 0.85f));
            UIFactory.Place(box.rectTransform, new Vector2(0.5f, 0f), new Vector2(0, 130), new Vector2(1000, 58));
            Text txt = UIFactory.Label(box.transform, "Pulsa [E]", 23, new Color(1f, 0.92f, 0.5f), TextAnchor.MiddleCenter, FontStyle.Bold);
            UIFactory.Stretch(txt.rectTransform, 16, 4, 16, 4);

            Inject(promptUI, "promptRoot", box.gameObject);
            Inject(promptUI, "promptText", txt);
        }

        private static void BuildFaintOverlay(Transform canvas, HUDManager hud)
        {
            Image faint = UIFactory.Box(canvas, "FaintOverlay", new Color(0.02f, 0.04f, 0.12f, 0.88f), false);
            UIFactory.Stretch(faint.rectTransform);
            faint.raycastTarget = false;
            Text txt = UIFactory.Label(faint.transform, "Te has desmayado...", 44, UIFactory.TextMain, TextAnchor.MiddleCenter, FontStyle.Bold);
            txt.name = "FaintText";
            CanvasGroup cg = faint.gameObject.AddComponent<CanvasGroup>();
            cg.alpha = 0f;
            cg.blocksRaycasts = false;
            faint.gameObject.SetActive(false);
            Inject(hud, "faintOverlay", cg);
        }

        // ---------------------------------------------------------- Inventario

        private static void BuildInventory(GameObject canvasObj, InventoryManager invMgr)
        {
            // La mochila crea su propio canvas (no puede ir anidada en el del HUD: perdería su orden de dibujo)
            GameObject ctrlObj = GameBootstrap.NewRoot("UI_Backpack");
            ctrlObj.AddComponent<InventoryUI>();
        }

        // ------------------------------------------------------------- Muerte

        private static void BuildDeathScreen(Transform canvas, HUDManager hud)
        {
            Image death = UIFactory.Box(canvas, "DeathScreen", new Color(0.32f, 0.03f, 0.05f, 0.92f), false);
            UIFactory.Stretch(death.rectTransform);

            Text title = UIFactory.Label(death.transform, "¡HAS MUERTO!", 96, Color.white, TextAnchor.MiddleCenter, FontStyle.Bold);
            UIFactory.Place(title.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0, 210), new Vector2(1200, 120));
            Text sub = UIFactory.Label(death.transform, "La isla no perdona a los descuidados.", 28, new Color(1f, 0.82f, 0.8f));
            UIFactory.Place(sub.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0, 125), new Vector2(1200, 40));
            Inject(hud, "deathCauseText", sub);

            Button respawn = UIFactory.MakeButton(death.transform, "Reaparecer", new Vector2(380, 66), UIFactory.Green, null);
            UIFactory.Place((RectTransform)respawn.transform, new Vector2(0.5f, 0.5f), new Vector2(0, 30), new Vector2(380, 66));
            Button load = UIFactory.MakeButton(death.transform, "Cargar Partida", new Vector2(380, 66), UIFactory.Teal, null);
            UIFactory.Place((RectTransform)load.transform, new Vector2(0.5f, 0.5f), new Vector2(0, -50), new Vector2(380, 66));
            Button menu = UIFactory.MakeButton(death.transform, "Menú Principal", new Vector2(380, 66), UIFactory.Grey, null);
            UIFactory.Place((RectTransform)menu.transform, new Vector2(0.5f, 0.5f), new Vector2(0, -130), new Vector2(380, 66));

            Inject(hud, "deathScreen", death.gameObject);
            Inject(hud, "respawnButton", respawn);
            Inject(hud, "loadSaveButton", load);
            Inject(hud, "mainMenuButton", menu);
            death.gameObject.SetActive(false);
        }
    }
}
