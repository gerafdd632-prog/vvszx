﻿using UnityEngine;

namespace PirateSurvival.Bootstrap
{
    /// <summary>
    /// Plano y constantes de la Isla 2 (Isla Volcán Negro / Grand Line).
    /// Una isla volcánica hostil situada al este en coordenadas oceánicas (centro en x=260, y=0).
    /// Terreno de ceniza negra, rocas de obsidiana, depósitos de azufre, manantiales hirvientes y el gran cráter.
    /// </summary>
    internal static class Island2Layout
    {
        public enum Terrain { DeepWater, ShallowWater, AshSand, Basalt, SulfurField, ObsidianRock, LavaCrust, CraterInterior }

        // Centro y dimensiones
        public static readonly Vector2 Center = new Vector2(260f, 0f);
        public const float GroundHalfSize = 38f;
        public const float IslandRadius = 26f;

        // Límites del mundo para la Isla 2 (WorldBoundsProvider)
        public static readonly Vector2 WorldMin = new Vector2(216f, -42f);
        public static readonly Vector2 WorldMax = new Vector2(304f, 42f);

        // Zonas clave de Isla 2
        public static readonly Vector2 Dock = new Vector2(230.5f, -13.5f);         // Playa de Desembarco de Ceniza
        public static readonly Vector2 Camp = new Vector2(242.0f, -7.5f);          // Campamento de Expedición Abandonado
        public static readonly Vector2 SulfurFields = new Vector2(256.0f, -16.0f); // Campos de Azufre y Fuentes Termales
        public static readonly Vector2 ObsidianRidge = new Vector2(266.0f, -6.0f);  // Cresta de Obsidiana
        public static readonly Vector2 Crater = new Vector2(274.0f, 10.0f);        // Cráter del Volcán Negro
        public static readonly Vector2 LavaVent = new Vector2(280.0f, 1.0f);       // Fisura Magmática Activa

        /// <summary>Calcula el radio de costa para un ángulo dado alrededor del centro de la Isla 2.</summary>
        public static float ShoreRadius(float angle)
        {
            return 24.5f + 2.4f * Mathf.Sin(4f * angle + 0.5f) + 1.8f * Mathf.Sin(6f * angle + 1.9f);
        }

        public static float DistanceToShore(Vector2 worldPos)
        {
            Vector2 local = worldPos - Center;
            float angle = Mathf.Atan2(local.y, local.x);
            float r = local.magnitude;
            float shoreR = ShoreRadius(angle);
            return r - shoreR; // < 0 dentro de la isla, > 0 en el agua
        }

        /// <summary>Determina el tipo de terreno en una coordenada dada de Isla 2.</summary>
        public static Terrain Sample(Vector2 p)
        {
            float dist = DistanceToShore(p);
            if (dist > 3.0f) return Terrain.DeepWater;
            if (dist > 0.0f) return Terrain.ShallowWater;

            // Zonas interiores de Isla 2
            if (Vector2.Distance(p, Crater) < 5.5f) return Terrain.CraterInterior;
            if (Vector2.Distance(p, LavaVent) < 3.8f) return Terrain.LavaCrust;
            if (Vector2.Distance(p, SulfurFields) < 5.0f) return Terrain.SulfurField;
            if (Vector2.Distance(p, ObsidianRidge) < 4.8f) return Terrain.ObsidianRock;

            // Camino de basalto entre el muelle, el campamento y el cráter
            if (DistanceToBasaltPath(p) < 1.4f) return Terrain.Basalt;

            // Orillas de ceniza volcánica
            return Terrain.AshSand;
        }

        private static float DistanceToBasaltPath(Vector2 p)
        {
            Vector2[] path = { Dock, Camp, new Vector2(249f, -11f), SulfurFields, ObsidianRidge, Crater };
            float minD = float.MaxValue;
            for (int i = 0; i < path.Length - 1; i++)
            {
                Vector2 a = path[i], b = path[i + 1];
                Vector2 ab = b - a;
                float t = Mathf.Clamp01(Vector2.Dot(p - a, ab) / Mathf.Max(0.0001f, ab.sqrMagnitude));
                float d = Vector2.Distance(p, a + ab * t);
                if (d < minD) minD = d;
            }
            return minD;
        }
    }
}
