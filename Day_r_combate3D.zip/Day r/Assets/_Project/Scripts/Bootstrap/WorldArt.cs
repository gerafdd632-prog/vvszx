﻿using UnityEngine;
using PirateSurvival.Core;

namespace PirateSurvival.Bootstrap
{
    /// <summary>
    /// Sprites del mundo dibujados por código (16 px = 1 unidad). Cada uno se pide por clave a GameSprites,
    /// así que una imagen en Resources/Sprites/&lt;clave&gt; lo sustituye sin tocar código.
    /// </summary>
    internal static class WorldArt
    {
        private const float PPU = 16f;
        private static readonly Color Ink = new Color(0.1f, 0.08f, 0.07f);

        // Paleta común
        private static readonly Color Wood = new Color(0.6f, 0.4f, 0.22f);
        private static readonly Color WoodDark = new Color(0.4f, 0.25f, 0.13f);
        private static readonly Color WoodLight = new Color(0.75f, 0.55f, 0.32f);
        private static readonly Color Leaf = new Color(0.27f, 0.62f, 0.25f);
        private static readonly Color LeafDark = new Color(0.15f, 0.42f, 0.18f);
        private static readonly Color LeafLight = new Color(0.5f, 0.8f, 0.35f);
        private static readonly Color Stone = new Color(0.55f, 0.55f, 0.58f);
        private static readonly Color Gold = new Color(0.95f, 0.75f, 0.25f);

        private static Vector2 Base(int h, int footPx = 2) => new Vector2(0.5f, footPx / (float)h);

        // ------------------------------------------------------------------ Vegetación

        public static Sprite Palm() => GameSprites.Get("w_palm", () =>
        {
            var c = new PixelCanvas(40, 58);
            c.GroundShadow(20, 3, 9, 2.5f, 0.28f);
            Color trunk = new Color(0.62f, 0.46f, 0.28f), trunkDark = new Color(0.45f, 0.31f, 0.17f);
            for (int y = 2; y < 40; y++)
            {
                int x = 18 + Mathf.RoundToInt(Mathf.Sin(y * 0.09f) * 3f);
                c.Rect(x, y, 4, 1, (y / 3) % 2 == 0 ? trunk : Color.Lerp(trunk, trunkDark, 0.5f));
                c.Set(x, y, trunkDark);
            }
            int topX = 18 + Mathf.RoundToInt(Mathf.Sin(39 * 0.09f) * 3f) + 2;
            // Hojas: arcos en abanico
            float[] angles = { 15f, 50f, 90f, 130f, 165f, 205f, 335f };
            foreach (float a in angles)
            {
                float rad = a * Mathf.Deg2Rad;
                for (int i = 0; i < 17; i++)
                {
                    float t = i / 16f;
                    float px = topX + Mathf.Cos(rad) * i * 1.1f;
                    float py = 41 + Mathf.Sin(rad) * i * 0.8f - t * t * 7f;
                    float w = Mathf.Lerp(3.2f, 1f, t);
                    c.Ellipse(px, py, w, w * 0.8f, t < 0.5f ? Leaf : LeafDark);
                    c.Set(Mathf.RoundToInt(px), Mathf.RoundToInt(py + w * 0.5f), LeafLight);
                }
            }
            c.Circle(topX - 1, 39, 1.8f, new Color(0.45f, 0.3f, 0.12f)); // cocos
            c.Circle(topX + 2, 38.5f, 1.8f, new Color(0.38f, 0.25f, 0.1f));
            c.Outline(Ink);
            return c.ToSprite(Base(58, 3), PPU);
        });

        public static Sprite Tree() => GameSprites.Get("w_tree", () =>
        {
            var c = new PixelCanvas(42, 50);
            c.GroundShadow(21, 4, 12, 3f, 0.3f);
            c.Rect(18, 3, 6, 16, Wood);
            c.Rect(18, 3, 2, 16, WoodDark);
            c.Rect(22, 6, 1, 10, WoodLight);
            c.Rect(16, 3, 2, 2, WoodDark); c.Rect(24, 3, 2, 2, WoodDark); // raíces
            c.ShadedEllipse(21, 30, 15, 12, Leaf, 0.25f, 0.35f);
            c.ShadedEllipse(13, 27, 8, 7, Leaf, 0.2f, 0.4f);
            c.ShadedEllipse(29, 27, 8, 7, Leaf, 0.2f, 0.4f);
            c.ShadedEllipse(20, 38, 9, 7, Leaf, 0.3f, 0.3f);
            c.Noise(0, 15, 42, 35, 0.18f, 0.35f, 3);
            c.Outline(Ink);
            return c.ToSprite(Base(50, 4), PPU);
        });

        public static Sprite Bush(bool berries) => GameSprites.Get(berries ? "w_bush_berry" : "w_bush", () =>
        {
            var c = new PixelCanvas(22, 16);
            c.GroundShadow(11, 2, 9, 2, 0.25f);
            c.ShadedEllipse(7, 7, 6, 5, Leaf);
            c.ShadedEllipse(15, 7, 6, 5, Leaf);
            c.ShadedEllipse(11, 10, 6, 5, Leaf, 0.3f, 0.3f);
            c.Noise(0, 0, 22, 16, 0.15f, 0.5f, 7);
            if (berries)
            {
                int[,] b = { { 6, 8 }, { 10, 11 }, { 14, 7 }, { 16, 10 }, { 8, 5 } };
                for (int i = 0; i < b.GetLength(0); i++) { c.Rect(b[i, 0], b[i, 1], 2, 2, new Color(0.85f, 0.15f, 0.25f)); c.Set(b[i, 0], b[i, 1] + 1, new Color(1f, 0.6f, 0.65f)); }
            }
            c.Outline(Ink);
            return c.ToSprite(Base(16, 2), PPU);
        });

        public static Sprite Flowers(int variant) => GameSprites.Get("w_flowers_" + variant, () =>
        {
            Color[] petals = { new Color(1f, 0.85f, 0.25f), new Color(0.95f, 0.4f, 0.55f), new Color(0.6f, 0.55f, 1f), Color.white };
            Color p = petals[variant % petals.Length];
            var c = new PixelCanvas(12, 10);
            int[,] pos = { { 2, 3 }, { 7, 6 }, { 9, 2 } };
            for (int i = 0; i < 3; i++)
            {
                int x = pos[i, 0], y = pos[i, 1];
                c.Set(x, y - 1, LeafDark); c.Set(x, y - 2, LeafDark);
                c.Set(x - 1, y, p); c.Set(x + 1, y, p); c.Set(x, y + 1, p); c.Set(x, y - 1, p);
                c.Set(x, y, new Color(1f, 0.95f, 0.5f));
            }
            return c.ToSprite(new Vector2(0.5f, 0.2f), PPU);
        });

        public static Sprite GrassTuft() => GameSprites.Get("w_grass", () =>
        {
            var c = new PixelCanvas(10, 8);
            for (int i = 0; i < 5; i++)
            {
                int x = 1 + i * 2;
                int h = 3 + (i % 3) * 2;
                c.Line(x, 0, x + (i % 2 == 0 ? -1 : 1), h, i % 2 == 0 ? LeafDark : Leaf);
            }
            return c.ToSprite(new Vector2(0.5f, 0.1f), PPU);
        });

        // ------------------------------------------------------------------ Rocas

        public static Sprite Rock(bool ore) => GameSprites.Get(ore ? "w_rock_ore" : "w_rock", () =>
        {
            var c = new PixelCanvas(26, 22);
            c.GroundShadow(13, 3, 11, 3, 0.3f);
            c.ShadedEllipse(13, 9, 11, 8, Stone, 0.3f, 0.4f);
            c.ShadedEllipse(9, 12, 6, 5, Color.Lerp(Stone, Color.white, 0.1f), 0.25f, 0.3f);
            c.Noise(0, 0, 26, 22, 0.2f, 0.4f, ore ? 11 : 5);
            c.Line(12, 6, 16, 11, Color.Lerp(Stone, Color.black, 0.45f));
            if (ore)
            {
                Color gold = new Color(1f, 0.82f, 0.25f);
                int[,] specks = { { 7, 9 }, { 15, 13 }, { 18, 7 }, { 11, 4 } };
                for (int i = 0; i < specks.GetLength(0); i++) { c.Rect(specks[i, 0], specks[i, 1], 2, 2, gold); c.Set(specks[i, 0], specks[i, 1] + 1, Color.white); }
            }
            c.Outline(Ink);
            return c.ToSprite(Base(22, 3), PPU);
        });

        public static Sprite Boulder(int variant) => GameSprites.Get("w_boulder_" + variant, () =>
        {
            var c = new PixelCanvas(32, 26);
            Color b = Color.Lerp(new Color(0.48f, 0.45f, 0.43f), new Color(0.42f, 0.4f, 0.45f), variant * 0.5f);
            c.GroundShadow(16, 3, 14, 3, 0.35f);
            c.ShadedEllipse(16, 11, 14, 10, b, 0.25f, 0.45f);
            c.ShadedEllipse(variant == 0 ? 10 : 22, 15, 7, 6, Color.Lerp(b, Color.white, 0.08f), 0.3f, 0.35f);
            c.Noise(0, 0, 32, 26, 0.22f, 0.3f, 20 + variant);
            c.Outline(Ink);
            return c.ToSprite(Base(26, 3), PPU);
        });

        public static Sprite Stalagmite() => GameSprites.Get("w_stalagmite", () =>
        {
            var c = new PixelCanvas(12, 18);
            Color s = new Color(0.45f, 0.4f, 0.42f);
            for (int y = 1; y < 16; y++)
            {
                int half = Mathf.Max(1, (16 - y) / 3);
                c.Rect(6 - half, y, half * 2, 1, s);
                c.Set(6 - half, y, Color.Lerp(s, Color.white, 0.25f));
            }
            c.Outline(Ink);
            return c.ToSprite(Base(18, 1), PPU);
        });

        // ------------------------------------------------------------------ Pueblo

        public static Sprite House(int variant) => GameSprites.Get("w_house_" + variant, () =>
        {
            Color[] roofs = { new Color(0.75f, 0.25f, 0.2f), new Color(0.25f, 0.45f, 0.7f), new Color(0.3f, 0.55f, 0.3f), new Color(0.6f, 0.4f, 0.65f) };
            Color[] walls = { new Color(0.93f, 0.87f, 0.74f), new Color(0.85f, 0.78f, 0.62f), new Color(0.8f, 0.7f, 0.55f), new Color(0.92f, 0.9f, 0.85f) };
            Color roof = roofs[variant % roofs.Length];
            Color wall = walls[variant % walls.Length];
            Color roofDark = Color.Lerp(roof, Color.black, 0.35f), roofLight = Color.Lerp(roof, Color.white, 0.25f);
            Color wallDark = Color.Lerp(wall, Color.black, 0.2f);

            var c = new PixelCanvas(58, 62);
            c.Rect(4, 0, 50, 4, new Color(0f, 0f, 0f, 0.3f));                 // sombra
            // Paredes (frente)
            c.Rect(6, 3, 46, 26, wall);
            for (int y = 6; y < 29; y += 4) c.Rect(6, y, 46, 1, wallDark);    // tablones
            c.Rect(6, 3, 46, 2, Color.Lerp(Stone, Color.black, 0.2f));        // zócalo
            c.Rect(6, 3, 3, 26, WoodDark); c.Rect(49, 3, 3, 26, WoodDark);    // vigas
            // Puerta
            c.Rect(24, 3, 10, 16, WoodDark);
            c.Rect(25, 4, 8, 14, Wood);
            c.Rect(29, 4, 1, 14, WoodDark);
            c.Set(31, 10, new Color(0.95f, 0.8f, 0.3f));
            c.Rect(23, 19, 12, 2, WoodDark);
            // Ventanas con luz cálida
            foreach (int wx in new[] { 11, 39 })
            {
                c.Rect(wx, 12, 9, 9, WoodDark);
                c.Rect(wx + 1, 13, 7, 7, new Color(0.98f, 0.85f, 0.45f));
                c.Rect(wx + 4, 13, 1, 7, WoodDark); c.Rect(wx + 1, 16, 7, 1, WoodDark);
                c.Rect(wx + 1, 18, 2, 2, new Color(1f, 0.95f, 0.75f));
                c.Rect(wx - 1, 11, 11, 1, WoodDark);
                c.Rect(wx, 10, 9, 1, new Color(0.45f, 0.65f, 0.3f)); // jardinera
                c.Set(wx + 2, 11, new Color(0.95f, 0.35f, 0.45f)); c.Set(wx + 6, 11, new Color(1f, 0.85f, 0.3f));
            }
            // Tejado a dos aguas visto desde arriba-frente
            for (int y = 28; y < 60; y++)
            {
                int inset = (y - 28) / 2;
                int x0 = 1 + inset / 3, x1 = 57 - inset / 3;
                bool front = y < 44;
                Color rc = front ? roof : roofLight;
                c.Rect(x0, y, x1 - x0, 1, rc);
                if ((y - 28) % 4 == 0) c.Rect(x0, y, x1 - x0, 1, front ? roofDark : roof); // tejas
            }
            c.Rect(1, 28, 56, 2, roofDark);
            c.Rect(3, 44, 52, 1, roofDark); // cumbrera
            for (int x = 3; x < 56; x += 5) c.Rect(x, 30, 1, 14, Color.Lerp(roof, Color.black, 0.18f));
            // Chimenea
            c.Rect(42, 50, 6, 10, Color.Lerp(Stone, new Color(0.6f, 0.3f, 0.25f), 0.5f));
            c.Rect(41, 59, 8, 2, Color.Lerp(Stone, Color.black, 0.3f));
            c.Noise(0, 28, 58, 34, 0.08f, 0.6f, 40 + variant);
            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 3f / 62f), PPU);
        });

        public static Sprite Well() => GameSprites.Get("w_well", () =>
        {
            var c = new PixelCanvas(30, 34);
            c.GroundShadow(15, 3, 13, 3, 0.3f);
            c.ShadedEllipse(15, 10, 12, 8, Stone, 0.2f, 0.4f);
            c.Noise(0, 0, 30, 20, 0.25f, 0.6f, 9);
            c.Ellipse(15, 12, 8, 4.5f, new Color(0.12f, 0.25f, 0.4f));
            c.Ellipse(14, 13, 4, 1.5f, new Color(0.35f, 0.6f, 0.85f));
            c.Rect(4, 10, 2, 18, WoodDark); c.Rect(24, 10, 2, 18, WoodDark);
            c.Rect(2, 27, 26, 3, new Color(0.65f, 0.3f, 0.2f));
            c.Rect(2, 30, 26, 2, Color.Lerp(new Color(0.65f, 0.3f, 0.2f), Color.white, 0.2f));
            c.Rect(14, 17, 1, 10, new Color(0.75f, 0.65f, 0.45f));            // cuerda
            c.Rect(12, 15, 5, 4, Wood); c.Rect(12, 18, 5, 1, WoodDark);       // cubo
            c.Outline(Ink);
            return c.ToSprite(Base(34, 3), PPU);
        });

        public static Sprite Fence() => GameSprites.Get("w_fence", () =>
        {
            var c = new PixelCanvas(16, 14);
            c.Rect(0, 5, 16, 2, Wood); c.Rect(0, 9, 16, 2, Wood);
            c.Rect(0, 5, 16, 1, WoodDark); c.Rect(0, 9, 16, 1, WoodDark);
            c.Rect(1, 1, 3, 12, WoodLight); c.Rect(12, 1, 3, 12, WoodLight);
            c.Rect(1, 1, 1, 12, WoodDark); c.Rect(12, 1, 1, 12, WoodDark);
            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 1f / 14f), PPU);
        });

        public static Sprite Crate() => GameSprites.Get("w_crate", () =>
        {
            var c = new PixelCanvas(16, 16);
            c.Rect(1, 0, 14, 2, new Color(0f, 0f, 0f, 0.3f));
            c.Rect(1, 1, 14, 13, Wood);
            c.Rect(1, 1, 14, 2, WoodDark); c.Rect(1, 12, 14, 2, WoodLight);
            c.Line(2, 3, 13, 11, WoodDark, 2);
            c.Rect(1, 1, 2, 13, WoodDark); c.Rect(13, 1, 2, 13, WoodDark);
            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 1f / 16f), PPU);
        });

        public static Sprite Barrel() => GameSprites.Get("w_barrel", () =>
        {
            var c = new PixelCanvas(14, 18);
            c.GroundShadow(7, 2, 6, 1.6f, 0.3f);
            c.ShadedEllipse(7, 9, 6, 8, Wood, 0.2f, 0.35f);
            c.Rect(1, 4, 12, 1, new Color(0.35f, 0.35f, 0.38f)); c.Rect(1, 13, 12, 1, new Color(0.35f, 0.35f, 0.38f));
            c.Ellipse(7, 15.5f, 4.5f, 1.5f, WoodDark);
            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 2f / 18f), PPU);
        });

        public static Sprite Stall() => GameSprites.Get("w_stall", () =>
        {
            var c = new PixelCanvas(46, 42);
            c.Rect(3, 0, 40, 3, new Color(0f, 0f, 0f, 0.3f));
            c.Rect(4, 2, 38, 12, Wood); c.Rect(4, 12, 38, 2, WoodLight); c.Rect(4, 2, 38, 2, WoodDark);
            // Fruta y pescado en el mostrador
            for (int i = 0; i < 6; i++) c.Circle(9 + i * 3, 15, 1.6f, i % 2 == 0 ? new Color(0.95f, 0.5f, 0.15f) : new Color(0.9f, 0.2f, 0.2f));
            c.Ellipse(32, 15, 4, 1.4f, new Color(0.6f, 0.75f, 0.85f)); c.Ellipse(37, 15.5f, 3.5f, 1.2f, new Color(0.55f, 0.7f, 0.8f));
            c.Rect(5, 13, 2, 20, WoodDark); c.Rect(39, 13, 2, 20, WoodDark);
            // Toldo a rayas
            for (int x = 1; x < 45; x++)
            {
                Color s = (x / 4) % 2 == 0 ? new Color(0.9f, 0.25f, 0.25f) : new Color(0.97f, 0.95f, 0.9f);
                c.Rect(x, 30, 1, 10, s);
                if (x % 4 == 2) c.Set(x, 29, s);
            }
            c.Rect(1, 30, 44, 1, Color.Lerp(new Color(0.9f, 0.25f, 0.25f), Color.black, 0.4f));
            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 2f / 42f), PPU);
        });

        public static Sprite Sign() => GameSprites.Get("w_sign", () =>
        {
            var c = new PixelCanvas(18, 20);
            c.Rect(8, 0, 2, 12, WoodDark);
            c.Rect(1, 9, 16, 9, Wood); c.Rect(1, 9, 16, 1, WoodDark); c.Rect(1, 17, 16, 1, WoodLight);
            c.Rect(4, 12, 9, 1, WoodDark); c.Rect(4, 14, 7, 1, WoodDark);
            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 0.02f), PPU);
        });

        public static Sprite Lantern() => GameSprites.Get("w_lantern", () =>
        {
            var c = new PixelCanvas(10, 30);
            c.Rect(4, 0, 2, 24, new Color(0.25f, 0.25f, 0.28f));
            c.Rect(2, 22, 6, 6, new Color(0.25f, 0.25f, 0.28f));
            c.Rect(3, 23, 4, 4, new Color(1f, 0.85f, 0.4f));
            c.Rect(2, 28, 6, 1, new Color(0.25f, 0.25f, 0.28f));
            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 0.02f), PPU);
        });

        // ------------------------------------------------------------------ Playa y campamento

        public static Sprite Tent() => GameSprites.Get("w_tent", () =>
        {
            var c = new PixelCanvas(40, 30);
            c.Rect(2, 0, 36, 3, new Color(0f, 0f, 0f, 0.3f));
            Color canvas = new Color(0.88f, 0.82f, 0.66f), canvasDark = new Color(0.68f, 0.6f, 0.45f);
            for (int y = 2; y < 26; y++)
            {
                int half = Mathf.RoundToInt((26 - y) * 0.75f);
                c.Rect(20 - half, y, half, 1, canvasDark);
                c.Rect(20, y, half, 1, canvas);
            }
            for (int y = 2; y < 14; y++) { int half = (14 - y) / 2; c.Rect(20 - half, y, half * 2, 1, new Color(0.25f, 0.18f, 0.12f)); }
            c.Rect(19, 25, 2, 4, WoodDark);
            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 2f / 30f), PPU);
        });

        public static Sprite Campfire(bool lit = false) => CampfireBase();
        public static Sprite CampfireBase() => GameSprites.Get("w_campfire", () =>
        {
            var c = new PixelCanvas(20, 12);
            for (int i = 0; i < 8; i++)
            {
                float a = i * Mathf.PI / 4f;
                c.ShadedEllipse(10 + Mathf.Cos(a) * 7.5f, 5 + Mathf.Sin(a) * 3.5f, 2.2f, 1.8f, Stone);
            }
            c.Line(4, 4, 15, 7, WoodDark, 2); c.Line(4, 7, 15, 4, Wood, 2);
            c.Ellipse(10, 5.5f, 3, 1.5f, new Color(0.25f, 0.12f, 0.08f));
            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 0.2f), PPU);
        });

        public static Sprite Flame(int frame) => GameSprites.Get("w_flame_" + frame, () =>
        {
            var c = new PixelCanvas(12, 16);
            float sway = frame == 0 ? -0.8f : 0.8f;
            c.Ellipse(6, 5, 4.5f, 4.5f, new Color(0.95f, 0.35f, 0.1f));
            c.Ellipse(6 + sway, 9, 3f, 4.5f, new Color(0.95f, 0.35f, 0.1f));
            c.Ellipse(6 + sway * 0.5f, 5, 3f, 3.5f, new Color(1f, 0.7f, 0.15f));
            c.Ellipse(6, 4, 1.6f, 2f, new Color(1f, 0.95f, 0.6f));
            c.Set(Mathf.RoundToInt(6 - sway * 2), 13, new Color(1f, 0.6f, 0.2f));
            return c.ToSprite(new Vector2(0.5f, 0.05f), PPU);
        });

        public static Sprite Wreck() => GameSprites.Get("w_wreck", () =>
        {
            var c = new PixelCanvas(66, 38);
            c.Ellipse(33, 6, 30, 5, new Color(0f, 0f, 0f, 0.25f));
            // Casco volcado
            for (int x = 4; x < 62; x++)
            {
                float t = (x - 4) / 58f;
                int h = Mathf.RoundToInt(Mathf.Sin(t * Mathf.PI) * 16f) + 4;
                c.Rect(x, 5, 1, h, (x / 3) % 2 == 0 ? Wood : Color.Lerp(Wood, WoodDark, 0.5f));
                c.Set(x, 5 + h - 1, WoodLight);
            }
            for (int y = 7; y < 22; y += 4) c.Rect(6, y, 54, 1, WoodDark);
            c.Rect(22, 8, 6, 6, new Color(0.15f, 0.1f, 0.08f)); // agujero
            // Mástil roto
            c.Line(40, 20, 50, 35, WoodDark, 3);
            c.Rect(46, 28, 10, 2, WoodDark);
            c.Line(48, 28, 60, 24, new Color(0.85f, 0.82f, 0.75f), 2); // vela rota
            c.Noise(0, 0, 66, 38, 0.12f, 0.5f, 31);
            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 5f / 38f), PPU);
        });

        public static Sprite Rowboat() => GameSprites.Get("w_rowboat", () =>
        {
            var c = new PixelCanvas(34, 16);
            c.Ellipse(17, 5, 16, 4, Wood);
            c.Ellipse(17, 7, 14, 3, WoodDark);
            c.Ellipse(17, 7.5f, 12, 2.2f, new Color(0.35f, 0.22f, 0.12f));
            c.Rect(10, 6, 2, 4, WoodLight); c.Rect(22, 6, 2, 4, WoodLight);
            c.Line(6, 12, 20, 4, WoodLight);
            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 0.2f), PPU);
        });

        public static Sprite Shell(int variant) => GameSprites.Get("w_shell_" + variant, () =>
        {
            var c = new PixelCanvas(8, 7);
            Color col = variant == 0 ? new Color(1f, 0.85f, 0.8f) : new Color(0.95f, 0.75f, 0.55f);
            c.Ellipse(4, 3, 3.2f, 2.6f, col);
            c.Line(4, 1, 2, 5, Color.Lerp(col, Color.black, 0.25f)); c.Line(4, 1, 6, 5, Color.Lerp(col, Color.black, 0.25f));
            return c.ToSprite(new Vector2(0.5f, 0.3f), PPU);
        });

        public static Sprite Driftwood() => GameSprites.Get("w_driftwood", () =>
        {
            var c = new PixelCanvas(20, 7);
            Color d = new Color(0.72f, 0.65f, 0.55f);
            c.Line(1, 2, 18, 4, d, 3);
            c.Line(13, 4, 17, 6, d);
            c.Line(2, 2, 17, 3, Color.Lerp(d, Color.black, 0.3f));
            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 0.3f), PPU);
        });

        public static Sprite Chest() => GameSprites.Get("w_chest", () =>
        {
            var c = new PixelCanvas(18, 16);
            c.Rect(1, 0, 16, 2, new Color(0f, 0f, 0f, 0.3f));
            c.Rect(1, 1, 16, 9, Wood);
            c.Ellipse(9, 10, 8, 4, WoodLight);
            c.Rect(1, 9, 16, 1, WoodDark);
            Color gold = new Color(0.95f, 0.78f, 0.25f);
            c.Rect(1, 1, 2, 12, gold); c.Rect(15, 1, 2, 12, gold);
            c.Rect(7, 6, 4, 4, gold); c.Set(9, 7, Ink);
            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 1f / 16f), PPU);
        });

        public static Sprite Torch() => GameSprites.Get("w_torch", () =>
        {
            var c = new PixelCanvas(8, 16);
            c.Rect(3, 0, 2, 11, WoodDark);
            c.Rect(2, 10, 4, 2, new Color(0.3f, 0.3f, 0.32f));
            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 0.02f), PPU);
        });

        public static Sprite Starfish() => GameSprites.Get("w_starfish", () =>
        {
            var c = new PixelCanvas(12, 12);
            c.GroundShadow(6, 2, 5, 1.8f, 0.25f);
            Color star = new Color(0.95f, 0.42f, 0.22f);
            Color starLight = new Color(1.0f, 0.65f, 0.4f);
            Color dot = new Color(1.0f, 0.95f, 0.8f);
            c.Circle(6, 6, 2.5f, star);
            for (int i = 0; i < 5; i++)
            {
                float a = (i * 72f + 90f) * Mathf.Deg2Rad;
                float tipX = 6 + Mathf.Cos(a) * 4.5f;
                float tipY = 6 + Mathf.Sin(a) * 4.5f;
                c.Line(6, 6, Mathf.RoundToInt(tipX), Mathf.RoundToInt(tipY), star, 2);
                c.Set(Mathf.RoundToInt(tipX), Mathf.RoundToInt(tipY), starLight);
            }
            c.Set(6, 6, dot);
            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 0.3f), PPU);
        });

        public static Sprite Anchor() => GameSprites.Get("w_anchor", () =>
        {
            var c = new PixelCanvas(22, 26);
            c.GroundShadow(11, 2, 9, 2.5f, 0.32f);
            Color iron = new Color(0.32f, 0.34f, 0.38f);
            Color ironLight = new Color(0.55f, 0.58f, 0.62f);
            Color rust = new Color(0.6f, 0.35f, 0.18f);
            c.Rect(10, 4, 2, 18, iron);
            c.Rect(10, 4, 1, 18, ironLight);
            c.Circle(11, 22, 3f, iron);
            c.Circle(11, 22, 1.2f, Color.clear);
            c.Rect(4, 18, 14, 2, WoodDark);
            c.Rect(5, 19, 12, 1, Wood);
            c.Line(4, 10, 11, 4, iron, 2);
            c.Line(11, 4, 18, 10, iron, 2);
            c.Line(2, 12, 5, 9, iron, 2);
            c.Line(17, 9, 20, 12, iron, 2);
            c.Set(10, 8, rust); c.Set(6, 10, rust); c.Set(16, 10, rust);
            c.Outline(Ink);
            return c.ToSprite(Base(26, 2), PPU);
        });

        public static Sprite FishRack() => GameSprites.Get("w_fishrack", () =>
        {
            var c = new PixelCanvas(30, 22);
            c.GroundShadow(15, 2, 13, 2.2f, 0.3f);
            c.Rect(4, 1, 2, 19, WoodDark);
            c.Rect(24, 1, 2, 19, WoodDark);
            c.Rect(2, 17, 26, 2, Wood);
            c.Rect(2, 17, 26, 1, WoodLight);
            Color fish = new Color(0.45f, 0.65f, 0.8f);
            Color belly = new Color(0.85f, 0.9f, 0.95f);
            int[] xs = { 9, 15, 21 };
            foreach (int fx in xs)
            {
                c.Rect(fx, 14, 1, 3, WoodDark);
                c.Ellipse(fx, 10, 2.5f, 4.5f, fish);
                c.Rect(fx, 7, 1, 5, belly);
                c.Line(fx - 1, 5, fx + 1, 5, fish);
                c.Set(fx, 13, Ink);
            }
            c.Outline(Ink);
            return c.ToSprite(Base(22, 2), PPU);
        });

        public static Sprite Banner(int variant) => GameSprites.Get("w_banner_" + variant, () =>
        {
            var c = new PixelCanvas(16, 28);
            c.GroundShadow(8, 2, 6, 1.8f, 0.28f);
            c.Rect(3, 1, 2, 26, WoodDark);
            c.Set(3, 26, Gold); c.Set(4, 26, Gold);
            Color primary = variant == 1 ? new Color(0.12f, 0.12f, 0.14f) : (variant == 2 ? new Color(0.15f, 0.3f, 0.65f) : new Color(0.85f, 0.25f, 0.22f));
            Color accent = variant == 1 ? Color.white : (variant == 2 ? Color.white : new Color(1f, 0.85f, 0.3f));
            for (int y = 14; y < 25; y++)
            {
                int wave = Mathf.RoundToInt(Mathf.Sin((y - 14) * 0.7f) * 1.5f);
                c.Rect(5 + wave, y, 9, 1, primary);
            }
            if (variant == 1)
            {
                c.Circle(9, 20, 1.8f, accent);
                c.Set(9, 18, accent);
            }
            else if (variant == 2)
            {
                c.Line(7, 20, 9, 18, accent);
                c.Line(9, 18, 11, 20, accent);
            }
            else
            {
                c.Circle(9, 20, 2f, accent);
                c.Set(9, 20, primary);
            }
            c.Outline(Ink);
            return c.ToSprite(Base(28, 2), PPU);
        });

        public static Sprite Crystal(int variant) => GameSprites.Get("w_crystal_" + variant, () =>
        {
            var c = new PixelCanvas(16, 20);
            c.GroundShadow(8, 2, 7, 2f, 0.3f);
            Color main = variant == 0 ? new Color(0.2f, 0.85f, 0.95f) : new Color(0.75f, 0.35f, 0.95f);
            Color dark = Color.Lerp(main, Color.black, 0.35f);
            Color bright = Color.Lerp(main, Color.white, 0.55f);
            for (int y = 2; y < 17; y++)
            {
                int w = y < 14 ? 3 : Mathf.Max(1, 17 - y);
                c.Rect(8 - w, y, w, 1, dark);
                c.Rect(8, y, w, 1, main);
                if (y % 3 == 0) c.Set(8, y, bright);
            }
            for (int y = 2; y < 11; y++)
            {
                int w = y < 9 ? 2 : 1;
                c.Rect(4 - w, y, w, 1, dark);
                c.Rect(4, y, w, 1, main);
            }
            for (int y = 2; y < 9; y++)
            {
                int w = y < 7 ? 2 : 1;
                c.Rect(12 - w, y, w, 1, main);
                c.Rect(12, y, w, 1, bright);
            }
            c.Outline(Ink);
            return c.ToSprite(Base(20, 2), PPU);
        });

        // ------------------------------------------------------------------ Puerto

        public static Sprite PierPlank() => GameSprites.Get("w_pier", () =>
        {
            var c = new PixelCanvas(16, 16);
            for (int y = 0; y < 16; y += 4)
            {
                c.Rect(0, y, 16, 3, (y / 4) % 2 == 0 ? Wood : WoodLight);
                c.Rect(0, y + 3, 16, 1, WoodDark);
            }
            c.Set(3, 1, WoodDark); c.Set(12, 5, WoodDark); c.Set(6, 9, WoodDark); c.Set(10, 13, WoodDark);
            return c.ToSprite(new Vector2(0.5f, 0.5f), PPU);
        });

        public static Sprite PierPost() => GameSprites.Get("w_pier_post", () =>
        {
            var c = new PixelCanvas(6, 12);
            c.Rect(1, 0, 4, 12, WoodDark);
            c.Rect(1, 10, 4, 2, WoodLight);
            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 0.1f), PPU);
        });

        public static Sprite Ship() => GameSprites.Get("w_ship", () =>
        {
            var c = new PixelCanvas(120, 104);
            Color hull = new Color(0.25f, 0.16f, 0.12f), hullLight = new Color(0.42f, 0.28f, 0.18f);
            c.Ellipse(60, 10, 56, 7, new Color(0f, 0.05f, 0.12f, 0.35f));
            // Casco
            for (int x = 6; x < 114; x++)
            {
                float t = (x - 6) / 108f;
                int bottom = 8 + Mathf.RoundToInt(Mathf.Pow(Mathf.Abs(t - 0.5f) * 2f, 2f) * 10f);
                int top = 36 + Mathf.RoundToInt(Mathf.Pow(Mathf.Abs(t - 0.45f) * 2f, 3f) * 10f);
                c.Rect(x, bottom, 1, top - bottom, (x / 4) % 2 == 0 ? hull : Color.Lerp(hull, hullLight, 0.4f));
                c.Set(x, top - 1, new Color(0.75f, 0.6f, 0.3f));
            }
            c.Rect(10, 22, 100, 2, new Color(0.75f, 0.6f, 0.3f));
            for (int x = 25; x < 100; x += 14) c.Rect(x, 26, 5, 4, new Color(0.08f, 0.06f, 0.05f)); // troneras
            // Mástiles y velas negras con calavera
            Color sail = new Color(0.12f, 0.12f, 0.14f), sailLight = new Color(0.22f, 0.22f, 0.25f);
            foreach (int mx in new[] { 40, 76 })
            {
                c.Rect(mx, 36, 3, 64, WoodDark);
                for (int y = 52; y < 90; y++)
                {
                    float bulge = Mathf.Sin((y - 52) / 38f * Mathf.PI) * 4f;
                    int half = 17 + Mathf.RoundToInt(bulge);
                    c.Rect(mx + 1 - half, y, half * 2, 1, y % 6 < 3 ? sail : sailLight);
                }
                c.Rect(mx - 19, 89, 40, 2, WoodDark);
                c.Rect(mx - 17, 51, 36, 2, WoodDark);
            }
            // Calavera en la vela delantera
            c.Circle(77, 74, 6, new Color(0.95f, 0.95f, 0.9f));
            c.Rect(74, 66, 7, 4, new Color(0.95f, 0.95f, 0.9f));
            c.Rect(74, 73, 2, 3, sail); c.Rect(79, 73, 2, 3, sail);
            c.Line(68, 62, 86, 70, new Color(0.95f, 0.95f, 0.9f), 2); c.Line(68, 70, 86, 62, new Color(0.95f, 0.95f, 0.9f), 2);
            // Bandera
            c.Rect(77, 100, 1, 4, WoodDark);
            c.Rect(78, 98, 10, 5, new Color(0.1f, 0.1f, 0.1f));
            c.Rect(82, 100, 2, 2, Color.white);
            // Mascarón y bauprés
            c.Line(112, 34, 119, 46, WoodDark, 2);
            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 10f / 104f), PPU);
        });

        // ------------------------------------------------------------------ Efectos

        /// <summary>Oscuridad de cueva: negro con un círculo de luz suave en el centro (128x128).</summary>
        public static Sprite DarknessMask() => GameSprites.Get("fx_darkness", () =>
        {
            var c = new PixelCanvas(128, 128);
            for (int y = 0; y < 128; y++)
                for (int x = 0; x < 128; x++)
                {
                    float dx = (x + 0.5f - 64f) / 64f, dy = (y + 0.5f - 64f) / 64f;
                    float d = Mathf.Sqrt(dx * dx + dy * dy);
                    float a = Mathf.SmoothStep(0f, 1f, Mathf.InverseLerp(0.05f, 0.2f, d));
                    c.Set(x, y, new Color(0.01f, 0.01f, 0.03f, a));
                }
            Sprite s = c.ToSprite(new Vector2(0.5f, 0.5f), 16f);
            s.texture.filterMode = FilterMode.Bilinear;
            return s;
        });

        public static Sprite Glow() => GameSprites.Get("fx_glow", () =>
        {
            var c = new PixelCanvas(32, 32);
            for (int y = 0; y < 32; y++)
                for (int x = 0; x < 32; x++)
                {
                    float dx = (x + 0.5f - 16f) / 16f, dy = (y + 0.5f - 16f) / 16f;
                    float a = Mathf.Clamp01(1f - Mathf.Sqrt(dx * dx + dy * dy));
                    c.Set(x, y, new Color(1f, 0.75f, 0.35f, a * a * 0.55f));
                }
            Sprite s = c.ToSprite(new Vector2(0.5f, 0.5f), 16f);
            s.texture.filterMode = FilterMode.Bilinear;
            return s;
        });

        /// <summary>Losa de agua del mar (32x32 = 2x2 unidades) que se repite en mosaico y se desplaza.</summary>
        public static Sprite WaterTile() => GameSprites.Get("w_water", () =>
        {
            var c = new PixelCanvas(32, 32);
            Color deep = new Color(0.11f, 0.38f, 0.62f), mid = new Color(0.15f, 0.45f, 0.7f), crest = new Color(0.45f, 0.72f, 0.9f);
            for (int y = 0; y < 32; y++)
                for (int x = 0; x < 32; x++)
                {
                    float w = Mathf.Sin((x + y) / 32f * Mathf.PI * 2f) + Mathf.Sin((y * 2f - x) / 32f * Mathf.PI * 2f) * 0.5f;
                    c.Set(x, y, w > 0.6f ? mid : deep);
                }
            // Crestas de ola cortas (se repiten sin costura porque no tocan los bordes)
            int[,] crests = { { 4, 6 }, { 18, 12 }, { 9, 22 }, { 24, 27 } };
            for (int i = 0; i < crests.GetLength(0); i++)
            {
                c.Rect(crests[i, 0], crests[i, 1], 4, 1, crest);
                c.Rect(crests[i, 0] + 1, crests[i, 1] + 1, 2, 1, Color.Lerp(crest, Color.white, 0.5f));
            }
            Sprite s = c.ToSprite(new Vector2(0.5f, 0.5f), PPU);
            s.texture.wrapMode = TextureWrapMode.Repeat;
            return s;
        });

        // -------------------------------------------------- Brújula Náutica

        public static Sprite CompassDial() => GameSprites.Get("w_compass_dial", () =>
        {
            const int S = 48;
            PixelCanvas c = new PixelCanvas(S, S);
            Vector2 center = new Vector2(23.5f, 23.5f);
            Color brassLight = new Color(1f, 0.90f, 0.45f);
            Color brassMid = new Color(0.85f, 0.68f, 0.22f);
            Color brassDark = new Color(0.48f, 0.32f, 0.10f);
            Color parchment = new Color(0.96f, 0.92f, 0.80f);
            Color parchmentShadow = new Color(0.82f, 0.74f, 0.58f);

            for (int y = 0; y < S; y++)
                for (int x = 0; x < S; x++)
                {
                    float dist = Vector2.Distance(new Vector2(x, y), center);
                    if (dist > 23.5f) continue;

                    if (dist >= 19.5f)
                    {
                        float angle = Mathf.Atan2(y - center.y, x - center.x);
                        float light = Mathf.Sin(angle + 0.8f);
                        Color col = light > 0.2f ? Color.Lerp(brassMid, brassLight, light) : Color.Lerp(brassMid, brassDark, -light);
                        c.Set(x, y, col);
                    }
                    else if (dist >= 18f)
                    {
                        c.Set(x, y, brassDark);
                    }
                    else
                    {
                        float t = dist / 18f;
                        c.Set(x, y, Color.Lerp(parchment, parchmentShadow, t * 0.7f));
                    }
                }

            // Remaches dorados
            int[,] rivets = { { 23, 44 }, { 24, 44 }, { 23, 3 }, { 24, 3 }, { 3, 23 }, { 3, 24 }, { 44, 23 }, { 44, 24 } };
            for (int i = 0; i < rivets.GetLength(0); i++) c.Set(rivets[i, 0], rivets[i, 1], Color.white);

            // Rosa de los vientos / Marcas cardinales
            Color ruby = new Color(0.88f, 0.15f, 0.15f);
            c.Line(23, 24, 23, 38, ruby); c.Line(24, 24, 24, 38, ruby);
            c.Set(23, 39, ruby); c.Set(24, 39, ruby);
            c.Set(22, 36, ruby); c.Set(25, 36, ruby);

            c.Line(23, 23, 23, 10, brassDark); c.Line(24, 23, 24, 10, brassDark);
            c.Line(23, 23, 38, 23, brassDark); c.Line(23, 24, 38, 24, brassDark);
            c.Line(23, 23, 10, 23, brassDark); c.Line(23, 24, 10, 24, brassDark);

            int[,] diag = { { 32, 32 }, { 15, 32 }, { 32, 15 }, { 15, 15 } };
            for (int i = 0; i < 4; i++) c.Rect(diag[i, 0], diag[i, 1], 2, 2, brassMid);

            c.Circle(23.5f, 23.5f, 3.5f, brassMid);
            c.Circle(23.5f, 23.5f, 2f, brassDark);
            c.Set(23, 24, Color.white);

            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 0.5f), 25f);
        });

        public static Sprite CompassNeedle() => GameSprites.Get("w_compass_needle", () =>
        {
            const int W = 20, H = 48;
            PixelCanvas c = new PixelCanvas(W, H);
            int cx = 10, cy = 24;

            Color redDark = new Color(0.72f, 0.12f, 0.12f);
            Color redLight = new Color(1f, 0.38f, 0.35f);
            for (int y = cy; y <= 44; y++)
            {
                float t = (y - cy) / 20f;
                int hw = Mathf.RoundToInt(Mathf.Lerp(4f, 0f, t));
                for (int x = cx - hw; x < cx; x++) c.Set(x, y, redDark);
                for (int x = cx; x <= cx + hw; x++) c.Set(x, y, redLight);
            }

            Color steelDark = new Color(0.35f, 0.40f, 0.48f);
            Color steelLight = new Color(0.78f, 0.84f, 0.92f);
            for (int y = 4; y < cy; y++)
            {
                float t = (cy - y) / 20f;
                int hw = Mathf.RoundToInt(Mathf.Lerp(4f, 0f, t));
                for (int x = cx - hw; x < cx; x++) c.Set(x, y, steelDark);
                for (int x = cx; x <= cx + hw; x++) c.Set(x, y, steelLight);
            }

            Color gold = new Color(1f, 0.85f, 0.3f);
            Color goldDark = new Color(0.55f, 0.38f, 0.12f);
            c.Circle(cx, cy, 3.5f, goldDark);
            c.Circle(cx, cy, 2.5f, gold);
            c.Set(cx - 1, cy + 1, Color.white);

            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 0.5f), 25f);
        });

        // -------------------------------------------------- Bosque Variado

        public static Sprite Pine(bool dark = false) => GameSprites.Get(dark ? "w_pine_dark" : "w_pine", () =>
        {
            var c = new PixelCanvas(38, 54);
            c.GroundShadow(19, 3, 10, 2.8f, 0.3f);
            c.Rect(17, 3, 5, 14, Wood);
            c.Rect(17, 3, 2, 14, WoodDark);
            c.Rect(15, 3, 2, 2, WoodDark); c.Rect(22, 3, 2, 2, WoodDark);

            Color pineGreen = dark ? new Color(0.12f, 0.35f, 0.18f) : new Color(0.18f, 0.48f, 0.22f);
            Color pineLight = dark ? new Color(0.22f, 0.50f, 0.28f) : new Color(0.32f, 0.68f, 0.35f);
            Color pineDark = dark ? new Color(0.06f, 0.22f, 0.10f) : new Color(0.10f, 0.28f, 0.14f);

            int[] tiersY = { 14, 23, 32, 40 };
            int[] tierW = { 15, 13, 10, 6 };
            for (int t = 0; t < 4; t++)
            {
                int y0 = tiersY[t], w = tierW[t];
                for (int dy = 0; dy < 11; dy++)
                {
                    int span = Mathf.RoundToInt(Mathf.Lerp(w, 1, dy / 10f));
                    c.Rect(19 - span, y0 + dy, span * 2 + 1, 1, dy < 3 ? pineDark : pineGreen);
                }
                c.Line(19 - w + 2, y0 + 1, 19 + w - 2, y0 + 1, pineLight);
            }
            c.Noise(0, 14, 38, 40, 0.15f, 0.3f, dark ? 8 : 4);
            c.Outline(Ink);
            return c.ToSprite(Base(54, 3), PPU);
        });

        public static Sprite TreeRound() => GameSprites.Get("w_tree_round", () =>
        {
            var c = new PixelCanvas(46, 52);
            c.GroundShadow(23, 4, 14, 3.2f, 0.32f);
            c.Rect(20, 3, 7, 15, Wood);
            c.Rect(20, 3, 2, 15, WoodDark);
            c.Rect(25, 5, 2, 9, WoodLight);
            c.Rect(18, 3, 3, 2, WoodDark); c.Rect(27, 3, 3, 2, WoodDark);

            Color leaf = new Color(0.22f, 0.58f, 0.25f);
            c.ShadedEllipse(23, 32, 18, 14, leaf, 0.25f, 0.35f);
            c.ShadedEllipse(14, 29, 9, 8, leaf, 0.2f, 0.4f);
            c.ShadedEllipse(32, 29, 9, 8, leaf, 0.2f, 0.4f);
            c.ShadedEllipse(23, 41, 11, 8, leaf, 0.3f, 0.25f);
            c.Noise(0, 16, 46, 36, 0.18f, 0.32f, 15);
            c.Outline(Ink);
            return c.ToSprite(Base(52, 4), PPU);
        });

        public static Sprite AutumnTree(int variant) => GameSprites.Get("w_autumn_" + variant, () =>
        {
            var c = new PixelCanvas(44, 52);
            c.GroundShadow(22, 4, 13, 3f, 0.3f);
            c.Rect(19, 3, 6, 16, Wood);
            c.Rect(19, 3, 2, 16, WoodDark);
            c.Rect(23, 6, 1, 10, WoodLight);
            c.Rect(17, 3, 2, 2, WoodDark); c.Rect(25, 3, 2, 2, WoodDark);

            Color autumnBase = variant == 0 ? new Color(0.92f, 0.48f, 0.12f) : new Color(0.85f, 0.22f, 0.15f);
            c.ShadedEllipse(22, 31, 16, 13, autumnBase, 0.28f, 0.32f);
            c.ShadedEllipse(14, 28, 8, 7, autumnBase, 0.2f, 0.4f);
            c.ShadedEllipse(30, 28, 8, 7, autumnBase, 0.2f, 0.4f);
            c.ShadedEllipse(21, 39, 10, 7, Color.Lerp(autumnBase, new Color(1f, 0.78f, 0.2f), 0.5f), 0.3f, 0.25f);
            c.Noise(0, 16, 44, 36, 0.2f, 0.35f, 30 + variant);
            c.Set(9, 14, autumnBase); c.Set(34, 18, autumnBase); c.Set(12, 8, autumnBase);
            c.Outline(Ink);
            return c.ToSprite(Base(52, 4), PPU);
        });

        // -------------------------------------------------- Criaturas de Cueva

        public static Sprite Spider() => GameSprites.Get("c_spider", () =>
        {
            var c = new PixelCanvas(22, 18);
            c.GroundShadow(11, 2, 7, 2, 0.3f);
            Color body = new Color(0.18f, 0.14f, 0.18f);
            Color belly = new Color(0.28f, 0.18f, 0.24f);
            Color eye = new Color(0.95f, 0.15f, 0.15f);

            c.Circle(11, 11, 4.2f, belly);
            c.Circle(11, 7, 3f, body);

            c.Set(10, 6, eye); c.Set(12, 6, eye);
            c.Set(9, 7, eye); c.Set(13, 7, eye);
            c.Set(10, 4, Color.white); c.Set(12, 4, Color.white);

            c.Line(8, 8, 3, 12, body); c.Line(3, 12, 2, 7, body);
            c.Line(8, 7, 3, 8, body); c.Line(3, 8, 1, 4, body);
            c.Line(8, 6, 4, 4, body); c.Line(4, 4, 3, 1, body);
            c.Line(9, 11, 4, 14, body); c.Line(4, 14, 3, 16, body);

            c.Line(14, 8, 19, 12, body); c.Line(19, 12, 20, 7, body);
            c.Line(14, 7, 19, 8, body); c.Line(19, 8, 21, 4, body);
            c.Line(14, 6, 18, 4, body); c.Line(18, 4, 19, 1, body);
            c.Line(13, 11, 18, 14, body); c.Line(18, 14, 19, 16, body);

            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 0.2f), PPU);
        });

        public static Sprite Bat() => GameSprites.Get("c_bat", () =>
        {
            var c = new PixelCanvas(26, 18);
            Color dark = new Color(0.18f, 0.16f, 0.22f);
            Color wing = new Color(0.28f, 0.24f, 0.32f);
            Color eye = new Color(1f, 0.85f, 0.2f);

            c.Rect(11, 5, 4, 7, dark);
            c.Set(11, 13, dark); c.Set(14, 13, dark);
            c.Set(11, 10, eye); c.Set(14, 10, eye);
            c.Set(12, 7, Color.white); c.Set(13, 7, Color.white);

            c.Line(11, 9, 3, 14, wing); c.Line(3, 14, 1, 10, wing);
            c.Line(1, 10, 4, 7, wing); c.Line(4, 7, 8, 6, wing); c.Line(8, 6, 11, 6, wing);
            c.Rect(4, 8, 5, 4, wing);

            c.Line(14, 9, 22, 14, wing); c.Line(22, 14, 24, 10, wing);
            c.Line(24, 10, 21, 7, wing); c.Line(21, 7, 17, 6, wing); c.Line(17, 6, 14, 6, wing);
            c.Rect(16, 8, 5, 4, wing);

            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 0.3f), PPU);
        });

        // -------------------------------------------------- Gran Ciudad Puerto

        public static Sprite Tavern() => GameSprites.Get("w_tavern", () =>
        {
            var c = new PixelCanvas(64, 56);
            c.GroundShadow(32, 4, 28, 4.5f, 0.35f);
            Color stoneWall = new Color(0.52f, 0.50f, 0.54f);
            Color timber = new Color(0.38f, 0.22f, 0.12f);
            Color plaster = new Color(0.88f, 0.82f, 0.72f);
            Color roof = new Color(0.72f, 0.26f, 0.18f);

            // Planta baja de piedra
            c.Rect(6, 4, 52, 18, stoneWall);
            c.Rect(6, 4, 52, 2, Color.Lerp(stoneWall, Color.black, 0.3f));
            // Primera planta entramado madera y cal
            c.Rect(8, 22, 48, 16, plaster);
            c.Rect(8, 22, 48, 2, timber); c.Rect(8, 36, 48, 2, timber);
            for (int x = 8; x <= 56; x += 12) c.Rect(x, 22, 2, 16, timber);

            // Tejado a dos aguas de teja roja
            for (int dy = 0; dy < 16; dy++)
            {
                int span = 28 - Mathf.RoundToInt(dy * 1.6f);
                c.Rect(32 - span, 38 + dy, span * 2, 1, roof);
            }

            // Puerta doble de roble con arco
            c.Rect(27, 4, 10, 14, timber);
            c.Rect(29, 6, 3, 10, Color.Lerp(timber, Color.black, 0.2f));
            c.Rect(33, 6, 3, 10, Color.Lerp(timber, Color.black, 0.2f));
            c.Set(30, 11, Gold); c.Set(33, 11, Gold);

            // Ventanas con luz cálida
            int[,] win = { { 12, 10 }, { 46, 10 }, { 14, 26 }, { 26, 26 }, { 38, 26 }, { 50, 26 } };
            for (int i = 0; i < win.GetLength(0); i++)
            {
                c.Rect(win[i, 0], win[i, 1], 6, 7, timber);
                c.Rect(win[i, 0] + 1, win[i, 1] + 1, 4, 5, new Color(1f, 0.85f, 0.35f));
            }

            // Cartel de la taberna con jarra de cerveza
            c.Rect(39, 17, 7, 5, timber);
            c.Rect(41, 18, 3, 3, new Color(1f, 0.8f, 0.2f));

            c.Outline(Ink);
            return c.ToSprite(Base(56, 4), PPU);
        });

        public static Sprite TownHall() => GameSprites.Get("w_townhall", () =>
        {
            var c = new PixelCanvas(72, 64);
            c.GroundShadow(36, 4, 32, 5f, 0.35f);
            Color wall = new Color(0.78f, 0.74f, 0.68f);
            Color roof = new Color(0.24f, 0.35f, 0.48f); // pizarra azul naval
            Color pillar = new Color(0.92f, 0.90f, 0.85f);

            c.Rect(8, 4, 56, 34, wall);
            // Columnas señoriales
            int[] colX = { 10, 22, 34, 46, 58 };
            foreach (int cx in colX) c.Rect(cx, 4, 4, 34, pillar);

            // Balcón superior
            c.Rect(20, 22, 32, 5, new Color(0.35f, 0.22f, 0.12f));
            c.Line(20, 27, 52, 27, Gold);

            // Tejado señorial triangular
            for (int dy = 0; dy < 24; dy++)
            {
                int span = 32 - Mathf.RoundToInt(dy * 1.3f);
                c.Rect(36 - span, 38 + dy, span * 2, 1, roof);
            }

            // Gran puerta consistorial con remaches dorados
            c.Rect(31, 4, 10, 16, new Color(0.25f, 0.15f, 0.08f));
            c.Set(33, 11, Gold); c.Set(38, 11, Gold);

            // Bandera de la isla en la cúspide
            c.Line(36, 61, 36, 64, Color.black);
            c.Rect(36, 62, 7, 2, new Color(0.85f, 0.2f, 0.2f));

            c.Outline(Ink);
            return c.ToSprite(Base(64, 4), PPU);
        });

        public static Sprite Lighthouse() => GameSprites.Get("w_lighthouse", () =>
        {
            var c = new PixelCanvas(36, 68);
            c.GroundShadow(18, 4, 14, 3.5f, 0.35f);
            Color redStripe = new Color(0.82f, 0.20f, 0.18f);
            Color whiteStripe = new Color(0.92f, 0.92f, 0.95f);
            Color darkStone = new Color(0.32f, 0.32f, 0.35f);

            c.Rect(11, 4, 14, 6, darkStone);
            for (int y = 10; y < 54; y++)
            {
                float t = (y - 10) / 44f;
                int hw = Mathf.RoundToInt(Mathf.Lerp(6.5f, 4.2f, t));
                Color col = ((y / 8) % 2 == 0) ? redStripe : whiteStripe;
                c.Rect(18 - hw, y, hw * 2, 1, col);
            }

            // Mirador y cúpula de la linterna
            c.Rect(11, 54, 14, 2, darkStone);
            c.Rect(13, 56, 10, 7, new Color(1f, 0.92f, 0.45f)); // cristal con brillo
            c.Rect(12, 63, 12, 3, darkStone);
            c.Set(18, 66, Gold);

            c.Outline(Ink);
            return c.ToSprite(Base(68, 4), PPU);
        });

        public static Sprite Fountain() => GameSprites.Get("w_fountain", () =>
        {
            var c = new PixelCanvas(38, 28);
            c.GroundShadow(19, 3, 17, 3.5f, 0.35f);
            Color stone = new Color(0.62f, 0.62f, 0.66f);
            Color water = new Color(0.25f, 0.65f, 0.92f);

            c.Ellipse(19, 8, 17, 7, stone);
            c.Ellipse(19, 9, 14, 5, water);
            c.Rect(17, 9, 4, 9, stone);
            c.Ellipse(19, 18, 7, 3.5f, stone);
            c.Ellipse(19, 19, 5, 2.2f, water);

            // Chorro de agua que cae
            c.Line(19, 21, 19, 25, new Color(0.85f, 0.95f, 1f));
            c.Set(19, 25, Color.white);

            c.Outline(Ink);
            return c.ToSprite(Base(28, 3), PPU);
        });

        public static Sprite Drydock() => GameSprites.Get("w_drydock", () =>
        {
            var c = new PixelCanvas(52, 32);
            c.GroundShadow(26, 3, 23, 3f, 0.3f);
            Color timber = new Color(0.45f, 0.30f, 0.16f);
            Color ribs = new Color(0.65f, 0.45f, 0.25f);

            // Quilla y cuadernas del barco en astillero
            c.Rect(6, 4, 40, 3, timber);
            for (int x = 10; x <= 42; x += 6)
            {
                c.Rect(x, 4, 2, 14, ribs);
                c.Line(x, 18, x - 2, 12, ribs);
                c.Line(x + 2, 18, x + 4, 12, ribs);
            }
            c.Line(8, 7, 44, 7, Color.Lerp(timber, Color.white, 0.2f));

            c.Outline(Ink);
            return c.ToSprite(Base(32, 3), PPU);
        });

        public static Sprite CannonDefense() => GameSprites.Get("w_cannon_defense", () =>
        {
            var c = new PixelCanvas(28, 20);
            c.GroundShadow(14, 3, 11, 2.8f, 0.35f);
            Color bronze = new Color(0.68f, 0.48f, 0.22f);
            Color iron = new Color(0.28f, 0.28f, 0.32f);

            // Cureña de madera naval
            c.Rect(7, 3, 14, 5, new Color(0.42f, 0.26f, 0.14f));
            c.Circle(8, 4, 2.5f, iron); c.Circle(20, 4, 2.5f, iron);

            // Tubo del cañón apuntando en ángulo
            c.Line(6, 9, 22, 15, bronze, 3);
            c.Line(7, 10, 23, 16, Color.Lerp(bronze, Color.white, 0.35f));
            c.Circle(5, 8, 3f, iron); // culata

            c.Outline(Ink);
            return c.ToSprite(Base(20, 3), PPU);
        });

        // ------------------------------------------------------------------ Easter Eggs
        public static Sprite EasterBarrel() => GameSprites.Get("w_easter_barrel", () =>
        {
            var c = new PixelCanvas(16, 22);
            c.GroundShadow(8, 2, 7, 2f, 0.3f);
            c.ShadedEllipse(8, 9, 7, 8, Wood, 0.2f, 0.35f);
            c.Rect(1, 4, 14, 1, new Color(0.35f, 0.35f, 0.38f));
            c.Rect(1, 13, 14, 1, new Color(0.35f, 0.35f, 0.38f));
            // Sombrero de paja encima del barril
            Color straw = new Color(0.95f, 0.82f, 0.32f);
            Color ribbon = new Color(0.85f, 0.15f, 0.15f);
            c.Ellipse(8, 16, 7, 2.5f, straw);
            c.Ellipse(8, 18, 4, 3f, straw);
            c.Ellipse(8, 16.5f, 4.2f, 1.2f, ribbon);
            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 2f / 22f), PPU);
        });

        public static Sprite WantedPoster() => GameSprites.Get("w_wanted_poster", () =>
        {
            var c = new PixelCanvas(18, 26);
            c.Rect(8, 0, 2, 14, WoodDark);
            Color parchment = new Color(0.92f, 0.85f, 0.7f);
            c.Rect(2, 8, 14, 16, parchment);
            c.Rect(2, 8, 14, 1, WoodDark);
            c.Rect(2, 23, 14, 1, WoodLight);
            // Letras WANTED en la parte superior
            c.Rect(4, 21, 10, 1, Ink);
            // Calavera pirata en el centro
            c.Circle(9, 16, 2.5f, Ink);
            c.Rect(8, 13, 3, 2, Ink);
            // Valor de recompensa
            c.Rect(4, 10, 10, 1, new Color(0.45f, 0.25f, 0.15f));
            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 0.02f), PPU);
        });

        public static Sprite SwordMonument() => GameSprites.Get("w_sword_monument", () =>
        {
            var c = new PixelCanvas(20, 30);
            c.GroundShadow(10, 3, 9, 2.5f, 0.35f);
            // Pedestal de roca
            c.ShadedEllipse(10, 7, 8, 5, Stone, 0.25f, 0.35f);
            c.Rect(6, 6, 8, 4, Stone);
            // Katana blanca clavada
            Color blade = new Color(0.95f, 0.96f, 0.98f);
            Color tsuba = new Color(0.95f, 0.82f, 0.3f);
            Color tsuka = Color.white;
            c.Line(10, 9, 10, 20, blade, 2);
            c.Line(7, 20, 13, 20, tsuba, 2); // guarda de oro
            c.Line(10, 20, 10, 27, tsuka, 2); // empuñadura blanca
            c.Set(10, 28, tsuba); // pomo
            // Lazo rojo ondeando
            c.Line(10, 21, 15, 19, new Color(0.85f, 0.2f, 0.2f), 1);
            c.Line(15, 19, 17, 21, new Color(0.85f, 0.2f, 0.2f), 1);
            c.Outline(Ink);
            return c.ToSprite(Base(30, 3), PPU);
        });

        public static Sprite MessageBottle() => GameSprites.Get("w_message_bottle", () =>
        {
            var c = new PixelCanvas(16, 14);
            c.GroundShadow(8, 2, 7, 1.8f, 0.25f);
            Color glass = new Color(0.45f, 0.75f, 0.8f, 0.75f);
            Color parchment = new Color(0.95f, 0.88f, 0.72f);
            Color wax = new Color(0.85f, 0.2f, 0.2f);
            // Botella acostada
            c.Ellipse(8, 6, 6, 3.5f, glass);
            c.Rect(1, 5, 4, 2, glass);
            c.Rect(0, 5, 2, 2, new Color(0.6f, 0.45f, 0.28f)); // corcho
            // Pergamino enrollado dentro
            c.Ellipse(8, 6, 3.5f, 1.8f, parchment);
            c.Set(8, 6, wax); // sello de lacre
            c.Outline(Ink);
            return c.ToSprite(new Vector2(0.5f, 0.2f), PPU);
        });

        public static Sprite Poneglyph() => GameSprites.Get("w_poneglyph", () =>
        {
            var c = new PixelCanvas(34, 38);
            c.GroundShadow(17, 4, 15, 3.5f, 0.4f);
            Color darkStone = new Color(0.18f, 0.2f, 0.28f);
            Color stoneSide = new Color(0.12f, 0.14f, 0.2f);
            Color stoneTop = new Color(0.28f, 0.3f, 0.4f);
            Color glyph = new Color(0.2f, 0.85f, 0.8f); // brillo misterioso de los glifos
            Color glyphRed = new Color(0.95f, 0.35f, 0.35f);
            // Cubo monolítico
            c.Rect(3, 4, 24, 26, darkStone);
            c.Rect(27, 4, 4, 26, stoneSide);
            c.Rect(3, 30, 24, 4, stoneTop);
            // Glifos ancestrales tallados
            for (int y = 8; y <= 24; y += 4)
            {
                for (int x = 6; x <= 22; x += 4)
                {
                    Color gColor = ((x + y) % 3 == 0) ? glyphRed : glyph;
                    c.Rect(x, y, 2, 2, gColor);
                    c.Set(x + 1, y, Color.Lerp(gColor, Color.white, 0.5f));
                }
            }
            c.Outline(Ink);
            return c.ToSprite(Base(38, 4), PPU);
        });

        public static Sprite DropShadow() => GameSprites.Get("w_drop_shadow", () =>
        {
            var c = new PixelCanvas(22, 12);
            c.GroundShadow(11, 6, 9.5f, 4.2f, 0.45f);
            return c.ToSprite(new Vector2(0.5f, 0.5f), PPU);
        });
    }
}
