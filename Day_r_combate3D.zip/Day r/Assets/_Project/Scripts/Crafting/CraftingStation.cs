﻿using System.Collections.Generic;
using UnityEngine;
using PirateSurvival.Core;
using PirateSurvival.Interaction;
using PirateSurvival.Inventory;
using PirateSurvival.Story;

namespace PirateSurvival.Crafting
{
    /// <summary>
    /// Mesa de trabajo o forja del mundo. Estar a menos de 'radius' permite fabricar sus recetas.
    /// Con [E] abre directamente la mochila en la pestaña Fabricar.
    /// </summary>
    [RequireComponent(typeof(Collider2D))]
    public class CraftingStation : MonoBehaviour, IInteractable
    {
        private static readonly List<CraftingStation> Active = new List<CraftingStation>();
        public static IReadOnlyList<CraftingStation> All => Active;

        [SerializeField] private StationType type = StationType.Workbench;
        [SerializeField] private float radius = 2.6f;

        public StationType Type => type;
        public bool IsInRange(Vector2 position) => Vector2.Distance(transform.position, position) <= radius;

        public void Configure(StationType stationType, float useRadius)
        {
            type = stationType;
            radius = useRadius;
        }

        private void OnEnable() { if (!Active.Contains(this)) Active.Add(this); }
        private void OnDisable() { Active.Remove(this); }

        public static bool IsNear(StationType t, Vector2 position)
        {
            if (t == StationType.None) return true;
            for (int i = 0; i < Active.Count; i++)
            {
                CraftingStation s = Active[i];
                if (s != null && s.type == t && Vector2.Distance(s.transform.position, position) <= s.radius) return true;
            }
            return false;
        }

        public static string DisplayName(StationType t)
        {
            switch (t)
            {
                case StationType.Workbench: return "Mesa de trabajo";
                case StationType.Forge: return "Forja";
                case StationType.Campfire: return "Hoguera";
                default: return "A mano";
            }
        }

        public string GetPromptText() => $"Pulsa [E] para usar la {DisplayName(type)}";

        public void Interact(PlayerInteraction2D interactor)
        {
            if (PirateSurvival.Inventory.UI.InventoryUI.Instance != null)
                PirateSurvival.Inventory.UI.InventoryUI.Instance.OpenCrafting();
        }

        public bool CanInteract() => true;
    }
}
