﻿using System.Collections.Generic;
using UnityEngine;
using PirateSurvival.Core;
using PirateSurvival.Interaction;
using PirateSurvival.Inventory;
using PirateSurvival.Story;

namespace PirateSurvival.Crafting
{
    /// <summary>Reglas de fabricación: qué se conoce, qué falta y fabricar de verdad.</summary>
    public static class CraftingSystem
    {
        /// <summary>¿Ya se ha aprendido? (las recetas de forja las enseña el herrero en la historia)</summary>
        public static bool IsKnown(Recipe r)
        {
            if (r == null) return false;
            if (string.IsNullOrEmpty(r.requiredFlag)) return true;
            return StoryManager.Instance == null || StoryManager.Instance.Flag(r.requiredFlag);
        }

        public static bool HasStation(Recipe r, Vector2 playerPos) => r != null && CraftingStation.IsNear(r.station, playerPos);

        public static bool HasIngredients(Recipe r, InventoryManager inv)
        {
            if (r == null || inv == null) return false;
            foreach (Ingredient ing in r.ingredients)
            {
                if (inv.CountItem(ing.itemId) < ing.quantity) return false;
            }
            return true;
        }

        public static bool CanCraft(Recipe r, InventoryManager inv, Vector2 playerPos, out string reason)
        {
            reason = string.Empty;
            if (!IsKnown(r)) { reason = "Aún no sabes hacerlo (habla con Tetsu el herrero)."; return false; }
            if (!HasStation(r, playerPos)) { reason = $"Necesitas estar junto a una {CraftingStation.DisplayName(r.station)}."; return false; }
            if (!HasIngredients(r, inv)) { reason = "Te faltan materiales."; return false; }
            if (ItemDatabase.Get(r.resultId) == null) { reason = "Objeto desconocido."; return false; }
            return true;
        }

        /// <summary>Gasta los ingredientes y da el resultado (si no cabe, cae al suelo). Avisa a la historia.</summary>
        public static bool Craft(Recipe r, InventoryManager inv, Vector2 playerPos, out string message)
        {
            if (!CanCraft(r, inv, playerPos, out message)) return false;

            foreach (Ingredient ing in r.ingredients)
            {
                inv.ConsumeItemById(ing.itemId, ing.quantity);
            }

            ItemData result = ItemDatabase.Get(r.resultId);
            if (!inv.AddItem(result, r.resultQuantity))
            {
                WorldItemFactory.Spawn(result, r.resultQuantity, playerPos + Vector2.down * 0.7f);
                message = $"{result.itemName}: no cabe en la mochila, lo dejas en el suelo.";
            }
            else
            {
                message = r.resultQuantity > 1 ? $"Has fabricado {result.itemName} x{r.resultQuantity}" : $"Has fabricado {result.itemName}";
            }
            GameEvents.TriggerStoryEvent("craft:" + r.resultId);
            return true;
        }
    }
}
