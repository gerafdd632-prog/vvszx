﻿using System.Collections.Generic;

namespace PirateSurvival.Crafting
{
    /// <summary>Dónde se puede fabricar algo.</summary>
    public enum StationType
    {
        None,       // en cualquier sitio (a mano)
        Workbench,  // Mesa de trabajo (carpintería de la aldea, campamento de la playa)
        Forge,      // Forja del herrero
        Campfire    // Hoguera para cocinar alimentos calientes
    }

    public enum RecipeCategory
    {
        Materiales,
        Herramientas,
        Espadas,
        Medicina,
        Cocina,
        Armaduras,
        Municion
    }

    public struct Ingredient
    {
        public string itemId;
        public int quantity;
        public Ingredient(string id, int qty) { itemId = id; quantity = qty; }
    }

    /// <summary>Receta: ingredientes, estación necesaria y tiempo de fabricación (segundos reales).</summary>
    public class Recipe
    {
        public string id;
        public string resultId;
        public int resultQuantity = 1;
        public RecipeCategory category;
        public StationType station;
        public float seconds = 1.5f;
        public List<Ingredient> ingredients = new List<Ingredient>();
        /// <summary>Si no está vacío, la receta solo aparece cuando la historia ha marcado este flag (p. ej. el herrero te enseña).</summary>
        public string requiredFlag = "";
    }

    /// <summary>Todas las recetas del juego.</summary>
    public static class RecipeBook
    {
        public const string ForgeFlag = "aprendio_forja";

        public static readonly List<Recipe> All = new List<Recipe>
        {
            // ================================================================ MATERIALES
            R("cuerda", "cuerda", 1, RecipeCategory.Materiales, StationType.None, 1.0f, I("fibra", 3)),
            R("tela", "tela", 1, RecipeCategory.Materiales, StationType.Workbench, 1.8f, I("fibra", 4)),
            R("carbon", "carbon", 2, RecipeCategory.Materiales, StationType.Campfire, 1.5f, I("madera", 2)),
            R("lingote", "lingote_hierro", 1, RecipeCategory.Materiales, StationType.Forge, 2.5f, I("mineral_hierro", 2), I("madera", 1)),
            R("lingote_acero", "lingote_acero", 1, RecipeCategory.Materiales, StationType.Forge, 3.0f, I("lingote_hierro", 2), I("carbon", 1)),
            R("polvora", "polvora", 2, RecipeCategory.Materiales, StationType.Workbench, 2.0f, I("carbon", 1), I("azufre", 1)),
            R("clavo_hierro", "clavo_hierro", 5, RecipeCategory.Materiales, StationType.Forge, 1.5f, I("lingote_hierro", 1)),
            R("cuero", "cuero", 1, RecipeCategory.Materiales, StationType.Workbench, 2.0f, I("carne_cruda", 1), I("fibra", 2)),

            // ================================================================ HERRAMIENTAS
            R("pico_madera", "pico_madera", 1, RecipeCategory.Herramientas, StationType.None, 1.5f, I("madera", 3), I("cuerda", 1)),
            R("hacha", "hacha", 1, RecipeCategory.Herramientas, StationType.Workbench, 2f, I("madera", 2), I("piedra", 2), I("cuerda", 1)),
            R("pico", "pico", 1, RecipeCategory.Herramientas, StationType.Workbench, 2f, I("madera", 2), I("piedra", 3), I("cuerda", 1)),
            R("pala_pirata", "pala_pirata", 1, RecipeCategory.Herramientas, StationType.Workbench, 2.2f, I("madera", 2), I("lingote_hierro", 1), I("cuerda", 1)),
            R("antorcha_mano", "antorcha_mano", 1, RecipeCategory.Herramientas, StationType.None, 1.2f, I("madera", 1), I("tela", 1), I("carbon", 1)),
            R("cana_pescar", "cana_pescar", 1, RecipeCategory.Herramientas, StationType.Workbench, 2.0f, I("madera", 3), I("cuerda", 2), I("clavo_hierro", 1)),

            // ================================================================ ESPADAS Y ARMAS CUERPO A CUERPO
            R("espada_madera", "espada_madera", 1, RecipeCategory.Espadas, StationType.None, 1.5f, I("madera", 3), I("cuerda", 1)),
            R("daga_abordaje", "daga_abordaje", 1, RecipeCategory.Espadas, StationType.Forge, 2.2f, I("lingote_hierro", 1), I("madera", 1), I("cuero", 1)),
            R("sable", "sable", 1, RecipeCategory.Espadas, StationType.Forge, 3f, I("lingote_hierro", 2), I("madera", 1)),
            R("espada_marina", "espada_marina", 1, RecipeCategory.Espadas, StationType.Forge, 3.2f, I("lingote_hierro", 3), I("tela", 1), I("cuero", 1)),
            R("katana", "katana", 1, RecipeCategory.Espadas, StationType.Forge, 3.5f, I("lingote_acero", 2), I("cuerda", 1), I("tela", 1)),
            R("nodachi", "nodachi", 1, RecipeCategory.Espadas, StationType.Forge, 4f, I("lingote_acero", 3), I("cuerda", 2), I("madera", 2)),
            R("maza_hierro", "maza_hierro", 1, RecipeCategory.Espadas, StationType.Forge, 3.0f, I("madera", 2), I("lingote_hierro", 2), I("clavo_hierro", 3)),
            R("lanza_madera", "lanza_madera", 1, RecipeCategory.Espadas, StationType.Workbench, 2.0f, I("madera", 4), I("cuerda", 1), I("lingote_hierro", 1)),
            R("daga_kairoseki", "daga_kairoseki", 1, RecipeCategory.Espadas, StationType.Forge, 4f, I("kairoseki", 2), I("lingote_hierro", 1), I("cuerda", 1)),

            // ================================================================ ARMAS A DISTANCIA Y MUNICIÓN
            R("tirachinas", "tirachinas", 1, RecipeCategory.Municion, StationType.None, 1.4f, I("madera", 2), I("cuerda", 1)),
            R("balines_piedra", "balines_piedra", 20, RecipeCategory.Municion, StationType.None, 1.0f, I("piedra", 2)),
            R("pistola_chispa", "pistola_chispa", 1, RecipeCategory.Municion, StationType.Forge, 3.8f, I("madera", 2), I("lingote_acero", 2), I("polvora", 1)),
            R("trabuco", "trabuco", 1, RecipeCategory.Municion, StationType.Forge, 4.2f, I("madera", 3), I("lingote_acero", 3), I("polvora", 2)),
            R("balas_plomo", "balas_plomo", 10, RecipeCategory.Municion, StationType.Forge, 2.0f, I("mineral_hierro", 1), I("polvora", 1)),

            // ================================================================ COCINA (HOGUERA)
            R("carne_asada", "carne_asada", 1, RecipeCategory.Cocina, StationType.Campfire, 2.0f, I("carne_cruda", 1), I("madera", 1)),
            R("pescado_asado", "pescado_asado", 1, RecipeCategory.Cocina, StationType.Campfire, 1.8f, I("carne_cangrejo", 1), I("madera", 1)),
            R("sopa_marisco", "sopa_marisco", 1, RecipeCategory.Cocina, StationType.Campfire, 2.5f, I("carne_cangrejo", 1), I("coco", 1), I("botella_agua", 1)),
            R("infusion_herbal", "infusion_herbal", 1, RecipeCategory.Cocina, StationType.Campfire, 1.6f, I("hierbas", 2), I("botella_agua", 1)),

            // ================================================================ MEDICINA
            R("venda", "venda", 2, RecipeCategory.Medicina, StationType.None, 1.2f, I("tela", 1)),
            R("unguento", "unguento", 1, RecipeCategory.Medicina, StationType.None, 1.5f, I("hierbas", 2), I("coco", 1)),
            R("antidoto", "antidoto", 1, RecipeCategory.Medicina, StationType.Workbench, 1.8f, I("hierbas", 2), I("azufre", 1)),
            R("botiquin", "botiquin", 1, RecipeCategory.Medicina, StationType.Workbench, 2.5f, I("venda", 2), I("unguento", 1), I("botella_agua", 1)),

            // ================================================================ ARMADURAS Y EQUIPO
            R("sombrero_paja", "sombrero_paja", 1, RecipeCategory.Armaduras, StationType.Workbench, 2.5f, I("fibra", 6), I("cuerda", 1)),
            R("chaleco_cuero", "chaleco_cuero", 1, RecipeCategory.Armaduras, StationType.Workbench, 3.0f, I("cuero", 4), I("cuerda", 2)),
            R("capa_justicia", "capa_justicia", 1, RecipeCategory.Armaduras, StationType.Workbench, 3.5f, I("tela", 4), I("cuerda", 2), I("lingote_hierro", 1))
        };

        public static Recipe Find(string id) => All.Find(r => r.id == id);

        private static Ingredient I(string id, int qty) => new Ingredient(id, qty);

        private static Recipe R(string id, string result, int qty, RecipeCategory cat, StationType station, float seconds, params Ingredient[] ings)
        {
            return new Recipe
            {
                id = id, resultId = result, resultQuantity = qty, category = cat, station = station, seconds = seconds,
                ingredients = new List<Ingredient>(ings),
                // La forja hay que aprenderla con el herrero (modo historia)
                requiredFlag = station == StationType.Forge ? ForgeFlag : ""
            };
        }
    }
}
