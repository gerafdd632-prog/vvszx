﻿using UnityEngine;

namespace PirateSurvival.Player
{
    public enum HakiType { Observation, Armament, Conqueror }

    /// <summary>
    /// Haki del jugador. Los tres tipos empiezan BLOQUEADOS; se desbloquean más adelante por historia/entrenamiento (Unlock).
    /// Cada tipo desbloqueado añade una habilidad de combate con coste, duración y cooldown (ver AbilityLibrary).
    /// </summary>
    public class HakiManager : MonoBehaviour
    {
        [SerializeField] private bool observation;
        [SerializeField] private bool armament;
        [SerializeField] private bool conqueror;

        public bool Has(HakiType type)
        {
            switch (type)
            {
                case HakiType.Observation: return observation;
                case HakiType.Armament: return armament;
                default: return conqueror;
            }
        }

        public void Unlock(HakiType type)
        {
            if (type == HakiType.Observation) observation = true;
            else if (type == HakiType.Armament) armament = true;
            else conqueror = true;
        }

        public void Load(bool obs, bool arm, bool con)
        {
            observation = obs;
            armament = arm;
            conqueror = con;
        }
    }
}
