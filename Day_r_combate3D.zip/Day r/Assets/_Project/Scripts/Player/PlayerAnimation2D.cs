﻿using UnityEngine;
using PirateSurvival.Core;

namespace PirateSurvival.Player
{
    /// <summary>
    /// Controlador de animaciones 2D (Item E, Paso 0.4, Puntos 6 y 9).
    /// Anima el hijo 'Visual' (rotación, traslación por rebote, escalado, parpadeo de daño)
    /// sin afectar al Transform raíz que posee el Rigidbody2D y los colliders físicos.
    /// Realiza un balanceo visual sobre la herramienta equipada (toolSocket) al interactuar.
    /// </summary>
    public class PlayerAnimation2D : MonoBehaviour
    {
        private static readonly int HashMoveX = Animator.StringToHash("MoveX");
        private static readonly int HashMoveY = Animator.StringToHash("MoveY");
        private static readonly int HashSpeed = Animator.StringToHash("Speed");
        private static readonly int HashIsSprinting = Animator.StringToHash("IsSprinting");
        private static readonly int HashIsFainted = Animator.StringToHash("IsFainted");
        private static readonly int HashInteract = Animator.StringToHash("Interact");
        private static readonly int HashDie = Animator.StringToHash("Die");
        private static readonly int HashIdleState = Animator.StringToHash("Idle");

        [Header("Referencias Visuales (Paso 0.4)")]
        [Tooltip("Transform del objeto hijo 'Visual' que recibe las transformaciones y animaciones")]
        [SerializeField] private Transform visualTransform;

        [Header("Punto de Herramienta (Punto 9)")]
        [Tooltip("Transform del socket de la herramienta en la mano")]
        [SerializeField] private Transform toolSocket;

        private Animator animator;
        private SpriteRenderer spriteRenderer;
        private PlayerController2D controller;

        private bool hasAnimatorController = false;
        private Vector3 initialScale = Vector3.one;
        private Vector3 baseLocalPosition = Vector3.zero;

        // Variables procedurales
        private float walkBobTimer = 0f;
        private float footstepTimer = 0f;
        private bool isDeadProcedural = false;
        private bool isFaintedProcedural = false;
        private Coroutine damageFlashCoroutine;
        private Coroutine toolSwingCoroutine;

        public Transform VisualTransform => visualTransform;

        private void Awake()
        {
            if (visualTransform == null)
            {
                Transform childVisual = transform.Find("Visual");
                visualTransform = childVisual != null ? childVisual : transform;
            }

            animator = visualTransform.GetComponent<Animator>();
            if (animator == null)
            {
                animator = GetComponent<Animator>();
            }

            spriteRenderer = visualTransform.GetComponent<SpriteRenderer>();
            if (spriteRenderer == null)
            {
                spriteRenderer = GetComponentInChildren<SpriteRenderer>();
            }

            controller = GetComponent<PlayerController2D>();

            baseLocalPosition = visualTransform.localPosition;
            initialScale = visualTransform.localScale;

            hasAnimatorController = (animator != null && animator.runtimeAnimatorController != null);
        }

        private void OnEnable()
        {
            GameEvents.OnPlayerDeath += HandleDeath;
            GameEvents.OnPlayerFaint += HandleFaint;
            GameEvents.OnPlayerRespawn += HandleRespawn;
            GameEvents.OnPlayerDamaged += HandleDamageFlash;
        }

        private void OnDisable()
        {
            GameEvents.OnPlayerDeath -= HandleDeath;
            GameEvents.OnPlayerFaint -= HandleFaint;
            GameEvents.OnPlayerRespawn -= HandleRespawn;
            GameEvents.OnPlayerDamaged -= HandleDamageFlash;
        }

        private void Update()
        {
            if (controller == null) return;

            if (hasAnimatorController)
            {
                UpdateAnimator();
            }
            else
            {
                UpdateProceduralAnimation();
            }
        }

        private void UpdateAnimator()
        {
            Vector2 face = controller.FaceDirection;
            float speedRatio = controller.SpeedRatio;

            animator.SetFloat(HashMoveX, face.x);
            animator.SetFloat(HashMoveY, face.y);
            animator.SetFloat(HashSpeed, speedRatio);
            animator.SetBool(HashIsSprinting, controller.IsSprinting);
        }

        private void UpdateProceduralAnimation()
        {
            if (spriteRenderer == null || isDeadProcedural || visualTransform == null) return;

            float speed = controller.CurrentSpeed;
            Vector2 move = controller.MoveInput;

            // Volteo horizontal según dirección de movimiento
            if (Mathf.Abs(move.x) > 0.05f)
            {
                spriteRenderer.flipX = (move.x < 0f);

                // Voltear también el socket de la herramienta según hacia dónde mire
                if (toolSocket != null)
                {
                    float sign = move.x < 0f ? -1f : 1f;
                    toolSocket.localPosition = new Vector3(Mathf.Abs(toolSocket.localPosition.x) * sign, toolSocket.localPosition.y, 0f);
                    toolSocket.localScale = new Vector3(sign, 1f, 1f);
                }
            }

            if (isFaintedProcedural)
            {
                spriteRenderer.color = new Color(0.4f, 0.45f, 0.6f, 1f);
                visualTransform.localRotation = Quaternion.Euler(0f, 0f, 45f);
                return;
            }

            // Rebote vertical al caminar / correr sobre visualTransform
            if (speed > 0.1f)
            {
                bool sprinting = controller.IsSprinting;
                float freq = sprinting ? 20f : 11f;
                float amplitude = sprinting ? 0.12f : 0.05f;
                walkBobTimer += Time.deltaTime * freq;

                float bob = Mathf.Abs(Mathf.Sin(walkBobTimer));
                float bobY = bob * amplitude;
                visualTransform.localPosition = baseLocalPosition + new Vector3(0f, bobY, 0f);

                // Dinámica de inclinación y squash & stretch
                float tiltAngle = -move.x * (sprinting ? 14f : 6f);
                if (sprinting)
                {
                    float pitchAngle = move.y * 5f;
                    visualTransform.localRotation = Quaternion.Euler(pitchAngle, 0f, tiltAngle);

                    float stretch = 1f + (bob - 0.5f) * 0.15f;
                    float squash = 1f - (bob - 0.5f) * 0.08f;
                    visualTransform.localScale = new Vector3(initialScale.x * squash, initialScale.y * stretch, initialScale.z);
                }
                else
                {
                    visualTransform.localRotation = Quaternion.Euler(0f, 0f, tiltAngle);
                    visualTransform.localScale = Vector3.MoveTowards(visualTransform.localScale, initialScale, 5f * Time.deltaTime);
                }

                // Pasos audibles con cadencia según velocidad y partículas de polvo
                footstepTimer += Time.deltaTime;
                float stepInterval = sprinting ? 0.20f : 0.38f;
                if (footstepTimer >= stepInterval)
                {
                    footstepTimer = 0f;
                    if (AudioManager.Instance != null)
                    {
                        bool onSand = transform.position.y < -15f;
                        AudioManager.Instance.PlayFootstep(onSand);
                    }
                    if (sprinting)
                    {
                        SpawnDustPuff(transform.position - (Vector3)(move * 0.2f) + new Vector3(0f, -0.3f, 0f));
                    }
                }
            }
            else
            {
                walkBobTimer = 0f;
                footstepTimer = 0.2f;
                visualTransform.localPosition = Vector3.MoveTowards(visualTransform.localPosition, baseLocalPosition, 8f * Time.deltaTime);
                visualTransform.localRotation = Quaternion.RotateTowards(visualTransform.localRotation, Quaternion.identity, 480f * Time.deltaTime);
                visualTransform.localScale = Vector3.MoveTowards(visualTransform.localScale, initialScale, 8f * Time.deltaTime);
            }
        }

        private static void SpawnDustPuff(Vector3 position)
        {
            GameObject go = new GameObject("Puff");
            go.transform.position = position;
            SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = DustSprite();
            sr.sortingOrder = 5;
            go.AddComponent<DustPuffFx>();
        }

        private class DustPuffFx : MonoBehaviour
        {
            private float timer = 0f;
            private SpriteRenderer sr;
            private Vector3 startScale;
            private void Awake()
            {
                sr = GetComponent<SpriteRenderer>();
                startScale = Vector3.one * 0.5f;
                transform.localScale = startScale;
            }
            private void Update()
            {
                timer += Time.deltaTime;
                float progress = Mathf.Clamp01(timer / 0.25f);
                transform.localScale = startScale * (1f + progress * 0.8f);
                transform.position += Vector3.up * (0.4f * Time.deltaTime);
                if (sr != null)
                {
                    Color c = sr.color;
                    c.a = Mathf.Lerp(0.55f, 0f, progress);
                    sr.color = c;
                }
                if (timer >= 0.25f) Destroy(gameObject);
            }
        }

        private static Sprite DustSprite() => RuntimeSpriteCache.Get("fx_dust_puff", () =>
        {
            PixelCanvas c = new PixelCanvas(12, 12);
            c.ShadedEllipse(6, 6, 5f, 4f, new Color(0.85f, 0.8f, 0.7f), 0.15f, 0.25f);
            return c.ToSprite(new Vector2(0.5f, 0.5f), 16f);
        });

        public void TriggerInteractAnimation()
        {
            if (hasAnimatorController)
            {
                animator.SetTrigger(HashInteract);
            }
            else
            {
                StartCoroutine(ProceduralInteractRoutine());
            }

            // Punto 9: Pequeño balanceo de la herramienta en la mano al interactuar
            if (toolSocket != null)
            {
                if (toolSwingCoroutine != null) StopCoroutine(toolSwingCoroutine);
                toolSwingCoroutine = StartCoroutine(ToolSwingRoutine());
            }
        }

        private System.Collections.IEnumerator ProceduralInteractRoutine()
        {
            if (visualTransform == null) yield break;
            visualTransform.localScale = initialScale * 1.15f;
            yield return new WaitForSeconds(0.12f);
            if (visualTransform != null) visualTransform.localScale = initialScale;
        }

        private System.Collections.IEnumerator ToolSwingRoutine()
        {
            if (toolSocket == null) yield break;

            Quaternion originalRot = Quaternion.identity;
            Quaternion swingRot = Quaternion.Euler(0f, 0f, -40f);

            float elapsed = 0f;
            float duration = 0.15f;

            // Golpe hacia adelante
            while (elapsed < duration * 0.5f)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / (duration * 0.5f);
                toolSocket.localRotation = Quaternion.Slerp(originalRot, swingRot, t);
                yield return null;
            }

            // Retorno
            elapsed = 0f;
            while (elapsed < duration * 0.5f)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / (duration * 0.5f);
                toolSocket.localRotation = Quaternion.Slerp(swingRot, originalRot, t);
                yield return null;
            }

            toolSocket.localRotation = originalRot;
            toolSwingCoroutine = null;
        }

        private void HandleDamageFlash(float damage)
        {
            if (spriteRenderer == null || isDeadProcedural) return;

            if (damageFlashCoroutine != null) StopCoroutine(damageFlashCoroutine);
            damageFlashCoroutine = StartCoroutine(DamageFlashRoutine());
        }

        private System.Collections.IEnumerator DamageFlashRoutine()
        {
            if (spriteRenderer == null) yield break;

            Color originalColor = isFaintedProcedural ? new Color(0.4f, 0.45f, 0.6f, 1f) : Color.white;
            spriteRenderer.color = new Color(1f, 0.25f, 0.25f, 1f); // Tinte rojo vivo
            yield return new WaitForSeconds(0.15f);

            if (spriteRenderer != null && !isDeadProcedural)
            {
                spriteRenderer.color = isFaintedProcedural ? new Color(0.4f, 0.45f, 0.6f, 1f) : Color.white;
            }
            damageFlashCoroutine = null;
        }

        private void HandleFaint(bool isFainted)
        {
            if (hasAnimatorController)
            {
                animator.SetBool(HashIsFainted, isFainted);
            }
            else
            {
                isFaintedProcedural = isFainted;
                if (!isFainted && !isDeadProcedural)
                {
                    if (spriteRenderer != null) spriteRenderer.color = Color.white;
                    if (visualTransform != null) visualTransform.localRotation = Quaternion.identity;
                }
            }
        }

        private void HandleDeath()
        {
            if (hasAnimatorController)
            {
                animator.SetTrigger(HashDie);
            }
            else
            {
                isDeadProcedural = true;
                if (spriteRenderer != null) spriteRenderer.color = new Color(0.7f, 0.2f, 0.2f, 1f);
                if (visualTransform != null) visualTransform.localRotation = Quaternion.Euler(0f, 0f, 90f);
            }
        }

        private void HandleRespawn()
        {
            if (hasAnimatorController)
            {
                animator.ResetTrigger(HashDie);
                animator.SetBool(HashIsFainted, false);
                if (animator.HasState(0, HashIdleState))
                {
                    animator.Play("Idle", 0, 0f);
                }
            }
            else
            {
                isDeadProcedural = false;
                isFaintedProcedural = false;
                if (spriteRenderer != null) spriteRenderer.color = Color.white;
                if (visualTransform != null)
                {
                    visualTransform.localRotation = Quaternion.identity;
                    visualTransform.localScale = initialScale;
                    visualTransform.localPosition = baseLocalPosition;
                }
                if (toolSocket != null)
                {
                    toolSocket.localRotation = Quaternion.identity;
                }
            }
        }
    }
}
