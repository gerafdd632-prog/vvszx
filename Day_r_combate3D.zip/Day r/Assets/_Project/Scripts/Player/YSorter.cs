﻿using System.Collections.Generic;
using UnityEngine;

namespace PirateSurvival.Player
{
    /// <summary>
    /// Gestiona la profundidad de renderizado top-down mediante el eje Y (Sorting Order) (Punto 2 y Punto 17).
    /// Los objetos más abajo en pantalla se dibujan delante de los que están más arriba.
    /// Soporta SpriteRenderer objetivo (en el mismo objeto o en hijos), no añade componentes fantasmas,
    /// ignora frames si el objeto no se ha movido y limita el rango a ±32000 para no desbordar Unity.
    /// </summary>
    public class YSorter : MonoBehaviour
    {
        [Header("Configuración de Orden")]
        [Tooltip("Si es estático (árboles, rocas), calcula el orden una sola vez al inicio para ahorrar CPU.")]
        [SerializeField] private bool isStatic = false;
        [Tooltip("Multiplicador de precisión para el eje Y (10 = 1 unidad de Unity son 10 órdenes; escalable para mapas grandes)")]
        [SerializeField] private float precision = 32f;
        [Tooltip("Desplazamiento adicional de sorting order")]
        [SerializeField] private int sortingOffset = 0;
        [Tooltip("Offset del punto de contacto con el suelo (e.g. pies del personaje o raíz)")]
        [SerializeField] private float yPivotOffset = 0f;

        [Header("Renderer Objetivo")]
        [Tooltip("SpriteRenderer específico que recibe el orden. Si es nulo, busca en sí mismo o en hijos.")]
        [SerializeField] private SpriteRenderer targetRenderer;

        [Tooltip("Los SpriteRenderer hijos (p. ej. la herramienta en la mano) siguen el orden del principal.")]
        [SerializeField] private bool syncChildRenderers = false;

        private float lastY = float.MinValue;
        private readonly List<SpriteRenderer> childBuffer = new List<SpriteRenderer>(4);

        public bool SyncChildRenderers
        {
            get => syncChildRenderers;
            set => syncChildRenderers = value;
        }

        public bool IsStatic
        {
            get => isStatic;
            set => isStatic = value;
        }

        public SpriteRenderer TargetRenderer
        {
            get => targetRenderer;
            set => targetRenderer = value;
        }

        private void Awake()
        {
            EnsureRenderer();
            UpdateSortingOrder();
        }

        private void Start()
        {
            UpdateSortingOrder();
        }

        private void LateUpdate()
        {
            if (!isStatic)
            {
                UpdateSortingOrder();
            }
        }

        private void EnsureRenderer()
        {
            if (targetRenderer == null)
            {
                targetRenderer = GetComponent<SpriteRenderer>();
                if (targetRenderer == null)
                {
                    targetRenderer = GetComponentInChildren<SpriteRenderer>();
                }
            }

            if (targetRenderer != null)
            {
                targetRenderer.spriteSortPoint = SpriteSortPoint.Pivot;
            }
        }

        public void UpdateSortingOrder()
        {
            if (targetRenderer == null)
            {
                EnsureRenderer();
                if (targetRenderer == null) return;
            }

            float baseFootY = transform.position.y + yPivotOffset;

            // Punto 17: Dejar de actualizar si no se ha movido en el eje Y
            if (!isStatic && Mathf.Abs(baseFootY - lastY) < 0.001f)
            {
                return;
            }
            lastY = baseFootY;

            // Punto 17: Clamp para evitar desbordar el límite de ±32767 de Unity en mapas grandes
            int calculatedOrder = Mathf.Clamp(Mathf.RoundToInt(-baseFootY * precision) + sortingOffset, -32000, 32000);
            targetRenderer.sortingOrder = calculatedOrder;

            if (syncChildRenderers)
            {
                GetComponentsInChildren(childBuffer);
                for (int i = 0; i < childBuffer.Count; i++)
                {
                    if (childBuffer[i] != targetRenderer) childBuffer[i].sortingOrder = calculatedOrder + 1;
                }
            }
        }
    }
}
