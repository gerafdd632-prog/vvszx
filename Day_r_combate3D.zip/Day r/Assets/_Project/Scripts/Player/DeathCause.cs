﻿namespace PirateSurvival.Player
{
    /// <summary>Causa del último daño letal. La pantalla de muerte muestra un mensaje distinto para cada una.</summary>
    public enum DeathCause
    {
        Unknown,
        Combat,
        Starvation,
        Dehydration,
        Hypothermia,
        Hyperthermia,
        Drowning,
        DevilFruitDrowning,
        Bleeding,
        Poison,
        Burning
    }

    public static class DeathCauseText
    {
        public static string Describe(DeathCause cause)
        {
            switch (cause)
            {
                case DeathCause.Combat: return "Has caído en combate.";
                case DeathCause.Starvation: return "Has muerto de hambre.";
                case DeathCause.Dehydration: return "Has muerto por deshidratación.";
                case DeathCause.Hypothermia: return "El frío ha acabado contigo.";
                case DeathCause.Hyperthermia: return "El calor ha acabado contigo.";
                case DeathCause.Drowning: return "Te has ahogado.";
                case DeathCause.DevilFruitDrowning: return "El mar ha reclamado a un usuario de una Fruta del Diablo.";
                case DeathCause.Bleeding: return "Te has desangrado.";
                case DeathCause.Poison: return "El veneno ha acabado contigo.";
                case DeathCause.Burning: return "Las llamas han acabado contigo.";
                default: return "La isla no perdona a los descuidados.";
            }
        }
    }
}
