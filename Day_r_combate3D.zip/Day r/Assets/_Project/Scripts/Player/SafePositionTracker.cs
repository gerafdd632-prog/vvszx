﻿using System.Collections.Generic;
using UnityEngine;
using PirateSurvival.Core;
using PirateSurvival.Environment;

namespace PirateSurvival.Player
{
    /// <summary>
    /// Recuerda la última posición segura en tierra (vivo, sin desmayo, fuera del agua y del combate,
    /// y sin pisar un collider sólido). Se usa como respaldo al cargar, reaparecer o huir si la posición pedida no es válida.
    /// Los límites del mundo los da WorldBoundsProvider (no hay tamaño de mapa fijo aquí).
    /// </summary>
    [RequireComponent(typeof(Rigidbody2D))]
    public class SafePositionTracker : MonoBehaviour
    {
        /// <summary>Los pies del jugador están 0.2 por debajo del pivote, con radio 0.35.</summary>
        public static readonly Vector2 FeetOffset = new Vector2(0f, -0.2f);
        public const float FeetRadius = 0.3f;
        private const int MaxPointsPerRing = 48;

        [SerializeField] private float sampleInterval = 1f;

        private static readonly List<Collider2D> HitBuffer = new List<Collider2D>(8);

        private PlayerStats stats;
        private PlayerSwimming swimming;
        private Rigidbody2D body;
        private float timer;

        public Vector2 LastSafeLandPosition { get; private set; }
        public bool HasSafePosition { get; private set; }

        private void Awake()
        {
            stats = GetComponent<PlayerStats>();
            swimming = GetComponent<PlayerSwimming>();
            body = GetComponent<Rigidbody2D>();
        }

        private void Start()
        {
            if (swimming == null) swimming = GetComponent<PlayerSwimming>();
            TrySample();
        }

        private void Update()
        {
            if (!GameState.IsPlaying || GameState.InBattle) return;
            timer += Time.deltaTime;
            if (timer < sampleInterval) return;
            timer = 0f;
            TrySample();
        }

        private void TrySample()
        {
            if (stats == null || stats.IsDead || stats.IsFainted) return;
            if (swimming != null && swimming.InWater) return;
            Vector2 p = body.position;
            if (IsValidLandPosition(p, body)) SetSafePosition(p);
        }

        public void SetSafePosition(Vector2 position)
        {
            LastSafeLandPosition = position;
            HasSafePosition = true;
        }

        /// <summary>Restaura la referencia desde un guardado (sin validar: quien carga la valida).</summary>
        public void Restore(Vector2 position, bool valid)
        {
            LastSafeLandPosition = position;
            HasSafePosition = valid;
        }

        /// <summary>
        /// Posición válida en tierra: valores finitos, dentro de los límites del mundo, fuera del mar
        /// y sin solaparse con colliders sólidos (ignorando los del cuerpo indicado, p. ej. el propio jugador).
        /// </summary>
        public static bool IsValidLandPosition(Vector2 position, Rigidbody2D ignoreBody)
        {
            if (float.IsNaN(position.x) || float.IsNaN(position.y) || float.IsInfinity(position.x) || float.IsInfinity(position.y)) return false;
            if (!WorldBoundsProvider.Contains(position)) return false;

            Vector2 feet = position + FeetOffset;
            if (SeaZone.IsDeepWaterAt(feet)) return false;

            ContactFilter2D filter = new ContactFilter2D();
            filter.useTriggers = false;
            int hits = Physics2D.OverlapCircle(feet, FeetRadius, filter, HitBuffer);
            for (int i = 0; i < hits; i++)
            {
                Collider2D c = HitBuffer[i];
                if (c == null || c.isTrigger) continue;
                if (ignoreBody != null && c.attachedRigidbody == ignoreBody) continue;
                return false;
            }
            return true;
        }

        /// <summary>
        /// Busca la posición válida más cercana en anillos concéntricos (paso 'step') hasta 'maxRadius'.
        /// Acotado (máx. 48 puntos por anillo) y sin asignaciones: pensado para cargar, reaparecer o recuperar, no para cada frame.
        /// </summary>
        public static bool TryFindNearestSafePosition(Vector2 origin, Rigidbody2D body, float maxRadius, float step, out Vector2 safePosition)
        {
            Physics2D.SyncTransforms();
            safePosition = origin;
            if (IsValidLandPosition(origin, body)) return true;
            if (step <= 0.01f || maxRadius <= 0f || float.IsNaN(origin.x) || float.IsNaN(origin.y)) return false;

            for (float r = step; r <= maxRadius + 0.001f; r += step)
            {
                int points = Mathf.Clamp(Mathf.CeilToInt(2f * Mathf.PI * r / step), 8, MaxPointsPerRing);
                for (int i = 0; i < points; i++)
                {
                    float a = i * Mathf.PI * 2f / points;
                    Vector2 candidate = origin + new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * r;
                    if (IsValidLandPosition(candidate, body))
                    {
                        safePosition = candidate;
                        return true;
                    }
                }
            }
            return false;
        }
    }
}
