﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace PirateSurvival.Player
{
    /// <summary>Miembro de la tripulación. Su estado (vida, equipo) persiste entre combates y en la partida guardada.</summary>
    [Serializable]
    public class CrewMemberData
    {
        public string id = "";
        public string name = "Tripulante";
        public string role = "Luchador"; // Espadachín, Tirador, Médico, Navegante, Luchador, Usuario de Fruta...
        public int maxHp = 60;
        public int hp = 60;
        public int attackBonus;
        public int defense = 1;
        public int maxAp = 6;
        public int speed = 4;
        public string weaponName = "Puños";
        public int weaponDamage = 8;
        public int weaponMinRange = 1;
        public int weaponMaxRange = 1;
        public int weaponApCost = 2;
        public float weaponAccuracy = 0.85f;
        public bool playerControlled = true; // false = lo mueve la IA
        public bool inParty = true;           // participa en los combates
    }

    /// <summary>
    /// Tripulación del jugador. Vacía por ahora: el sistema de combate ya la incluye en el tablero
    /// (controlada por el jugador o por IA) cuando haya miembros.
    /// </summary>
    public class CrewManager : MonoBehaviour
    {
        [SerializeField] private List<CrewMemberData> members = new List<CrewMemberData>();

        public List<CrewMemberData> Members => members;

        public void Recruit(CrewMemberData member)
        {
            if (member != null && members.Find(m => m.id == member.id) == null) members.Add(member);
        }

        public void Load(List<CrewMemberData> saved) => members = saved ?? new List<CrewMemberData>();
    }
}
