﻿using UnityEngine;
using PirateSurvival.Core;

namespace PirateSurvival.Player
{
    /// <summary>
    /// Cámara ortográfica 2D top-down con seguimiento suave, límites de mapa opcionales,
    /// zoom continuo mediante GameInput y soporte para Pixel Perfect Camera.
    /// </summary>
    [RequireComponent(typeof(Camera))]
    public class Camera2D : MonoBehaviour
    {
        [Header("Seguimiento del Objetivo")]
        [Tooltip("Transform del jugador u objetivo a seguir")]
        [SerializeField] private Transform target;
        [Tooltip("Offset respecto al objetivo")]
        [SerializeField] private Vector2 targetOffset = Vector2.zero;
        [Tooltip("Tiempo de suavizado para el seguimiento")]
        [SerializeField] private float smoothTime = 0.12f;

        [Header("Límites del Mapa (Opcional)")]
        [SerializeField] private bool useBounds = false;
        [SerializeField] private Vector2 minBounds = new Vector2(-50f, -50f);
        [SerializeField] private Vector2 maxBounds = new Vector2(50f, 50f);

        [Header("Zoom")]
        [SerializeField] private float defaultOrthoSize = 6.0f;
        [SerializeField] private float minOrthoSize = 3.5f;
        [SerializeField] private float maxOrthoSize = 10.0f;
        [SerializeField] private float zoomSensitivity = 0.75f;
        [SerializeField] private float zoomSpeed = 8.0f;

        private Camera cam;
        private Vector3 currentVelocity;
        private float targetOrthoSize;
        private Vector3 shakeOffset = Vector3.zero;
        private Coroutine shakeCoroutine;

        public Transform Target => target;

        private void OnEnable()
        {
            GameEvents.OnPlayerDamaged += HandlePlayerDamaged;
        }

        private void OnDisable()
        {
            GameEvents.OnPlayerDamaged -= HandlePlayerDamaged;
            shakeOffset = Vector3.zero;
        }

        private void HandlePlayerDamaged(float amount)
        {
            float mag = Mathf.Clamp(amount * 0.018f, 0.05f, 0.32f);
            Shake(0.14f, mag);
        }

        public void Shake(float duration, float magnitude)
        {
            if (!gameObject.activeInHierarchy) return;
            if (shakeCoroutine != null) StopCoroutine(shakeCoroutine);
            shakeCoroutine = StartCoroutine(ShakeRoutine(duration, magnitude));
        }

        private System.Collections.IEnumerator ShakeRoutine(float duration, float magnitude)
        {
            float elapsed = 0f;
            while (elapsed < duration)
            {
                shakeOffset = new Vector3(Random.Range(-1f, 1f) * magnitude, Random.Range(-1f, 1f) * magnitude, 0f);
                elapsed += Time.unscaledDeltaTime;
                yield return null;
            }
            shakeOffset = Vector3.zero;
            shakeCoroutine = null;
        }

        private void OnValidate()
        {
            if (minOrthoSize <= 1f) minOrthoSize = 1f;
            if (maxOrthoSize <= minOrthoSize) maxOrthoSize = minOrthoSize + 3f;
            if (defaultOrthoSize < minOrthoSize || defaultOrthoSize > maxOrthoSize)
            {
                defaultOrthoSize = Mathf.Clamp(defaultOrthoSize, minOrthoSize, maxOrthoSize);
            }
        }

        public static Camera2D Instance { get; private set; }

        public static void TriggerShake(float duration = 0.14f, float magnitude = 0.15f)
        {
            if (Instance != null) Instance.Shake(duration, magnitude);
        }

        private void Awake()
        {
            Instance = this;
            cam = GetComponent<Camera>();
            cam.orthographic = true;
            cam.transparencySortMode = TransparencySortMode.CustomAxis;
            cam.transparencySortAxis = new Vector3(0f, 1f, 0f);

            targetOrthoSize = defaultOrthoSize;
            cam.orthographicSize = defaultOrthoSize;

            if (target == null)
            {
                PlayerController2D player = FindFirstObjectByType<PlayerController2D>();
                if (player != null) target = player.transform;
            }
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        private void LateUpdate()
        {
            if (target == null) return;

            HandleZoom();
            FollowTarget();
        }

        private void HandleZoom()
        {
            float scroll = GameInput.GetScrollDelta();
            if (Mathf.Abs(scroll) > 0.01f)
            {
                targetOrthoSize = Mathf.Clamp(targetOrthoSize - (scroll * zoomSensitivity), minOrthoSize, maxOrthoSize);
            }

            cam.orthographicSize = Mathf.MoveTowards(cam.orthographicSize, targetOrthoSize, zoomSpeed * Time.deltaTime);
        }

        private void FollowTarget()
        {
            Vector3 desiredPos = new Vector3(target.position.x + targetOffset.x, target.position.y + targetOffset.y, transform.position.z);

            if (useBounds)
            {
                float vertExtent = cam.orthographicSize;
                float horzExtent = vertExtent * cam.aspect;

                float clampedX = Mathf.Clamp(desiredPos.x, minBounds.x + horzExtent, maxBounds.x - horzExtent);
                float clampedY = Mathf.Clamp(desiredPos.y, minBounds.y + vertExtent, maxBounds.y - vertExtent);

                desiredPos.x = clampedX;
                desiredPos.y = clampedY;
            }

            transform.position = Vector3.SmoothDamp(transform.position, desiredPos, ref currentVelocity, smoothTime) + shakeOffset;
        }

        public void SetTarget(Transform newTarget)
        {
            target = newTarget;
        }

        private void OnDrawGizmosSelected()
        {
            if (useBounds)
            {
                Gizmos.color = Color.yellow;
                Vector3 center = new Vector3((minBounds.x + maxBounds.x) * 0.5f, (minBounds.y + maxBounds.y) * 0.5f, 0f);
                Vector3 size = new Vector3(maxBounds.x - minBounds.x, maxBounds.y - minBounds.y, 0.1f);
                Gizmos.DrawWireCube(center, size);
            }
        }
    }
}
