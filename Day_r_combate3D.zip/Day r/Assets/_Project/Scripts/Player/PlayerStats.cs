﻿using System.Collections;
using UnityEngine;
using PirateSurvival.Core;

namespace PirateSurvival.Player
{
    /// <summary>
    /// Gestiona las estadísticas vitales de supervivencia inspiradas en Day R Survival (Versión 2D Top-Down):
    /// Vida, Hambre, Sed, Estamina, Humedad corporal y Termorregulación con homeostasis reequilibrada.
    /// Incorpora histéresis de estamina (A2.I.1), balance térmico a 5-6 minutos en frío nocturno (A2.I.6),
    /// causa de muerte, daño continuo sin spam visual, desmayo por estado crítico prolongado y humedad centralizada.
    /// </summary>
    public class PlayerStats : MonoBehaviour
    {
        [Header("Configuración Máxima")]
        [Tooltip("Salud máxima del jugador")]
        [SerializeField] private float maxHealth = 100f;
        [Tooltip("Hambre máxima (100 = saciado, 0 = inanición)")]
        [SerializeField] private float maxHunger = 100f;
        [Tooltip("Sed máxima (100 = hidratado, 0 = deshidratación)")]
        [SerializeField] private float maxThirst = 100f;
        [Tooltip("Estamina máxima para correr")]
        [SerializeField] private float maxStamina = 100f;

        [Header("Tasas de Decaimiento Base (por segundo)")]
        [Tooltip("Pérdida pasiva de hambre por segundo")]
        [SerializeField] private float hungerDecayRate = 0.035f;
        [Tooltip("Pérdida pasiva de sed por segundo")]
        [SerializeField] private float thirstDecayRate = 0.06f;
        [Tooltip("Regeneración pasiva de estamina por segundo")]
        [SerializeField] private float staminaRegenRate = 22f;
        [Tooltip("Consumo de estamina por segundo al esprintar")]
        [SerializeField] private float sprintStaminaCost = 8.5f;

        [Header("Termorregulación y Homeostasis (°C)")]
        [Tooltip("Temperatura corporal normal óptima")]
        [SerializeField] private float optimalBodyTemp = 36.6f;
        [Tooltip("Límite inferior de la zona de confort ambiental")]
        [SerializeField] private float minComfortTemp = 18f;
        [Tooltip("Límite superior de la zona de confort ambiental")]
        [SerializeField] private float maxComfortTemp = 36f;
        [Tooltip("Velocidad de recuperación interna homeostática hacia 36.6 °C")]
        [SerializeField] private float homeostaticRegenRate = 0.04f;
        [Tooltip("Velocidad de intercambio térmico (calibrada para 5-6 min hacia hipotermia nocturna)")]
        [SerializeField] private float thermalExchangeRate = 0.012f;
        [Tooltip("Umbral de hipotermia grave (comienza el daño a la salud)")]
        [SerializeField] private float hypothermiaThreshold = 32.0f;
        [Tooltip("Umbral de hipertermia / golpe de calor (recalibrado para no ser letal de golpe)")]
        [SerializeField] private float hyperthermiaThreshold = 41.5f;

        [Header("Aislamiento y Modificadores Térmicos")]
        [Tooltip("Aislamiento térmico de la ropa (0 = desnudo, 0.7 = ropa abrigada)")]
        [Range(0f, 0.85f)]
        [SerializeField] private float clothingInsulation = 0.2f;

        [Header("Humedad corporal (todas las fuentes pasan por aquí)")]
        [Tooltip("Humedad ganada por segundo bajo lluvia normal (1 = empapado). 0.006 ≈ 2,8 min para empaparse")]
        [SerializeField] private float rainWetnessPerSecond = 0.006f;
        [Tooltip("Humedad ganada por segundo bajo tormenta. 0.02 ≈ 50 s para empaparse")]
        [SerializeField] private float stormWetnessPerSecond = 0.02f;
        [Tooltip("Velocidad de secado natural por segundo (solo cuando nada te está mojando)")]
        [SerializeField] private float dryingRate = 0.01f;
        [Tooltip("Multiplicador de secado junto al fuego")]
        [SerializeField] private float fireDryingMultiplier = 4.5f;

        [Header("Daño por Negligencia (por segundo)")]
        [SerializeField] private float starvationDamage = 1.0f;
        [SerializeField] private float dehydrationDamage = 2.5f;
        [SerializeField] private float extremeTempDamage = 1.8f;
        [Tooltip("El daño continuo (hambre, sed, frío, heridas) solo dispara el destello de daño cada X segundos")]
        [SerializeField] private float continuousFeedbackInterval = 1.5f;

        [Header("Desmayo (estado crítico prolongado)")]
        [Tooltip("Segundos seguidos en estado crítico antes de desmayarse")]
        [SerializeField] private float faintAfterCriticalSeconds = 40f;
        [Tooltip("Duración del desmayo")]
        [SerializeField] private float faintDurationSeconds = 6f;
        [Tooltip("Protección tras despertar: no puede volver a desmayarse en este tiempo")]
        [SerializeField] private float faintImmunitySeconds = 120f;
        [Tooltip("Vida por debajo de la cual el agotamiento total cuenta como crítico (fracción de la máxima)")]
        [SerializeField] private float exhaustionCriticalHealthFraction = 0.25f;

        // Estado vital
        private float currentHealth;
        private float currentHunger;
        private float currentThirst;
        private float currentStamina;
        private float currentTemperature;
        private float wetness = 0f;

        // Entorno activo
        private float ambientTemperature = 25f;
        private bool isSheltered = false;
        private bool isNearFire = false;
        private float fireWarmthBonus = 0f;
        private bool isSwimming = false;
        private float lastWettedTime = -999f;

        private bool isDead = false;
        private bool isFainted = false;
        private bool isExhaustedLock = false; // Histéresis: no permite volver a correr hasta recuperar 15 de estamina
        private Coroutine faintCoroutine;
        private float criticalTimer;
        private float faintImmuneUntil;
        private DeathCause lastDeathCause = DeathCause.Unknown;

        // Feedback de daño continuo acumulado
        private float pendingContinuousFeedback;
        private float lastDamageFeedbackTime = -999f;

        // Cache para broadcast reactivo sin recolección de basura
        private float lastBroadcastHealth = -999f;
        private float lastBroadcastHunger = -999f;
        private float lastBroadcastThirst = -999f;
        private float lastBroadcastStamina = -999f;
        private float lastBroadcastTemp = -999f;
        private float lastBroadcastWetness = -999f;
        private const float EventBroadcastEpsilon = 0.08f;

        public float CurrentHealth => currentHealth;
        public float MaxHealth => maxHealth;
        public float CurrentHunger => currentHunger;
        public float MaxHunger => maxHunger;
        public float CurrentThirst => currentThirst;
        public float MaxThirst => maxThirst;
        public float CurrentStamina => currentStamina;
        public float MaxStamina => maxStamina;
        public float CurrentTemperature => currentTemperature;
        public float Wetness => wetness;
        public bool IsDead => isDead;
        public bool IsFainted => isFainted;
        public bool IsSheltered => isSheltered;
        public bool IsNearFire => isNearFire;
        public bool IsSwimming => isSwimming;
        public bool IsExhausted => currentStamina <= 15f;
        /// <summary>Causa del último daño que dejó la vida a 0. Se reinicia al reaparecer o cargar.</summary>
        public DeathCause LastDeathCause => lastDeathCause;

        /// <summary>Estado crítico que, mantenido en el tiempo, provoca un desmayo.</summary>
        public bool IsInCriticalState =>
            currentThirst <= 0f ||
            currentTemperature <= hypothermiaThreshold ||
            currentTemperature >= hyperthermiaThreshold ||
            (currentStamina <= 0.1f && currentHealth < maxHealth * exhaustionCriticalHealthFraction);

        private void OnValidate()
        {
            if (minComfortTemp >= maxComfortTemp)
            {
                Debug.LogWarning("[PlayerStats] minComfortTemp debe ser menor que maxComfortTemp.");
            }
            if (hypothermiaThreshold >= optimalBodyTemp)
            {
                Debug.LogWarning("[PlayerStats] hypothermiaThreshold debe ser inferior a optimalBodyTemp.");
            }
        }

        private void Awake()
        {
            currentHealth = maxHealth;
            currentHunger = maxHunger;
            currentThirst = maxThirst;
            currentStamina = maxStamina;
            currentTemperature = optimalBodyTemp;
            wetness = 0f;
        }

        private void Start()
        {
            BroadcastAllStats(force: true);
        }

        private void Update()
        {
            if (isDead) return;

            // La supervivencia de exploración solo corre en Playing. En combate el desgaste lo aplica BattleManager por rondas;
            // en menú, pausa o muerte no se simula nada. Los cambios hechos desde fuera (combate, carga) se siguen emitiendo.
            if (!GameState.IsPlaying)
            {
                CheckAndBroadcastChanges();
                return;
            }

            UpdatePassiveDecay();
            UpdateThermalRegulation();
            CheckVitalDamage();
            if (isDead) return;
            UpdateFaintRisk();
            CheckVitalWarnings();
            CheckAndBroadcastChanges();

            // Desbloqueo de histéresis de estamina cuando se recupera al menos a 15
            if (isExhaustedLock && currentStamina >= 15f)
            {
                isExhaustedLock = false;
            }
        }

        private void UpdatePassiveDecay()
        {
            currentHunger = Mathf.Max(0f, currentHunger - hungerDecayRate * Time.deltaTime);
            currentThirst = Mathf.Max(0f, currentThirst - thirstDecayRate * Time.deltaTime);

            // Solo se seca cuando nada le está mojando (lluvia o mar en el último medio segundo)
            if (wetness > 0f && Time.time - lastWettedTime > 0.5f)
            {
                float drySpeed = dryingRate * (isNearFire ? fireDryingMultiplier : 1f);
                wetness = Mathf.Max(0f, wetness - drySpeed * Time.deltaTime);
            }
        }

        private void UpdateThermalRegulation()
        {
            float effectiveAmbient = ambientTemperature;

            if (isNearFire)
            {
                effectiveAmbient += fireWarmthBonus;
            }

            if (isSheltered)
            {
                effectiveAmbient = Mathf.Lerp(effectiveAmbient, (minComfortTemp + maxComfortTemp) * 0.5f, 0.55f);
            }

            if (effectiveAmbient >= minComfortTemp && effectiveAmbient <= maxComfortTemp)
            {
                currentTemperature = Mathf.MoveTowards(currentTemperature, optimalBodyTemp, homeostaticRegenRate * Time.deltaTime);
            }
            else if (effectiveAmbient < minComfortTemp)
            {
                // Balance térmico corregido (A2.I.6):
                // En tormenta nocturna (7 °C), sin ropa ni refugio la temperatura tarda entre 5 y 6 minutos en llegar a 32 °C
                float coldDelta = minComfortTemp - effectiveAmbient; // ej: 18 - 7 = 11 °C
                float protection = Mathf.Clamp01(1f - clothingInsulation);

                float targetColdTemp = optimalBodyTemp - (coldDelta * 0.95f * protection);
                targetColdTemp = Mathf.Clamp(targetColdTemp, 24f, optimalBodyTemp);

                float wetMultiplier = 1f + (wetness * 0.8f);
                float rate = thermalExchangeRate * protection * wetMultiplier;

                currentTemperature = Mathf.MoveTowards(currentTemperature, targetColdTemp, rate * Time.deltaTime);
            }
            else
            {
                float heatDelta = effectiveAmbient - maxComfortTemp;
                float targetHeatTemp = optimalBodyTemp + (heatDelta * 0.35f);
                targetHeatTemp = Mathf.Clamp(targetHeatTemp, optimalBodyTemp, 43f);

                currentTemperature = Mathf.MoveTowards(currentTemperature, targetHeatTemp, thermalExchangeRate * Time.deltaTime);
            }
        }

        private void CheckVitalDamage()
        {
            // Daño continuo exacto cada frame, pero con feedback visual limitado (ver TakeDamage)
            if (currentHunger <= 0f) TakeDamage(starvationDamage * Time.deltaTime, DeathCause.Starvation, true);
            if (currentThirst <= 0f && !isDead) TakeDamage(dehydrationDamage * Time.deltaTime, DeathCause.Dehydration, true);
            if (currentTemperature <= hypothermiaThreshold && !isDead) TakeDamage(extremeTempDamage * Time.deltaTime, DeathCause.Hypothermia, true);
            else if (currentTemperature >= hyperthermiaThreshold && !isDead)
            {
                TakeDamage(0.35f * Time.deltaTime, DeathCause.Hyperthermia, true);
                currentThirst = Mathf.Max(0f, currentThirst - 0.5f * Time.deltaTime);
            }
        }

        /// <summary>
        /// Desmayo = estado crítico mantenido (no simple agotamiento). Tiene protección tras despertar
        /// y no ocurre nadando (ahí manda PlayerSwimming).
        /// </summary>
        private void UpdateFaintRisk()
        {
            if (isFainted || isSwimming) return;

            if (IsInCriticalState) criticalTimer += Time.deltaTime;
            else criticalTimer = Mathf.Max(0f, criticalTimer - Time.deltaTime * 0.5f);

            if (criticalTimer >= faintAfterCriticalSeconds && Time.time >= faintImmuneUntil)
            {
                criticalTimer = 0f;
                GameEvents.TriggerNotificationMessage("Tu cuerpo no aguanta más... Te desmayas.");
                TriggerFaint();
            }
        }

        private float lastHungerWarning = -999f;
        private float lastThirstWarning = -999f;
        private float lastColdWarning = -999f;
        private float lastHeatWarning = -999f;
        private float lastExhaustionWarning = -999f;
        private const float WarningCooldown = 15f;

        private void CheckVitalWarnings()
        {
            float time = Time.time;
            if (currentHunger <= 5f && time - lastHungerWarning > WarningCooldown)
            {
                lastHungerWarning = time;
                GameEvents.TriggerNotificationMessage("¡Tienes hambre extrema!");
            }
            if (currentThirst <= 5f && time - lastThirstWarning > WarningCooldown)
            {
                lastThirstWarning = time;
                GameEvents.TriggerNotificationMessage("¡Estás deshidratado!");
            }
            if (currentTemperature <= hypothermiaThreshold && time - lastColdWarning > WarningCooldown)
            {
                lastColdWarning = time;
                GameEvents.TriggerNotificationMessage("¡Sufres hipotermia!");
            }
            else if (currentTemperature >= hyperthermiaThreshold && time - lastHeatWarning > WarningCooldown)
            {
                lastHeatWarning = time;
                GameEvents.TriggerNotificationMessage("¡Sufres golpe de calor!");
            }
            if (isExhaustedLock && time - lastExhaustionWarning > WarningCooldown)
            {
                lastExhaustionWarning = time;
                GameEvents.TriggerNotificationMessage("¡Estás completamente agotado!");
            }
        }

        /// <summary>Daño directo de causa desconocida (compatibilidad con llamadas existentes).</summary>
        public void TakeDamage(float amount)
        {
            TakeDamage(amount, DeathCause.Unknown, false);
        }

        /// <summary>
        /// Aplica daño. continuous = daño aplicado poco a poco (cada frame o en ticks frecuentes): la vida baja con precisión
        /// pero el evento OnPlayerDamaged (destello rojo) solo se dispara una vez por continuousFeedbackInterval con el total acumulado.
        /// </summary>
        public void TakeDamage(float amount, DeathCause cause, bool continuous = false)
        {
            if (isDead || float.IsNaN(amount) || amount <= 0f) return;

            currentHealth = Mathf.Clamp(currentHealth - amount, 0f, maxHealth);

            if (continuous)
            {
                pendingContinuousFeedback += amount;
                if (Time.unscaledTime - lastDamageFeedbackTime >= continuousFeedbackInterval)
                {
                    lastDamageFeedbackTime = Time.unscaledTime;
                    GameEvents.TriggerPlayerDamaged(pendingContinuousFeedback);
                    pendingContinuousFeedback = 0f;
                }
            }
            else
            {
                lastDamageFeedbackTime = Time.unscaledTime;
                GameEvents.TriggerPlayerDamaged(amount);
            }

            if (currentHealth <= 0f)
            {
                lastDeathCause = cause;
                Die();
            }
        }

        public void Heal(float amount)
        {
            if (isDead) return;
            currentHealth = Mathf.Clamp(currentHealth + amount, 0f, maxHealth);
        }

        public void ModifyHunger(float amount)
        {
            if (isDead) return;
            currentHunger = Mathf.Clamp(currentHunger + amount, 0f, maxHunger);
        }

        public void ModifyThirst(float amount)
        {
            if (isDead) return;
            currentThirst = Mathf.Clamp(currentThirst + amount, 0f, maxThirst);
        }

        public void ModifyStamina(float amount)
        {
            if (isDead) return;
            currentStamina = Mathf.Clamp(currentStamina + amount, 0f, maxStamina);
            if (currentStamina <= 0f) isExhaustedLock = true;
        }

        public void ModifyTemperature(float amount)
        {
            if (isDead) return;
            currentTemperature = Mathf.Clamp(currentTemperature + amount, 20f, 44f);
        }

        /// <summary>
        /// Bug A2.I.1 resuelto: Permite correr hasta 0 de estamina e impone bloqueo de histéresis.
        /// </summary>
        public bool ConsumeSprintStamina(float deltaTime)
        {
            if (isDead || isFainted) return false;

            float cost = sprintStaminaCost * deltaTime;

            if (currentStamina > cost)
            {
                currentStamina -= cost;
                currentThirst = Mathf.Max(0f, currentThirst - (thirstDecayRate * 0.15f) * deltaTime);
                return true;
            }
            else
            {
                currentStamina = 0f;
                isExhaustedLock = true;
                return false;
            }
        }

        public bool CanSprint()
        {
            // Histéresis: si se agotó totalmente, se desbloquea al recuperar 8 de estamina
            if (isExhaustedLock)
            {
                if (currentStamina >= 8f) isExhaustedLock = false;
                else return false;
            }

            return currentStamina > 0.1f && !isFainted && !isDead && !isSwimming;
        }

        public void RegenerateStamina(float deltaTime)
        {
            // Nadando no se recupera estamina de la forma normal
            if (isDead || isFainted || isSwimming) return;

            if (currentStamina < maxStamina)
            {
                currentStamina = Mathf.Min(maxStamina, currentStamina + staminaRegenRate * deltaTime);
            }
        }

        public void SetAmbientTemperature(float newAmbientTemp) => ambientTemperature = newAmbientTemp;
        public void SetWetness(float value) => wetness = Mathf.Clamp01(value);

        /// <summary>Humedad genérica (compatibilidad). Un refugio la bloquea.</summary>
        public void AddWetness(float amount)
        {
            if (isSheltered || amount <= 0f) return;
            wetness = Mathf.Clamp01(wetness + amount);
            lastWettedTime = Time.time;
        }

        /// <summary>Lluvia o tormenta durante deltaTime. Ritmos configurados aquí, no en WeatherSystem.</summary>
        public void AddRainWetness(bool storm, float deltaTime)
        {
            AddWetness((storm ? stormWetnessPerSecond : rainWetnessPerSecond) * deltaTime);
        }

        /// <summary>Entrar en el mar: empapado casi al instante (el refugio no aplica).</summary>
        public void Soak()
        {
            wetness = 1f;
            lastWettedTime = Time.time;
        }

        /// <summary>Lo llama PlayerSwimming al entrar/salir del agua profunda.</summary>
        public void SetSwimming(bool swimming) => isSwimming = swimming;

        public void SetSheltered(bool sheltered) => isSheltered = sheltered;
        public void SetNearFire(bool nearFire, float warmth = 20f)
        {
            isNearFire = nearFire;
            fireWarmthBonus = nearFire ? warmth : 0f;
        }
        public void SetClothingInsulation(float insulation) => clothingInsulation = Mathf.Clamp01(insulation);

        private void TriggerFaint()
        {
            if (isFainted || isDead) return;

            if (faintCoroutine != null) StopCoroutine(faintCoroutine);
            faintCoroutine = StartCoroutine(FaintRoutine());
        }

        private IEnumerator FaintRoutine()
        {
            isFainted = true;
            GameEvents.TriggerPlayerFaint(true);

            yield return new WaitForSeconds(faintDurationSeconds);

            currentStamina = Mathf.Max(currentStamina, maxStamina * 0.25f);
            isFainted = false;
            isExhaustedLock = false;
            criticalTimer = 0f;
            faintImmuneUntil = Time.time + faintImmunitySeconds;
            faintCoroutine = null;
            GameEvents.TriggerPlayerFaint(false);
            BroadcastAllStats(force: true);
        }

        private void Die()
        {
            isDead = true;
            isFainted = false;
            if (faintCoroutine != null)
            {
                StopCoroutine(faintCoroutine);
                faintCoroutine = null;
            }

            BroadcastAllStats(force: true);
            // Muerte en exploración o en combate: directamente a Dead (nunca pasa por Playing)
            GameState.Set(GameScreen.Dead);
            GameEvents.TriggerPlayerDeath();
            Debug.Log($"[PlayerStats] El jugador ha muerto. Causa: {lastDeathCause}.");
        }

        public void Respawn()
        {
            isDead = false;
            isFainted = false;
            isExhaustedLock = false;
            isSwimming = false;
            criticalTimer = 0f;
            faintImmuneUntil = Time.time + faintImmunitySeconds;
            lastDeathCause = DeathCause.Unknown;
            pendingContinuousFeedback = 0f;

            if (faintCoroutine != null)
            {
                StopCoroutine(faintCoroutine);
                faintCoroutine = null;
            }

            currentHealth = maxHealth;
            currentHunger = maxHunger * 0.85f;
            currentThirst = maxThirst * 0.85f;
            currentStamina = maxStamina * 0.85f;
            currentTemperature = optimalBodyTemp;
            wetness = 0f;

            BroadcastAllStats(force: true);
            GameEvents.TriggerPlayerRespawn();
            GameEvents.TriggerPlayerFaint(false);
        }

        /// <summary>
        /// Bug A2.I.2 resuelto: Restaura estadísticas correctamente sin sobreescribir desmayo con respawn.
        /// Los valores ya llegan validados por SaveDataValidator; aquí solo se acotan a los máximos reales.
        /// </summary>
        public void LoadStats(float health, float hunger, float thirst, float stamina, float temp, float savedWetness, bool fainted)
        {
            currentHealth = Mathf.Clamp(health, 0f, maxHealth);
            currentHunger = Mathf.Clamp(hunger, 0f, maxHunger);
            currentThirst = Mathf.Clamp(thirst, 0f, maxThirst);
            currentStamina = Mathf.Clamp(stamina, 0f, maxStamina);
            currentTemperature = Mathf.Clamp(temp, 20f, 44f);
            wetness = Mathf.Clamp01(savedWetness);
            isDead = currentHealth <= 0;
            lastDeathCause = DeathCause.Unknown;
            criticalTimer = 0f;
            pendingContinuousFeedback = 0f;
            isSwimming = false; // PlayerSwimming lo vuelve a detectar en su siguiente Update

            if (faintCoroutine != null)
            {
                StopCoroutine(faintCoroutine);
                faintCoroutine = null;
            }

            // Poner isFainted = false antes de evaluar TriggerFaint (Bug I.2)
            isFainted = false;

            // Limpia visuales de muerte/desmayo previos ANTES de re-aplicar el desmayo guardado
            if (!isDead) GameEvents.TriggerPlayerRespawn();

            if (!isDead && fainted)
            {
                TriggerFaint();
            }
            else
            {
                isFainted = false;
                GameEvents.TriggerPlayerFaint(false);
            }

            BroadcastAllStats(force: true);
        }

        private void CheckAndBroadcastChanges()
        {
            if (Mathf.Abs(currentHealth - lastBroadcastHealth) >= EventBroadcastEpsilon || currentHealth <= 0f || currentHealth >= maxHealth)
            {
                if (lastBroadcastHealth != currentHealth)
                {
                    lastBroadcastHealth = currentHealth;
                    GameEvents.TriggerHealthChanged(currentHealth, maxHealth);
                }
            }

            if (Mathf.Abs(currentHunger - lastBroadcastHunger) >= EventBroadcastEpsilon || currentHunger <= 0f || currentHunger >= maxHunger)
            {
                if (lastBroadcastHunger != currentHunger)
                {
                    lastBroadcastHunger = currentHunger;
                    GameEvents.TriggerHungerChanged(currentHunger, maxHunger);
                }
            }

            if (Mathf.Abs(currentThirst - lastBroadcastThirst) >= EventBroadcastEpsilon || currentThirst <= 0f || currentThirst >= maxThirst)
            {
                if (lastBroadcastThirst != currentThirst)
                {
                    lastBroadcastThirst = currentThirst;
                    GameEvents.TriggerThirstChanged(currentThirst, maxThirst);
                }
            }

            if (Mathf.Abs(currentStamina - lastBroadcastStamina) >= EventBroadcastEpsilon || currentStamina <= 0f || currentStamina >= maxStamina)
            {
                if (lastBroadcastStamina != currentStamina)
                {
                    lastBroadcastStamina = currentStamina;
                    GameEvents.TriggerStaminaChanged(currentStamina, maxStamina);
                }
            }

            if (Mathf.Abs(currentTemperature - lastBroadcastTemp) >= 0.05f)
            {
                lastBroadcastTemp = currentTemperature;
                GameEvents.TriggerTemperatureChanged(currentTemperature);
            }

            if (Mathf.Abs(wetness - lastBroadcastWetness) >= 0.04f)
            {
                lastBroadcastWetness = wetness;
                GameEvents.TriggerWetnessChanged(wetness);
            }
        }

        public void BroadcastAllStats(bool force = false)
        {
            if (force)
            {
                lastBroadcastHealth = currentHealth;
                lastBroadcastHunger = currentHunger;
                lastBroadcastThirst = currentThirst;
                lastBroadcastStamina = currentStamina;
                lastBroadcastTemp = currentTemperature;
                lastBroadcastWetness = wetness;

                GameEvents.TriggerHealthChanged(currentHealth, maxHealth);
                GameEvents.TriggerHungerChanged(currentHunger, maxHunger);
                GameEvents.TriggerThirstChanged(currentThirst, maxThirst);
                GameEvents.TriggerStaminaChanged(currentStamina, maxStamina);
                GameEvents.TriggerTemperatureChanged(currentTemperature);
                GameEvents.TriggerWetnessChanged(wetness);
            }
            else
            {
                CheckAndBroadcastChanges();
            }
        }
    }
}
