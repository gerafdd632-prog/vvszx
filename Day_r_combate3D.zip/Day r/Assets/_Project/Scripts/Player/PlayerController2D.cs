﻿using UnityEngine;
using PirateSurvival.Bootstrap;
using PirateSurvival.Core;
using PirateSurvival.Environment;
using PirateSurvival.Inventory;

namespace PirateSurvival.Player
{
    /// <summary>
    /// Controlador del jugador 2D top-down para Unity 6.
    /// Utiliza GameInput (compatible con New Input System y Legacy Input), Rigidbody2D,
    /// y protege la entrada virtual para que no sea pisada por el teclado (A2.I.5).
    /// Se detiene físicamente al salir del estado Playing (combate, pausa, menú) y nada más lento en el mar.
    /// </summary>
    [RequireComponent(typeof(Rigidbody2D))]
    [RequireComponent(typeof(PlayerStats))]
    public class PlayerController2D : MonoBehaviour
    {
        [Header("Velocidades de Movimiento 2D")]
        [Tooltip("Velocidad normal de caminata")]
        [SerializeField] private float walkSpeed = 4.8f;
        [Tooltip("Velocidad de esprint")]
        [SerializeField] private float sprintSpeed = 8.4f;
        [Tooltip("Aceleración del movimiento")]
        [SerializeField] private float acceleration = 65f;
        [Tooltip("Desaceleración al soltar controles")]
        [SerializeField] private float deceleration = 55f;

        [Header("Orientación 2D")]
        [Tooltip("Si está activo, rota físicamente el transform (estilo barco/cenital puro).")]
        [SerializeField] private bool rotateTransform = false;
        [Tooltip("Si está activo y se presiona botón derecho del ratón, orienta al personaje hacia el cursor")]
        [SerializeField] private bool aimTowardsMouse = true;
        [Tooltip("Velocidad de giro del transform")]
        [SerializeField] private float rotationSpeed = 720f;

        private Rigidbody2D rb;
        private Collider2D bodyCollider;
        private readonly System.Collections.Generic.List<Collider2D> overlapBuffer = new System.Collections.Generic.List<Collider2D>(8);
        private ContactFilter2D solidFilter;
        private float stuckTimer;
        private Vector2 lastFixedPosition;
        private PlayerStats playerStats;
        private PlayerSwimming swimming;
        private Camera mainCamera;

        private Vector2 moveInput;
        private Vector2 currentVelocity;
        private Vector2 lastNonZeroDirection = Vector2.down;
        private bool isSprinting;
        private bool isInventoryOpen = false;

        // Soporte de joystick virtual (A2.I.5)
        private Vector2 virtualMoveInput = Vector2.zero;
        private bool hasVirtualInput = false;

        public Vector2 MoveInput => moveInput;
        public Vector2 FaceDirection => lastNonZeroDirection;
        public float CurrentSpeed => currentVelocity.magnitude;
        public float SpeedRatio => currentVelocity.magnitude / sprintSpeed;
        public bool IsSprinting => isSprinting;
        public bool IsInventoryOpen => isInventoryOpen;

        private void OnValidate()
        {
            if (walkSpeed <= 0f) walkSpeed = 4.8f;
            if (sprintSpeed <= walkSpeed) sprintSpeed = walkSpeed * 1.75f;
        }

        private void Awake()
        {
            rb = GetComponent<Rigidbody2D>();
            playerStats = GetComponent<PlayerStats>();
            swimming = GetComponent<PlayerSwimming>();

            rb.gravityScale = 0f;
            rb.constraints = RigidbodyConstraints2D.FreezeRotation;
            rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
            rb.interpolation = RigidbodyInterpolation2D.Interpolate;

            mainCamera = Camera.main;
            bodyCollider = GetComponent<Collider2D>();
            solidFilter = new ContactFilter2D { useTriggers = false };
        }

        private void OnEnable()
        {
            GameEvents.OnInventoryToggle += HandleInventoryToggle;
            GameState.OnChanged += HandleGameStateChanged;
        }

        private void OnDisable()
        {
            GameEvents.OnInventoryToggle -= HandleInventoryToggle;
            GameState.OnChanged -= HandleGameStateChanged;
        }

        private GameObject shadowObj;

        private void Start()
        {
            // Por si PlayerSwimming se añadió después que este componente
            if (swimming == null) swimming = GetComponent<PlayerSwimming>();
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            AttachShadow();
        }

        private void AttachShadow()
        {
            if (shadowObj != null) return;
            shadowObj = new GameObject("PlayerDropShadow");
            shadowObj.transform.SetParent(transform, false);
            shadowObj.transform.localPosition = new Vector3(0f, -0.22f, 0f);
            SpriteRenderer ssr = shadowObj.AddComponent<SpriteRenderer>();
            ssr.sprite = WorldArt.DropShadow();
            ssr.sortingOrder = -4400;
        }

        private void Update()
        {
            if (shadowObj != null && swimming != null)
            {
                shadowObj.SetActive(!swimming.IsSwimming);
            }

            if (!GameState.IsPlaying || isInventoryOpen || playerStats.IsDead || playerStats.IsFainted)
            {
                moveInput = Vector2.zero;
                isSprinting = false;

                if (!playerStats.IsDead && !playerStats.IsFainted && GameState.IsPlaying)
                {
                    playerStats.RegenerateStamina(Time.deltaTime);
                }
                return;
            }

            ReadInput();
            HandleFacing();
            HandleHotbarInput();
        }

        private void HandleHotbarInput()
        {
            if (GameState.Current != GameScreen.Playing) return;
            int hotbar = GameInput.GetHotbarNumberPressed();
            if (hotbar > 0 && InventoryManager.Instance != null)
            {
                int slotIndex = hotbar - 1;
                if (slotIndex >= 0 && slotIndex < InventoryManager.Instance.Slots.Count)
                {
                    var slot = InventoryManager.Instance.Slots[slotIndex];
                    if (!slot.IsEmpty)
                    {
                        InventoryManager.Instance.UseItem(slotIndex);
                        if (AudioManager.Instance != null) AudioManager.Instance.PlayUiClick();
                    }
                }
            }
        }

        private void FixedUpdate()
        {
            if (!GameState.IsPlaying)
            {
                if (rb != null) rb.linearVelocity = Vector2.zero;
                return;
            }
            ApplyMovement();
            ResolveOverlaps();
        }

        /// <summary>
        /// Anti-atascos: si el cuerpo ha quedado metido dentro de un collider sólido (aparecer encima de un objeto,
        /// cargar partida, un empujón), se le saca por el camino más corto. Si además lleva un rato pulsando
        /// una dirección sin avanzar, se recoloca en la última posición segura cercana.
        /// </summary>
        private void ResolveOverlaps()
        {
            if (bodyCollider == null || !bodyCollider.enabled) return;
            int count = bodyCollider.Overlap(solidFilter, overlapBuffer);
            for (int i = 0; i < count; i++)
            {
                Collider2D other = overlapBuffer[i];
                if (other == null || other.isTrigger || other.attachedRigidbody == rb) continue;
                ColliderDistance2D d = bodyCollider.Distance(other);
                if (d.isValid && d.isOverlapped && d.distance < -0.005f)
                {
                    // normal apunta de B (el otro) a A (el jugador): normal * distance movería a B.
                    // Para sacar a A se aplica el opuesto (con distance < 0 lo aleja de B).
                    rb.position -= d.normal * d.distance;
                }
            }

            bool pushing = moveInput.sqrMagnitude > 0.25f && !GameInput.GameplayBlocked && !GameInput.ModalBlocked;
            // Movimiento real desde el paso anterior (la velocidad pedida no sirve: es la que se intenta, no la que se consigue)
            bool barelyMoving = (rb.position - lastFixedPosition).sqrMagnitude < 0.0001f;
            lastFixedPosition = rb.position;
            stuckTimer = pushing && barelyMoving && count > 0 ? stuckTimer + Time.fixedDeltaTime : 0f;
            if (stuckTimer > 1.2f)
            {
                stuckTimer = 0f;
                if (SafePositionTracker.TryFindNearestSafePosition(rb.position, rb, 2.5f, 0.25f, out Vector2 free))
                {
                    rb.position = free;
                }
            }
        }

        private void HandleInventoryToggle(bool open)
        {
            isInventoryOpen = open;
            if (isInventoryOpen)
            {
                moveInput = Vector2.zero;
                isSprinting = false;
            }
        }

        /// <summary>
        /// Al entrar en combate, pausa o menú se congela la física (timeScale 0), pero la velocidad del Rigidbody2D se conservaría
        /// y al volver el jugador seguiría deslizándose. Se para en seco.
        /// </summary>
        private void HandleGameStateChanged(GameScreen screen)
        {
            if (screen == GameScreen.Playing) return;
            StopImmediately();
        }

        public void StopImmediately()
        {
            moveInput = Vector2.zero;
            virtualMoveInput = Vector2.zero;
            hasVirtualInput = false;
            isSprinting = false;
            currentVelocity = Vector2.zero;
            if (rb != null) rb.linearVelocity = Vector2.zero;
        }

        private void ReadInput()
        {
            // Bug A2.I.5 resuelto: Si hay un joystick virtual activo, no es pisado por el teclado
            if (hasVirtualInput && virtualMoveInput.sqrMagnitude > 0.01f)
            {
                moveInput = virtualMoveInput;
            }
            else
            {
                moveInput = GameInput.GetMoveVector();
            }

            if (moveInput.sqrMagnitude > 0.01f)
            {
                lastNonZeroDirection = moveInput.normalized;
            }

            // Comprobar esprint mediante GameInput (no se puede esprintar nadando)
            bool wantsToSprint = GameInput.IsSprintHeld() && moveInput.sqrMagnitude > 0.05f && (swimming == null || swimming.CanSprint);

            if (wantsToSprint && playerStats.CanSprint())
            {
                isSprinting = playerStats.ConsumeSprintStamina(Time.deltaTime);
            }
            else
            {
                isSprinting = false;
                playerStats.RegenerateStamina(Time.deltaTime);
            }
        }

        private void HandleFacing()
        {
            bool isAiming = aimTowardsMouse && GameInput.IsAimHeld();

            if (isAiming)
            {
                if (mainCamera == null) mainCamera = Camera.main;
                if (mainCamera != null)
                {
                    Vector2 mouseWorld = GameInput.GetMouseWorldPosition(mainCamera);
                    Vector2 lookDir = (mouseWorld - rb.position).normalized;
                    if (lookDir.sqrMagnitude > 0.01f)
                    {
                        lastNonZeroDirection = lookDir;
                    }
                }
            }

            if (rotateTransform && lastNonZeroDirection.sqrMagnitude > 0.01f)
            {
                float targetAngle = Mathf.Atan2(lastNonZeroDirection.y, lastNonZeroDirection.x) * Mathf.Rad2Deg - 90f;
                Quaternion targetRot = Quaternion.Euler(0f, 0f, targetAngle);
                transform.rotation = Quaternion.RotateTowards(transform.rotation, targetRot, rotationSpeed * Time.deltaTime);
            }
        }

        private void ApplyMovement()
        {
            if (playerStats.IsDead || playerStats.IsFainted || GameInput.GameplayBlocked || GameInput.ModalBlocked)
            {
                rb.linearVelocity = Vector2.zero;
                currentVelocity = Vector2.zero;
                return;
            }

            float targetSpeed = isSprinting ? sprintSpeed : walkSpeed;
            if (swimming != null) targetSpeed *= swimming.SpeedMultiplier;
            Vector2 targetVelocity = moveInput * targetSpeed;

            float accelRate = (moveInput.sqrMagnitude > 0.01f) ? acceleration : deceleration;
            currentVelocity = Vector2.MoveTowards(currentVelocity, targetVelocity, accelRate * Time.fixedDeltaTime);

            rb.linearVelocity = currentVelocity;
        }

        /// <summary>
        /// Bug A2.I.5: Entrada virtual protegida para controles táctiles o pads virtuales.
        /// </summary>
        public void SetVirtualMoveInput(Vector2 virtualInput)
        {
            virtualMoveInput = Vector2.ClampMagnitude(virtualInput, 1f);
            hasVirtualInput = virtualMoveInput.sqrMagnitude > 0.01f;

            if (hasVirtualInput)
            {
                lastNonZeroDirection = virtualMoveInput.normalized;
            }
        }
    }
}
