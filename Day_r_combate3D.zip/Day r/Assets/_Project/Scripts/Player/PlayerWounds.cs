﻿using UnityEngine;
using PirateSurvival.Core;

namespace PirateSurvival.Player
{
    /// <summary>
    /// Heridas que sobreviven al combate (sangrado, veneno). Siguen quitando vida durante la exploración
    /// hasta que se agotan o se curan con vendas/medicinas.
    /// </summary>
    [RequireComponent(typeof(PlayerStats))]
    public class PlayerWounds : MonoBehaviour
    {
        [SerializeField] private float bleedDamagePerSecond = 0.12f;
        [SerializeField] private float poisonDamagePerSecond = 0.08f;
        [Tooltip("Inconsciente, el tiempo sigue pasando y las heridas también, pero más despacio")]
        [SerializeField] private float faintedBleedingMultiplier = 0.5f;
        [SerializeField] private float faintedPoisonMultiplier = 0.5f;

        private float bleedSeconds;
        private float poisonSeconds;
        private PlayerStats stats;

        public bool IsBleeding => bleedSeconds > 0f;
        public bool IsPoisoned => poisonSeconds > 0f;
        public float BleedSeconds => bleedSeconds;
        public float PoisonSeconds => poisonSeconds;

        private void Awake() { stats = GetComponent<PlayerStats>(); }

        private void OnEnable() { GameEvents.OnPlayerFaint += HandleFaint; }
        private void OnDisable() { GameEvents.OnPlayerFaint -= HandleFaint; }

        /// <summary>Un solo aviso al perder el conocimiento con heridas abiertas.</summary>
        private void HandleFaint(bool fainted)
        {
            if (fainted && (IsBleeding || IsPoisoned))
                GameEvents.TriggerNotificationMessage("Sigues herido mientras estás inconsciente.");
        }

        private void Update()
        {
            // Solo en exploración: en combate manda BattleManager y muerto/pausa/menú no corre el tiempo
            if (stats.IsDead || !GameState.IsPlaying || Time.deltaTime <= 0f) return;
            bool fainted = stats.IsFainted;
            if (bleedSeconds > 0f)
            {
                bleedSeconds -= Time.deltaTime;
                float mult = fainted ? faintedBleedingMultiplier : 1f;
                stats.TakeDamage(bleedDamagePerSecond * mult * Time.deltaTime, DeathCause.Bleeding, true);
            }
            if (poisonSeconds > 0f && !stats.IsDead)
            {
                poisonSeconds -= Time.deltaTime;
                float mult = fainted ? faintedPoisonMultiplier : 1f;
                stats.TakeDamage(poisonDamagePerSecond * mult * Time.deltaTime, DeathCause.Poison, true);
                stats.ModifyStamina(-0.5f * mult * Time.deltaTime);
            }
        }

        public void AddBleeding(float seconds)
        {
            bleedSeconds = Mathf.Max(bleedSeconds, seconds);
            GameEvents.TriggerNotificationMessage("Sigues sangrando. Usa una venda.");
        }

        public void AddPoison(float seconds)
        {
            poisonSeconds = Mathf.Max(poisonSeconds, seconds);
            GameEvents.TriggerNotificationMessage("El veneno sigue en tu cuerpo.");
        }

        public void CureBleeding() => bleedSeconds = 0f;
        public void CurePoison() => poisonSeconds = 0f;

        public void Load(float bleed, float poison)
        {
            bleedSeconds = Mathf.Max(0f, bleed);
            poisonSeconds = Mathf.Max(0f, poison);
        }
    }
}
