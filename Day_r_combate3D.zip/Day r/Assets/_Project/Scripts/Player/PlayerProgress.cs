﻿using System.Collections.Generic;
using UnityEngine;

namespace PirateSurvival.Player
{
    /// <summary>
    /// Progreso persistente del jugador: experiencia y enemigos únicos/jefes ya derrotados.
    /// </summary>
    public class PlayerProgress : MonoBehaviour
    {
        [SerializeField] private int experience;
        [Tooltip("Recompensa sobre la cabeza del JUGADOR, en berries. Solo sube por actos que le hagan más buscado (atacar a la Marina, civiles...).")]
        [SerializeField] private int bounty;
        private readonly HashSet<string> defeatedEncounters = new HashSet<string>();
        private readonly HashSet<string> storyFlags = new HashSet<string>();

        /// <summary>Se dispara al añadir un flag de historia nuevo.</summary>
        public event System.Action<string> OnFlagAdded;

        public bool HasFlag(string flag) => !string.IsNullOrEmpty(flag) && storyFlags.Contains(flag);
        public List<string> FlagList => new List<string>(storyFlags);

        /// <summary>Marca un flag de historia. Devuelve true si es nuevo.</summary>
        public bool SetFlag(string flag)
        {
            if (string.IsNullOrEmpty(flag) || !storyFlags.Add(flag)) return false;
            OnFlagAdded?.Invoke(flag);
            return true;
        }

        public void LoadFlags(List<string> saved)
        {
            storyFlags.Clear();
            if (saved == null) return;
            foreach (string f in saved)
            {
                if (!string.IsNullOrEmpty(f)) storyFlags.Add(f);
            }
        }

        public int Experience => experience;
        public int Bounty => bounty;
        /// <summary>Sube la recompensa sobre la cabeza del jugador. Derrotar piratas corrientes NO debe llamarla.</summary>
        public void AddPlayerBounty(int amount) => bounty += Mathf.Max(0, amount);
        public List<string> DefeatedList => new List<string>(defeatedEncounters);

        public void AddExperience(int amount) => experience += Mathf.Max(0, amount);
        public bool HasDefeated(string encounterId) => defeatedEncounters.Contains(encounterId);
        public void MarkDefeated(string encounterId) => defeatedEncounters.Add(encounterId);

        public void Load(int savedExperience, List<string> savedDefeated, int savedBounty = 0)
        {
            experience = Mathf.Max(0, savedExperience);
            bounty = Mathf.Max(0, savedBounty);
            defeatedEncounters.Clear();
            if (savedDefeated != null)
            {
                foreach (string id in savedDefeated) defeatedEncounters.Add(id);
            }
        }
    }
}
