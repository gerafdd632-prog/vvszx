﻿using UnityEngine;
using PirateSurvival.Core;

namespace PirateSurvival.Player
{
    /// <summary>
    /// Fruta del Diablo del jugador. Solo se puede tener una. Da habilidades en combate (ver AbilityLibrary)
    /// y te convierte en un ancla en el mar: el agua te ahoga mucho más rápido.
    /// </summary>
    public class DevilFruitManager : MonoBehaviour
    {
        public const string Elastic = "elastica";

        [SerializeField] private string fruitId = "";

        public string FruitId => fruitId;
        public bool HasFruit => !string.IsNullOrEmpty(fruitId);
        /// <summary>Cuerpo de goma: resiste golpes contundentes y balas.</summary>
        public bool IsRubber => fruitId == Elastic;

        public static string DisplayName(string id) => id == Elastic ? "Fruta Elástica" : id;

        public void Eat(string id)
        {
            if (HasFruit || string.IsNullOrEmpty(id)) return;
            fruitId = id;
            GameEvents.TriggerNotificationMessage($"Has comido la {DisplayName(id)}. Tu cuerpo cambia... y el mar ya no te perdona.");
        }

        public void Load(string savedId) => fruitId = savedId ?? "";
    }
}
