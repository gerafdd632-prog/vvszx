﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace PirateSurvival.Core
{
    /// <summary>
    /// Caché de sprites generados por código. Evita crear Texture2D/Sprite idénticos cada vez que se reconstruye el mundo
    /// (volver al menú, nueva partida). Las entradas destruidas (p. ej. al salir del Play Mode) se regeneran solas.
    /// </summary>
    public static class RuntimeSpriteCache
    {
        private static readonly Dictionary<string, Sprite> Sprites = new Dictionary<string, Sprite>();

        public static int Count => Sprites.Count;

        public static Sprite Get(string key, Func<Sprite> create)
        {
            if (Sprites.TryGetValue(key, out Sprite cached) && cached != null) return cached;
            Sprite created = create();
            Sprites[key] = created;
            return created;
        }

        public static void Set(string key, Sprite sprite)
        {
            Sprites[key] = sprite;
        }

        public static void Remove(string key)
        {
            Sprites.Remove(key);
        }

        /// <summary>
        /// Libera todas las texturas cacheadas. Solo debe llamarse cuando nada las usa (p. ej. al cerrar el juego o al cambiar de escena completa);
        /// la reconstrucción normal del mundo NO lo necesita porque reutiliza la caché.
        /// </summary>
        public static void Clear()
        {
            foreach (Sprite s in Sprites.Values)
            {
                if (s == null) continue;
                if (s.texture != null) UnityEngine.Object.Destroy(s.texture);
                UnityEngine.Object.Destroy(s);
            }
            Sprites.Clear();
        }
    }
}
