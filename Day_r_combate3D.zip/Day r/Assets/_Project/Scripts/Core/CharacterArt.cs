﻿using UnityEngine;

namespace PirateSurvival.Core
{
    public enum HatStyle { None, Straw, Bandana, MarineCap, Tricorn, Headscarf, Goggles, Fedora }
    public enum ShirtStyle { Plain, OpenVest, Striped, Coat, Dress, ModernJacket, Hawaiian }
    public enum HeldItem { None, Sword, Pistol, FishingRod, Basket, Hammer }

    /// <summary>Aspecto de un personaje (jugador, aldeanos, piratas, marines) con estilo One Piece.</summary>
    [System.Serializable]
    public struct CharacterLook
    {
        public Color skin, hair, shirt, pants, shoes, hatColor, accent;
        public HatStyle hat;
        public ShirtStyle shirtStyle;
        public HeldItem held;
        public bool beard, eyePatch, shortPants, longHair;
        public bool sunglasses;
        public bool cape;

        public string Key()
        {
            return $"{ColorUtility.ToHtmlStringRGB(skin)}{ColorUtility.ToHtmlStringRGB(hair)}{ColorUtility.ToHtmlStringRGB(shirt)}" +
                   $"{ColorUtility.ToHtmlStringRGB(pants)}{ColorUtility.ToHtmlStringRGB(hatColor)}{ColorUtility.ToHtmlStringRGB(accent)}" +
                   $"{(int)hat}{(int)shirtStyle}{(int)held}{(beard ? 1 : 0)}{(eyePatch ? 1 : 0)}{(shortPants ? 1 : 0)}{(longHair ? 1 : 0)}" +
                   $"{(sunglasses ? 1 : 0)}{(cape ? 1 : 0)}";
        }

        public string ToJson() => JsonUtility.ToJson(this);

        public static CharacterLook FromJson(string json)
        {
            if (string.IsNullOrEmpty(json)) return CharacterArt.Castaway();
            try { return JsonUtility.FromJson<CharacterLook>(json); }
            catch { return CharacterArt.Castaway(); }
        }
    }

    /// <summary>
    /// Personajes pixel art 32x32 con sombreado, contorno y sombra en el suelo.
    /// Incorpora atuendos modernos inspirados en los Color Spreads de One Piece (gafas de sol, chaquetas abiertas,
    /// capas sobre los hombros, camisas hawaianas y gorras/gafas tácticas).
    /// </summary>
    public static class CharacterArt
    {
        public static readonly Color SkinLight = new Color(0.98f, 0.82f, 0.68f);
        public static readonly Color SkinTan = new Color(0.86f, 0.64f, 0.48f);
        public static readonly Color SkinDark = new Color(0.55f, 0.37f, 0.25f);
        public static readonly Color SkinDeep = new Color(0.38f, 0.24f, 0.16f);
        private static readonly Color Outline = new Color(0.08f, 0.06f, 0.07f);

        public static string PlayerName = "Náufrago";
        public static CharacterLook CurrentPlayerLook = Castaway();

        public static readonly (string name, Color color)[] SkinOptions =
        {
            ("Clara", SkinLight),
            ("Bronceada", SkinTan),
            ("Morena", SkinDark),
            ("Oscura", SkinDeep)
        };

        public static readonly (string name, Color color)[] HairColorOptions =
        {
            ("Negro Azabache", new Color(0.12f, 0.12f, 0.14f)),
            ("Castaño Pirata", new Color(0.35f, 0.22f, 0.14f)),
            ("Rubio Dorado", new Color(0.95f, 0.82f, 0.35f)),
            ("Verde Cazador", new Color(0.2f, 0.65f, 0.3f)),
            ("Rojo Fuego", new Color(0.85f, 0.2f, 0.2f)),
            ("Azul Marino", new Color(0.2f, 0.45f, 0.85f)),
            ("Naranja Zorro", new Color(0.95f, 0.5f, 0.15f)),
            ("Plata / Canoso", new Color(0.88f, 0.9f, 0.95f))
        };

        public static readonly (string name, HatStyle style)[] HatOptions =
        {
            ("Ninguno", HatStyle.None),
            ("Sombrero de Paja", HatStyle.Straw),
            ("Bandana Pirata", HatStyle.Bandana),
            ("Gorra Marina", HatStyle.MarineCap),
            ("Tricornio Capitán", HatStyle.Tricorn),
            ("Gafas de Aviador", HatStyle.Goggles),
            ("Pañuelo Pirata", HatStyle.Headscarf),
            ("Fedora con Pluma", HatStyle.Fedora)
        };

        public static readonly (string name, Color color)[] HatColorOptions =
        {
            ("Dorado Paja", new Color(0.95f, 0.82f, 0.38f)),
            ("Rojo Carmesí", new Color(0.85f, 0.2f, 0.2f)),
            ("Negro Cuervo", new Color(0.15f, 0.15f, 0.18f)),
            ("Verde Oscuro", new Color(0.15f, 0.45f, 0.22f)),
            ("Blanco Marina", new Color(0.95f, 0.95f, 0.98f)),
            ("Azul Real", new Color(0.2f, 0.35f, 0.65f))
        };

        public static readonly (string name, ShirtStyle style)[] ShirtOptions =
        {
            ("Chaleco Abierto", ShirtStyle.OpenVest),
            ("Chaqueta Moderna", ShirtStyle.ModernJacket),
            ("Camisa Hawaiana", ShirtStyle.Hawaiian),
            ("Abrigo de Capitán", ShirtStyle.Coat),
            ("Marinera a Rayas", ShirtStyle.Striped),
            ("Camisa Lisa", ShirtStyle.Plain)
        };

        public static readonly (string name, Color color)[] ShirtColorOptions =
        {
            ("Rojo Escarlata", new Color(0.88f, 0.25f, 0.22f)),
            ("Azul Océano", new Color(0.25f, 0.45f, 0.85f)),
            ("Negro Cuero", new Color(0.18f, 0.18f, 0.22f)),
            ("Verde Esmeralda", new Color(0.2f, 0.65f, 0.35f)),
            ("Blanco Puro", new Color(0.95f, 0.95f, 0.98f)),
            ("Naranja Tropical", new Color(0.95f, 0.55f, 0.15f)),
            ("Púrpura Noble", new Color(0.55f, 0.22f, 0.65f))
        };

        public static readonly (string name, Color color, bool isShort)[] PantsOptions =
        {
            ("Bermudas Denim", new Color(0.25f, 0.42f, 0.65f), true),
            ("Bermudas Negras", new Color(0.2f, 0.2f, 0.22f), true),
            ("Pantalón Marino", new Color(0.2f, 0.3f, 0.5f), false),
            ("Pantalón Cuero", new Color(0.38f, 0.25f, 0.15f), false),
            ("Pantalón Blanco", new Color(0.9f, 0.9f, 0.92f), false)
        };

        public static Sprite Get(string id, CharacterLook look)
        {
            return GameSprites.Get(id, () => Draw(look));
        }

        public static Sprite GetPlayerSprite() => Draw(CurrentPlayerLook);

        public static void ApplyPlayerLook(CharacterLook look, string name = null)
        {
            CurrentPlayerLook = look;
            if (!string.IsNullOrEmpty(name)) PlayerName = name;
            Sprite newSprite = Draw(CurrentPlayerLook);
            RuntimeSpriteCache.Set("c_player", newSprite);

            var pc = Object.FindAnyObjectByType<PirateSurvival.Player.PlayerController2D>();
            if (pc != null)
            {
                var sr = pc.GetComponentInChildren<SpriteRenderer>();
                if (sr != null) sr.sprite = newSprite;
            }

            var hud = Object.FindAnyObjectByType<PirateSurvival.UI.HUDManager>();
            if (hud != null) hud.RefreshAvatar();
        }

        /// <summary>Protagonista: joven pirata intrépido con chaleco carmesí, fajín dorado y sombrero de paja.</summary>
        public static CharacterLook Castaway() => new CharacterLook
        {
            skin = SkinTan,
            hair = new Color(0.12f, 0.12f, 0.14f),
            shirt = new Color(0.85f, 0.18f, 0.18f),   // Chaleco pirata carmesí abierto
            pants = new Color(0.18f, 0.32f, 0.58f),   // Pantalones marineros azul índigo
            shoes = new Color(0.24f, 0.16f, 0.10f),   // Botas de cuero
            hatColor = new Color(0.95f, 0.82f, 0.35f), // Sombrero de paja icónico
            accent = new Color(1.0f, 0.78f, 0.2f),    // Cinta y fajín de oro
            hat = HatStyle.Straw,
            shirtStyle = ShirtStyle.OpenVest,
            shortPants = true,
            sunglasses = false
        };

        public static Sprite Draw(CharacterLook l)
        {
            PixelCanvas c = new PixelCanvas(32, 32);
            Color skinShadow = Color.Lerp(l.skin, Color.black, 0.25f);
            Color shirtShadow = Color.Lerp(l.shirt, Color.black, 0.3f);
            Color shirtLight = Color.Lerp(l.shirt, Color.white, 0.2f);
            Color pantsShadow = Color.Lerp(l.pants, Color.black, 0.3f);

            // Capa sobre los hombros estilo One Piece (Justicia / Capitán)
            if (l.cape)
            {
                Color capeCol = l.hatColor == Color.clear ? Color.white : l.hatColor;
                Color capeShadow = Color.Lerp(capeCol, Color.black, 0.25f);
                c.Rect(6, 4, 20, 14, capeCol);
                c.Rect(6, 4, 2, 14, capeShadow);
                c.Rect(24, 4, 2, 14, capeShadow);
                // Charreteras doradas en los hombros
                c.Rect(6, 16, 4, 2, new Color(1f, 0.82f, 0.28f));
                c.Rect(22, 16, 4, 2, new Color(1f, 0.82f, 0.28f));
            }

            // Piernas
            if (l.shirtStyle != ShirtStyle.Dress)
            {
                if (l.shortPants)
                {
                    c.Rect(12, 4, 3, 3, l.skin); c.Rect(17, 4, 3, 3, l.skin);
                    c.Rect(12, 4, 1, 3, skinShadow); c.Rect(17, 4, 1, 3, skinShadow);
                    c.Rect(11, 7, 5, 3, l.pants); c.Rect(16, 7, 5, 3, l.pants);
                    c.Rect(15, 7, 2, 2, pantsShadow);
                }
                else
                {
                    c.Rect(12, 4, 3, 6, l.pants); c.Rect(17, 4, 3, 6, l.pants);
                    c.Rect(14, 4, 1, 6, pantsShadow); c.Rect(19, 4, 1, 6, pantsShadow);
                }
            }
            c.Rect(11, 2, 4, 2, l.shoes); c.Rect(17, 2, 4, 2, l.shoes);

            // Torso
            switch (l.shirtStyle)
            {
                case ShirtStyle.Dress:
                    for (int y = 3; y <= 16; y++)
                    {
                        int half = 4 + Mathf.Max(0, (12 - y) / 2);
                        c.Rect(16 - half, y, half * 2, 1, l.shirt);
                    }
                    c.Rect(11, 3, 2, 8, shirtShadow);
                    c.Rect(12, 10, 8, 1, l.accent);
                    break;
                case ShirtStyle.Coat:
                    c.Rect(10, 5, 12, 12, l.shirt);
                    c.Rect(10, 5, 2, 12, shirtShadow);
                    c.Rect(15, 5, 2, 12, l.accent);
                    c.Set(16, 13, new Color(0.95f, 0.8f, 0.3f)); c.Set(16, 10, new Color(0.95f, 0.8f, 0.3f));
                    break;
                case ShirtStyle.ModernJacket:
                    // Chaqueta abierta moderna con camiseta de contraste interior
                    c.Rect(10, 10, 12, 7, l.shirt);
                    c.Rect(10, 10, 2, 7, shirtShadow);
                    c.Rect(20, 10, 2, 7, shirtShadow);
                    c.Rect(13, 10, 6, 7, l.accent == Color.clear ? Color.white : l.accent); // camiseta interior
                    c.Rect(11, 10, 10, 1, Color.black); // cinturón
                    break;
                case ShirtStyle.Hawaiian:
                    // Camisa hawaiana alegre abierta
                    c.Rect(11, 10, 10, 7, l.shirt);
                    c.Rect(14, 11, 4, 6, l.skin);
                    for (int y = 11; y < 17; y += 2)
                    {
                        c.Set(12, y, l.accent); c.Set(19, y, l.accent);
                    }
                    c.Rect(11, 10, 10, 1, Color.black);
                    break;
                default:
                    c.Rect(11, 10, 10, 7, l.shirt);
                    c.Rect(11, 10, 2, 7, shirtShadow);
                    c.Rect(19, 12, 2, 5, shirtLight);
                    if (l.shirtStyle == ShirtStyle.OpenVest)
                    {
                        c.Rect(14, 11, 4, 6, l.skin);
                        c.Set(14, 11, skinShadow);
                    }
                    else if (l.shirtStyle == ShirtStyle.Striped)
                    {
                        for (int y = 11; y < 17; y += 2) c.Rect(11, y, 10, 1, Color.Lerp(l.shirt, Color.white, 0.65f));
                    }
                    c.Rect(11, 10, 10, 1, Color.Lerp(l.pants, Color.black, 0.45f));
                    c.Set(16, 10, new Color(0.9f, 0.75f, 0.3f));
                    break;
            }

            // Brazos y mangas
            Color sleeve = (l.shirtStyle == ShirtStyle.OpenVest || l.shirtStyle == ShirtStyle.Hawaiian) ? l.skin : l.shirt;
            c.Rect(8, 11, 3, 6, sleeve); c.Rect(21, 11, 3, 6, sleeve);
            c.Rect(8, 11, 1, 6, sleeve == l.skin ? skinShadow : shirtShadow);
            c.Rect(8, 9, 3, 2, l.skin); c.Rect(21, 9, 3, 2, l.skin);

            // Cabeza
            c.ShadedEllipse(16, 21.5f, 6.5f, 6f, l.skin, 0.15f, 0.22f);

            // Pelo
            c.Ellipse(16, 25.5f, 6.8f, 3.4f, l.hair);
            c.Rect(9, 21, 2, 4, l.hair); c.Rect(21, 21, 2, 4, l.hair);
            if (l.longHair) { c.Rect(9, 15, 2, 7, l.hair); c.Rect(21, 15, 2, 7, l.hair); }

            // Ojos o Gafas de Sol modernas (estilo One Piece)
            if (l.sunglasses)
            {
                c.Rect(11, 19, 5, 3, Outline); c.Rect(17, 19, 5, 3, Outline);
                c.Line(12, 21, 20, 21, Outline);
                Color lens = l.accent == Color.clear ? new Color(0.12f, 0.14f, 0.18f) : l.accent;
                c.Rect(12, 19, 3, 2, lens);
                c.Rect(18, 19, 3, 2, lens);
                c.Set(13, 20, Color.white); c.Set(19, 20, Color.white); // reflejo
            }
            else
            {
                c.Rect(13, 20, 2, 2, Outline); c.Rect(18, 20, 2, 2, Outline);
                c.Set(13, 21, Color.white); c.Set(18, 21, Color.white);
            }

            c.Rect(15, 17, 3, 1, Color.Lerp(l.skin, new Color(0.5f, 0.15f, 0.12f), 0.6f));
            c.Set(12, 18, Color.Lerp(l.skin, new Color(1f, 0.4f, 0.4f), 0.35f)); c.Set(20, 18, Color.Lerp(l.skin, new Color(1f, 0.4f, 0.4f), 0.35f));
            if (l.beard)
            {
                c.Rect(12, 15, 9, 3, l.hair); c.Rect(13, 14, 7, 1, l.hair);
                c.Rect(15, 17, 3, 1, Color.Lerp(l.hair, Color.black, 0.4f));
            }
            if (l.eyePatch)
            {
                c.Rect(12, 19, 4, 3, Outline);
                c.Line(9, 24, 22, 22, Outline);
            }

            // Sombrero / Accesorios para la cabeza
            switch (l.hat)
            {
                case HatStyle.Straw:
                {
                    Color strawLight = Color.Lerp(l.hatColor, Color.white, 0.3f);
                    Color strawDark = Color.Lerp(l.hatColor, Color.black, 0.3f);
                    c.Ellipse(16, 25.5f, 11f, 2.4f, l.hatColor);
                    c.Ellipse(16, 25f, 11f, 1.2f, strawDark);
                    c.Rect(11, 26, 11, 5, l.hatColor);
                    c.Ellipse(16.5f, 30.5f, 5.5f, 1.4f, l.hatColor);
                    c.Rect(11, 26, 11, 2, l.accent);
                    c.Rect(19, 28, 2, 3, strawLight);
                    c.Rect(11, 28, 1, 3, strawDark);
                    break;
                }
                case HatStyle.Bandana:
                    c.Ellipse(16, 25.5f, 7.2f, 3.8f, l.hatColor);
                    c.Rect(9, 23, 15, 2, l.hatColor);
                    c.Rect(22, 21, 3, 2, l.hatColor); c.Rect(24, 19, 2, 3, l.hatColor);
                    c.Set(13, 27, Color.Lerp(l.hatColor, Color.white, 0.6f)); c.Set(18, 26, Color.Lerp(l.hatColor, Color.white, 0.6f));
                    c.Rect(9, 23, 15, 1, Color.Lerp(l.hatColor, Color.black, 0.35f));
                    break;
                case HatStyle.Goggles:
                    // Gafas de aviador / tirador estilo Usopp en la frente
                    c.Rect(10, 24, 12, 3, Outline);
                    c.Rect(11, 24, 4, 2, new Color(0.9f, 0.75f, 0.25f)); // montura dorada
                    c.Rect(17, 24, 4, 2, new Color(0.9f, 0.75f, 0.25f));
                    c.Set(12, 25, new Color(0.3f, 0.8f, 1f)); c.Set(18, 25, new Color(0.3f, 0.8f, 1f)); // cristal azul
                    break;
                case HatStyle.Fedora:
                    // Sombrero fedora moderno con pluma
                    c.Ellipse(16, 26f, 11f, 2.5f, l.hatColor);
                    c.Rect(11, 26, 10, 5, l.hatColor);
                    c.Rect(11, 26, 10, 1, l.accent);
                    c.Line(20, 28, 23, 31, new Color(0.9f, 0.2f, 0.2f)); // pluma roja
                    break;
                case HatStyle.MarineCap:
                    c.Ellipse(16, 26f, 7f, 3.6f, l.hatColor);
                    c.Rect(9, 24, 14, 2, Color.Lerp(l.accent, Color.black, 0.1f));
                    c.Rect(10, 23, 12, 1, Color.Lerp(l.hatColor, Color.black, 0.25f));
                    c.Set(16, 27, l.accent);
                    break;
                case HatStyle.Tricorn:
                    c.Ellipse(16, 26f, 11f, 2.6f, l.hatColor);
                    c.Ellipse(16, 28.5f, 6.5f, 3f, l.hatColor);
                    c.Rect(6, 26, 21, 1, l.accent);
                    c.Rect(14, 28, 4, 2, Color.white); c.Set(15, 27, Outline); c.Set(16, 27, Outline);
                    break;
                case HatStyle.Headscarf:
                    c.Ellipse(16, 25.5f, 7.4f, 4f, l.hatColor);
                    for (int x = 10; x < 23; x += 3) c.Set(x, 26, Color.Lerp(l.hatColor, Color.white, 0.55f));
                    break;
            }

            // Objeto en la mano derecha
            switch (l.held)
            {
                case HeldItem.Sword:
                    c.Line(24, 11, 29, 22, new Color(0.88f, 0.92f, 0.96f), 2);
                    c.Line(25, 11, 30, 22, Color.white);
                    c.Rect(21, 10, 4, 2, new Color(0.9f, 0.75f, 0.25f));
                    break;
                case HeldItem.Pistol:
                    c.Rect(22, 10, 7, 2, new Color(0.25f, 0.25f, 0.28f));
                    c.Rect(22, 8, 2, 3, new Color(0.45f, 0.28f, 0.14f));
                    c.Set(28, 11, new Color(0.6f, 0.6f, 0.65f));
                    break;
                case HeldItem.FishingRod:
                    c.Line(23, 9, 30, 30, new Color(0.55f, 0.38f, 0.2f));
                    c.Line(30, 30, 31, 20, new Color(0.85f, 0.85f, 0.85f, 0.7f));
                    break;
                case HeldItem.Hammer:
                    c.Line(23, 8, 28, 18, new Color(0.55f, 0.38f, 0.2f), 2);
                    c.Rect(26, 17, 5, 3, new Color(0.4f, 0.42f, 0.48f));
                    break;
                case HeldItem.Basket:
                    c.Rect(21, 6, 7, 4, new Color(0.7f, 0.5f, 0.25f));
                    c.Rect(21, 6, 7, 1, new Color(0.5f, 0.33f, 0.15f));
                    c.Rect(22, 10, 2, 1, new Color(0.9f, 0.3f, 0.2f)); c.Set(25, 10, new Color(0.95f, 0.75f, 0.2f));
                    break;
            }

            c.Outline(Outline);

            // Sombra en el suelo
            for (int y = 0; y < 5; y++)
                for (int x = 6; x < 27; x++)
                {
                    float dx = (x + 0.5f - 16f) / 9.5f, dy = (y + 0.5f - 2.2f) / 2.2f;
                    if (dx * dx + dy * dy <= 1f && !c.IsOpaque(x, y)) c.Set(x, y, new Color(0f, 0f, 0f, 0.28f));
                }

            return c.ToSprite(new Vector2(0.5f, 0.2f), 32f);
        }
    }
}
