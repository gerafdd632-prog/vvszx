﻿using System;
using UnityEngine;

namespace PirateSurvival.Core
{
    /// <summary>
    /// Punto único para pedir un sprite por clave.
    /// Si existe una imagen en Resources/Sprites/&lt;clave&gt;.png (gráficos del pack de Kenney y los generados para la isla),
    /// se usa esa; si no, se dibuja por código con 'fallback'. Todo queda cacheado en RuntimeSpriteCache.
    /// Si Unity importó la imagen sin los ajustes de pixel art (.meta perdido), se corrige aquí: filtro Point,
    /// 16 píxeles por unidad y el pivote correcto (SpritePivots).
    /// </summary>
    public static class GameSprites
    {
        public const string ResourcesFolder = "Sprites/";
        public const float PixelsPerUnit = 16f;

        public static Sprite Get(string key, Func<Sprite> fallback)
        {
            return RuntimeSpriteCache.Get(key, () => LoadExternal(key) ?? fallback());
        }

        /// <summary>¿Hay imagen externa para esta clave?</summary>
        public static bool HasExternal(string key) => Resources.Load<Texture2D>(ResourcesFolder + key) != null;

        private static Sprite LoadExternal(string key)
        {
            string path = ResourcesFolder + key;
            Sprite sprite = Resources.Load<Sprite>(path);
            Texture2D tex = sprite != null ? sprite.texture : Resources.Load<Texture2D>(path);
            if (tex == null) return null;

            tex.filterMode = FilterMode.Point;
            if (sprite != null && Mathf.Approximately(sprite.pixelsPerUnit, PixelsPerUnit)) return sprite;

            Vector2 pivot = SpritePivots.Get(key);
            Sprite rebuilt = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), pivot, PixelsPerUnit, 0, SpriteMeshType.FullRect);
            rebuilt.name = key;
            return rebuilt;
        }
    }
}
