﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace PirateSurvival.Core
{
    /// <summary>
    /// Gestor de audio procedural autónomo y de alta fidelidad táctica (16-bit retro/Day R).
    /// Sintetiza efectos de sonido limpios en memoria mediante AudioClip.Create, con
    /// acumulador de fase continuo (sin clicks/pops) y pool de 8 canales 2D.
    /// </summary>
    public class AudioManager : MonoBehaviour
    {
        private static AudioManager instance;
        public static AudioManager Instance
        {
            get
            {
                if (instance == null)
                {
                    GameObject go = new GameObject("AudioManager");
                    instance = go.AddComponent<AudioManager>();
                    DontDestroyOnLoad(go);
                }
                return instance;
            }
        }

        private const int PoolSize = 8;
        private AudioSource[] sfxPool;
        private int sfxPoolIndex;
        private AudioSource ambientSource;
        private readonly Dictionary<string, AudioClip> clipCache = new Dictionary<string, AudioClip>();

        private void Awake()
        {
            if (instance != null && instance != this)
            {
                Destroy(gameObject);
                return;
            }
            instance = this;
            DontDestroyOnLoad(gameObject);

            sfxPool = new AudioSource[PoolSize];
            for (int i = 0; i < PoolSize; i++)
            {
                AudioSource src = gameObject.AddComponent<AudioSource>();
                src.playOnAwake = false;
                src.spatialBlend = 0f; // 100% 2D no posicional
                src.volume = 0.85f;
                src.rolloffMode = AudioRolloffMode.Linear;
                sfxPool[i] = src;
            }

            ambientSource = gameObject.AddComponent<AudioSource>();
            ambientSource.playOnAwake = false;
            ambientSource.spatialBlend = 0f;
            ambientSource.loop = true;
            ambientSource.volume = 0.25f;
        }

        public void PlaySfx(string key, Func<AudioClip> generator, float pitch = 1f, float volume = 1f)
        {
            if (sfxPool == null || sfxPool.Length == 0) return;
            if (!clipCache.TryGetValue(key, out AudioClip clip) || clip == null)
            {
                clip = generator();
                clipCache[key] = clip;
            }
            AudioSource src = sfxPool[sfxPoolIndex];
            sfxPoolIndex = (sfxPoolIndex + 1) % sfxPool.Length;
            src.pitch = pitch;
            src.PlayOneShot(clip, Mathf.Clamp01(volume));
        }

        // ================================================================ EFECTOS DE COMBATE TÁCTICO DAY R

        /// <summary>Tajo de espada / sable: silbido aerodinámico + resonancia de acero templado.</summary>
        public void PlaySlash()
        {
            PlaySfx("sfx_slash", () => SynthSlash(0.18f), UnityEngine.Random.Range(0.96f, 1.04f), 0.85f);
        }

        /// <summary>Golpe contundente / porra / puñetazo: impacto sub-bass y crujido seco.</summary>
        public void PlayBlunt()
        {
            PlaySfx("sfx_blunt", () => SynthBlunt(0.16f), UnityEngine.Random.Range(0.94f, 1.06f), 0.9f);
        }

        /// <summary>Disparo de pólvora / mosquete de chispa: detonación con eco sordo.</summary>
        public void PlayGunshot()
        {
            PlaySfx("sfx_gunshot", () => SynthGunshot(0.38f), UnityEngine.Random.Range(0.97f, 1.03f), 0.95f);
        }

        /// <summary>Recarga táctica: dos chasquidos metálicos de cerrojo y cierre.</summary>
        public void PlayReload()
        {
            PlaySfx("sfx_reload", () => SynthReload(0.24f), 1f, 0.8f);
        }

        /// <summary>Impacto crítico: tañido brillante con armónico resonante.</summary>
        public void PlayCrit()
        {
            PlaySfx("sfx_crit", () => SynthCritChime(0.42f), 1.02f, 0.9f);
        }

        /// <summary>Explosión de barril de pólvora: estampido sordo y metralla.</summary>
        public void PlayExplosion()
        {
            PlaySfx("sfx_explosion", () => SynthExplosion(0.65f), UnityEngine.Random.Range(0.95f, 1.05f), 1f);
        }

        /// <summary>Bloqueo de guardia / escudo: rebote metálico seco.</summary>
        public void PlayShield()
        {
            PlaySfx("sfx_shield", () => SynthShield(0.18f), UnityEngine.Random.Range(0.98f, 1.04f), 0.85f);
        }

        /// <summary>Ataque fallado / esquiva: leve silbido de aire sin impacto.</summary>
        public void PlayMiss()
        {
            PlaySfx("sfx_miss", () => SynthMiss(0.14f), UnityEngine.Random.Range(0.95f, 1.1f), 0.6f);
        }

        /// <summary>Acción fallida, sin AP o fuera de alcance: aviso sonoro.</summary>
        public void PlayCraftFailed()
        {
            PlayMiss();
        }

        public void PlayDeny()
        {
            PlayMiss();
        }

        public void PlayHit()
        {
            PlayBlunt();
        }

        /// <summary>Comienzo de turno táctico: doble tono de alerta militar.</summary>
        public void PlayTurnStart()
        {
            PlaySfx("sfx_turn", () => SynthTurnAlert(0.18f), 1f, 0.7f);
        }

        /// <summary>Clic de botón táctico / selector de AP: chasquido suave de slate.</summary>
        public void PlayUiClick()
        {
            PlaySfx("sfx_click", () => SynthClick(0.045f), UnityEngine.Random.Range(0.98f, 1.03f), 0.5f);
        }

        /// <summary>Uso de objeto médico o comida: crujido de vendaje / trago.</summary>
        public void PlayItemUse()
        {
            PlaySfx("sfx_item", () => SynthItemUse(0.22f), 1f, 0.75f);
        }

        /// <summary>Fanfarria de victoria triunfal: acordes mayores limpios en arpegio.</summary>
        public void PlayVictory()
        {
            PlaySfx("sfx_victory", () => SynthFanfare(0.85f, true), 1f, 0.95f);
        }

        /// <summary>Subida de nivel o hito importante: fanfarria de avance.</summary>
        public void PlayLevelUp()
        {
            PlayVictory();
        }

        /// <summary>Acorde de derrota o retirada sombría: descenso menor suave.</summary>
        public void PlayDefeat()
        {
            PlaySfx("sfx_defeat", () => SynthFanfare(0.95f, false), 1f, 0.9f);
        }

        /// <summary>Tala de madera: impacto sordo y crujido de astillas.</summary>
        public void PlayWoodChop()
        {
            PlaySfx("sfx_chop", () => SynthChop(0.15f), UnityEngine.Random.Range(0.92f, 1.08f), 0.85f);
        }

        /// <summary>Picado de roca o mineral: impacto metálico con resonancia de piedra.</summary>
        public void PlayPickaxeHit()
        {
            PlaySfx("sfx_mine", () => SynthMine(0.18f), UnityEngine.Random.Range(0.95f, 1.05f), 0.85f);
        }

        /// <summary>Recolección de arbustos/plantas: crujido vegetal de hojas secas.</summary>
        public void PlayBushGather()
        {
            PlaySfx("sfx_bush", () => SynthBush(0.16f), UnityEngine.Random.Range(0.95f, 1.1f), 0.75f);
        }

        /// <summary>Paso del jugador: sutil golpe rítmico en arena o tierra.</summary>
        public void PlayFootstep(bool sand = false)
        {
            PlaySfx(sand ? "sfx_step_sand" : "sfx_step_earth", () => SynthStep(0.08f, sand), UnityEngine.Random.Range(0.92f, 1.08f), 0.35f);
        }

        /// <summary>Comer alimento: crujido de masticación.</summary>
        public void PlayEat()
        {
            PlaySfx("sfx_eat", () => SynthEat(0.2f), UnityEngine.Random.Range(0.95f, 1.05f), 0.75f);
        }

        /// <summary>Beber agua/bebida: trago suave con eco líquido.</summary>
        public void PlayDrink()
        {
            PlaySfx("sfx_drink", () => SynthDrink(0.24f), UnityEngine.Random.Range(0.98f, 1.02f), 0.75f);
        }

        /// <summary>Fabricación completada: tintineo alegre de yunque y forja.</summary>
        public void PlayCraftSuccess()
        {
            PlaySfx("sfx_craft_ok", () => SynthCraftOk(0.35f), 1f, 0.85f);
        }

        /// <summary>Descanso en hoguera o tienda: acorde relajante de bienestar.</summary>
        public void PlayRest()
        {
            PlaySfx("sfx_rest", () => SynthRest(0.6f), 1f, 0.9f);
        }

        /// <summary>Apertura de cofre del tesoro: chirrido de bisagra y brillo metálico.</summary>
        public void PlayTreasureOpen()
        {
            PlaySfx("sfx_chest", () => SynthTreasure(0.45f), 1f, 0.9f);
        }

        /// <summary>Disparo de tirachinas: silbido elástico rápido.</summary>
        public void PlaySlingshot()
        {
            PlaySfx("sfx_slingshot", () => SynthSlingshot(0.16f), UnityEngine.Random.Range(0.95f, 1.05f), 0.8f);
        }

        // ================================================================ SINTETIZADOR DE ONDAS LIMPIO

        private static AudioClip SynthSlash(float duration)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(sampleRate * duration);
            float[] samples = new float[count];
            float phaseTone = 0f;
            float phaseSteel = 0f;

            for (int i = 0; i < count; i++)
            {
                float t = (float)i / count;
                // Frecuencia descendente rápida
                float fTone = Mathf.Lerp(1600f, 320f, t * t);
                float fSteel = Mathf.Lerp(2800f, 740f, t);

                phaseTone += 2f * Mathf.PI * fTone / sampleRate;
                phaseSteel += 2f * Mathf.PI * fSteel / sampleRate;

                float env = Mathf.Sin(t * Mathf.PI); // campana suave
                float noise = UnityEngine.Random.Range(-0.4f, 0.4f) * env;
                float tone = Mathf.Sin(phaseTone) * 0.45f;
                float steel = Mathf.Sin(phaseSteel) * 0.25f * (1f - t);

                samples[i] = Mathf.Clamp((tone + steel + noise) * env * 0.9f, -1f, 1f);
            }

            AudioClip clip = AudioClip.Create("synth_slash", count, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip SynthBlunt(float duration)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(sampleRate * duration);
            float[] samples = new float[count];
            float phase = 0f;

            for (int i = 0; i < count; i++)
            {
                float t = (float)i / count;
                float freq = Mathf.Lerp(140f, 38f, t * t);
                phase += 2f * Mathf.PI * freq / sampleRate;

                float sub = Mathf.Sin(phase) * Mathf.Exp(-t * 12f);
                float punch = (i < sampleRate * 0.02f) ? UnityEngine.Random.Range(-0.7f, 0.7f) : 0f;
                samples[i] = Mathf.Clamp((sub * 0.75f + punch * 0.5f) * 0.9f, -1f, 1f);
            }

            AudioClip clip = AudioClip.Create("synth_blunt", count, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip SynthGunshot(float duration)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(sampleRate * duration);
            float[] samples = new float[count];
            float phaseBoom = 0f;

            for (int i = 0; i < count; i++)
            {
                float t = (float)i / count;
                // Crack inicial seco (0 a 18ms)
                float crack = (i < sampleRate * 0.022f) ? UnityEngine.Random.Range(-1f, 1f) * (1f - t / 0.022f) : 0f;

                // Estampido de pólvora grave con caída
                phaseBoom += 2f * Mathf.PI * Mathf.Lerp(110f, 42f, t) / sampleRate;
                float boom = Mathf.Sin(phaseBoom) * Mathf.Exp(-t * 9f);
                float tail = UnityEngine.Random.Range(-0.35f, 0.35f) * Mathf.Exp(-t * 6f);

                samples[i] = Mathf.Clamp(crack * 0.9f + boom * 0.65f + tail * 0.35f, -1f, 1f);
            }

            AudioClip clip = AudioClip.Create("synth_gunshot", count, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip SynthReload(float duration)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(sampleRate * duration);
            float[] samples = new float[count];

            int click1 = Mathf.FloorToInt(sampleRate * 0.03f);
            int click2 = Mathf.FloorToInt(sampleRate * 0.13f);

            for (int i = 0; i < count; i++)
            {
                float val = 0f;
                if (i >= click1 && i < click1 + 220)
                {
                    float t = (float)(i - click1) / 220f;
                    val = UnityEngine.Random.Range(-0.8f, 0.8f) * (1f - t);
                }
                if (i >= click2 && i < click2 + 300)
                {
                    float t = (float)(i - click2) / 300f;
                    val = UnityEngine.Random.Range(-0.95f, 0.95f) * (1f - t);
                }
                samples[i] = val;
            }

            AudioClip clip = AudioClip.Create("synth_reload", count, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip SynthCritChime(float duration)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(sampleRate * duration);
            float[] samples = new float[count];

            float p1 = 0f, p2 = 0f, p3 = 0f;
            for (int i = 0; i < count; i++)
            {
                float t = (float)i / count;
                p1 += 2f * Mathf.PI * 987f / sampleRate;  // B5
                p2 += 2f * Mathf.PI * 1318f / sampleRate; // E6
                p3 += 2f * Mathf.PI * 1975f / sampleRate; // B6

                float env = Mathf.Exp(-t * 7f);
                float tone = (Mathf.Sin(p1) * 0.45f + Mathf.Sin(p2) * 0.35f + Mathf.Sin(p3) * 0.2f) * env;
                samples[i] = tone * 0.85f;
            }

            AudioClip clip = AudioClip.Create("synth_crit", count, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip SynthExplosion(float duration)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(sampleRate * duration);
            float[] samples = new float[count];
            float phase = 0f;

            for (int i = 0; i < count; i++)
            {
                float t = (float)i / count;
                phase += 2f * Mathf.PI * Mathf.Lerp(65f, 25f, t) / sampleRate;
                float boom = Mathf.Sin(phase) * Mathf.Exp(-t * 4.5f);
                float roar = UnityEngine.Random.Range(-0.9f, 0.9f) * Mathf.Exp(-t * 3.8f);
                samples[i] = Mathf.Clamp(boom * 0.65f + roar * 0.55f, -1f, 1f);
            }

            AudioClip clip = AudioClip.Create("synth_explosion", count, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip SynthShield(float duration)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(sampleRate * duration);
            float[] samples = new float[count];
            float phase = 0f;

            for (int i = 0; i < count; i++)
            {
                float t = (float)i / count;
                phase += 2f * Mathf.PI * Mathf.Lerp(680f, 340f, t * t) / sampleRate;
                float clang = Mathf.Sin(phase) * Mathf.Exp(-t * 14f);
                float crack = (i < sampleRate * 0.015f) ? UnityEngine.Random.Range(-0.7f, 0.7f) : 0f;
                samples[i] = Mathf.Clamp(clang * 0.7f + crack * 0.4f, -1f, 1f);
            }

            AudioClip clip = AudioClip.Create("synth_shield", count, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip SynthMiss(float duration)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(sampleRate * duration);
            float[] samples = new float[count];

            for (int i = 0; i < count; i++)
            {
                float t = (float)i / count;
                float env = Mathf.Sin(t * Mathf.PI);
                samples[i] = UnityEngine.Random.Range(-0.55f, 0.55f) * env * 0.4f;
            }

            AudioClip clip = AudioClip.Create("synth_miss", count, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip SynthTurnAlert(float duration)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(sampleRate * duration);
            float[] samples = new float[count];
            float phase = 0f;

            for (int i = 0; i < count; i++)
            {
                float t = (float)i / count;
                float freq = t < 0.5f ? 523f : 659f; // C5 luego E5
                phase += 2f * Mathf.PI * freq / sampleRate;
                float env = 1f - Mathf.Abs(t - 0.5f) * 1.6f;
                samples[i] = Mathf.Sin(phase) * Mathf.Clamp01(env) * 0.55f;
            }

            AudioClip clip = AudioClip.Create("synth_turn", count, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip SynthClick(float duration)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(sampleRate * duration);
            float[] samples = new float[count];
            float phase = 0f;

            for (int i = 0; i < count; i++)
            {
                float t = (float)i / count;
                phase += 2f * Mathf.PI * Mathf.Lerp(1200f, 600f, t) / sampleRate;
                samples[i] = Mathf.Sin(phase) * (1f - t) * 0.45f;
            }

            AudioClip clip = AudioClip.Create("synth_click", count, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip SynthItemUse(float duration)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(sampleRate * duration);
            float[] samples = new float[count];
            float phase = 0f;

            for (int i = 0; i < count; i++)
            {
                float t = (float)i / count;
                phase += 2f * Mathf.PI * Mathf.Lerp(380f, 540f, t) / sampleRate;
                float rustle = UnityEngine.Random.Range(-0.3f, 0.3f);
                samples[i] = (Mathf.Sin(phase) * 0.4f + rustle * 0.3f) * Mathf.Sin(t * Mathf.PI) * 0.7f;
            }

            AudioClip clip = AudioClip.Create("synth_item", count, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip SynthFanfare(float duration, bool victory)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(sampleRate * duration);
            float[] samples = new float[count];
            // Acordes limpios en arpegio continuo
            float[] notes = victory
                ? new[] { 523.25f, 659.25f, 783.99f, 1046.50f } // C5, E5, G5, C6 (Mayor épico)
                : new[] { 440.00f, 392.00f, 329.63f, 261.63f }; // A4, G4, E4, C4 (Menor melancólico)

            float step = duration / notes.Length;
            float phase = 0f;
            float harmonicPhase = 0f;

            for (int i = 0; i < count; i++)
            {
                float t = (float)i / sampleRate;
                int idx = Mathf.Clamp(Mathf.FloorToInt(t / step), 0, notes.Length - 1);
                float f = notes[idx];

                phase += 2f * Mathf.PI * f / sampleRate;
                harmonicPhase += 2f * Mathf.PI * (f * 2f) / sampleRate;

                float noteLocalTime = (t % step) / step;
                // Envolvente tipo trompeta (ataque rápido, sustain y caída suave)
                float attack = Mathf.Clamp01(noteLocalTime * 15f);
                float decay = 1f - noteLocalTime * 0.25f;
                float env = attack * decay;

                float fundamental = Mathf.Sin(phase);
                float overtone = Mathf.Sin(harmonicPhase) * 0.35f;

                samples[i] = (fundamental + overtone) * env * 0.7f;
            }

            AudioClip clip = AudioClip.Create("synth_fanfare", count, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip SynthChop(float duration)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(sampleRate * duration);
            float[] samples = new float[count];
            float phase = 0f;
            for (int i = 0; i < count; i++)
            {
                float t = (float)i / count;
                float freq = Mathf.Lerp(220f, 60f, t * t);
                phase += 2f * Mathf.PI * freq / sampleRate;
                float crack = (i < sampleRate * 0.025f) ? UnityEngine.Random.Range(-0.9f, 0.9f) : UnityEngine.Random.Range(-0.25f, 0.25f);
                float woodTone = Mathf.Sin(phase) * 0.6f;
                float env = Mathf.Exp(-t * 14f);
                samples[i] = Mathf.Clamp((woodTone + crack) * env * 0.9f, -1f, 1f);
            }
            AudioClip clip = AudioClip.Create("synth_chop", count, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip SynthMine(float duration)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(sampleRate * duration);
            float[] samples = new float[count];
            float pTone = 0f, pMetal = 0f;
            for (int i = 0; i < count; i++)
            {
                float t = (float)i / count;
                pTone += 2f * Mathf.PI * Mathf.Lerp(450f, 180f, t) / sampleRate;
                pMetal += 2f * Mathf.PI * 1840f / sampleRate;
                float click = (i < sampleRate * 0.015f) ? UnityEngine.Random.Range(-0.85f, 0.85f) : 0f;
                float tone = Mathf.Sin(pTone) * 0.5f + Mathf.Sin(pMetal) * 0.35f * Mathf.Exp(-t * 20f);
                float env = Mathf.Exp(-t * 11f);
                samples[i] = Mathf.Clamp((tone + click) * env * 0.85f, -1f, 1f);
            }
            AudioClip clip = AudioClip.Create("synth_mine", count, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip SynthBush(float duration)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(sampleRate * duration);
            float[] samples = new float[count];
            for (int i = 0; i < count; i++)
            {
                float t = (float)i / count;
                float env = Mathf.Sin(t * Mathf.PI);
                float rustle = UnityEngine.Random.Range(-0.7f, 0.7f);
                samples[i] = rustle * env * 0.65f;
            }
            AudioClip clip = AudioClip.Create("synth_bush", count, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip SynthStep(float duration, bool sand)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(sampleRate * duration);
            float[] samples = new float[count];
            float phase = 0f;
            for (int i = 0; i < count; i++)
            {
                float t = (float)i / count;
                float env = Mathf.Exp(-t * (sand ? 22f : 30f));
                phase += 2f * Mathf.PI * (sand ? 95f : 140f) / sampleRate;
                float thud = Mathf.Sin(phase) * 0.5f;
                float noise = UnityEngine.Random.Range(-0.4f, 0.4f) * (sand ? 0.7f : 0.3f);
                samples[i] = (thud + noise) * env * 0.6f;
            }
            AudioClip clip = AudioClip.Create("synth_step", count, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip SynthEat(float duration)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(sampleRate * duration);
            float[] samples = new float[count];
            for (int i = 0; i < count; i++)
            {
                float t = (float)i / count;
                float crunch = UnityEngine.Random.Range(-0.6f, 0.6f) * Mathf.Sin(t * Mathf.PI * 4f);
                float env = Mathf.Exp(-t * 6f);
                samples[i] = crunch * env * 0.7f;
            }
            AudioClip clip = AudioClip.Create("synth_eat", count, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip SynthDrink(float duration)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(sampleRate * duration);
            float[] samples = new float[count];
            float phase = 0f;
            for (int i = 0; i < count; i++)
            {
                float t = (float)i / count;
                phase += 2f * Mathf.PI * Mathf.Lerp(260f, 480f, t) / sampleRate;
                float gulp = Mathf.Sin(phase) * Mathf.Sin(t * Mathf.PI) * 0.75f;
                samples[i] = gulp;
            }
            AudioClip clip = AudioClip.Create("synth_drink", count, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip SynthCraftOk(float duration)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(sampleRate * duration);
            float[] samples = new float[count];
            float p1 = 0f, p2 = 0f;
            for (int i = 0; i < count; i++)
            {
                float t = (float)i / count;
                p1 += 2f * Mathf.PI * 880f / sampleRate; // A5
                p2 += 2f * Mathf.PI * 1320f / sampleRate; // E6
                float env = Mathf.Exp(-t * 6f);
                float tone = (Mathf.Sin(p1) * 0.5f + Mathf.Sin(p2) * 0.4f) * env;
                samples[i] = tone * 0.8f;
            }
            AudioClip clip = AudioClip.Create("synth_craft_ok", count, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip SynthRest(float duration)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(sampleRate * duration);
            float[] samples = new float[count];
            float p1 = 0f, p2 = 0f, p3 = 0f;
            for (int i = 0; i < count; i++)
            {
                float t = (float)i / count;
                p1 += 2f * Mathf.PI * 330f / sampleRate; // E4
                p2 += 2f * Mathf.PI * 392f / sampleRate; // G4
                p3 += 2f * Mathf.PI * 494f / sampleRate; // B4
                float env = Mathf.Sin(t * Mathf.PI);
                float tone = (Mathf.Sin(p1) * 0.4f + Mathf.Sin(p2) * 0.35f + Mathf.Sin(p3) * 0.3f) * env;
                samples[i] = tone * 0.75f;
            }
            AudioClip clip = AudioClip.Create("synth_rest", count, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip SynthTreasure(float duration)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(sampleRate * duration);
            float[] samples = new float[count];
            float pChime = 0f;
            for (int i = 0; i < count; i++)
            {
                float t = (float)i / count;
                // Chirrido inicial
                float creak = (i < sampleRate * 0.15f) ? (Mathf.Sin(2f * Mathf.PI * 220f * (float)i / sampleRate) * 0.35f + UnityEngine.Random.Range(-0.25f, 0.25f)) : 0f;
                // Chime dorado de oro
                pChime += 2f * Mathf.PI * Mathf.Lerp(1200f, 1800f, t) / sampleRate;
                float chime = Mathf.Sin(pChime) * Mathf.Exp(-t * 5f) * 0.6f;
                samples[i] = Mathf.Clamp(creak + chime, -1f, 1f);
            }
            AudioClip clip = AudioClip.Create("synth_treasure", count, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip SynthSlingshot(float duration)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(sampleRate * duration);
            float[] samples = new float[count];
            float phase = 0f;
            for (int i = 0; i < count; i++)
            {
                float t = (float)i / count;
                float freq = Mathf.Lerp(450f, 950f, t * t);
                phase += 2f * Mathf.PI * freq / sampleRate;
                float snap = (i < sampleRate * 0.03f) ? UnityEngine.Random.Range(-0.8f, 0.8f) : 0f;
                float twang = Mathf.Sin(phase) * Mathf.Exp(-t * 12f);
                samples[i] = Mathf.Clamp((snap * 0.6f + twang * 0.5f), -1f, 1f);
            }
            AudioClip clip = AudioClip.Create("synth_slingshot", count, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }
    }
}
