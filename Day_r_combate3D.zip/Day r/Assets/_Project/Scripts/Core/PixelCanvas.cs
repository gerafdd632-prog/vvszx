﻿using UnityEngine;

namespace PirateSurvival.Core
{
    /// <summary>
    /// Lienzo de pixel art en memoria para dibujar sprites por código con un acabado cuidado:
    /// formas con sombreado, ruido de textura y contorno oscuro automático alrededor de la silueta.
    /// Todo se dibuja sobre un Color32[] y se vuelca a la textura una sola vez (rápido).
    /// Coordenadas: (0,0) abajo a la izquierda, como Texture2D.
    /// </summary>
    public class PixelCanvas
    {
        public readonly int Width;
        public readonly int Height;
        private readonly Color32[] px;

        public PixelCanvas(int width, int height)
        {
            Width = width;
            Height = height;
            px = new Color32[width * height];
        }

        public bool InBounds(int x, int y) => x >= 0 && y >= 0 && x < Width && y < Height;

        public Color32 Get(int x, int y) => InBounds(x, y) ? px[y * Width + x] : new Color32(0, 0, 0, 0);

        public bool IsOpaque(int x, int y) => InBounds(x, y) && px[y * Width + x].a > 0;

        public void Set(int x, int y, Color c)
        {
            if (!InBounds(x, y)) return;
            if (c.a >= 0.999f) { px[y * Width + x] = c; return; }
            if (c.a <= 0f) return;
            Color under = px[y * Width + x];
            float a = c.a + under.a * (1f - c.a);
            Color mixed = a > 0f ? (c * c.a + under * under.a * (1f - c.a)) / a : Color.clear;
            mixed.a = a;
            px[y * Width + x] = mixed;
        }

        /// <summary>Pinta solo si ya hay algo opaco debajo (para sombrear sin salirse de la silueta).</summary>
        public void Tint(int x, int y, Color c)
        {
            if (IsOpaque(x, y)) Set(x, y, c);
        }

        public void Rect(int x0, int y0, int w, int h, Color c)
        {
            for (int y = y0; y < y0 + h; y++)
                for (int x = x0; x < x0 + w; x++)
                    Set(x, y, c);
        }

        public void Ellipse(float cx, float cy, float rx, float ry, Color c)
        {
            int minX = Mathf.FloorToInt(cx - rx), maxX = Mathf.CeilToInt(cx + rx);
            int minY = Mathf.FloorToInt(cy - ry), maxY = Mathf.CeilToInt(cy + ry);
            for (int y = minY; y <= maxY; y++)
                for (int x = minX; x <= maxX; x++)
                {
                    float dx = (x + 0.5f - cx) / rx, dy = (y + 0.5f - cy) / ry;
                    if (dx * dx + dy * dy <= 1f) Set(x, y, c);
                }
        }

        public void Circle(float cx, float cy, float r, Color c) => Ellipse(cx, cy, r, r, c);
        public void Disc(float cx, float cy, float r, Color c) => Circle(cx, cy, r, c);

        /// <summary>Elipse sombreada: luz arriba a la izquierda, sombra abajo a la derecha.</summary>
        public void ShadedEllipse(float cx, float cy, float rx, float ry, Color baseColor, float lightAmount = 0.28f, float shadowAmount = 0.35f)
        {
            Color light = Color.Lerp(baseColor, Color.white, lightAmount);
            Color shadow = Color.Lerp(baseColor, Color.black, shadowAmount);
            int minX = Mathf.FloorToInt(cx - rx), maxX = Mathf.CeilToInt(cx + rx);
            int minY = Mathf.FloorToInt(cy - ry), maxY = Mathf.CeilToInt(cy + ry);
            for (int y = minY; y <= maxY; y++)
                for (int x = minX; x <= maxX; x++)
                {
                    float dx = (x + 0.5f - cx) / rx, dy = (y + 0.5f - cy) / ry;
                    float d = dx * dx + dy * dy;
                    if (d > 1f) continue;
                    float lightDot = -dx * 0.6f + dy * 0.8f; // luz desde arriba-izquierda
                    Color c = baseColor;
                    if (lightDot > 0.45f && d < 0.75f) c = light;
                    else if (lightDot < -0.35f || d > 0.82f && lightDot < 0.1f) c = shadow;
                    Set(x, y, c);
                }
        }

        public void Line(int x0, int y0, int x1, int y1, Color c, int thickness = 1)
        {
            int dx = Mathf.Abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
            int dy = -Mathf.Abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
            int err = dx + dy;
            while (true)
            {
                if (thickness <= 1) Set(x0, y0, c);
                else Rect(x0 - thickness / 2, y0 - thickness / 2, thickness, thickness, c);
                if (x0 == x1 && y0 == y1) break;
                int e2 = 2 * err;
                if (e2 >= dy) { err += dy; x0 += sx; }
                if (e2 <= dx) { err += dx; y0 += sy; }
            }
        }

        /// <summary>Variación de brillo con ruido dentro de la silueta ya pintada (textura de tela, piedra, hojas...).</summary>
        public void Noise(int x0, int y0, int w, int h, float amount, float scale, int seed)
        {
            for (int y = y0; y < y0 + h; y++)
                for (int x = x0; x < x0 + w; x++)
                {
                    if (!IsOpaque(x, y)) continue;
                    float n = Mathf.PerlinNoise((x + seed * 13.1f) * scale, (y + seed * 7.7f) * scale) - 0.5f;
                    n += (Hash(x, y, seed) - 0.5f) * 0.6f;
                    Color c = px[y * Width + x];
                    float k = n * amount;
                    c = k > 0 ? Color.Lerp(c, Color.white, k) : Color.Lerp(c, Color.black, -k);
                    c.a = px[y * Width + x].a / 255f;
                    px[y * Width + x] = c;
                }
        }

        /// <summary>Contorno de 1 píxel alrededor de toda la silueta, del color del borde oscurecido (estilo pixel art).</summary>
        public void Outline(Color outline, bool tintFromNeighbour = true)
        {
            Color32[] copy = (Color32[])px.Clone();
            for (int y = 0; y < Height; y++)
                for (int x = 0; x < Width; x++)
                {
                    if (copy[y * Width + x].a > 0) continue;
                    Color32 neighbour = default;
                    bool found = false;
                    if (x > 0 && copy[y * Width + x - 1].a > 0) { neighbour = copy[y * Width + x - 1]; found = true; }
                    else if (x < Width - 1 && copy[y * Width + x + 1].a > 0) { neighbour = copy[y * Width + x + 1]; found = true; }
                    else if (y > 0 && copy[(y - 1) * Width + x].a > 0) { neighbour = copy[(y - 1) * Width + x]; found = true; }
                    else if (y < Height - 1 && copy[(y + 1) * Width + x].a > 0) { neighbour = copy[(y + 1) * Width + x]; found = true; }
                    if (!found) continue;
                    Color c = tintFromNeighbour ? Color.Lerp((Color)neighbour, outline, 0.75f) : outline;
                    c.a = 1f;
                    px[y * Width + x] = c;
                }
        }

        /// <summary>Sombra suave elíptica en el suelo (se pinta ANTES del objeto).</summary>
        public void GroundShadow(float cx, float cy, float rx, float ry, float alpha = 0.3f)
        {
            Ellipse(cx, cy, rx, ry, new Color(0f, 0f, 0f, alpha));
        }

        public Texture2D ToTexture()
        {
            Texture2D tex = new Texture2D(Width, Height, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Point;
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.SetPixels32(px);
            tex.Apply(false, false);
            return tex;
        }

        /// <summary>Sprite con pivote normalizado. ppu = píxeles por unidad del mundo (16 = 1 casilla por cada 16 px).</summary>
        public Sprite ToSprite(Vector2 pivot, float ppu = 16f)
        {
            Texture2D tex = ToTexture();
            return Sprite.Create(tex, new UnityEngine.Rect(0, 0, Width, Height), pivot, ppu, 0, SpriteMeshType.FullRect);
        }

        /// <summary>Ruido blanco determinista en [0,1).</summary>
        public static float Hash(int x, int y, int seed)
        {
            unchecked
            {
                uint h = (uint)(x * 374761393 + y * 668265263 + seed * 2147483647);
                h = (h ^ (h >> 13)) * 1274126177u;
                h ^= h >> 16;
                return (h & 0xFFFFFF) / 16777216f;
            }
        }
    }
}
