﻿using System;
using UnityEngine;

namespace PirateSurvival.Core
{
    public enum GameScreen { MainMenu, Playing, Paused, Battle, Dead }

    /// <summary>
    /// Estado global de pantalla. Fuera de "Playing" (menú, pausa, combate, muerte) el tiempo se congela
    /// y las entradas de juego se bloquean. La UI usa tiempo no escalado, así que sigue funcionando.
    /// </summary>
    public static class GameState
    {
        public static GameScreen Current { get; private set; } = GameScreen.Playing;
        public static bool IsPlaying => Current == GameScreen.Playing;
        /// <summary>Hay un combate táctico abierto (sigue a true mientras la pausa está encima del combate).</summary>
        public static bool InBattle;
        public static event Action<GameScreen> OnChanged;

        public static void Set(GameScreen screen)
        {
            Current = screen;
            GameInput.GameplayBlocked = screen != GameScreen.Playing;
            Time.timeScale = screen == GameScreen.Playing ? 1f : 0f;
            OnChanged?.Invoke(screen);
        }
    }
}
