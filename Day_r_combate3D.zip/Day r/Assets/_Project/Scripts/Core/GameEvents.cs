﻿using System;
using UnityEngine;

namespace PirateSurvival.Core
{
    /// <summary>
    /// Bus de eventos global estático para desacoplar sistemas en 2D.
    /// Resuelve la dependencia circular Core ↔ Inventory utilizando tipos primitivos (itemId string).
    /// </summary>
    public static class GameEvents
    {
        // Eventos de Estadísticas del Jugador
        public static event Action<float, float> OnHealthChanged; // (actual, max)
        public static event Action<float, float> OnHungerChanged;
        public static event Action<float, float> OnThirstChanged;
        public static event Action<float, float> OnStaminaChanged;
        public static event Action<float> OnTemperatureChanged;
        public static event Action<float> OnWetnessChanged; // (0.0f a 1.0f)
        public static event Action OnPlayerDeath;
        public static event Action OnPlayerRespawn; // Disparado al revivir o cargar partida vivo
        public static event Action<bool> OnPlayerFaint; // true = desmayado, false = recuperado
        public static event Action<float> OnPlayerDamaged; // Disparado al recibir daño (Punto 6)

        public static void TriggerHealthChanged(float current, float max) => OnHealthChanged?.Invoke(current, max);
        public static void TriggerHungerChanged(float current, float max) => OnHungerChanged?.Invoke(current, max);
        public static void TriggerThirstChanged(float current, float max) => OnThirstChanged?.Invoke(current, max);
        public static void TriggerStaminaChanged(float current, float max) => OnStaminaChanged?.Invoke(current, max);
        public static void TriggerTemperatureChanged(float currentTemp) => OnTemperatureChanged?.Invoke(currentTemp);
        public static void TriggerWetnessChanged(float currentWetness) => OnWetnessChanged?.Invoke(currentWetness);
        public static void TriggerPlayerDeath() => OnPlayerDeath?.Invoke();
        public static void TriggerPlayerRespawn() => OnPlayerRespawn?.Invoke();
        public static void TriggerPlayerFaint(bool isFainted) => OnPlayerFaint?.Invoke(isFainted);
        public static void TriggerPlayerDamaged(float amount) => OnPlayerDamaged?.Invoke(amount);

        // Eventos de Inventario y Equipamiento (Sin dependencia de ItemData)
        public static event Action OnInventoryUpdated;
        public static event Action<float, float> OnWeightChanged; // (actual, max)
        public static event Action<string> OnEquippedToolChanged; // itemId de la herramienta o string.Empty
        public static event Action<bool> OnInventoryToggle; // true = abierto, false = cerrado

        public static void TriggerInventoryUpdated() => OnInventoryUpdated?.Invoke();
        public static void TriggerWeightChanged(float current, float max) => OnWeightChanged?.Invoke(current, max);
        public static void TriggerEquippedToolChanged(string toolItemId) => OnEquippedToolChanged?.Invoke(toolItemId);
        public static void TriggerInventoryToggle(bool isOpen) => OnInventoryToggle?.Invoke(isOpen);

        // Eventos de Interacción 2D
        public static event Action<string> OnInteractionPromptChanged; // texto para HUD o string.Empty
        public static event Action<GameObject> OnTargetInteractableChanged; // Objeto objetivo actual para indicador visual

        public static void TriggerInteractionPromptChanged(string promptText) => OnInteractionPromptChanged?.Invoke(promptText);
        public static void TriggerTargetInteractableChanged(GameObject target) => OnTargetInteractableChanged?.Invoke(target);

        // Eventos de Clima y Ciclo Horario
        public static event Action<float> OnTimeUpdated; // hora actual en formato 24h
        public static event Action<string> OnWeatherChanged; // nombre del clima actual

        public static void TriggerTimeUpdated(float currentHour) => OnTimeUpdated?.Invoke(currentHour);
        public static void TriggerWeatherChanged(string weatherName) => OnWeatherChanged?.Invoke(weatherName);

        // Notificaciones y Avisos de HUD (Paso 0.11)
        /// <summary>Algo que le interesa al modo historia: "bebio_agua", "craft:katana"... (StoryManager lo guarda como flag).</summary>
        public static event Action<string> OnStoryEvent;
        public static void TriggerStoryEvent(string id) => OnStoryEvent?.Invoke(id);

        public static event Action<string> OnNotificationMessage; // Mensajes en pantalla (ej. "¡Inventario lleno!")
        public static void TriggerNotificationMessage(string message) => OnNotificationMessage?.Invoke(message);

        // Confirmaciones de acciones irreversibles (mensaje, texto de aceptar, texto de cancelar, acción al aceptar)
        public static event Action<string, string, string, Action> OnConfirmationRequested;

        /// <summary>Pide confirmación a la UI. Devuelve false si no hay ninguna UI escuchando (la acción NO debe ejecutarse).</summary>
        public static bool RequestConfirmation(string message, string confirmLabel, string cancelLabel, Action onConfirm)
        {
            if (OnConfirmationRequested == null) return false;
            OnConfirmationRequested.Invoke(message, confirmLabel, cancelLabel, onConfirm);
            return true;
        }
    }
}
