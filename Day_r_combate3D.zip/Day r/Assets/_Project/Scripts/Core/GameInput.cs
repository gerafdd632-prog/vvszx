﻿using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace PirateSurvival.Core
{
    /// <summary>Atajos del combate táctico.</summary>
    public enum BattleKey { Move, Attack, Strong, Defend, Swap, Reload, Flee, EndTurn, Confirm }

    /// <summary>
    /// Capa de abstracción estática de entrada de usuario.
    /// Soporta automáticamente tanto el New Input System como el Legacy Input Manager,
    /// permitiendo que el proyecto funcione sin importar la configuración de Project Settings.
    /// </summary>

    public static class GameInput
    {
        /// <summary>
        /// Atajos del combate: 1 mover, 2 atacar, 3 golpe fuerte, 4 guardia, 5 cambiar arma, R recargar, F huir,
        /// Espacio terminar turno, Intro/Espacio confirmar. Solo los bloquea un modal (la pausa la filtra BattleUI).
        /// </summary>
        public static bool IsBattleKeyPressed(BattleKey key)
        {
            if (ModalBlocked) return false;
#if ENABLE_INPUT_SYSTEM
            Keyboard k = Keyboard.current;
            if (k == null) return false;
            switch (key)
            {
                case BattleKey.Move: return k.digit1Key.wasPressedThisFrame || k.numpad1Key.wasPressedThisFrame;
                case BattleKey.Attack: return k.digit2Key.wasPressedThisFrame || k.numpad2Key.wasPressedThisFrame;
                case BattleKey.Strong: return k.digit3Key.wasPressedThisFrame || k.numpad3Key.wasPressedThisFrame;
                case BattleKey.Defend: return k.digit4Key.wasPressedThisFrame || k.numpad4Key.wasPressedThisFrame;
                case BattleKey.Swap: return k.digit5Key.wasPressedThisFrame || k.numpad5Key.wasPressedThisFrame;
                case BattleKey.Reload: return k.rKey.wasPressedThisFrame;
                case BattleKey.Flee: return k.fKey.wasPressedThisFrame;
                case BattleKey.EndTurn: return k.spaceKey.wasPressedThisFrame;
                case BattleKey.Confirm: return k.spaceKey.wasPressedThisFrame || k.enterKey.wasPressedThisFrame || k.numpadEnterKey.wasPressedThisFrame;
                default: return false;
            }
#else
            switch (key)
            {
                case BattleKey.Move: return Input.GetKeyDown(KeyCode.Alpha1) || Input.GetKeyDown(KeyCode.Keypad1);
                case BattleKey.Attack: return Input.GetKeyDown(KeyCode.Alpha2) || Input.GetKeyDown(KeyCode.Keypad2);
                case BattleKey.Strong: return Input.GetKeyDown(KeyCode.Alpha3) || Input.GetKeyDown(KeyCode.Keypad3);
                case BattleKey.Defend: return Input.GetKeyDown(KeyCode.Alpha4) || Input.GetKeyDown(KeyCode.Keypad4);
                case BattleKey.Swap: return Input.GetKeyDown(KeyCode.Alpha5) || Input.GetKeyDown(KeyCode.Keypad5);
                case BattleKey.Reload: return Input.GetKeyDown(KeyCode.R);
                case BattleKey.Flee: return Input.GetKeyDown(KeyCode.F);
                case BattleKey.EndTurn: return Input.GetKeyDown(KeyCode.Space);
                case BattleKey.Confirm: return Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter);
                default: return false;
            }
#endif
        }

        /// <summary>Tecla numérica 1-9 en combate (0 = ninguna). Solo la bloquea un modal; la pausa la filtra quien la usa.</summary>
        public static int GetBattleDigitPressed()
        {
            if (ModalBlocked) return 0;
#if ENABLE_INPUT_SYSTEM
            Keyboard k = Keyboard.current;
            if (k == null) return 0;
            if (k.digit1Key.wasPressedThisFrame || k.numpad1Key.wasPressedThisFrame) return 1;
            if (k.digit2Key.wasPressedThisFrame || k.numpad2Key.wasPressedThisFrame) return 2;
            if (k.digit3Key.wasPressedThisFrame || k.numpad3Key.wasPressedThisFrame) return 3;
            if (k.digit4Key.wasPressedThisFrame || k.numpad4Key.wasPressedThisFrame) return 4;
            if (k.digit5Key.wasPressedThisFrame || k.numpad5Key.wasPressedThisFrame) return 5;
            if (k.digit6Key.wasPressedThisFrame || k.numpad6Key.wasPressedThisFrame) return 6;
            if (k.digit7Key.wasPressedThisFrame || k.numpad7Key.wasPressedThisFrame) return 7;
            if (k.digit8Key.wasPressedThisFrame || k.numpad8Key.wasPressedThisFrame) return 8;
            if (k.digit9Key.wasPressedThisFrame || k.numpad9Key.wasPressedThisFrame) return 9;
            return 0;
#else
            for (int i = 1; i <= 9; i++)
            {
                if (Input.GetKeyDown(KeyCode.Alpha0 + i) || Input.GetKeyDown(KeyCode.Keypad0 + i)) return i;
            }
            return 0;
#endif
        }

        /// <summary>Volver atrás en un submenú de combate: Retroceso o clic derecho.</summary>
        public static bool IsBattleBackPressed()
        {
            if (ModalBlocked) return false;
#if ENABLE_INPUT_SYSTEM
            bool key = Keyboard.current != null && Keyboard.current.backspaceKey.wasPressedThisFrame;
            bool mouse = Mouse.current != null && Mouse.current.rightButton.wasPressedThisFrame;
            return key || mouse;
#else
            return Input.GetKeyDown(KeyCode.Backspace) || Input.GetMouseButtonDown(1);
#endif
        }

        /// <summary>true en menús y pausa: las entradas de juego devuelven "sin pulsar". ESC (IsCancelPressed) sigue activo para los menús.</summary>
        public static bool GameplayBlocked;

        /// <summary>true mientras hay una confirmación modal abierta (MenuManager). Bloquea lo mismo que GameplayBlocked sin tocar GameState.</summary>
        public static bool ModalBlocked;

        /// <summary>true mientras hay una conversación abierta (DialogueUI): el mundo no recibe teclas.</summary>
        public static bool DialogueBlocked;

        private static bool Blocked => GameplayBlocked || ModalBlocked || DialogueBlocked;

        /// <summary>Avanzar diálogo: E, Espacio o Intro (no depende de los bloqueos de juego).</summary>
        public static bool IsDialogueAdvancePressed()
        {
#if ENABLE_INPUT_SYSTEM
            Keyboard keyboard = Keyboard.current;
            return keyboard != null && (keyboard.eKey.wasPressedThisFrame || keyboard.spaceKey.wasPressedThisFrame || keyboard.enterKey.wasPressedThisFrame);
#else
            return Input.GetKeyDown(KeyCode.E) || Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Return);
#endif
        }

        /// <summary>Tecla numérica 1-4 pulsada este frame (0 = ninguna). Para elegir respuestas.</summary>
        public static int GetChoiceNumberPressed()
        {
#if ENABLE_INPUT_SYSTEM
            Keyboard keyboard = Keyboard.current;
            if (keyboard == null) return 0;
            if (keyboard.digit1Key.wasPressedThisFrame || keyboard.numpad1Key.wasPressedThisFrame) return 1;
            if (keyboard.digit2Key.wasPressedThisFrame || keyboard.numpad2Key.wasPressedThisFrame) return 2;
            if (keyboard.digit3Key.wasPressedThisFrame || keyboard.numpad3Key.wasPressedThisFrame) return 3;
            if (keyboard.digit4Key.wasPressedThisFrame || keyboard.numpad4Key.wasPressedThisFrame) return 4;
            return 0;
#else
            if (Input.GetKeyDown(KeyCode.Alpha1) || Input.GetKeyDown(KeyCode.Keypad1)) return 1;
            if (Input.GetKeyDown(KeyCode.Alpha2) || Input.GetKeyDown(KeyCode.Keypad2)) return 2;
            if (Input.GetKeyDown(KeyCode.Alpha3) || Input.GetKeyDown(KeyCode.Keypad3)) return 3;
            if (Input.GetKeyDown(KeyCode.Alpha4) || Input.GetKeyDown(KeyCode.Keypad4)) return 4;
            return 0;
#endif
        }

        /// <summary>Tecla numérica 1-9 pulsada durante la exploración para acceso rápido de mochila (0 = ninguna).</summary>
        public static int GetHotbarNumberPressed()
        {
            if (Blocked) return 0;
#if ENABLE_INPUT_SYSTEM
            Keyboard k = Keyboard.current;
            if (k == null) return 0;
            if (k.digit1Key.wasPressedThisFrame) return 1;
            if (k.digit2Key.wasPressedThisFrame) return 2;
            if (k.digit3Key.wasPressedThisFrame) return 3;
            if (k.digit4Key.wasPressedThisFrame) return 4;
            if (k.digit5Key.wasPressedThisFrame) return 5;
            if (k.digit6Key.wasPressedThisFrame) return 6;
            if (k.digit7Key.wasPressedThisFrame) return 7;
            if (k.digit8Key.wasPressedThisFrame) return 8;
            if (k.digit9Key.wasPressedThisFrame) return 9;
            return 0;
#else
            if (Input.GetKeyDown(KeyCode.Alpha1)) return 1;
            if (Input.GetKeyDown(KeyCode.Alpha2)) return 2;
            if (Input.GetKeyDown(KeyCode.Alpha3)) return 3;
            if (Input.GetKeyDown(KeyCode.Alpha4)) return 4;
            if (Input.GetKeyDown(KeyCode.Alpha5)) return 5;
            if (Input.GetKeyDown(KeyCode.Alpha6)) return 6;
            if (Input.GetKeyDown(KeyCode.Alpha7)) return 7;
            if (Input.GetKeyDown(KeyCode.Alpha8)) return 8;
            if (Input.GetKeyDown(KeyCode.Alpha9)) return 9;
            return 0;
#endif
        }

        public static Vector2 GetMoveVector()
        {
            if (Blocked) return Vector2.zero;
            float h = 0f;
            float v = 0f;

#if ENABLE_INPUT_SYSTEM
            Keyboard keyboard = Keyboard.current;
            if (keyboard != null)
            {
                if (keyboard.wKey.isPressed || keyboard.upArrowKey.isPressed) v += 1f;
                if (keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed) v -= 1f;
                if (keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed) h += 1f;
                if (keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed) h -= 1f;
            }

            Gamepad gamepad = Gamepad.current;
            if (gamepad != null)
            {
                Vector2 stick = gamepad.leftStick.ReadValue();
                if (stick.sqrMagnitude > 0.04f)
                {
                    h += stick.x;
                    v += stick.y;
                }
            }
#else
            h = Input.GetAxisRaw("Horizontal");
            v = Input.GetAxisRaw("Vertical");
#endif

            Vector2 move = new Vector2(h, v);
            return move.sqrMagnitude > 1f ? move.normalized : move;
        }

        public static bool IsSprintHeld()
        {
            if (Blocked) return false;
#if ENABLE_INPUT_SYSTEM
            Keyboard keyboard = Keyboard.current;
            return keyboard != null && (keyboard.leftShiftKey.isPressed || keyboard.rightShiftKey.isPressed);
#else
            return Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift);
#endif
        }

        public static bool IsInteractPressed()
        {
            if (Blocked) return false;
#if ENABLE_INPUT_SYSTEM
            Keyboard keyboard = Keyboard.current;
            return keyboard != null && keyboard.eKey.wasPressedThisFrame;
#else
            return Input.GetKeyDown(KeyCode.E);
#endif
        }

        public static bool IsInteractHeld()
        {
            if (Blocked) return false;
#if ENABLE_INPUT_SYSTEM
            Keyboard keyboard = Keyboard.current;
            return keyboard != null && keyboard.eKey.isPressed;
#else
            return Input.GetKey(KeyCode.E);
#endif
        }

        public static bool IsInventoryTogglePressed()
        {
            if (Blocked) return false;
#if ENABLE_INPUT_SYSTEM
            Keyboard keyboard = Keyboard.current;
            return keyboard != null && (keyboard.tabKey.wasPressedThisFrame || keyboard.iKey.wasPressedThisFrame);
#else
            return Input.GetKeyDown(KeyCode.Tab) || Input.GetKeyDown(KeyCode.I);
#endif
        }

        public static bool IsCancelPressed()
        {
#if ENABLE_INPUT_SYSTEM
            Keyboard keyboard = Keyboard.current;
            return keyboard != null && keyboard.escapeKey.wasPressedThisFrame;
#else
            return Input.GetKeyDown(KeyCode.Escape);
#endif
        }

        public static bool IsQuickSavePressed()
        {
            // En combate sí se lee, para que SaveManager avise de que no se puede guardar
            if (ModalBlocked || (GameplayBlocked && GameState.Current != GameScreen.Battle)) return false;
#if ENABLE_INPUT_SYSTEM
            Keyboard keyboard = Keyboard.current;
            return keyboard != null && keyboard.f5Key.wasPressedThisFrame;
#else
            return Input.GetKeyDown(KeyCode.F5);
#endif
        }

        public static bool IsQuickLoadPressed()
        {
            if (Blocked) return false;
#if ENABLE_INPUT_SYSTEM
            Keyboard keyboard = Keyboard.current;
            return keyboard != null && keyboard.f9Key.wasPressedThisFrame;
#else
            return Input.GetKeyDown(KeyCode.F9);
#endif
        }

        public static bool IsF2Pressed()
        {
#if ENABLE_INPUT_SYSTEM
            Keyboard keyboard = Keyboard.current;
            return keyboard != null && keyboard.f2Key.wasPressedThisFrame;
#else
            return Input.GetKeyDown(KeyCode.F2);
#endif
        }

        /// <summary>Golpe en el mundo: clic izquierdo o [F]. 'fromMouse' indica si fue con el ratón (para ignorar clics sobre la UI).</summary>
        public static bool IsAttackPressed(out bool fromMouse)
        {
            fromMouse = false;
            if (Blocked) return false;
#if ENABLE_INPUT_SYSTEM
            Mouse mouse = Mouse.current;
            Keyboard keyboard = Keyboard.current;
            if (mouse != null && mouse.leftButton.wasPressedThisFrame) { fromMouse = true; return true; }
            return keyboard != null && keyboard.fKey.wasPressedThisFrame;
#else
            if (Input.GetMouseButtonDown(0)) { fromMouse = true; return true; }
            return Input.GetKeyDown(KeyCode.F);
#endif
        }

        public static bool IsAimHeld()
        {
            if (Blocked) return false;
#if ENABLE_INPUT_SYSTEM
            Mouse mouse = Mouse.current;
            return mouse != null && mouse.rightButton.isPressed;
#else
            return Input.GetMouseButton(1);
#endif
        }

        public static Vector2 GetMouseScreenPosition()
        {
#if ENABLE_INPUT_SYSTEM
            Mouse mouse = Mouse.current;
            return mouse != null ? mouse.position.ReadValue() : Vector2.zero;
#else
            return Input.mousePosition;
#endif
        }

        public static Vector2 GetMouseWorldPosition(Camera cam)
        {
            if (cam == null) cam = Camera.main;
            if (cam == null) return Vector2.zero;

            Vector2 screenPos = GetMouseScreenPosition();
            Vector3 worldPoint = cam.ScreenToWorldPoint(new Vector3(screenPos.x, screenPos.y, cam.nearClipPlane));
            return new Vector2(worldPoint.x, worldPoint.y);
        }

        public static float GetScrollDelta()
        {
            if (Blocked) return 0f;
#if ENABLE_INPUT_SYSTEM
            Mouse mouse = Mouse.current;
            if (mouse == null) return 0f;
            float raw = mouse.scroll.ReadValue().y;
            if (Mathf.Abs(raw) < 0.001f) return 0f;
            return Mathf.Sign(raw);
#else
            float raw = Input.mouseScrollDelta.y;
            if (Mathf.Abs(raw) < 0.001f) return 0f;
            return Mathf.Sign(raw);
#endif
        }

        public static bool IsShiftHeld()
        {
            if (Blocked) return false;
#if ENABLE_INPUT_SYSTEM
            Keyboard keyboard = Keyboard.current;
            return keyboard != null && (keyboard.leftShiftKey.isPressed || keyboard.rightShiftKey.isPressed);
#else
            return Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift);
#endif
        }
    }
}
