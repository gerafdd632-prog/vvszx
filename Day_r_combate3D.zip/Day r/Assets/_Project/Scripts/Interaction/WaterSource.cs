﻿using UnityEngine;
using PirateSurvival.Player;
using PirateSurvival.Core;

namespace PirateSurvival.Interaction
{
    public enum WaterType
    {
        FreshWater,
        SaltWater
    }

    /// <summary>
    /// Fuente desde la que se puede BEBER (charca de agua dulce, orilla del mar).
    /// Solo gestiona beber: no moja, no gasta estamina, no ahoga ni activa la debilidad de las Frutas del Diablo.
    /// Estar dentro del mar es responsabilidad de SeaZone + PlayerSwimming.
    /// </summary>
    [RequireComponent(typeof(Collider2D))]
    public class WaterSource : MonoBehaviour, IInteractable
    {
        [Header("Tipo de Agua")]
        [SerializeField] private WaterType waterType = WaterType.FreshWater;
        [SerializeField] private float thirstRecovery = 25f;
        [SerializeField] private float saltWaterThirstPenalty = -15f;
        [SerializeField] private float saltWaterDamage = 6f;
        [SerializeField] private float seaWaterDrinkCooldown = 2.5f;
        [SerializeField] private AudioClip drinkSound;

        private float lastSeaDrinkTime = -10f;

        // Por debajo de este margen beber apenas movería la barra: se trata como "sin sed"
        private const float FullMargin = 2f;
        private static PlayerStats cachedStats;

        public WaterType Type => waterType;

        private void OnValidate()
        {
            Collider2D col = GetComponent<Collider2D>();
            if (col != null && !col.isTrigger)
            {
                col.isTrigger = true;
            }
        }

        public string GetPromptText()
        {
            if (waterType == WaterType.FreshWater)
            {
                if (cachedStats == null) cachedStats = FindAnyObjectByType<PlayerStats>();
                PlayerStats stats = cachedStats;
                if (stats != null && stats.CurrentThirst >= stats.MaxThirst - FullMargin)
                {
                    return "Agua dulce (ahora no tienes sed)";
                }
                return "Pulsa [E] para beber agua dulce";
            }
            else
            {
                return "Pulsa [E] para beber agua de mar (¡Peligro de deshidratación severa!)";
            }
        }

        public void Interact(PlayerInteraction2D interactor)
        {
            PlayerStats stats = interactor.GetComponentInParent<PlayerStats>();
            if (stats == null) stats = interactor.GetComponent<PlayerStats>();
            if (stats == null) return;

            if (waterType == WaterType.FreshWater)
            {
                // Punto 12: Si la sed ya está llena, no gastar interacción y avisar
                if (stats.CurrentThirst >= stats.MaxThirst - FullMargin)
                {
                    GameEvents.TriggerNotificationMessage("No tienes sed ahora mismo.");
                    GameEvents.TriggerStoryEvent("bebio_agua"); // ya sabe dónde beber: el objetivo cuenta igual
                    return;
                }
                float before = stats.CurrentThirst;

                if (drinkSound != null)
                {
                    AudioSource.PlayClipAtPoint(drinkSound, transform.position);
                }

                stats.ModifyThirst(thirstRecovery);
                stats.ModifyTemperature(-0.4f);
                GameEvents.TriggerNotificationMessage($"Bebes agua dulce. Sed {before:0} → {stats.CurrentThirst:0}");
                GameEvents.TriggerStoryEvent("bebio_agua");
            }
            else
            {
                // Punto 12: Cooldown para beber agua de mar
                if (Time.time < lastSeaDrinkTime + seaWaterDrinkCooldown)
                {
                    GameEvents.TriggerNotificationMessage("¡Espera antes de beber más agua salada!");
                    return;
                }

                lastSeaDrinkTime = Time.time;

                if (drinkSound != null)
                {
                    AudioSource.PlayClipAtPoint(drinkSound, transform.position);
                }

                stats.ModifyThirst(saltWaterThirstPenalty);
                stats.TakeDamage(saltWaterDamage, DeathCause.Dehydration);
                GameEvents.TriggerNotificationMessage("¡El agua de mar te da MÁS sed y te hace daño! Busca agua dulce.");
            }
        }

        public bool CanInteract()
        {
            return true;
        }
    }
}
