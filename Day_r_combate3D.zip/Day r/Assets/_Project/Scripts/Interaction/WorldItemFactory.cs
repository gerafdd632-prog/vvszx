﻿using UnityEngine;
using PirateSurvival.Inventory;
using PirateSurvival.Player;

namespace PirateSurvival.Interaction
{
    /// <summary>
    /// Factoría estática para instanciar objetos coleccionables en el mundo 2D (Item D).
    /// Si el ItemData no tiene worldPrefab, construye automáticamente un objeto con SpriteRenderer,
    /// CircleCollider2D, Rigidbody2D y YSorter, garantizando que NINGÚN objeto se pierda.
    /// </summary>
    public static class WorldItemFactory
    {
        public static GameObject Spawn(ItemData item, int quantity, Vector2 position, Vector2 impulse = default)
        {
            if (item == null || quantity <= 0) return null;

            GameObject pickupObj;

            if (item.worldPrefab != null)
            {
                pickupObj = Object.Instantiate(item.worldPrefab, new Vector3(position.x, position.y, 0f), Quaternion.identity);
            }
            else
            {
                pickupObj = new GameObject($"Pickup_{item.itemName}");
                pickupObj.transform.position = new Vector3(position.x, position.y, 0f);

                // Configurar SpriteRenderer
                SpriteRenderer sr = pickupObj.AddComponent<SpriteRenderer>();
                sr.sprite = item.icon;
                sr.sortingOrder = 0;

                // Configurar Collider2D como trigger (Paso 0.10: no bloquea el paso del jugador)
                CircleCollider2D col = pickupObj.AddComponent<CircleCollider2D>();
                col.radius = 0.35f;
                col.isTrigger = true;

                // Configurar Rigidbody2D para frenado suave tras el impulso
                Rigidbody2D rb = pickupObj.AddComponent<Rigidbody2D>();
                rb.gravityScale = 0f;
                rb.linearDamping = 3.5f;
                rb.constraints = RigidbodyConstraints2D.FreezeRotation;

                // Configurar YSorter
                YSorter sorter = pickupObj.AddComponent<YSorter>();
                sorter.IsStatic = false;
            }

            // Asegurar que cualquier collider del prefab también sea trigger
            Collider2D[] existingColliders = pickupObj.GetComponentsInChildren<Collider2D>();
            for (int i = 0; i < existingColliders.Length; i++)
            {
                existingColliders[i].isTrigger = true;
            }

            // Configurar componente de recolección
            WorldItemPickup pickupComp = pickupObj.GetComponent<WorldItemPickup>();
            if (pickupComp == null)
            {
                pickupComp = pickupObj.AddComponent<WorldItemPickup>();
            }
            pickupComp.Configure(item, quantity);

            // Aplicar impulso físico
            if (impulse.sqrMagnitude > 0.001f)
            {
                Rigidbody2D rb = pickupObj.GetComponent<Rigidbody2D>();
                if (rb != null)
                {
                    rb.AddForce(impulse, ForceMode2D.Impulse);
                }
            }

            return pickupObj;
        }
    }
}
