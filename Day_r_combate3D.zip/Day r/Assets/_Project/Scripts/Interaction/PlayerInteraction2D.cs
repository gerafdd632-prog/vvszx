﻿using System.Collections.Generic;
using UnityEngine;
using PirateSurvival.Core;
using PirateSurvival.Player;

namespace PirateSurvival.Interaction
{
    /// <summary>
    /// Escanea objetos interactuables en 2D (Item H).
    /// Utiliza ContactFilter2D y Physics2D.OverlapCircle (API moderna no obsoleta),
    /// calcula la distancia con Collider2D.ClosestPoint, soporta mantener pulsado [E] con cooldown,
    /// y autoconfigura LayerMasks si no están asignadas para no requerir configuración manual en el editor.
    /// </summary>
    public class PlayerInteraction2D : MonoBehaviour
    {
        [Header("Detección en 2D")]
        [Tooltip("Radio de interacción")]
        [SerializeField] private float interactionRadius = 2.2f;
        [Tooltip("Capa de interactuables (si está vacía, detecta todas excepto la del jugador)")]
        [SerializeField] private LayerMask interactableLayers;
        [Tooltip("Capa de paredes y obstáculos que bloquean la línea de visión")]
        [SerializeField] private LayerMask obstacleLayers;

        [Header("Comprobación de Obstáculos")]
        [SerializeField] private bool checkObstacles = true;

        [Header("Repetición de Acción (Mantener E)")]
        [Tooltip("Intervalo en segundos entre golpes automáticos al mantener pulsado E")]
        [SerializeField] private float repeatCooldown = 0.45f;

        private PlayerStats playerStats;
        private PlayerAnimation2D playerAnimation;
        private IInteractable currentInteractable;
        private GameObject currentTargetObject;
        private string lastPromptText = string.Empty;
        private bool isInventoryOpen = false;

        private float holdTimer = 0f;
        private readonly List<Collider2D> hitBuffer = new List<Collider2D>(16);
        private ContactFilter2D contactFilter;

        private void Awake()
        {
            playerStats = GetComponent<PlayerStats>();
            playerAnimation = GetComponent<PlayerAnimation2D>();

            SetupContactFilter();
        }

        private void OnEnable()
        {
            GameEvents.OnEquippedToolChanged += HandleEquippedToolChanged;
            GameEvents.OnInventoryToggle += HandleInventoryToggle;
        }

        private void OnDisable()
        {
            GameEvents.OnEquippedToolChanged -= HandleEquippedToolChanged;
            GameEvents.OnInventoryToggle -= HandleInventoryToggle;
        }

        private void SetupContactFilter()
        {
            contactFilter = new ContactFilter2D();
            contactFilter.useTriggers = true;

            // Si interactableLayers está vacía, usar TODAS las capas. (Excluir la capa del jugador dejaba fuera
            // la capa Default, donde está todo el mundo generado, y no se detectaba nada.) El propio jugador
            // se descarta más abajo porque no es IInteractable.
            if (interactableLayers.value == 0)
            {
                contactFilter.SetLayerMask(~0);
            }
            else
            {
                contactFilter.SetLayerMask(interactableLayers);
            }
        }

        private void Update()
        {
            // Paso 0.8: Bloquea la interacción si el jugador está muerto o desmayado
            // Sin interacción fuera de Playing (combate, pausa, menú, muerte) ni con una confirmación abierta
            if ((playerStats != null && (playerStats.IsDead || playerStats.IsFainted)) || isInventoryOpen ||
                !GameState.IsPlaying || GameInput.ModalBlocked)
            {
                ClearCurrentInteractable();
                holdTimer = 0f;
                return;
            }

            DetectClosestInteractable();
            HandleInteractionInput();
        }

        private void HandleInventoryToggle(bool open)
        {
            isInventoryOpen = open;
            if (isInventoryOpen)
            {
                ClearCurrentInteractable();
            }
        }

        private void HandleEquippedToolChanged(string toolItemId)
        {
            if (currentInteractable != null && currentInteractable.CanInteract())
            {
                UpdatePrompt(currentInteractable.GetPromptText());
            }
        }

        private void DetectClosestInteractable()
        {
            Vector2 playerPos = transform.position;
            hitBuffer.Clear();

            // API moderna no obsoleta (ContactFilter2D)
            Physics2D.OverlapCircle(playerPos, interactionRadius, contactFilter, hitBuffer);

            IInteractable closestInteractable = null;
            GameObject closestObject = null;
            float maxAllowedDistanceSqr = interactionRadius * interactionRadius;
            float closestDistanceSqr = maxAllowedDistanceSqr;

            for (int i = 0; i < hitBuffer.Count; i++)
            {
                Collider2D col = hitBuffer[i];
                if (col == null || col.gameObject == gameObject) continue;

                IInteractable interactable = col.GetComponentInParent<IInteractable>();
                if (interactable == null || !interactable.CanInteract()) continue;

                // Item H: Calcular distancia exacta con Collider2D.ClosestPoint
                Vector2 closestPoint = col.ClosestPoint(playerPos);
                float distSqr = (closestPoint - playerPos).sqrMagnitude;

                // Paso 0.5: Respetar estrictamente interactionRadius
                if (distSqr > maxAllowedDistanceSqr) continue;

                // Comprobación de obstáculos Linecast
                if (checkObstacles && obstacleLayers.value != 0)
                {
                    RaycastHit2D hitObstacle = Physics2D.Linecast(playerPos, closestPoint, obstacleLayers);
                    if (hitObstacle.collider != null && hitObstacle.collider != col && !hitObstacle.collider.isTrigger)
                    {
                        continue;
                    }
                }

                if (distSqr < closestDistanceSqr)
                {
                    closestDistanceSqr = distSqr;
                    closestInteractable = interactable;
                    closestObject = (interactable as Component)?.gameObject ?? col.gameObject;
                }
            }

            if (closestInteractable != null)
            {
                if (currentInteractable != closestInteractable)
                {
                    currentInteractable = closestInteractable;
                    currentTargetObject = closestObject;
                    GameEvents.TriggerTargetInteractableChanged(currentTargetObject);
                }
                UpdatePrompt(currentInteractable.GetPromptText());
            }
            else
            {
                ClearCurrentInteractable();
            }
        }

        private void HandleInteractionInput()
        {
            if (currentInteractable == null)
            {
                holdTimer = 0f;
                return;
            }

            // Primer toque con E
            if (GameInput.IsInteractPressed())
            {
                holdTimer = 0f;
                PerformInteraction();
            }
            // Item H: Mantener pulsado E con cooldown
            else if (GameInput.IsInteractHeld())
            {
                holdTimer += Time.deltaTime;
                if (holdTimer >= repeatCooldown)
                {
                    holdTimer = 0f;
                    PerformInteraction();
                }
            }
            else
            {
                holdTimer = 0f;
            }
        }

        private void PerformInteraction()
        {
            if (currentInteractable == null) return;

            if (playerAnimation != null)
            {
                playerAnimation.TriggerInteractAnimation();
            }

            currentInteractable.Interact(this);

            if (currentInteractable == null || !currentInteractable.CanInteract())
            {
                ClearCurrentInteractable();
            }
            else
            {
                UpdatePrompt(currentInteractable.GetPromptText());
            }
        }

        private void UpdatePrompt(string newPrompt)
        {
            if (lastPromptText != newPrompt)
            {
                lastPromptText = newPrompt;
                GameEvents.TriggerInteractionPromptChanged(lastPromptText);
            }
        }

        private void ClearCurrentInteractable()
        {
            if (currentInteractable != null || currentTargetObject != null || !string.IsNullOrEmpty(lastPromptText))
            {
                currentInteractable = null;
                currentTargetObject = null;
                GameEvents.TriggerTargetInteractableChanged(null);
                UpdatePrompt(string.Empty);
            }
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.cyan;
            Gizmos.DrawWireSphere(transform.position, interactionRadius);
        }
    }
}
