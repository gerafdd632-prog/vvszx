﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PirateSurvival.Inventory;
using PirateSurvival.Player;

namespace PirateSurvival.Interaction
{
    public enum ResourceType
    {
        Tree,
        Rock,
        Bush // arbustos y matorrales: se recogen con las manos
    }

    /// <summary>
    /// Recurso cosechable en 2D (árboles para madera, vetas para piedra/mineral).
    /// Utiliza WorldItemFactory para garantizar la generación de botín (Item D),
    /// valida escenas en OnValidate sin contaminar prefabs y regenera IDs duplicados automáticamente (A2.I.3).
    /// </summary>
    [RequireComponent(typeof(Collider2D))]
    public class HarvestableResource : MonoBehaviour, IInteractable
    {
        private static readonly Dictionary<string, HarvestableResource> SceneResourceRegistry = new Dictionary<string, HarvestableResource>();

        [Header("Identificación")]
        [Tooltip("Identificador único de la instancia en la escena")]
        [SerializeField] private string resourceId;

        [Header("Tipo de Recurso")]
        [SerializeField] private ResourceType resourceType = ResourceType.Tree;
        [SerializeField] private string resourceName = "Palmera";
        [SerializeField] private ToolType requiredTool = ToolType.Axe;

        [Header("Resistencia")]
        [SerializeField] private float maxHealth = 50f;
        [SerializeField] private float unarmedDamage = 0f;

        [Header("Reaparición")]
        [SerializeField] private float respawnTimeMinutes = 4f;

        [Header("Botín 2D")]
        [SerializeField] private ItemData dropItem;
        [SerializeField] private int minDropAmount = 2;
        [SerializeField] private int maxDropAmount = 4;
        [Tooltip("Botín extra poco común (p. ej. Kairoseki en las vetas de la cueva)")]
        [SerializeField] private ItemData bonusDropItem;
        [Range(0f, 1f)] [SerializeField] private float bonusDropChance = 0f;

        [Header("Efectos Audiovisuales")]
        [SerializeField] private AudioClip hitSound;
        [SerializeField] private AudioClip ineffectiveHitSound;
        [SerializeField] private AudioClip destroySound;

        private float currentHealth;
        private bool isHarvested = false;
        private float remainingRespawnTime = 0f;

        private Vector2 originalLocalPos;
        private SpriteRenderer[] childRenderers;
        private Collider2D[] allColliders;

        public string ResourceId => resourceId;
        public bool IsHarvested => isHarvested;
        public float RemainingRespawnTime => remainingRespawnTime;
        public float CurrentHealth => currentHealth;
        public float MaxHealth => maxHealth;

        private void OnValidate()
        {
            // Punto 15: Validar que tenga ID en escena sin generar con posición
            if (gameObject.scene.IsValid() && !string.IsNullOrEmpty(gameObject.scene.name))
            {
                if (string.IsNullOrEmpty(resourceId))
                {
                    resourceId = gameObject.name;
                }
            }

            if (resourceType == ResourceType.Rock && unarmedDamage > 0f)
            {
                unarmedDamage = 0f;
            }
        }

        private void Awake()
        {
            currentHealth = maxHealth;
            originalLocalPos = transform.localPosition;
            childRenderers = GetComponentsInChildren<SpriteRenderer>();
            allColliders = GetComponentsInChildren<Collider2D>();

            RegisterResourceId();
        }

        private void OnDestroy()
        {
            if (!string.IsNullOrEmpty(resourceId) && SceneResourceRegistry.ContainsKey(resourceId))
            {
                if (SceneResourceRegistry[resourceId] == this)
                {
                    SceneResourceRegistry.Remove(resourceId);
                }
            }
        }

        /// <summary>
        /// Punto 15: Registra el ID persistente guardado en la escena sin mutarlo por posición en tiempo de ejecución.
        /// </summary>
        private void RegisterResourceId()
        {
            if (string.IsNullOrEmpty(resourceId))
            {
                resourceId = gameObject.name;
            }

            if (SceneResourceRegistry.TryGetValue(resourceId, out var existing) && existing != null && existing != this)
            {
                Debug.LogWarning($"[HarvestableResource] resourceId duplicado: '{resourceId}' en '{gameObject.name}'. Usa 'Pirate Survival/Reparar IDs de Recursos' en el Editor.");
            }

            SceneResourceRegistry[resourceId] = this;
        }

        /// <summary>
        /// Asigna el ID persistente desde código (GameBootstrap). Awake ya registró el nombre del GameObject, así que se re-registra.
        /// </summary>
        public void SetResourceId(string id)
        {
            if (string.IsNullOrEmpty(id) || id == resourceId) return;
            if (!string.IsNullOrEmpty(resourceId) && SceneResourceRegistry.TryGetValue(resourceId, out var current) && current == this)
            {
                SceneResourceRegistry.Remove(resourceId);
            }
            resourceId = id;
            RegisterResourceId();
        }

        private void Update()
        {
            if (isHarvested)
            {
                remainingRespawnTime -= Time.deltaTime;
                if (remainingRespawnTime <= 0f)
                {
                    Respawn();
                }
            }
        }

        public string GetPromptText()
        {
            if (isHarvested) return string.Empty;
            if (resourceType == ResourceType.Bush) return $"Pulsa [E] para recoger {resourceName}";

            string action = (resourceType == ResourceType.Tree) ? "talar" : "picar";
            string toolName = (requiredTool == ToolType.Axe) ? "Hacha" : ((requiredTool == ToolType.Pickaxe) ? "Pico" : "Herramienta");

            ItemData equipped = InventoryManager.Instance != null ? InventoryManager.Instance.CurrentEquippedTool : null;
            bool hasCorrectTool = equipped != null && equipped.toolType == requiredTool;

            if (hasCorrectTool)
            {
                return $"Pulsa [E] para {action} {resourceName} ({equipped.itemName}) [{currentHealth:F0}/{maxHealth:F0}]";
            }
            else
            {
                if (unarmedDamage <= 0f)
                {
                    return $"Pulsa [E] para examinar {resourceName} (¡Requiere {toolName}! Sin efecto con las manos)";
                }
                else
                {
                    return $"Pulsa [E] para golpear {resourceName} (¡Requiere {toolName} para mayor efectividad!) [{currentHealth:F0}/{maxHealth:F0}]";
                }
            }
        }

        public void Interact(PlayerInteraction2D interactor)
        {
            if (isHarvested) return;

            ItemData equipped = InventoryManager.Instance != null ? InventoryManager.Instance.CurrentEquippedTool : null;
            float damage = unarmedDamage;

            if (equipped != null && equipped.toolType == requiredTool)
            {
                damage = equipped.resourceDamage;
            }

            if (interactor != null)
            {
                PlayerAnimation2D anim = interactor.GetComponent<PlayerAnimation2D>();
                if (anim != null) anim.TriggerInteractAnimation();
            }

            if (damage <= 0f)
            {
                if (ineffectiveHitSound != null || hitSound != null)
                {
                    AudioClip clipToPlay = ineffectiveHitSound != null ? ineffectiveHitSound : hitSound;
                    AudioSource.PlayClipAtPoint(clipToPlay, transform.position);
                }
                else if (PirateSurvival.Core.AudioManager.Instance != null)
                {
                    PirateSurvival.Core.AudioManager.Instance.PlayMiss();
                }

                StartCoroutine(ShakeRoutine(0.08f, 0.04f));
                return;
            }

            if (equipped != null && InventoryManager.Instance != null)
            {
                InventoryManager.Instance.WearItem(equipped, 1);
            }

            TakeHit(damage);
        }

        private void TakeHit(float damage)
        {
            currentHealth -= damage;

            if (hitSound != null)
            {
                AudioSource.PlayClipAtPoint(hitSound, transform.position);
            }
            else if (PirateSurvival.Core.AudioManager.Instance != null)
            {
                if (resourceType == ResourceType.Tree) PirateSurvival.Core.AudioManager.Instance.PlayWoodChop();
                else if (resourceType == ResourceType.Rock) PirateSurvival.Core.AudioManager.Instance.PlayPickaxeHit();
                else PirateSurvival.Core.AudioManager.Instance.PlayBushGather();
            }

            transform.localPosition = originalLocalPos;
            StopAllCoroutines();
            StartCoroutine(ShakeRoutine(0.12f, 0.08f));

            PirateSurvival.Combat.DamagePopup2D.Spawn((Vector2)transform.position + Vector2.up * 0.4f, Mathf.RoundToInt(damage), false);
            PirateSurvival.Player.Camera2D.TriggerShake(0.07f, 0.08f);

            if (currentHealth <= 0f)
            {
                HarvestComplete();
            }
        }

        private IEnumerator ShakeRoutine(float duration, float magnitude)
        {
            transform.localPosition = originalLocalPos;
            float elapsed = 0f;

            while (elapsed < duration)
            {
                float x = UnityEngine.Random.Range(-1f, 1f) * magnitude;
                float y = UnityEngine.Random.Range(-1f, 1f) * magnitude;
                transform.localPosition = originalLocalPos + new Vector2(x, y);

                elapsed += Time.deltaTime;
                yield return null;
            }

            transform.localPosition = originalLocalPos;
        }

        private void OnDisable()
        {
            transform.localPosition = originalLocalPos;
        }

        private void HarvestComplete()
        {
            isHarvested = true;
            remainingRespawnTime = respawnTimeMinutes * 60f;

            if (destroySound != null)
            {
                AudioSource.PlayClipAtPoint(destroySound, transform.position);
            }
            else if (PirateSurvival.Core.AudioManager.Instance != null)
            {
                if (resourceType == ResourceType.Rock) PirateSurvival.Core.AudioManager.Instance.PlayPickaxeHit();
                else PirateSurvival.Core.AudioManager.Instance.PlayWoodChop();
            }

            // Item D: Usar WorldItemFactory para garantizar soltado 100% libre de fallos
            if (dropItem != null)
            {
                int totalDrops = UnityEngine.Random.Range(minDropAmount, maxDropAmount + 1);
                for (int i = 0; i < totalDrops; i++)
                {
                    Vector2 randomOffset = UnityEngine.Random.insideUnitCircle * 1.2f;
                    Vector2 spawnPos = (Vector2)transform.position + randomOffset;
                    Vector2 impulse = (randomOffset.normalized + Vector2.up * 0.35f).normalized * UnityEngine.Random.Range(2.5f, 4f);

                    WorldItemFactory.Spawn(dropItem, 1, spawnPos, impulse);
                }
            }

            if (bonusDropItem != null && UnityEngine.Random.value < bonusDropChance)
            {
                WorldItemFactory.Spawn(bonusDropItem, 1, (Vector2)transform.position + Vector2.down * 0.6f, Vector2.down * 2f);
                PirateSurvival.Core.GameEvents.TriggerNotificationMessage($"¡Has encontrado {bonusDropItem.itemName}!");
            }

            SetVisibilityAndCollision(false);
        }

        private void Respawn()
        {
            isHarvested = false;
            currentHealth = maxHealth;
            remainingRespawnTime = 0f;
            SetVisibilityAndCollision(true);
        }

        private void SetVisibilityAndCollision(bool visible)
        {
            if (childRenderers != null)
            {
                for (int i = 0; i < childRenderers.Length; i++)
                {
                    if (childRenderers[i] != null) childRenderers[i].enabled = visible;
                }
            }

            if (allColliders != null)
            {
                for (int i = 0; i < allColliders.Length; i++)
                {
                    if (allColliders[i] != null) allColliders[i].enabled = visible;
                }
            }
        }

        public void SetHarvestedState(bool harvested, float remainingSeconds)
        {
            isHarvested = harvested;
            remainingRespawnTime = remainingSeconds;

            if (isHarvested)
            {
                currentHealth = 0f;
                SetVisibilityAndCollision(false);
            }
            else
            {
                currentHealth = maxHealth;
                SetVisibilityAndCollision(true);
            }
        }

        public bool CanInteract()
        {
            return !isHarvested;
        }
    }
}
