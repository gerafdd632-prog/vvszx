﻿using System.Collections.Generic;
using UnityEngine;
using PirateSurvival.Core;
using PirateSurvival.Inventory;
using PirateSurvival.Player;

namespace PirateSurvival.Interaction
{
    /// <summary>
    /// Cofre del tesoro interactivo en el mundo 2D.
    /// Al abrirlo reproduce audio triunfal, cambia de aspecto, otorga botín y berries,
    /// y persiste su estado abierto para no poder saquearse repetidamente.
    /// </summary>
    [RequireComponent(typeof(Collider2D))]
    public class TreasureChest : MonoBehaviour, IInteractable
    {
        [Header("Identificación")]
        [SerializeField] private string chestId;

        [Header("Contenido")]
        [SerializeField] private int berriesReward = 1000;
        [SerializeField] private List<string> dropItemIds = new List<string>();
        [SerializeField] private List<int> dropQuantities = new List<int>();

        [Header("Visual")]
        [SerializeField] private Sprite openedSprite;
        private SpriteRenderer spriteRenderer;
        private bool isOpened = false;

        public string ChestId => chestId;
        public bool IsOpened => isOpened;

        public void Configure(string id, int berries, string[] items, int[] quantities, Sprite openSprite = null)
        {
            chestId = id;
            berriesReward = berries;
            dropItemIds = items != null ? new List<string>(items) : new List<string>();
            dropQuantities = quantities != null ? new List<int>(quantities) : new List<int>();
            openedSprite = openSprite;
        }

        public void Configure(string id, int berries, IEnumerable<string> items, IEnumerable<int> quantities, Sprite openSprite = null)
        {
            chestId = id;
            berriesReward = berries;
            dropItemIds = items != null ? new List<string>(items) : new List<string>();
            dropQuantities = quantities != null ? new List<int>(quantities) : new List<int>();
            openedSprite = openSprite;
        }

        private void Awake()
        {
            spriteRenderer = GetComponent<SpriteRenderer>();
            if (string.IsNullOrEmpty(chestId))
            {
                chestId = $"chest_{Mathf.RoundToInt(transform.position.x)}_{Mathf.RoundToInt(transform.position.y)}";
            }
        }

        private void Start()
        {
            PlayerProgress prog = FindAnyObjectByType<PlayerProgress>();
            if (prog != null && prog.HasFlag("opened:" + chestId))
            {
                MarkOpenedVisuals();
            }
        }

        public bool CanInteract() => !isOpened;

        public string GetPromptText()
        {
            return isOpened ? string.Empty : "Pulsa [E] para abrir el Cofre del Tesoro";
        }

        public void Interact(PlayerInteraction2D interactor)
        {
            if (isOpened) return;
            OpenChest(interactor);
        }

        private void OpenChest(PlayerInteraction2D interactor)
        {
            isOpened = true;
            MarkOpenedVisuals();

            if (AudioManager.Instance != null)
            {
                AudioManager.Instance.PlayTreasureOpen();
            }

            PlayerProgress prog = FindAnyObjectByType<PlayerProgress>();
            if (prog != null)
            {
                prog.SetFlag("opened:" + chestId);
                if (berriesReward > 0)
                {
                    prog.AddPlayerBounty(berriesReward);
                }
            }

            InventoryManager inv = InventoryManager.Instance;
            Vector2 spawnPos = (Vector2)transform.position + Vector2.down * 0.5f;

            for (int i = 0; i < dropItemIds.Count; i++)
            {
                string id = dropItemIds[i];
                int qty = i < dropQuantities.Count ? Mathf.Max(1, dropQuantities[i]) : 1;
                ItemData item = ItemDatabase.Get(id);
                if (item != null)
                {
                    if (inv == null || !inv.AddItem(item, qty))
                    {
                        WorldItemFactory.Spawn(item, qty, spawnPos + new Vector2(Random.Range(-0.4f, 0.4f), Random.Range(-0.3f, 0.1f)));
                    }
                }
            }

            string bountyMsg = berriesReward > 0 ? $" ¡+B {berriesReward:N0} Berries!" : "";
            GameEvents.TriggerNotificationMessage($"¡Has abierto un cofre del tesoro!{bountyMsg}");
        }

        private void MarkOpenedVisuals()
        {
            isOpened = true;
            if (spriteRenderer != null && openedSprite != null)
            {
                spriteRenderer.sprite = openedSprite;
            }
            else if (spriteRenderer != null)
            {
                spriteRenderer.color = new Color(0.85f, 0.85f, 0.75f, 1f);
            }
        }
    }
}
