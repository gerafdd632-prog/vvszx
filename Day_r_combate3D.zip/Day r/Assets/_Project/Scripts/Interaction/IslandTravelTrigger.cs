﻿using UnityEngine;
using PirateSurvival.Core;
using PirateSurvival.Player;
using PirateSurvival.Bootstrap;

namespace PirateSurvival.Interaction
{
    /// <summary>
    /// Objeto interactuable en el mundo (timón de navío o bote de remos)
    /// que permite al jugador zarpar entre Isla Coral (Isla 1) e Isla Volcán Negro (Isla 2).
    /// </summary>
    public class IslandTravelTrigger : MonoBehaviour, IInteractable
    {
        [Tooltip("Si es true, viaja a Isla 2. Si es false, regresa a Isla 1.")]
        [SerializeField] private bool toIsland2 = true;

        [Tooltip("Texto opcional personalizado para el prompt.")]
        [SerializeField] private string customPrompt = "";

        public void Setup(bool travelToIsland2, string prompt = "")
        {
            toIsland2 = travelToIsland2;
            customPrompt = prompt;
        }

        public string GetPromptText()
        {
            if (!string.IsNullOrEmpty(customPrompt)) return customPrompt;
            return toIsland2
                ? "Pulsa [E] para Zarpar rumbo a Isla Volcán Negro"
                : "Pulsa [E] para Regresar a Isla Coral";
        }

        public void Interact(PlayerInteraction2D interactor)
        {
            PlayerController2D pc = interactor != null ? interactor.GetComponent<PlayerController2D>() : null;
            if (toIsland2)
            {
                IslandTravelManager.TravelToIsland2(pc);
            }
            else
            {
                IslandTravelManager.TravelToIsland1(pc);
            }
        }

        public bool CanInteract() => true;
    }
}
