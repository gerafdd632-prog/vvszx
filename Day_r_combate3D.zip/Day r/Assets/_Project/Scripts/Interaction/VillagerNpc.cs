﻿using System;
using UnityEngine;
using PirateSurvival.Core;
using PirateSurvival.Story;

namespace PirateSurvival.Interaction
{
    /// <summary>
    /// Aldeano o cartel con el que se habla con [E]. Cada interacción muestra la siguiente frase en el aviso de pantalla.
    /// Los aldeanos se balancean un poco para parecer vivos y miran hacia el jugador cuando les hablas.
    /// </summary>
    [RequireComponent(typeof(Collider2D))]
    public class VillagerNpc : MonoBehaviour, IInteractable
    {
        [SerializeField] private string displayName = "Aldeano";
        [SerializeField] private string[] lines = { "Hola, forastero." };
        [SerializeField] private bool isSign = false;
        [SerializeField] private Transform visual;

        private int next;
        private Func<Dialogue> dialogueProvider;

        /// <summary>Conversación con respuestas (caja de diálogo). Si no hay, se usan las frases sueltas.</summary>
        public void SetDialogue(Func<Dialogue> provider) => dialogueProvider = provider;
        private float phase;
        private Vector3 visualBase;

        public void Configure(string npcName, string[] dialogue, bool sign, Transform visualRoot)
        {
            displayName = npcName;
            lines = dialogue;
            isSign = sign;
            visual = visualRoot;
            if (visual != null) visualBase = visual.localPosition;
        }

        private void Awake()
        {
            phase = UnityEngine.Random.value * Mathf.PI * 2f;
            if (visual != null) visualBase = visual.localPosition;
        }

        private void Update()
        {
            if (isSign || visual == null) return;
            // Respiración: sube y baja 1 píxel muy despacio
            float bob = Mathf.Round(Mathf.Sin(Time.time * 2.2f + phase) * 0.5f + 0.5f) / 16f;
            visual.localPosition = visualBase + new Vector3(0f, bob, 0f);
        }

        public string GetPromptText()
        {
            return isSign ? "Pulsa [E] para leer el cartel" : $"Pulsa [E] para hablar con {displayName}";
        }

        public void Interact(PlayerInteraction2D interactor)
        {
            if (!isSign && visual != null && interactor != null)
            {
                SpriteRenderer face = visual.GetComponent<SpriteRenderer>();
                if (face != null) face.flipX = interactor.transform.position.x < transform.position.x;
            }

            if (dialogueProvider != null && DialogueUI.Instance != null)
            {
                Dialogue d = dialogueProvider();
                if (d != null)
                {
                    DialogueUI.Instance.Open(d);
                    return;
                }
            }

            if (lines == null || lines.Length == 0) return;
            string line = lines[next % lines.Length];
            next++;
            GameEvents.TriggerNotificationMessage(isSign ? line : $"{displayName}: «{line}»");
        }

        public bool CanInteract() => true;
    }
}
