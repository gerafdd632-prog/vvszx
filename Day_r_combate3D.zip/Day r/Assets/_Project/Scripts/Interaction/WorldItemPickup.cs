﻿using System.Collections.Generic;
using UnityEngine;
using PirateSurvival.Core;
using PirateSurvival.Inventory;

namespace PirateSurvival.Interaction
{
    /// <summary>
    /// Objeto coleccionable 2D en el suelo (cocos, madera, piedra, objetos tirados).
    /// Utiliza Collider2D y Rigidbody2D opcional para impulsos de soltado.
    /// Soporta recogida parcial segura, despawn tras N minutos y fusión de objetos cercanos (Punto 13).
    /// </summary>
    [RequireComponent(typeof(Collider2D))]
    public class WorldItemPickup : MonoBehaviour, IInteractable
    {
        [Header("Datos del Objeto")]
        [SerializeField] private ItemData itemData;
        [SerializeField] private int quantity = 1;

        [Header("Despawn y Fusión (Punto 13)")]
        [Tooltip("Tiempo en minutos antes de que el objeto desaparezca del suelo (0 para desactivar)")]
        [SerializeField] private float despawnMinutes = 10f;
        [Tooltip("Radio para buscar otros objetos idénticos y fusionarse")]
        [SerializeField] private float mergeRadius = 1.2f;
        [Tooltip("Intervalo en segundos entre chequeos de fusión")]
        [SerializeField] private float mergeCheckInterval = 2.5f;

        [Header("Efectos Opcionales")]
        [SerializeField] private AudioClip pickupSound;
        [SerializeField] private GameObject pickupEffectPrefab;

        private float despawnTimer;
        private float nextMergeCheckTime;
        private bool destroying = false;

        // Id propio para romper simetría al fusionar (GetInstanceID está obsoleto en Unity 6.5+)
        private static int s_NextMergeOrder;
        private readonly int mergeOrder = System.Threading.Interlocked.Increment(ref s_NextMergeOrder);

        private static readonly List<Collider2D> s_MergeResults = new List<Collider2D>(16);
        private static readonly ContactFilter2D s_MergeFilter = CreateMergeFilter();

        private static ContactFilter2D CreateMergeFilter()
        {
            ContactFilter2D f = new ContactFilter2D();
            f.NoFilter();
            return f;
        }

        public ItemData ItemData => itemData;
        public int Quantity => quantity;
        /// <summary>Los objetos importantes (y toda Fruta del Diablo) no tienen despawn.</summary>
        public bool IsPersistent => itemData != null && (itemData.neverDespawn || itemData.itemType == ItemType.DevilFruit);
        /// <summary>Segundos hasta desaparecer (0 si es persistente o no tiene despawn).</summary>
        public float RemainingDespawnSeconds => IsPersistent || despawnMinutes <= 0f ? 0f : Mathf.Max(0f, despawnTimer);

        /// <summary>Restaura el temporizador guardado (valores <= 0 dejan el temporizador completo).</summary>
        public void SetRemainingDespawnSeconds(float seconds)
        {
            if (seconds > 0f) despawnTimer = Mathf.Min(seconds, despawnMinutes * 60f);
        }

        private void Awake()
        {
            despawnTimer = despawnMinutes * 60f;
            nextMergeCheckTime = Time.time + Random.Range(1f, 2.5f);
        }

        private void Update()
        {
            if (destroying) return;

            // 1. Temporizador de Despawn
            if (despawnMinutes > 0f && !IsPersistent)
            {
                despawnTimer -= Time.deltaTime;
                if (despawnTimer <= 0f)
                {
                    destroying = true;
                    Destroy(gameObject);
                    return;
                }
            }

            // 2. Fusión periódica con pickups idénticos cercanos
            if (Time.time >= nextMergeCheckTime)
            {
                nextMergeCheckTime = Time.time + mergeCheckInterval;
                TryMergeWithNearby();
            }
        }

        private void TryMergeWithNearby()
        {
            if (itemData == null || quantity <= 0 || destroying) return;
            if (quantity >= itemData.maxStackSize) return;

            int hits = Physics2D.OverlapCircle(transform.position, mergeRadius, s_MergeFilter, s_MergeResults);
            for (int i = 0; i < hits; i++)
            {
                Collider2D col = s_MergeResults[i];
                if (col == null || col.gameObject == gameObject) continue;

                WorldItemPickup otherPickup = col.GetComponent<WorldItemPickup>();
                if (otherPickup == null || otherPickup.destroying) continue;

                // Solo fusionar si tienen el mismo itemId y el otro no se está destruyendo
                if (otherPickup.itemData != null && otherPickup.itemData.itemId == itemData.itemId)
                {
                    // Romper simetría: el objeto creado antes absorbe al creado después
                    if (mergeOrder > otherPickup.mergeOrder) continue;

                    int space = itemData.maxStackSize - quantity;
                    if (space <= 0) break;

                    int transfer = Mathf.Min(space, otherPickup.quantity);
                    quantity += transfer;
                    otherPickup.quantity -= transfer;

                    // Reiniciar temporizador de despawn al recibir objetos nuevos
                    despawnTimer = despawnMinutes * 60f;

                    if (otherPickup.quantity <= 0)
                    {
                        otherPickup.destroying = true;
                        Destroy(otherPickup.gameObject);
                    }
                }
            }
        }

        public void Configure(ItemData data, int count)
        {
            itemData = data;
            quantity = Mathf.Max(1, count);
            despawnTimer = despawnMinutes * 60f;
        }

        public string GetPromptText()
        {
            if (itemData == null) return "Recoger";
            return $"Pulsa [E] para recoger {itemData.itemName} x{quantity}";
        }

        public void Interact(PlayerInteraction2D interactor)
        {
            if (itemData == null || quantity <= 0 || destroying) return;

            // Recogida atómica/parcial según capacidad
            int added = InventoryManager.Instance.TryAddPartial(itemData, quantity);

            if (added > 0)
            {
                if (pickupEffectPrefab != null)
                {
                    Instantiate(pickupEffectPrefab, transform.position, Quaternion.identity);
                }

                if (pickupSound != null)
                {
                    AudioSource.PlayClipAtPoint(pickupSound, transform.position);
                }

                quantity -= added;

                if (quantity <= 0)
                {
                    destroying = true;
                    Destroy(gameObject);
                }
            }
            else
            {
                GameEvents.TriggerNotificationMessage("¡Inventario lleno o sobrecargado!");
                Debug.LogWarning("[Pickup] No se puede recoger: peso máximo alcanzado o sin casillas disponibles.");
            }
        }

        public bool CanInteract()
        {
            return itemData != null && quantity > 0 && !destroying;
        }

        private void OnDestroy()
        {
            destroying = true;
        }
    }
}
