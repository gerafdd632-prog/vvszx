﻿namespace PirateSurvival.Interaction
{
    /// <summary>
    /// Interfaz para cualquier entidad u objeto en el mundo 2D con el que el jugador puede interactuar.
    /// </summary>
    public interface IInteractable
    {
        /// <summary>
        /// Texto descriptivo que se mostrará en pantalla (ej: "Pulsa [E] para Recoger Coco")
        /// </summary>
        string GetPromptText();

        /// <summary>
        /// Lógica ejecutada al pulsar la tecla de interacción en 2D
        /// </summary>
        void Interact(PlayerInteraction2D interactor);

        /// <summary>
        /// Indica si la interacción está habilitada en este momento
        /// </summary>
        bool CanInteract();
    }
}
