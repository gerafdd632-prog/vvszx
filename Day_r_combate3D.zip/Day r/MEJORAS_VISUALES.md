# Mejoras visuales, isla nueva y sed

Revisión estática solamente: no se ha compilado ni probado en Unity.

## 1. Beber agua (antes parecía que no funcionaba)
- La partida empezaba con la sed al 100 %. Beber subía la barra solo unas décimas, así que parecía que no hacía nada.
- Ahora la partida nueva empieza con sed 55. Sale una pista: "busca la charca de agua dulce al noroeste y pulsa [E]".
- Al beber aparece "Bebes agua dulce. Sed 55 → 80".
- Con la sed casi llena, el aviso dice "ahora no tienes sed" en vez de "Pulsa E".
- El agua de mar avisa de que da más sed y hace daño.
- Los avisos largos se quedan más tiempo en pantalla.
- Hay agua dulce en la charca y en el pozo de la aldea.

## 2. Gráficos
- Personajes, casas, árboles, vallas, pozo, barriles, cofre e iconos vienen de los packs Tiny Town y Tiny Dungeon de Kenney (CC0).
- Palmeras, rocas, barco, naufragio, tienda, hoguera, agua y suelo están dibujados en el mismo estilo de pixel art.
- Las imágenes están en `Assets/_Project/Resources/Sprites/` con sus `.meta`: Point, sin compresión y 16 px por unidad.
- Si falta una imagen, el juego la dibuja por código (`GameSprites` + `WorldArt` / `CharacterArt`).
- `Editor/PixelArtImporter.cs` aplica los mismos ajustes a cualquier imagen nueva de esa carpeta.
- El mar está animado.
- Hogueras y antorchas tienen llama animada y halo de luz. La hoguera del campamento da calor y seca la ropa.
- El protagonista es un diseño propio: náufrago con camisa clara.

## 3. Isla inicial (unas 4 veces más grande)
- **Playa del naufragio** (sur): punto de inicio, hoguera, tienda, bote, restos del barco, pico y cocos.
- **Charca de agua dulce**: la Abuela Marea vive al lado.
- **Aldea Coral** (centro-este):
  - 6 casas, plaza con pozo, farolas, puesto del mercader, vallas, colmena y cartel.
  - 4 aldeanos con los que se habla con [E]: Alcaldesa Coral, Tico, Ramón y Bruno.
- **Cueva del Eco** (noroeste):
  - Pared de roca con una sola entrada.
  - Dentro está oscuro (solo se ve un círculo alrededor del jugador) y se está a cubierto de la lluvia.
  - Tiene vetas brillantes (más piedra), antorchas, estalagmitas, murciélagos, una araña, un cofre, la botella y la Fruta del Diablo.
- **Bosque** al oeste, con setas y árboles talables (dan madera).
- **Muelle** (norte):
  - Se camina por él sin nadar.
  - Allí está atracado el barco del Capitán Cuervo, y el jefe espera en la entrada del muelle.
- **Campamento pirata** (playa este): el primer combate.
- Hay puntos de agua de mar en varias orillas.
- Los ids de los combates (`piratas_playa`, `capitan_cuervo`) no cambian, así que las partidas guardadas siguen funcionando.

## 4. Combate
- El suelo depende del lugar: arena en la playa, hierba en el bosque, tablones en la cubierta.
- Cada casilla muestra su objeto: roca, árbol, arbusto, barril, barril de pólvora, caja, mástil, restos o fuego animado.
- El tablero tiene marco de madera y rejilla suave, sobre un fondo de mar.
- Unidades:
  - Llevan sombra y respiran; la del turno activo bota más.
  - Se deslizan al moverse, embisten al atacar y tiemblan al recibir daño.
  - Los enemigos miran hacia el jugador.
- Cada tipo de enemigo tiene su propio sprite: piratas, marines, el Capitán Cuervo y el usuario de fruta de fuego.

## Archivos nuevos
- Core: `GameSprites`, `PixelCanvas`, `CharacterArt`, `SpritePivots` (generado)
- Bootstrap: `IslandLayout`, `IslandBuilder`, `IslandPlacements` (generado), `WorldArt`
- Environment: `WaterScroller`, `Campfire`, `CaveZone`, `CaveDarkness`, `IdleCritter`
- Interaction: `VillagerNpc`
- Combat/UI: `BattleArt`
- Editor: `PixelArtImporter`
- `Tools/island_designer/`: script de Python que genera el suelo, las imágenes y las posiciones. Está fuera de Assets.
