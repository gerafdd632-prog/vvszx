﻿# Cambios

## Bugs arreglados
- **No compilaba**: `InventorySlotUI` llamaba a `SwapSlots` (no existe) -> `SwapOrCombineSlots`.
- **No se podía interactuar con nada**: el filtro de `PlayerInteraction2D` excluía la capa Default (donde está todo el mundo).
- **Barras de vida/hambre/sed/energía no bajaban**: `Image` en modo Filled sin sprite ignora `fillAmount`.
- **Cartel "Pulsa [E]" desaparecía para siempre**: el script estaba en el mismo objeto que se desactivaba. Ahora va en un contenedor aparte.
- **Marco de "equipado" tapaba el icono** en el inventario (ahora va detrás).
- **Mar**: 4 rectángulos dejaban esquinas de agua sin ahogamiento; ahora un solo anillo alrededor de la isla.
- **Herramienta en mano** quedaba detrás de árboles/rocas al andar cerca (ahora hereda el orden del jugador).
- **Cargar partida desmayado** dejaba al jugador girado/rojo como muerto.
- Fusión de objetos del suelo usaba API obsoleta (`OverlapCircleNonAlloc`).
- Etiquetas de las barras salían debajo de la barra; textos del cartel se salían del fondo.
- Tooltip podía salirse de la pantalla; hover de casillas buscaba el `InventoryUI` cada vez.
- Iconos de herramientas/objetos son ahora formas reconocibles.
- Lluvia dibujada por encima de todo; singletons limpiados al destruirse.

## Menús nuevos (todo creado por código, sin montaje en el editor)
- **Menú principal**: Continuar (partida más reciente), Nueva Partida, Cargar Partida, Opciones, Salir.
- **Pausa (ESC)**: Reanudar, Guardar, Cargar, Opciones, Menú Principal, Salir. Congela el tiempo.
- **3 ranuras de guardado** con fecha, hora de juego y salud; sobrescribir/borrar con confirmación.
- **Opciones**: volumen, pantalla completa, calidad (se recuerdan) + lista de controles.
- **Pantalla de muerte**: Reaparecer, Cargar (desactivado si no hay partidas), Menú Principal.
- HUD, inventario y avisos rediseñados. ESC cierra el inventario antes de abrir la pausa.

Archivos nuevos: `Core/GameState.cs`, `UI/UIFactory.cs`, `UI/MenuManager.cs`, `Bootstrap/GameUIBuilder.cs`.

## Combate táctico — fases C1 + C2 (primer combate completo)
- **Entrada**: dos piratas acampados en la playa sureste. Si te acercas (radio 2.6) te detectan y se abre el combate. Se pueden evitar rodeándolos.
- **Modo combate** (`GameScreen.Battle`): el mundo se congela, se abre un tablero propio (11x7) con la arena de playa: rocas (bloquean paso y disparos), restos de barco (cobertura -30% contra disparos) y mar en un extremo.
- **Turnos y AP**: tú 6 AP, piratas 5 AP. Orden por velocidad. Mover 1 AP/casilla (8 direcciones, pathfinding), atacar = AP del arma, golpe fuerte +1 AP y 12 de energía (x1.6 daño, -20% precisión), defender 2 AP (mitad de daño), objeto 2 AP, cambiar arma 1 AP.
- **Armas**: puños, hacha, pico y sable con daño, AP, alcance, precisión y crítico propios (campos `combat*` en `ItemData`). El sable es barato y preciso; el hacha pega más pero cuesta 3 AP y falla más.
- **IA distinta**: Pirata Bruto (`MeleeAI`) va directo a por ti y se cubre si está muy herido. Pirata Tirador (`RangedAI`) dispara a 2-6 casillas, pierde precisión con la distancia, recarga tras cada disparo, busca cobertura y retrocede si te pegas a él.
- **Interfaz** (`BattleUI`): enemigo seleccionado arriba, AP/vida/energía/arma/acciones/objetos abajo. Casillas alcanzables en azul con su coste, alcance en naranja, objetivos en rojo con % de impacto, daño estimado y descripciones al pasar el ratón.
- **Supervivencia conectada**: la vida, energía, objetos y arma son los reales. Cada ronda cuesta algo de hambre y sed. Las heridas se quedan al terminar.
- **Victoria**: experiencia, botín (sable si no lo tienes, coco, a veces agua) y resumen de daños. El encuentro queda derrotado y se guarda.
- **Derrota**: la pantalla de muerte de siempre.
- **Guardado**: no se puede guardar durante el combate ("No puedes guardar durante un combate."), tampoco se autoguarda. Se guarda la experiencia y los enemigos únicos derrotados. ESC abre la pausa encima del combate.

## Combate táctico — fases C3, C4 y C5
- **Fruta del Diablo (C3)**: la "Fruta Elástica" está escondida en la isla (oeste). Al comerla (clic en el inventario) ganas 3 habilidades: Puñetazo Extensible (3 AP, alcance 4 en línea, pasa por encima de obstáculos bajos, empuja), Golpe Circular (4 AP, área alrededor, mucha energía) e Impulso Elástico (2 AP, desplazamiento hasta 4 casillas). Cada una tiene coste de energía y recarga. Cuerpo de goma: golpes y balas te hacen la mitad. Precio: en el mar te ahogas 3 veces más rápido y en combate la orilla te debilita.
- **Estados alterados (C4)**: sangrado, quemadura, veneno, aturdido, mojado, exhausto, derribado, confundido, inmovilizado, debilidad al mar, Kairoseki, Haki reforzado y fruta bloqueada. Tienen duración, intensidad, acumulación, efecto por turno, icono y descripción (`StatusEffectSystem`).
- **Escenario (C4)**: barriles (cobertura destructible), barriles de pólvora (explotan en cadena y dejan fuego), cajas, árboles, fuego (quema), orilla (2 AP, moja), arbustos y mar profundo. Empujar a un enemigo al mar lo saca del combate; si caes tú con Fruta, pierdes mucha vida.
- **IA avanzada (C4)**: el tirador dispara a barriles de pólvora junto a ti. Nuevas IA: espadachín (guardia + contraataque), Marine con fusil (fuego concentrado), Marine con escudo, jefe con dos fases y técnicas propias. Plantillas en `EnemyLibrary` (incluido Marine de élite con Kairoseki y un usuario Logia de fuego, para islas futuras).
- **Jefe opcional**: Capitán Cuervo + espadachín + tirador en la costa norte, combate en la cubierta de un barco. No se puede huir.
- **Haki (C5)**: Observación, Armadura y Rey listos en `HakiManager` + `AbilityLibrary`, BLOQUEADOS hasta que se desbloqueen con `HakiManager.Unlock`. El del Rey solo aturde a enemigos débiles y una vez por combate.
- **Kairoseki (C5)**: armas con `kairoseki` bloquean poderes, quitan AP y reducen el daño de usuarios de Fruta. Los Logia solo reciben daño con Haki, Kairoseki o mojados.
- **Tripulación (C5)**: `CrewManager` + `CrewMemberData` (vida, equipo, rol, control por jugador o IA, persistente). Vacía de momento; cuando haya miembros salen en el tablero y se controlan por turnos.
- **Supervivencia**: huir (3 AP, desde un borde), durabilidad de armas (se rompen), vendas (curan sangrado), sangrado y veneno que siguen tras el combate (`PlayerWounds`), recompensa en berries.
- **Guardado**: Fruta, Haki, heridas, recompensa, durabilidad y tripulación.

Pendiente: munición para el jugador (el sistema existe: `ammoItemId`), médicos/descanso, más islas y enemigos colocados.
